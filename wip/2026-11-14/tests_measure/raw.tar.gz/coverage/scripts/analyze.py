"""Coverage part, analysis: reads data/<module>/.coverage.* (arcs per static|dynamic context) and the tree's workbench/, and
writes per-source, per-test-module, per-test, never-executed and line-map JSON next to this script's parent folder.
usage: analyze.py W"""
import ast, collections, json, re, sqlite3, sys, time
from pathlib import Path

W = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(W / 'lib'))
import coverage
from coverage.python import PythonFileReporter
from coverage.results import analysis_from_file_reporter

TREE = W / 'tree'; WB = TREE / 'workbench'; DATA = W / 'data'
run = json.loads((W / 'run_results.json').read_text())
MODULES = [m for m in run if (DATA / m).is_dir()]
MODULES.sort()
MI = {m: i for i, m in enumerate(MODULES)}
FOCUSED = set(MODULES) - {'test_exact_math_solvers'}
t0 = time.time()

# ---- read raw arcs: per module per file (union), per test context per file
mod_arcs = {m: collections.defaultdict(set) for m in MODULES}          # module -> abs path -> raw arcs
test_arcs = {}                                                         # 'module|Class.test' -> abs path -> raw arcs
for m in MODULES:
    for f in sorted((DATA / m).glob('.coverage*')):
        con = sqlite3.connect(str(f))
        paths = dict(con.execute('select id, path from file'))
        ctxs = dict(con.execute('select id, context from context'))
        for fid, cid, a, b in con.execute('select file_id, context_id, fromno, tono from arc'):
            p = paths[fid]; arc = (a, b)
            mod_arcs[m][p].add(arc)
            c = ctxs[cid]
            if '|' in c and c.split('|', 1)[1].startswith('tests_integrated.'):
                test_arcs.setdefault(c, collections.defaultdict(set))[p].add(arc)
        con.close()
print('read', round(time.time() - t0, 1), 'tests with contexts', len(test_arcs), flush=True)

# ---- parse every workbench source file once
cov = coverage.Coverage(config_file=False, branch=True, data_file=None)


class OneFile:
    def __init__(self, arcs): self._arcs = arcs
    def has_arcs(self): return True
    def lines(self, filename): return {l for a in self._arcs for l in a if l > 0}
    def arcs(self, filename): return self._arcs


class Cached:
    def __init__(self, fr):
        self.fr = fr; self._l = fr.lines(); self._x = fr.excluded_lines(); self._a = fr.arcs(); self._e = fr.exit_counts()
        self._n = fr.no_branch_lines()
    def lines(self): return self._l
    def excluded_lines(self): return self._x
    def arcs(self): return self._a
    def exit_counts(self): return self._e
    def no_branch_lines(self): return self._n
    def translate_lines(self, lines): return self.fr.translate_lines(lines)
    def translate_arcs(self, arcs): return self.fr.translate_arcs(arcs)


SOURCES = sorted(str(p) for p in WB.rglob('*.py'))
reporters = {}; meta = {}
for p in SOURCES:
    fr = PythonFileReporter(p, cov)
    try:
        st = fr.lines(); fr.arcs(); fr.exit_counts()
    except Exception as exc:  # unparsable
        meta[p] = {'error': repr(exc)}; continue
    reporters[p] = Cached(fr)
print('parsed', len(reporters), round(time.time() - t0, 1), flush=True)


def analyse(p, arcs):
    a = analysis_from_file_reporter(OneFile(arcs), 2, reporters[p], p)
    branch_lines = {l for l, c in a.exit_counts.items() if c > 1}
    covered_branches = {x for x in a.arcs_executed_set if x[0] in branch_lines and x in a.arc_possibilities_set}
    return a, covered_branches


rel = lambda p: str(Path(p).relative_to(TREE))
# statements inside function bodies (run only when called) vs module/class level (run on import)
BODY = {}
for p, fr in reporters.items():
    try: tr = ast.parse(Path(p).read_text(errors='replace'))
    except Exception: BODY[p] = set(); continue
    spans = [(n.body[0].lineno, n.end_lineno) for n in ast.walk(tr) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
    st = fr.lines(); b = set()
    for a, z in spans: b |= {l for l in st if a <= l <= z}
    BODY[p] = b
empty = {p: analyse(p, set())[0] for p in reporters}

# ---- per module per file: covered statements and covered branch arcs
mod_lines = {m: {} for m in MODULES}; mod_br = {m: {} for m in MODULES}; mod_nums = {}
for m in MODULES:
    stl = sbr = stb = 0
    for p, arcs in mod_arcs[m].items():
        if p not in reporters or not arcs: continue
        a, cb = analyse(p, arcs)
        if a.executed: mod_lines[m][p] = a.executed
        if cb: mod_br[m][p] = cb
        stl += len(a.executed); sbr += a.numbers.n_branches - a.numbers.n_missing_branches
    mod_nums[m] = {'lines': stl, 'branches_coverage_counted': sbr}
print('modules analysed', round(time.time() - t0, 1), flush=True)

# ---- per test
TESTS = sorted(test_arcs)
TI = {t: i for i, t in enumerate(TESTS)}
test_lines = {}
for t in TESTS:
    d = {}
    for p, arcs in test_arcs[t].items():
        if p not in reporters: continue
        fr = reporters[p]
        ex = fr.translate_lines({l for a in arcs for l in a if l > 0}) & fr.lines()
        if ex: d[p] = ex
    test_lines[t] = d
print('tests analysed', round(time.time() - t0, 1), flush=True)

# ---- line map and union
line_mods = {}                                   # p -> line -> set(module idx)
br_mods = {}                                     # p -> arc -> set(module idx)
for m in MODULES:
    for p, ls in mod_lines[m].items():
        d = line_mods.setdefault(p, {})
        for l in ls: d.setdefault(l, set()).add(MI[m])
    for p, bs in mod_br[m].items():
        d = br_mods.setdefault(p, {})
        for b in bs: d.setdefault(b, set()).add(MI[m])
line_tests = {}
for t, d in test_lines.items():
    for p, ls in d.items():
        x = line_tests.setdefault(p, {})
        for l in ls: x.setdefault(l, set()).add(TI[t])

FOC_IDX = {MI[m] for m in FOCUSED}

# ---- (1) per source module
per_source = {}
tot = collections.Counter()
for p in SOURCES:
    r = rel(p)
    if p not in reporters:
        per_source[r] = meta[p]; continue
    e = empty[p]
    n_st = len(e.statements); n_br = e.numbers.n_branches
    union_arcs = set().union(*[mod_arcs[m].get(p, set()) for m in MODULES])
    ua, ucb = analyse(p, union_arcs)
    foc_arcs = set().union(*[mod_arcs[m].get(p, set()) for m in FOCUSED])
    fa, _ = analyse(p, foc_arcs)
    covering = {m: len(mod_lines[m][p]) for m in MODULES if p in mod_lines[m]}
    lm = line_mods.get(p, {})
    only = collections.Counter(next(iter(s)) for s in lm.values() if len(s) == 1)
    per_source[r] = {
        'statements': n_st, 'covered_lines': len(ua.executed), 'covered_lines_focused': len(fa.executed),
        'line_pct': round(100 * len(ua.executed) / n_st, 1) if n_st else None,
        'branches': n_br, 'covered_branches': n_br - ua.numbers.n_missing_branches,
        'covered_branches_focused': n_br - fa.numbers.n_missing_branches,
        'branch_pct': round(100 * (n_br - ua.numbers.n_missing_branches) / n_br, 1) if n_br else None,
        'body_statements': len(BODY[p]), 'covered_body_lines': len(ua.executed & BODY[p]),
        'covering_modules': dict(sorted(covering.items(), key=lambda kv: -kv[1])),
        'lines_covered_by_one_module_only': {MODULES[i]: n for i, n in only.most_common()},
        'source_lines': sum(1 for _ in open(p, encoding='utf-8', errors='replace')),
    }
    tot['statements'] += n_st; tot['covered_lines'] += len(ua.executed); tot['covered_lines_focused'] += len(fa.executed)
    tot['branches'] += n_br; tot['covered_branches'] += n_br - ua.numbers.n_missing_branches
    tot['covered_branches_focused'] += n_br - fa.numbers.n_missing_branches
    tot['files'] += 1; tot['files_executed'] += bool(ua.executed)
    tot['body_statements'] += len(BODY[p]); tot['covered_body_lines'] += len(ua.executed & BODY[p])
    tot['covered_body_lines_focused'] += len(fa.executed & BODY[p]); tot['files_with_a_body_line_run'] += bool(ua.executed & BODY[p])
print('per source', round(time.time() - t0, 1), flush=True)

# ---- (2) per test module: unique lines/branches
per_module = {}
for m in MODULES:
    i = MI[m]
    uniq_l = {}; uniq_l_foc = 0; uniq_b = 0
    for p, ls in mod_lines[m].items():
        u = [l for l in ls if line_mods[p][l] == {i}]
        if u: uniq_l[rel(p)] = sorted(u)
    uniq_l_foc_total = 0
    if m in FOCUSED:
        for p, ls in mod_lines[m].items():
            uniq_l_foc_total += sum(1 for l in ls if not ((line_mods[p][l] & FOC_IDX) - {i}))
    for p, bs in mod_br[m].items():
        uniq_b += sum(1 for b in bs if br_mods[p][b] == {i})
    tests_ctx = [t for t in TESTS if t.startswith(m + '|')]
    r = run[m]
    per_module[m] = {
        'index': i, 'focused': m in FOCUSED, 'tests': r.get('tests'), 'tests_with_workbench_lines': len(tests_ctx),
        'skipped': r.get('skipped'), 'failing_under_coverage': r.get('bad'), 'failing_baseline': r.get('bad_base'),
        'seconds_baseline': r.get('seconds_base'), 'seconds_under_coverage': r.get('seconds_cov'),
        'covered_lines': mod_nums[m]['lines'], 'covered_branches': sum(len(b) for b in mod_br[m].values()),
        'files_touched': len(mod_lines[m]),
        'covered_body_lines': sum(len(ls & BODY[p]) for p, ls in mod_lines[m].items()),
        'unique_body_lines': sum(1 for p, ls in mod_lines[m].items() for l in ls & BODY[p] if line_mods[p][l] == {i}),
        'unique_lines': sum(len(v) for v in uniq_l.values()),
        'unique_lines_among_focused': uniq_l_foc_total if m in FOCUSED else None,
        'unique_branches': uniq_b,
        'unique_lines_by_file': {k: v for k, v in sorted(uniq_l.items(), key=lambda kv: -len(kv[1]))},
    }
body_sets = {m: {(p, l) for p, ls in mod_lines[m].items() for l in ls & BODY[p]} for m in MODULES}
for m in MODULES:
    b = body_sets[m]
    if not b: per_module[m]['body_contained_in_best_single_other'] = None; continue
    pct, other = max((len(b & body_sets[o]) / len(b), o) for o in MODULES if o != m)
    per_module[m]['body_contained_in_best_single_other'] = {'module': other, 'pct': round(100 * pct, 1)}
print('per module', round(time.time() - t0, 1), flush=True)

# ---- per test: lines, unique lines (no other test anywhere), unique within its module
per_test = {}
for t in TESTS:
    i = TI[t]; m = t.split('|')[0]; mi = MI[m]
    n = sum(len(v) for v in test_lines[t].values())
    u = sum(1 for p, ls in test_lines[t].items() for l in ls if line_tests[p][l] == {i})
    # lines no other module covers and no other test of this module covers
    um = sum(1 for p, ls in test_lines[t].items() for l in ls
             if line_mods[p][l] == {mi} and not any(TESTS[j].startswith(m + '|') and j != i for j in line_tests[p][l]))
    refs_u = sorted('%s:%d' % (rel(p), l) for p, ls in test_lines[t].items() for l in ls if line_tests[p][l] == {i})
    nb = sum(len(ls & BODY.get(p, set())) for p, ls in test_lines[t].items())
    per_test[t] = {'lines': n, 'body_lines': nb, 'unique_lines': u, 'unique_lines_suite_wide_via_module': um,
                   'unique_line_refs': refs_u[:60]}

# tests run but with no workbench line in their own context (setUp/setUpClass lines go to the module context only)
log_tests = {}
for m in MODULES:
    text = (W / 'logs' / (m + '.log')).read_text(errors='replace')
    bad = set(re.findall(r'^(?:FAIL|ERROR): \S+ \(([\w.]+)\)', text, re.M))
    for name, tid, rest in re.findall(r'^(test\w*) \(([\w.]+)\)(.*)$', text, re.M):
        tid = tid if tid.endswith('.' + name) else tid + '.' + name
        log_tests[m + '|' + tid] = 'skipped' if '... skipped' in rest else ('FAIL' if tid in bad else 'ok')
no_lines = sorted(t for t in log_tests if t not in test_lines and not log_tests[t].startswith('skipped'))
skipped = sorted(t for t in log_tests if log_tests[t].startswith('skipped'))

# ---- greedy set cover: modules by new lines per second (baseline seconds), and tests by new lines
def greedy(cands, cover, cost):
    import heapq
    got = set(); order = []; total = len(set().union(*cands.values())) if cands else 0
    heap = [(-len(v) / max(cost(k), 0.05), k) for k, v in cands.items()]; heapq.heapify(heap)
    while heap:
        g, k = heapq.heappop(heap)
        new = cands[k] - got
        if not new: continue
        gain = -len(new) / max(cost(k), 0.05)
        if heap and gain > heap[0][0]:
            heapq.heappush(heap, (gain, k)); continue
        got |= new; order.append({'item': k, 'new_lines': len(new), 'cum_lines': len(got),
                                  'cum_pct': round(100 * len(got) / total, 2), 'cost': cost(k)})
    return order, total

mod_sets = {m: {(p, l) for p, ls in mod_lines[m].items() for l in ls & BODY[p]} for m in FOCUSED}  # function-body lines
mod_order, mod_total = greedy(mod_sets, None, lambda m: run[m].get('seconds_base') or 0.1)
c = 0
for row in mod_order: c += row['cost']; row['cum_seconds'] = round(c, 1)
test_sets = {t: {(p, l) for p, ls in d.items() for l in ls & BODY[p]} for t, d in test_lines.items() if t.split('|')[0] in FOCUSED}
test_order, test_total = greedy(test_sets, None, lambda t: 1)
print('greedy', round(time.time() - t0, 1), flush=True)

# ---- (3) never executed: modules, and functions in executed modules
def py_files(root):
    for p in root.rglob('*'):
        if p.is_file() and p.suffix in ('.py', '.sh', '.cmd', '.json', '.desktop', '.service', '.txt', '.toml', '.cfg', '.ini', '.qml', '.spec'):
            yield p

TOKEN = re.compile(r'[A-Za-z_][A-Za-z0-9_]*')
token_count = collections.Counter(); token_files = collections.defaultdict(set)
texts = {}
for f in py_files(TREE):
    if f.stat().st_size > 3_000_000: continue
    try: s = f.read_text(errors='replace')
    except Exception: continue
    texts[str(f)] = s
    for tok in TOKEN.findall(s):
        token_count[tok] += 1; token_files[tok].add(str(Path(f).relative_to(TREE)))

executed_files = {rel(p) for p in reporters if line_mods.get(p)}


def module_name(p):
    r = Path(p).relative_to(TREE).with_suffix('')
    parts = list(r.parts)
    if parts[-1] == '__init__': parts = parts[:-1]
    return '.'.join(parts)


# who references each workbench module: imports (absolute/relative) and dotted/slashed names in any text
refs = collections.defaultdict(set); imps = collections.defaultdict(set)
for f, s in texts.items():
    rf = str(Path(f).relative_to(TREE))
    if f.endswith('.py'):
        try: tree = ast.parse(s)
        except Exception: tree = None
        if tree is not None:
            pkg = module_name(f).rsplit('.', 1)[0] if Path(f).name != '__init__.py' else module_name(f)
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for a in node.names: imps[a.name].add(rf)
                elif isinstance(node, ast.ImportFrom):
                    base = node.module or ''
                    if node.level:
                        up = pkg.split('.')
                        up = up[:len(up) - (node.level - 1)] if node.level > 1 else up
                        base = '.'.join(up + ([base] if base else []))
                    imps[base].add(rf)
                    for a in node.names: imps[(base + '.' + a.name) if base else a.name].add(rf)
                elif isinstance(node, ast.Constant) and isinstance(node.value, str) and 'workbench' in node.value:
                    for mm in re.findall(r'workbench[./][\w./]+', node.value):
                        mm = mm.replace('/', '.').removesuffix('.py').rstrip('.'); refs[mm].add(rf)
    for mm in re.findall(r'workbench[./][\w./]+', s):
        mm = mm.replace('/', '.').removesuffix('.py').rstrip('.'); refs[mm].add(rf)

never_modules = []
for p in reporters:
    if line_mods.get(p): continue
    name = module_name(p); r = rel(p); e = empty[p]
    gather = lambda d: sorted(x for x in (d.get(name, set()) | {y for k, v in d.items() if k.startswith(name + '.') for y in v}) if x != r)
    imported_by = gather(imps); mentioned_by = [x for x in gather(refs) if x not in imported_by]
    imp_wb = [x for x in imported_by if x.startswith('workbench/')]
    imp_exec = [x for x in imp_wb if x in executed_files]
    code_mentions = [x for x in mentioned_by if x.endswith(('.py', '.sh', '.cmd', '.desktop', '.service'))]
    src = texts.get(p, '')
    entry = "__name__" in src and "__main__" in src
    if imp_exec: verdict = 'imported (lazily) by executed workbench code, on a path no test takes: untested'
    elif imp_wb: verdict = 'imported only by workbench modules that are themselves never executed: dead chain or untested'
    elif imported_by: verdict = 'imported only outside workbench (tools, sdk, root scripts, tests)'
    elif code_mentions: verdict = 'never imported; named in code as a path or -m target (launched or listed by name)'
    else: verdict = 'never imported and named in no code (at most in MANIFEST/docs data): likely dead'
    who = imported_by + mentioned_by
    never_modules.append({'file': r, 'statements': len(e.statements), 'source_lines': per_source[r]['source_lines'],
                          'branches': e.numbers.n_branches, 'has_main': entry, 'imported_by': imported_by[:25],
                          'named_in_code': code_mentions[:15], 'named_elsewhere': [x for x in mentioned_by if x not in code_mentions][:10],
                          'verdict': verdict})
never_modules.sort(key=lambda x: -x['statements'])

QT_HOOKS = re.compile(r'^(paintEvent|resizeEvent|mouse\w*Event|key\w*Event|wheelEvent|enterEvent|leaveEvent|focus\w*Event|'
                      r'showEvent|hideEvent|closeEvent|changeEvent|timerEvent|event|eventFilter|contextMenuEvent|drag\w*Event|'
                      r'drop\w*Event|moveEvent|sizeHint|minimumSizeHint|hasHeightForWidth|heightForWidth|rowCount|columnCount|'
                      r'data|setData|headerData|flags|index|parent|roleNames|run|paint|boundingRect|shape|createEditor|'
                      r'setEditorData|setModelData|updateEditorGeometry|inputMethod\w*|tabletEvent|actionEvent|nativeEvent|'
                      r'initStyleOption|sizeFromContents|drawControl|drawPrimitive|pixelMetric|styleHint|polish|unpolish|'
                      r'validate|fixup|canFetchMore|fetchMore|mimeData|mimeTypes|supportedDropActions|filterAcceptsRow|lessThan|'
                      r'do_\w+|handle|setUp|tearDown|highlightBlock)$')
never_functions = []; func_totals = collections.Counter()
for p, fr in reporters.items():
    lm = line_mods.get(p)
    if not lm: continue
    r = rel(p); st = empty[p].statements
    try: tree = ast.parse(texts.get(p) or Path(p).read_text(errors='replace'))
    except Exception: continue
    stack = [(tree, '')]
    while stack:
        node, prefix = stack.pop()
        for ch in ast.iter_child_nodes(node):
            if isinstance(ch, (ast.FunctionDef, ast.AsyncFunctionDef)):
                q = prefix + ch.name
                body_first = ch.body[0].lineno; end = ch.end_lineno
                # a docstring-only first statement still counts as a statement line in coverage
                body = {l for l in st if body_first <= l <= end}
                func_totals['functions'] += 1; func_totals['function_statements'] += len(body)
                if body and not any(l in lm for l in body):
                    func_totals['never_called'] += 1; func_totals['never_called_statements'] += len(body)
                    n = token_count.get(ch.name, 0)
                    if ch.name.startswith('__') and ch.name.endswith('__'): kind = 'protocol method'
                    elif QT_HOOKS.match(ch.name) and prefix: kind = 'framework hook (called by Qt/stdlib by name)'
                    elif n <= 1: kind = 'name appears nowhere else in the tree (likely dead)'
                    elif isinstance(node, ast.ClassDef) is False and prefix and '.<locals>' in prefix: kind = 'nested'
                    else: kind = 'name referenced elsewhere (%d occurrences): untested' % n
                    never_functions.append({'file': r, 'function': q, 'line': ch.lineno, 'statements': len(body), 'kind': kind,
                                            'name_occurrences_in_tree': n})
                stack.append((ch, q + '.<locals>.'))
            elif isinstance(ch, ast.ClassDef):
                stack.append((ch, prefix + ch.name + '.'))
never_functions.sort(key=lambda x: -x['statements'])
kinds = collections.Counter(); kind_st = collections.Counter()
for f in never_functions:
    k = f['kind'].split(' (')[0] if f['kind'].startswith('name referenced') else f['kind']
    kinds[k] += 1; kind_st[k] += f['statements']
verdicts = collections.Counter(x['verdict'] for x in never_modules)
verdict_st = collections.Counter()
for x in never_modules: verdict_st[x['verdict']] += x['statements']

# ---- write
OUTD = W
summary = {
    'tree': str(TREE), 'commit': 'd1df337', 'coverage_py': coverage.__version__,
    'method': 'one process per test module: python -B -m unittest -v tests_integrated.<m>, coverage started at interpreter start by '
              'boot/sitecustomize.py (COVERAGE_PROCESS_START=rc/<m>.rc: branch=True, parallel=True, source=<tree>/workbench, '
              'context=<m>, dynamic_context=test_function); Python children that inherit the environment are measured too',
    'modules': MODULES, 'focused_modules': len(FOCUSED), 'totals': dict(tot),
    'body_line_pct_all': round(100 * tot['covered_body_lines'] / tot['body_statements'], 2),
    'line_pct_all': round(100 * tot['covered_lines'] / tot['statements'], 2),
    'branch_pct_all': round(100 * tot['covered_branches'] / tot['branches'], 2),
    'line_pct_focused': round(100 * tot['covered_lines_focused'] / tot['statements'], 2),
    'branch_pct_focused': round(100 * tot['covered_branches_focused'] / tot['branches'], 2),
    'never_executed_modules': len(never_modules), 'never_executed_module_statements': sum(x['statements'] for x in never_modules),
    'never_executed_module_verdicts': {k: {'files': v, 'statements': verdict_st[k]} for k, v in verdicts.items()},
    'functions': dict(func_totals), 'never_called_function_kinds': {k: {'functions': v, 'statements': kind_st[k]} for k, v in kinds.items()},
    'tests_in_logs': len(log_tests), 'tests_with_own_workbench_lines': len(test_lines), 'tests_ran_without_own_lines': len(no_lines),
    'tests_skipped': len(skipped),
    'tests_with_zero_unique_lines': sum(1 for v in per_test.values() if v['unique_lines'] == 0),
    'modules_with_zero_unique_lines': [m for m in MODULES if per_module[m]['unique_lines'] == 0],
    'greedy_note': 'set cover over function-body lines; modules ranked by new body lines per baseline second, tests by new body lines',
    'greedy_modules_for_full_focused_line_coverage': len(mod_order), 'focused_union_lines': mod_total,
    'greedy_tests_for_full_focused_line_coverage': len(test_order), 'focused_union_lines_tests': test_total,
}
(OUTD / 'summary.json').write_text(json.dumps(summary, indent=1))
(OUTD / 'per_source.json').write_text(json.dumps(per_source, indent=1))
(OUTD / 'per_module.json').write_text(json.dumps(per_module, indent=1))
(OUTD / 'per_test.json').write_text(json.dumps({'tests': per_test, 'ran_without_own_workbench_lines': no_lines, 'skipped': skipped,
                                                 'statuses': log_tests}, indent=1))
(OUTD / 'never_executed.json').write_text(json.dumps({'modules': never_modules, 'functions': never_functions}, indent=1))
(OUTD / 'greedy.json').write_text(json.dumps({'modules_by_new_lines_per_second': mod_order, 'tests_by_new_lines': test_order}, indent=1))
lm_out = {'modules': MODULES, 'note': 'files -> line -> indexes into modules; covered statements only (coverage.py line numbers)',
          'files': {rel(p): {str(l): sorted(s) for l, s in sorted(d.items())} for p, d in sorted(line_mods.items())},
          'statements': {rel(p): sorted(empty[p].statements) for p in sorted(reporters)}}
(OUTD / 'line_map.json').write_text(json.dumps(lm_out, separators=(',', ':')))
tm_out = {'tests': TESTS, 'files': {rel(p): {str(l): sorted(s) for l, s in sorted(d.items())} for p, d in sorted(line_tests.items())}}
(OUTD / 'test_line_map.json').write_text(json.dumps(tm_out, separators=(',', ':')))
br_out = {'modules': MODULES, 'files': {rel(p): {'%d>%d' % b: sorted(s) for b, s in sorted(d.items())} for p, d in sorted(br_mods.items())}}
(OUTD / 'branch_map.json').write_text(json.dumps(br_out, separators=(',', ':')))
print('written', round(time.time() - t0, 1), flush=True)
print(json.dumps({k: v for k, v in summary.items() if k not in ('modules',)}, indent=1))
