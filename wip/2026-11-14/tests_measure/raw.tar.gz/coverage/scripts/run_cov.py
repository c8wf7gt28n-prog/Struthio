"""Coverage part: every focused tests_integrated module (tools/check_hatch.py FOCUSED_MODULES) of the extracted tree, each in
its own process under coverage.py (branch, source=workbench, parallel data files, static context = the module name, dynamic
context = the test method), at most two at once, nice 19, each in a private pid namespace, HOME a fresh empty folder.
Children that inherit PYTHONPATH and COVERAGE_PROCESS_START are measured too (boot/sitecustomize.py).
usage: run_cov.py W PY [module ...]"""
import ast, json, os, re, shutil, subprocess, sys, threading, time
from pathlib import Path

W = Path(sys.argv[1]).resolve(); PY = sys.argv[2]
TREE = W / 'tree'; DATA = W / 'data'; RC = W / 'rc'; LOGS = W / 'logs'; HOMES = W / 'homes'
src = (TREE / 'tools/check_hatch.py').read_text()
FOCUSED = next(list(ast.literal_eval(n.value)) for n in ast.parse(src).body
               if isinstance(n, ast.Assign) and any(getattr(t, 'id', None) == 'FOCUSED_MODULES' for t in n.targets))
base = json.loads((W.parent.parent / 'modules_082.json').read_text())
modules = sys.argv[3:] or sorted(FOCUSED, key=lambda m: -base.get(m, {}).get('seconds', 0)) + ['test_exact_math_solvers']
OUT = W / 'run_results.json'
rows = json.loads(OUT.read_text()) if OUT.exists() else {}
lock = threading.Lock()


def one(name):
    d = DATA / name
    if d.exists(): shutil.rmtree(d)
    d.mkdir(parents=True)
    home = HOMES / name
    if home.exists(): shutil.rmtree(home)
    home.mkdir(parents=True)
    rc = RC / (name + '.rc')
    rc.write_text('[run]\nbranch = True\nparallel = True\nsource =\n    %s\n' % (TREE / 'workbench')
                  + 'data_file = %s\ncontext = %s\ndynamic_context = test_function\n' % (d / '.coverage', name)
                  + 'disable_warnings = no-data-collected, module-not-measured, module-not-imported, couldnt-parse, no-ctracer\n')
    env = dict(os.environ, QT_QPA_PLATFORM='offscreen', PYTHONDONTWRITEBYTECODE='1', HOME=str(home),
               COVERAGE_PROCESS_START=str(rc), PYTHONPATH='%s:%s' % (W / 'boot', W / 'lib'))
    env.pop('COVERAGE_PROCESS_CONFIG', None)
    cmd = ['nice', '-n', '19', 'unshare', '--pid', '--fork', '--mount-proc', '--kill-child',
           PY, '-B', '-m', 'unittest', '-v', 'tests_integrated.' + name]
    t = time.time()
    try:
        r = subprocess.run(cmd, cwd=TREE, env=env, capture_output=True, text=True, timeout=2400)
        text = r.stderr + r.stdout; code = r.returncode
    except subprocess.TimeoutExpired as exc:
        text = exc.stderr if isinstance(exc.stderr, str) else (exc.stderr or b'').decode('utf-8', 'replace'); code = 'timeout'
    sec = round(time.time() - t, 1)
    (LOGS / (name + '.log')).write_text(text)
    ran = re.search(r'^Ran (\d+) tests?', text, re.M)
    bad = sorted(set(re.findall(r'^(?:FAIL|ERROR): (\S+ \(\S+\))', text, re.M)))
    skipped = len(re.findall(r'\.\.\. skipped', text))
    files = sorted(p.name for p in d.iterdir())
    with lock:
        rows[name] = {'code': code, 'tests': int(ran.group(1)) if ran else None, 'skipped': skipped, 'bad': bad,
                      'seconds_cov': sec, 'seconds_base': base.get(name, {}).get('seconds'),
                      'bad_base': base.get(name, {}).get('bad'), 'data_files': len(files)}
        OUT.write_text(json.dumps(rows, indent=1))
    print(name, code, rows[name]['tests'], len(bad), sec, len(files), flush=True)


queue = list(modules); qlock = threading.Lock()


def worker():
    while True:
        with qlock:
            if not queue: return
            name = queue.pop(0)
        one(name)


threads = [threading.Thread(target=worker) for _ in range(2)]
for th in threads: th.start()
for th in threads: th.join()
print('DONE', len(rows), flush=True)
