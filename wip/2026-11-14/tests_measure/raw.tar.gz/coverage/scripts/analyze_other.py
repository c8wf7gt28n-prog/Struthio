"""Coverage part, supplement: what each test module covers OUTSIDE workbench/ and tests_integrated/ (tools/, root scripts,
sdk/, arc1, ...), from data_other/<module>/.coverage.*; and each module's unique lines when workbench and outside are joined.
usage: analyze_other.py W"""
import collections, json, sqlite3, sys
from pathlib import Path

W = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(W / 'lib'))
import coverage
from coverage.python import PythonFileReporter

TREE = W / 'tree'; DATA = W / 'data_other'
run = json.loads((W / 'run_results_other.json').read_text())
MODULES = sorted(m for m in run if (DATA / m).is_dir())
cov = coverage.Coverage(config_file=False, branch=True, data_file=None)
raw = {m: collections.defaultdict(set) for m in MODULES}
for m in MODULES:
    for f in (DATA / m).glob('.coverage*'):
        con = sqlite3.connect(str(f))
        paths = dict(con.execute('select id, path from file'))
        for fid, a, b in con.execute('select file_id, fromno, tono from arc'):
            raw[m][paths[fid]].update(x for x in (a, b) if x > 0)
        con.close()
rep = {}
mod_lines = {m: {} for m in MODULES}
for m in MODULES:
    for p, ls in raw[m].items():
        if not ls or '/workbench/' in p or '/tests_integrated/' in p: continue
        if p not in rep:
            try: fr = PythonFileReporter(p, cov); rep[p] = (fr, fr.lines())
            except Exception: rep[p] = None
        if rep[p] is None: continue
        fr, st = rep[p]
        ex = fr.translate_lines(ls) & st
        if ex: mod_lines[m][str(Path(p).relative_to(TREE))] = ex
owners = collections.defaultdict(set)
for m in MODULES:
    for p, ls in mod_lines[m].items():
        for l in ls: owners[(p, l)].add(m)
# join with workbench unique lines from per_module.json
pm = json.loads((W / 'per_module.json').read_text())
out = {}
for m in MODULES:
    files = {p: len(ls) for p, ls in sorted(mod_lines[m].items(), key=lambda kv: -len(kv[1]))}
    uniq = collections.Counter(p for p, ls in mod_lines[m].items() for l in ls if owners[(p, l)] == {m})
    out[m] = {'lines_outside_workbench': sum(files.values()), 'unique_lines_outside_workbench': sum(uniq.values()),
              'unique_lines_workbench': pm.get(m, {}).get('unique_lines'),
              'unique_by_file': dict(uniq.most_common()), 'files': files,
              'failing': run[m].get('bad'), 'seconds_under_coverage': run[m].get('seconds_cov')}
statements = {str(Path(p).relative_to(TREE)): len(v[1]) for p, v in rep.items() if v}
covered = collections.Counter(p for (p, l) in owners)
summary = {'files_executed_outside_workbench': len(covered), 'their_statements': sum(statements[p] for p in covered),
           'their_covered_lines': sum(covered.values()),
           'per_file': {p: {'statements': statements[p], 'covered': covered[p]} for p in sorted(covered, key=lambda p: -covered[p])}}
(W / 'outside_workbench.json').write_text(json.dumps({'summary': summary, 'modules': out}, indent=1))
for m, v in sorted(out.items(), key=lambda kv: -kv[1]['unique_lines_outside_workbench']):
    print(m, v['lines_outside_workbench'], v['unique_lines_outside_workbench'], v['unique_lines_workbench'], list(v['unique_by_file'])[:3])
print(json.dumps({k: v for k, v in summary.items() if k != 'per_file'}))
