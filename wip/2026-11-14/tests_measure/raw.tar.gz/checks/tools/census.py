"""census.py TREE OUT.json: for each probe, the identifiers that carry what it checks, and which test modules (tests_integrated) use each."""
import json, re, sys
from pathlib import Path
T = Path(sys.argv[1]); tests = {p.stem: p.read_text(encoding='utf-8', errors='replace') for p in sorted((T / 'tests_integrated').glob('test_*.py'))}
PROBES = {
 'look_probe': ['friendly(', 'edit_location', '_fitted', 'Key_Z', 'still = lambda', 'PathBar'],
 'head_probe': ['bar_menus', 'more_menus', 'MoreMenus', 'menu_words'],
 'glow_probe': ['choose_glow', '.glow()', "choose_art(", 'GLOW'],
 'centre_probe': ['centre_bar', 'bar.larger', 'bar.smaller', 'bar.save', '.sync()'],
 'audit_probe': ['_hot', 'Desk artwork', 'context_strip', 'save.isEnabled'],
 'mouse_probe': ['_bars(', '_grab', 'Put this line', 'Read on', '_guard', 'greenPointer'],
 'mouse2_probe': ['Check original', 'OCR this page', 'Review file', 'Save output copy', 'TEAL_SOFT', "'link'"],
 'pages_probe': ['open_tile', 'page.more', 'findChildren(QPushButton)'],
 'more_probe': ['page.more', 'Recover draft', 'Focus reading'],
 'icons_probe': ['faces.choose', 'tool_faces', 'BARE', 'glyph_of', "'Buttons'"],
 'crash_probe': ['Compare sources again', 'focus_moved', 'page.render()'],
 'boxes_probe': ['own_light', 'page_light', 'Review table', 'lightness'],
 'map_probe': ['field_zoom', 'FAR', 'set_zoom'],
 'find_probe': ['centre_find', 'finder', 'not here', 'a_find', 'a_find_next'],
 'zoom_probe': ['QWheelEvent', 'Key_0', 'set_zoom', 'scroll_x', '_hit('],
 'amber_probe': ['v.go', 'Key_G', 'Key_A', 'amber'],
 'green_probe': ['pointer.drawn', 'graphitePointer', 'liveReading', 'DesktopMonitors', 'BitmapCursor'],
 'cascade_probe': ['field:whatif', 'field:doubt', 'field:trace', 'field:do', 'field:words', 'open_at_focus', 'drill('],
 'ux044_probe': ['Key_Question', 'Key_X', 'Key_B', 'BRIEF', '_read_room', 'reading'],
 'first_probe': ["'empty'", 'problem', 'locations.office'],
 'eq_probe': ['equalizer', 'eq.card', 'eq.sizes', 'edit_location', 'glide'],
 'pane_probe': ['face_tabs', 'title_word', 'at_rest', 'show_agenda', 'linkActivated'],
 'line_probe': ['type_bar', 'targets', 'openUrl', 'No browser', 'Run this line', 'duckduckgo'],
 'hand_probe': ['stacy_hand', 'StagedUndo', 'StagedRun', 'trail(', 'terminal_hers', 'say_always', 'undo_allowed'],
 'start_probe': ['stacy_start', 'Lander', 'program_build', 'godot_tool', 'PlanRun'],
 'door_probe': ['_meter_card', 'click_meter', 'Brain room', 'size_level', 'expand', 'Log out'],
 'kasandra_probe': ['kasandra_art', 'current_state', 'awaiting_approval', 'Special Elite', 'ArtPanel', 'note_outcome'],
 'window': ['a_field', 'Key_F9', "'F9'", 'Key_Return', 'ShiftModifier', 'census('],
 'stacy': ['show_slate_face', 'field:ask', 'answered', 'signature'],
 'regress': ['saveState', 'reading.ui_pt', 'Key_Home', 'Key_PageDown', 'open_at_focus'],
 'crawl_probe': ['findChildren(QAbstractButton)', 'excepthook', 'activeModalWidget'],
 'name_sweep': ['stac(?!y)', 'staC', 'NAME', 'accessibleDescription', 'findChildren(QWidget)'],
}
out = {}
for probe, ids in PROBES.items():
    row = {}
    for i in ids:
        hits = {m: t.count(i) for m, t in tests.items() if i in t}
        row[i] = hits
    out[probe] = row
json.dump(out, open(sys.argv[2], 'w'), indent=1)
for probe, row in out.items():
    print(probe)
    for i, hits in row.items():
        print('   %-28s %s' % (i, ', '.join('%s:%d' % kv for kv in sorted(hits.items(), key=lambda kv: -kv[1])[:6]) or '-- none'))
