"""assemble.py: gather the measurements of the release checks outside the suite into checks.json.
Inputs (all under testclean/checks unless named): timings.json, gate_history.json, census_identifiers.json, release_changes.json,
touch/*.json and touch/*.log (one traced run of each probe at 1920x1200), logs/*_timed.log, and the release logs in work/logs0*/."""
import glob, hashlib, json, os, re
C = '/tmp/claude-0/-home-user-Struthio/62270cd8-8155-590e-b29e-91307882a142/scratchpad/work/testclean/checks'
W = '/tmp/claude-0/-home-user-Struthio/62270cd8-8155-590e-b29e-91307882a142/scratchpad/work'
F = '/tmp/claude-0/-home-user-Struthio/62270cd8-8155-590e-b29e-91307882a142/scratchpad/tools/field'
def load(p): return json.load(open(os.path.join(C, p)))
timings = load('timings.json'); gate = load('gate_history.json'); census = load('census_identifiers.json'); changes = load('release_changes.json')
PROBES = list(timings['per_probe'])

# ---- fixed waits: TIMED lines of the traced and timed runs (the share of a run spent in QTest.qWait the script asked for)
waits = {}
for f in glob.glob(C + '/touch/*.log') + glob.glob(C + '/logs/*_timed.log'):
    t = open(f, errors='replace').read(); m = re.search(r'TIMED total ([\d.]+) s \| fixed waits asked ([\d.]+) s', t)
    if m:
        name = os.path.basename(f).replace('_timed.log', '').replace('.log', '')
        if name == 'crawl': name = 'crawl_probe'
        tot, wt = float(m.group(1)), float(m.group(2)); waits.setdefault(name, []).append({'run_s': tot, 'waits_s': wt, 'share': round(wt / tot, 3), 'log': f})

# ---- the two sizes: output compared with sizes and digits taken out
def norm(path, tag):
    return [re.sub(r'\d+(\.\d+)?', 'N', l.replace(tag, 'SIZE')) for l in open(path, errors='replace').read().splitlines() if 'plugin does not support' not in l]
sizes = {}
for p in PROBES:
    a = norm(W + '/logs082/set_1920x1200/%s.log' % p, '1920x1200'); b = norm(W + '/logs082/set_1366x768/%s.log' % p, '1366x768')
    raw_a = [l for l in open(W + '/logs082/set_1920x1200/%s.log' % p, errors='replace').read().splitlines() if 'plugin does not' not in l]
    raw_b = [l for l in open(W + '/logs082/set_1366x768/%s.log' % p, errors='replace').read().splitlines() if 'plugin does not' not in l]
    only_a = [l for l in raw_a if re.sub(r'\d+(\.\d+)?', 'N', l.replace('1920x1200', 'SIZE')) not in b]
    only_b = [l for l in raw_b if re.sub(r'\d+(\.\d+)?', 'N', l.replace('1366x768', 'SIZE')) not in a]
    sizes[p] = {'same_output_digits_aside': a == b, 'only_at_1920': [l[:220] for l in only_a][:8], 'only_at_1366': [l[:220] for l in only_b][:8]}

# ---- the crawler: every log it ever wrote, by content
crawl = []
for f in glob.glob(W + '/logs*/**/*.log', recursive=True):
    t = open(f, 'rb').read()
    if b'CRAWL ' in t and b'pressed' in t:
        crawl.append({'log': f, 'mtime': os.path.getmtime(f), 'bytes': len(t), 'md5': hashlib.md5(t).hexdigest()[:12], 'verdict': re.findall(rb'CRAWL (\w+)', t)[-1].decode()})
crawl.sort(key=lambda r: r['mtime'])
for r in crawl:
    import datetime; r['when'] = datetime.datetime.utcfromtimestamp(r['mtime']).strftime('%Y-%m-%d %H:%M'); del r['mtime']

# ---- touch sets: which workbench files each check runs (startup = what the window runs before the probe starts)
touch = {}
for f in glob.glob(C + '/touch/*.json'):
    touch[os.path.basename(f)[:-5]] = json.load(open(f))
startup = set(touch.get('first_probe', {}))
touch_summary = {}
for n, d in touch.items():
    own = sorted(k for k, v in d.items() if k not in startup)
    touch_summary[n] = {'files_run': len(d), 'beyond_window_start': own}

# ---- would a file-change rule have skipped a check?  For each release: changed workbench files that the check runs
trigger = []
for rel in changes:
    ch = set(rel['workbench_files']); row = {'release': rel['release'], 'changed_workbench_files': len(ch), 'changed_in_window_start': sorted(ch & startup)[:20],
                                          'checks_whose_own_files_changed': {}}
    for n, s in touch_summary.items():
        hit = sorted(ch & set(s['beyond_window_start']))
        if hit: row['checks_whose_own_files_changed'][n] = hit
    trigger.append(row)

out = {'timings': timings, 'fixed_waits': waits, 'two_sizes': sizes, 'crawler_logs': crawl, 'gate_history': gate, 'census_identifiers': census,
       'touch_summary': {'workbench_modules': 445, 'run_at_window_start': len(startup), 'per_check': touch_summary}, 'release_triggers': trigger}
json.dump(out, open(C + '/measurements.json', 'w'), indent=1, default=str)
print('waits:', {k: [x['share'] for x in v] for k, v in sorted(waits.items())})
print('same output at both sizes:', sum(v['same_output_digits_aside'] for v in sizes.values()), 'of', len(sizes))
print('crawler logs:', len(crawl), 'distinct contents:', len({r['md5'] for r in crawl}), [(r['when'], r['md5'], r['verdict']) for r in crawl])
print('startup files:', len(startup))
for r in trigger: print(r['release'], r['changed_workbench_files'], 'in window start:', len(r['changed_in_window_start']), '| own files hit:', {k: len(v) for k, v in r['checks_whose_own_files_changed'].items()})
