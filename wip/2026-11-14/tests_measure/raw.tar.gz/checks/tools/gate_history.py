"""gate_history.py: every stored gate result (reports2/ui_*.json), script by script: pass, the line it stopped at, the last line of its error."""
import json, re, sys, os, glob
S = '/tmp/claude-0/-home-user-Struthio/62270cd8-8155-590e-b29e-91307882a142/scratchpad/work/reports2'
files = sorted(glob.glob(S + '/ui_*.json'), key=os.path.getmtime)
hist = {}
order = []
for f in files:
    tag = os.path.basename(f)[3:-5]
    try: d = json.load(open(f))
    except Exception as e: print('skip', tag, e); continue
    sc = d.get('ui_checks', {}).get('scripts', {})
    if not sc: print('skip', tag, 'no scripts'); continue
    order.append(tag)
    for name, r in sc.items():
        ok = r.get('state') == 'PASSED'
        err = r.get('error') or ''
        own = re.findall(re.escape(name.split('/')[-1]) + r'", line (\d+)', err)
        last = [l for l in err.strip().splitlines() if l.strip()][-1][:160] if err else ''
        hist.setdefault(name, {})[tag] = {'ok': ok, 'line': int(own[-1]) if own and not ok else None, 'error': last, 'checks': r.get('checks')}
out = {'runs': order, 'scripts': hist}
json.dump(out, open(sys.argv[1], 'w'), indent=1)
for name in sorted(hist):
    seq = []
    for t in order:
        r = hist[name].get(t)
        seq.append('-' if r is None else ('P' if r['ok'] else str(r['line'])))
    changes = sum(1 for a, b in zip(seq, seq[1:]) if a != b)
    print('%-40s changes=%d %s' % (name, changes, ' '.join(seq)))
print('runs:', ' '.join(order))
