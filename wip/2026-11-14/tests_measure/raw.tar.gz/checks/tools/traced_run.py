"""traced_run.py OUT.json SCRIPT ARGS...: run a standalone window script and record which workbench files had code run."""
import sys, json, atexit, runpy
out = sys.argv[1]; script = sys.argv[2]; sys.argv = [script] + sys.argv[3:]
SEEN = {}; M = sys.monitoring; TOOL = 4
M.use_tool_id(TOOL, 'touch')
def on_start(code, offset):
    f = code.co_filename
    if '/workbench/' in f:
        k = SEEN.setdefault(f.split('/workbench/', 1)[1], [])
        if 'start' not in k: k.append('start')
    return M.DISABLE
M.register_callback(TOOL, M.events.PY_START, on_start); M.set_events(TOOL, M.events.PY_START)
atexit.register(lambda: json.dump(SEEN, open(out, 'w'), indent=0))
runpy.run_path(script, run_name='__main__')
