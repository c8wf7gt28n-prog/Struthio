#!/bin/bash
# every probe once at 1920 x 1200 with the traced harness: which workbench files each one runs, and its time
C=/tmp/claude-0/-home-user-Struthio/62270cd8-8155-590e-b29e-91307882a142/scratchpad/work/testclean/checks
S=/tmp/claude-0/-home-user-Struthio/62270cd8-8155-590e-b29e-91307882a142/scratchpad; PY=$S/work/venv/bin/python
cd $C/tree
for p in first_probe look_probe head_probe glow_probe centre_probe audit_probe mouse_probe mouse2_probe pages_probe more_probe icons_probe crash_probe boxes_probe map_probe find_probe zoom_probe amber_probe green_probe cascade_probe ux044_probe eq_probe pane_probe line_probe hand_probe start_probe door_probe kasandra_probe name_sweep; do
  A=; [ $p = kasandra_probe ] && A=kasandra
  GRAPHITE_APPEARANCE=$A TOUCH_OUT=$C/touch/$p.json REHEARSAL_MODEL=x REHEARSAL_SCRIPT=$S/tools/field/$p.py PYTHONUNBUFFERED=1 QT_QPA_PLATFORM=offscreen timeout 400 nice -n 19 unshare --pid --fork --mount-proc --kill-child $PY -u -B $C/tools/nomodel_traced.py $C/tree $C/shots 1920 1200 > $C/touch/$p.log 2>&1
  echo "$p exit $? $(grep -E 'TIMED|PROBE|WRONG|SWEEP' $C/touch/$p.log | tr '\n' ' ')"
done
for p in window stacy regress; do
  TMP=$C/run QT_QPA_PLATFORM=offscreen timeout 300 nice -n 19 unshare --pid --fork --mount-proc --kill-child $PY -u -B $C/tools/traced_run.py $C/touch/$p.json $C/tools/standalone_$p.py $C/tree $C/shots 1920 1200 > $C/touch/$p.log 2>&1
  echo "$p exit $? $(tail -1 $C/touch/$p.log)"
done
echo SET DONE
