"""timings.py OUT.json: seconds per check and per probe from the log files' modification times (a log is last written when its
run ends; in a sequential run, a run's start is the previous run's end)."""
import json, os, sys, statistics
W = '/tmp/claude-0/-home-user-Struthio/62270cd8-8155-590e-b29e-91307882a142/scratchpad/work'
PROBES = 'look_probe head_probe glow_probe centre_probe audit_probe mouse_probe mouse2_probe pages_probe more_probe icons_probe crash_probe boxes_probe map_probe find_probe zoom_probe amber_probe green_probe cascade_probe ux044_probe first_probe eq_probe pane_probe line_probe hand_probe start_probe door_probe kasandra_probe'.split() + ['window', 'stacy', 'regress']
def m(p): return os.path.getmtime(p)
def birth(p):
    import subprocess
    return float(subprocess.run(['stat', '-c', '%W', p], capture_output=True, text=True).stdout.strip())
def seq(start, items):
    out = {}; t = start
    for name, path in items:
        e = m(path); out[name] = round(e - t, 1); t = e
    return out, t
res = {}
# 0.8.2: one script, everything in order (checks_082.sh); the run starts when its trees were extracted
L = W + '/logs082'; t0 = birth(W + '/t_ui')
r = {}
r['suite'] = round(m(L + '/modules.log') - t0, 1)
r['scene_graphite'] = round(m(L + '/scene_graphite.log') - m(L + '/modules.log'), 1)
r['scene_kasandra'] = round(m(L + '/scene_kasandra.log') - m(L + '/scene_graphite.log'), 1)
p1920, end1920 = seq(m(L + '/scene_kasandra.log'), [(p, L + '/set_1920x1200/%s.log' % p) for p in PROBES])
p1366, end1366 = seq(end1920, [(p, L + '/set_1366x768/%s.log' % p) for p in PROBES])
r['probes_1920x1200'] = round(end1920 - m(L + '/scene_kasandra.log'), 1); r['probes_1366x768'] = round(end1366 - end1920, 1)
r['crawl_graphite'] = round(m(L + '/crawl_graphite.log') - end1366, 1)
r['sweep_graphite'] = round(m(L + '/sweep_graphite.log') - m(L + '/crawl_graphite.log'), 1)
r['crawl_kasandra'] = round(m(L + '/crawl_kasandra.log') - m(L + '/sweep_graphite.log'), 1)
r['sweep_kasandra'] = round(m(L + '/sweep_kasandra.log') - m(L + '/crawl_kasandra.log'), 1)
r['gate'] = round(m(L + '/gate.log') - m(L + '/sweep_kasandra.log'), 1)
r['total'] = round(m(L + '/gate.log') - t0, 1)
res['0.8.2'] = {'checks_seconds': r, 'probe_seconds_1920x1200': p1920, 'probe_seconds_1366x768': p1366, 'method': 'sequential (checks_082.sh); start = birth time of the extracted trees'}
# 0.8.1: the 1920 set ran after the suite with modules_b alongside until 03:40; the 1366 set overlapped the crawler and the gate
L = W + '/logs081'
q1920, e = seq(m(L + '/modules.log'), [(p, L + '/set_1920x1200/%s.log' % p) for p in PROBES])
q1366, e2 = seq(e, [(p, L + '/set_1366x768/%s.log' % p) for p in PROBES])
res['0.8.1'] = {'probe_seconds_1920x1200': q1920, 'probe_seconds_1366x768': q1366, 'probes_1920x1200': round(e - m(L + '/modules.log'), 1), 'probes_1366x768': round(e2 - e, 1),
                'crawl_kasandra': round(m(L + '/crawl_kasandra.log') - m(L + '/sweep_graphite.log'), 1),
                'method': 'the 1920 set started after the suite log; a second suite run (modules_b) overlapped its first minutes; the 1366 set overlapped the Graphite crawl and the gate, so its times are inflated'}
L = W + '/logs080'
res['0.8.0'] = {'crawl_kasandra': round(m(L + '/crawl_kasandra.log') - m(L + '/crawl_graphite.log'), 1), 'method': 'crawl_kasandra started when crawl_graphite ended (as its log order shows)'}
# per probe: the 0.8.2 pair and the 0.8.1 1920 run
per = {}
for p in PROBES:
    vals = [p1920[p], p1366[p], q1920[p]]
    per[p] = {'0.8.2_1920': p1920[p], '0.8.2_1366': p1366[p], '0.8.1_1920': q1920[p], '0.8.1_1366(contended)': q1366[p], 'per_release_both_sizes_0.8.2': round(p1920[p] + p1366[p], 1)}
res['per_probe'] = per
json.dump(res, open(sys.argv[1], 'w'), indent=1)
print(json.dumps(res['0.8.2']['checks_seconds'], indent=0))
print('%-16s %8s %8s %8s %8s' % ('probe', '082_1920', '082_1366', '081_1920', 'both082'))
for p, v in sorted(per.items(), key=lambda kv: -kv[1]['per_release_both_sizes_0.8.2']):
    print('%-16s %8.1f %8.1f %8.1f %8.1f' % (p, v['0.8.2_1920'], v['0.8.2_1366'], v['0.8.1_1920'], v['per_release_both_sizes_0.8.2']))
print({k: v for k, v in res['0.8.1'].items() if not isinstance(v, dict)}, res['0.8.0'])
