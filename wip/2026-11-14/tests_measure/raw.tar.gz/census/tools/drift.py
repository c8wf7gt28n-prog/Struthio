"""Drift: for every test module, the commits after the import (aa0ce07) that changed the source files its tests name directly,
against the commits that changed the test file itself.  usage: drift.py <repo> <rev> <static.json> <churn.json> <out.json>"""
import json, subprocess, sys, collections

REPO, REV = sys.argv[1], sys.argv[2]; static = json.load(open(sys.argv[3])); churn = json.load(open(sys.argv[4]))
imports = collections.defaultdict(set)
for r in static['tests']:
    for m in r['imports']:
        if m.startswith('script:'): imports[r['module']].add(m[7:])
        else: imports[r['module']].add(m.replace('.', '/') + '.py')
out = {}
for mod, files in sorted(imports.items()):
    files = [f for f in files if subprocess.run(['git', '-C', REPO, 'cat-file', '-e', '%s:%s' % (REV, f)], capture_output=True).returncode == 0]
    log = subprocess.run(['git', '-C', REPO, 'log', '--format=%h', 'aa0ce07..' + REV, '--'] + files, capture_output=True, text=True).stdout.split() if files else []
    test_commits = [r['commit'] for r in churn['files'].get(mod, []) if not r['is_import']]
    out[mod] = {'source_files': sorted(files), 'source_commits_after_import': len(log), 'test_commits_after_import': len(test_commits),
                'source_changed_without_test': len([c for c in log if c not in test_commits])}
json.dump(out, open(sys.argv[5], 'w'), indent=1)
for mod, v in sorted(out.items(), key=lambda kv: -kv[1]['source_changed_without_test']):
    print(mod, v['source_commits_after_import'], v['test_commits_after_import'], v['source_changed_without_test'], len(v['source_files']))
