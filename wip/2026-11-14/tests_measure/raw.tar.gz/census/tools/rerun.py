"""Run every tests_integrated module (the 59 focused ones in FOCUSED_MODULES order, then the on-demand ones) N times, one module
per child process, each child in its own pid namespace at nice 19, HOME a fresh empty folder per run. One process at a time.
usage: rerun.py <tree> <outdir> <python> <first_run> <last_run>"""
import ast, glob, json, os, subprocess, sys, time
from pathlib import Path

TREE = Path(sys.argv[1]).resolve(); OUT = Path(sys.argv[2]); PY = sys.argv[3]; A, B = int(sys.argv[4]), int(sys.argv[5])
RUN_ONE = str(Path(__file__).resolve().parent / (sys.argv[6] if len(sys.argv) > 6 else 'run_one.py'))
src = (TREE / 'tools/check_hatch.py').read_text()
focused = next(list(ast.literal_eval(n.value)) for n in ast.parse(src).body
               if isinstance(n, ast.Assign) and any(getattr(t, 'id', None) == 'FOCUSED_MODULES' for t in n.targets))
every = sorted(Path(p).stem for p in glob.glob(str(TREE / 'tests_integrated/test_*.py')))
order = focused + [m for m in every if m not in focused]
for run in range(A, B + 1):
    d = OUT / (('counted%d' if len(sys.argv) > 6 else 'run%d') % run); d.mkdir(parents=True, exist_ok=True)
    home = OUT / ('home%d' % run); home.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, QT_QPA_PLATFORM='offscreen', PYTHONDONTWRITEBYTECODE='1', HOME=str(home))
    summary = {}
    for name in order:
        t = time.time()
        cmd = ['nice', '-n', '19', 'unshare', '--pid', '--fork', '--mount-proc', '--kill-child', PY, '-B', RUN_ONE, name, str(d / (name + '.json'))]
        try:
            r = subprocess.run(cmd, cwd=TREE, env=env, capture_output=True, text=True, timeout=1200); code = r.returncode
            (d / (name + '.log')).write_text(r.stdout[-20000:] + '\n---stderr---\n' + r.stderr[-20000:])
        except subprocess.TimeoutExpired:
            code = 'timeout'
        summary[name] = {'code': code, 'wall_seconds': round(time.time() - t, 2), 'load': os.getloadavg()[0]}
        (d / '_summary.json').write_text(json.dumps(summary, indent=1))
        print(run, name, code, summary[name]['wall_seconds'], flush=True)
print('DONE')
