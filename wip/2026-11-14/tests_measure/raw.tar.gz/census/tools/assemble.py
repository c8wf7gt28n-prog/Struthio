"""Assemble census.json (one row per test) and modules.json (one row per tests_integrated file) from the pieces:
static.json, kinds.json, constants.json, dupes.json, churn.json, drift.json, importmap.json, runs/run{1,2,3}, runs/counted4,
the 0.8.2 module timings (modules_082.json) and the import-commit run (at_import_runs).
usage: assemble.py <census_dir> <modules_082.json>"""
import ast, glob, json, re, statistics, sys, collections
from pathlib import Path

C = Path(sys.argv[1]); M082 = json.load(open(sys.argv[2]))
J = lambda n: json.load(open(C / n))
static = J('static.json'); kinds = {r['id']: r for r in J('kinds.json')}; consts = J('constants.json'); dupes = J('dupes.json')
churn = J('churn.json'); drift = J('drift.json'); imap = J('importmap.json')
src = (C / 'tree/tools/check_hatch.py').read_text()
FOCUSED = next(list(ast.literal_eval(n.value)) for n in ast.parse(src).body if isinstance(n, ast.Assign) and any(getattr(t, 'id', None) == 'FOCUSED_MODULES' for t in n.targets))
ON_DEMAND = next(ast.literal_eval(n.value) for n in ast.parse(src).body if isinstance(n, ast.Assign) and any(getattr(t, 'id', None) == 'ON_DEMAND_MODULES' for t in n.targets))
RUNS = sorted(p for p in glob.glob(str(C / 'runs/run*')) if Path(p).is_dir())
COUNTED = sorted(p for p in glob.glob(str(C / 'runs/counted*')) if Path(p).is_dir())


def load_runs(dirs):
    out = []
    for d in dirs:
        mods = {}
        for f in glob.glob(d + '/test_*.json'):
            try: mods[Path(f).stem] = json.load(open(f))
            except ValueError: pass
        summ = json.load(open(d + '/_summary.json')) if Path(d + '/_summary.json').exists() else {}
        out.append((Path(d).name, mods, summ))
    return out


runs = load_runs(RUNS); counted = load_runs(COUNTED)
# the 0.8.2 baseline lists failing ids as "test_x (tests_integrated.mod.Class.test_x)"
bad082 = {re.search(r'\((\S+)\)', b).group(1) for m in M082.values() for b in m['bad']}
at_import = {}
for f in glob.glob(str(C / 'at_import_runs/*.json')):
    d = json.load(open(f)); at_import.update({k: v['outcome'] for k, v in d['tests'].items()})

dup_of = collections.defaultdict(set)
for s in dupes['same_assertion_across_modules']:
    for a in s['tests']:
        for b in s['tests']:
            if a != b and a.split('.')[1] != b.split('.')[1]: dup_of[a].add(b)
for s in dupes['similar_bodies_across_modules']:
    dup_of[s['a']].add(s['b']); dup_of[s['b']].add(s['a'])
# reviewed by hand (census report): same check in two modules, not caught by the two mechanical searches
HAND_DUPES = [
    ('tests_integrated.test_launcher.LauncherTests.test_explore_contract_is_a_bounded_read',
     'tests_integrated.test_release_check.LiveRecord.test_the_live_tree_equals_the_recorded_graphite_registry'),
    ('tests_integrated.test_frame.ColumnArithmeticTests.test_the_workspace_floor_is_the_desks',
     'tests_integrated.test_desk.PaneWidthTests.test_the_workspace_keeps_the_floor_the_old_rules_protected'),
    ('tests_integrated.test_frame.ColumnArithmeticTests.test_the_strip_words_and_destination_hint',
     'tests_integrated.test_writing_line.ModeTests.test_five_modes_and_the_old_targets_mapping'),
    ('tests_integrated.test_desk.GrainTests.test_the_band_colours_are_the_palettes',
     'tests_integrated.test_graphite.MarkAndTileTests.test_palette_is_graphite_paper_eraser_and_pencil_only'),
    ('tests_integrated.test_graphite.MarkAndTileTests.test_palette_is_graphite_paper_eraser_and_pencil_only',
     'tests_integrated.test_system_menu.CatColourTests.test_the_colours_are_named_constants_and_the_coat_is_warm_paper'),
    ('tests_integrated.test_graphite.MarkAndTileTests.test_palette_is_graphite_paper_eraser_and_pencil_only',
     'tests_integrated.test_kasandra.PaletteTests.test_graphite_keeps_its_colours_and_its_roles_are_amber'),
]
for a, b in HAND_DUPES: dup_of[a].add(b); dup_of[b].add(a)
FOLLOW = collections.defaultdict(list)
for line in open(C / 'followed_look.txt'):
    if line.strip() and not line.startswith('#'):
        t, commit, why = line.strip().split(' ', 2); FOLLOW['tests_integrated.' + t].append(commit + ' ' + why)
MODS = churn.get('per_test_modifications', {})
CONST_FALSE_POSITIVE = {'tests_integrated.test_profile_files.Words.test_registered_whichever_module_is_imported_first'}

suite_total = sum(v['seconds'] for v in M082.values())
mod_wall = collections.defaultdict(list)
for name, mods, summ in runs:
    for m, s in summ.items(): mod_wall[m].append(s['wall_seconds'])
rows = []; per_mod = collections.defaultdict(list)
for r in static['tests']:
    tid = r['id']; mod = r['module']
    outcomes = {}
    if mod in M082: outcomes['082'] = 'FAIL' if tid in bad082 else ('ok' if M082[mod]['tests'] else None)
    secs = []
    for name, mods, _ in runs + counted:
        t = mods.get(mod, {}).get('tests', {}).get(tid)
        if t: outcomes[name] = t['outcome']
        if t and t.get('seconds') is not None and name.startswith('run'): secs.append(t['seconds'])
    executed = None
    for name, mods, _ in counted:
        t = mods.get(mod, {}).get('tests', {}).get(tid)
        if t: executed = t.get('executed_assertions')
    vals = {v for v in outcomes.values() if v}
    norm = {'ok' if v in ('ok', 'skip') else 'bad' for v in vals}
    c = consts[tid]; ch = churn['per_test'].get(mod + '.' + r['class'] + '.' + r['name'], {'commits': 0, 'look_commits': 0, 'subjects': []})
    fail_detail = ''
    for name, mods, _ in runs:
        t = mods.get(mod, {}).get('tests', {}).get(tid)
        if t and t['outcome'] in ('FAIL', 'ERROR'):
            lines = [l for l in t['detail'].splitlines() if re.match(r'\s*(AssertionError|ValueError|TypeError|KeyError|\w+Error)\b', l)]
            loc = re.findall(r'File ".*?(tests_integrated/\w+\.py)", line (\d+)', t['detail'])
            fail_detail = ((loc[-1][0] + ':' + loc[-1][1] + ' ') if loc else '') + (lines[-1].strip()[:300] if lines else t['detail'].strip().splitlines()[-1][:300])
            break
    mean = round(statistics.mean(secs), 3) if secs else None
    row = {'id': tid, 'module': mod, 'class': r['class'], 'name': r['name'], 'where': 'tests_integrated/%s.py:%d' % (mod, r['line']),
           'focused': mod in FOCUSED, 'kind': kinds[tid]['kind'], 'kind_source': kinds[tid]['kind_source'],
           'seconds_mean': mean, 'seconds_runs': secs,
           'seconds_share_of_module': None, 'seconds_share_of_suite': None,
           'assertions_static': r['assert_direct'] + r['assert_via_helpers'], 'assertions_direct': r['assert_direct'],
           'assertions_in_helpers': r['assert_via_helpers'], 'assertions_executed': executed,
           'imports': r['imports'],
           'outcomes': outcomes, 'status': 'FAILING' if norm == {'bad'} else ('FLAKY' if len(norm) > 1 else 'passing'),
           'flaky': len(norm) > 1, 'failing_at_import_aa0ce07': at_import.get(tid) in ('FAIL', 'ERROR') if tid in at_import else None,
           'failure': fail_detail,
           'churn': {'added_after_import': bool(MODS.get(mod + '.' + r['class'] + '.' + r['name'], {}).get('added_after_import')),
                     'modified_after_import': MODS.get(mod + '.' + r['class'] + '.' + r['name'], {}).get('modified', 0),
                     'modified_in_commit_touching_look_files': MODS.get(mod + '.' + r['class'] + '.' + r['name'], {}).get('modified_in_look_commit', 0),
                     'modified_only_to_follow_look_or_words': FOLLOW.get(tid, []),
                     'commits': MODS.get(mod + '.' + r['class'] + '.' + r['name'], {}).get('commits', [])},
           'file_churn': {'commits': len(churn['files'].get(mod, [])), 'after_import': sum(1 for x in churn['files'].get(mod, []) if not x['is_import']),
                          'after_import_with_look_files': sum(1 for x in churn['files'].get(mod, []) if not x['is_import'] and x['n_look_files'])},
           'flags': {'no_assertion': r['assert_direct'] + r['assert_via_helpers'] == 0,
                     'no_assertion_executed': executed == 0,
                     'tautology': r['tautologies'],
                     'constant_only': c['constant_only'] and tid not in CONST_FALSE_POSITIVE,
                     'constant_restatements': c['constant_restatements'], 'wording_assertions': c['wording_assertions'],
                     'near_duplicates': sorted(dup_of.get(tid, []))}}
    rows.append(row); per_mod[mod].append(row)
for mod, rs in per_mod.items():
    walls = mod_wall.get(mod, [])
    wall = statistics.mean(walls) if walls else None
    for row in rs:
        if row['seconds_mean'] is not None and wall: row['seconds_share_of_module'] = round(row['seconds_mean'] / wall, 4)
        if row['seconds_mean'] is not None: row['seconds_share_of_suite'] = round(row['seconds_mean'] / suite_total, 5)
json.dump({'about': 'one row per test in tests_integrated at d1df337; see modules.json and the census report', 'rows': rows},
          open(C / 'census.json', 'w'), indent=1)

modules = {}
for p in sorted(glob.glob(str(C / 'tree/tests_integrated/*.py'))):
    mod = Path(p).stem; rs = per_mod.get(mod, [])
    walls = mod_wall.get(mod, [])
    test_sum = [sum(t for t in [x['seconds_runs'][i] for x in rs if len(x['seconds_runs']) > i]) for i in range(len(walls))] if rs else []
    kinds_c = collections.Counter(x['kind'] for x in rs)
    modules[mod] = {
        'file': 'tests_integrated/%s.py' % mod,
        'guards_docstring': ' '.join((ast.get_docstring(ast.parse(Path(p).read_text())) or '').split())[:400], 'lines': len(Path(p).read_text().splitlines()), 'tests': len(rs),
        'focused': mod in FOCUSED, 'role': 'focused test module' if mod in FOCUSED else (('on demand: ' + ON_DEMAND[mod]) if mod in ON_DEMAND else ('helper (not a test module)' if not rs else 'unlisted')),
        'seconds_082': M082.get(mod, {}).get('seconds'), 'wall_seconds_runs': walls,
        'wall_min': min(walls) if walls else None, 'wall_max': max(walls) if walls else None,
        'wall_spread_pct': round(100 * (max(walls) - min(walls)) / min(walls), 1) if walls and min(walls) else None,
        'test_seconds_sum_runs': [round(x, 2) for x in test_sum],
        'overhead_seconds_mean': round(statistics.mean(w - t for w, t in zip(walls, test_sum)), 2) if test_sum else None,
        'share_of_suite_082': round(M082[mod]['seconds'] / suite_total, 4) if mod in M082 else None,
        'kinds': dict(kinds_c), 'assertions_static': sum(x['assertions_static'] for x in rs),
        'assertions_executed': sum(x['assertions_executed'] or 0 for x in rs) if any(x['assertions_executed'] is not None for x in rs) else None,
        'failing': [x['id'] for x in rs if x['status'] == 'FAILING'], 'flaky': [x['id'] for x in rs if x['flaky']],
        'imports_direct': imap['test_module_imports_direct'].get(mod, []), 'loads_runtime_count': len(imap['test_module_loads_runtime'].get(mod, [])),
        'churn_file_commits': len(churn['files'].get(mod, [])),
        'churn_after_import': sum(1 for x in churn['files'].get(mod, []) if not x['is_import']),
        'churn_after_import_with_look_files': sum(1 for x in churn['files'].get(mod, []) if not x['is_import'] and x['n_look_files']),
        'drift': drift.get(mod),
        'constant_only_tests': [x['id'] for x in rs if x['flags']['constant_only']],
        'tests_with_near_duplicates': sum(1 for x in rs if x['flags']['near_duplicates']),
    }
json.dump(modules, open(C / 'modules.json', 'w'), indent=1)
print('rows', len(rows), 'modules', len(modules))
print('status', collections.Counter(r['status'] for r in rows))
print('kinds', collections.Counter(r['kind'] for r in rows))
