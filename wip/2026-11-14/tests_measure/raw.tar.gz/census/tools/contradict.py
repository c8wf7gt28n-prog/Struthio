"""Contradictions: the same expression (module aliases resolved) asserted equal to different literal values in two tests.
usage: contradict.py <tree> <static.json> <constants.json> <out.json>"""
import ast, json, sys, collections
sys.path.insert(0, sys.argv[0].rsplit('/', 1)[0])
from pathlib import Path
TREE = Path(sys.argv[1]); static = json.load(open(sys.argv[2])); consts = json.load(open(sys.argv[3]))
def bindings(module, cache={}):
    if module in cache: return cache[module]
    tree = ast.parse((TREE / 'tests_integrated' / (module + '.py')).read_text()); b = {}
    for n in ast.walk(tree):
        if isinstance(n, ast.ImportFrom) and n.module and n.module.startswith('workbench'):
            for a in n.names: b[a.asname or a.name] = n.module + '.' + a.name
        if isinstance(n, ast.Import):
            for a in n.names:
                if a.asname: b[a.asname] = a.name
    cache[module] = b; return b
class R(ast.NodeTransformer):
    def __init__(s, b): s.b = b
    def visit_Name(s, n): return ast.Name(id=s.b.get(n.id, n.id), ctx=n.ctx)
def lit(n):
    try: return ast.literal_eval(n)
    except Exception: return None
rows = {r['id']: r for r in static['tests']}
seen = collections.defaultdict(dict)
for tid, c in consts.items():
    b = bindings(rows[tid]['module'])
    for fp in c['fingerprints']:
        node = ast.parse(fp, mode='eval').body
        if getattr(node.func, 'id', '') != 'assertEqual' or len(node.args) != 2: continue
        x, y = node.args
        if lit(x) is not None and lit(y) is None: x, y = y, x
        v = lit(y)
        if v is None or lit(x) is not None: continue
        key = ast.unparse(R(b).visit(x))
        if 'workbench.' not in key: continue
        seen[key].setdefault(repr(v), set()).add(tid)
out = []
for key, vals in seen.items():
    if len(vals) > 1:
        out.append({'expression': key, 'values': {v: sorted(t) for v, t in vals.items()}})
json.dump(out, open(sys.argv[4], 'w'), indent=1)
for o in out:
    print(o['expression'][:120])
    for v, t in o['values'].items(): print('    ', v[:80], '<-', ', '.join(x.split('.', 2)[2] for x in t))
