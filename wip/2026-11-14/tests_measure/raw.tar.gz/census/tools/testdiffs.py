"""For every test function modified after the import: the lines its body lost and gained in that commit (from the repository)."""
import ast, difflib, json, subprocess, sys
REPO = '/home/user/Struthio'; c = json.load(open(sys.argv[1])); out = []
def body(src, cls, name):
    tree = ast.parse(src); lines = src.splitlines()
    for n in tree.body:
        if isinstance(n, ast.ClassDef) and n.name == cls:
            for m in n.body:
                if isinstance(m, ast.FunctionDef) and m.name == name: return lines[m.lineno - 1:m.end_lineno]
    return []
for mod, rows in c['files'].items():
    for r in rows:
        if r['is_import']: continue
        path = 'tests_integrated/%s.py' % mod
        for t in r['modified']:
            cls, name = t.split('.')
            a = body(subprocess.run(['git', '-C', REPO, 'show', r['commit'] + '^:' + path], capture_output=True, text=True).stdout, cls, name)
            b = body(subprocess.run(['git', '-C', REPO, 'show', r['commit'] + ':' + path], capture_output=True, text=True).stdout, cls, name)
            d = [l for l in difflib.unified_diff(a, b, lineterm='', n=0) if l[:1] in '+-' and not l.startswith(('+++', '---'))]
            out.append({'test': mod + '.' + t, 'commit': r['commit'], 'subject': r['subject'], 'look_commit': bool(r['n_look_files'] or r['look_subject']), 'diff': d})
json.dump(out, open(sys.argv[2], 'w'), indent=1)
for o in out:
    print('##', o['commit'], 'LOOK' if o['look_commit'] else '', o['test'])
    for l in o['diff'][:6]: print('   ', l.strip()[:170])
