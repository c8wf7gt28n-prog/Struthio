"""run_one.py with every TestCase assert*/fail method counted while each test runs (outermost calls only), so a test whose
assertions sit in a loop or a branch that never ran shows 0 executed assertions.  usage: run_one_counted.py <module> <out.json>"""
import functools, json, sys, time, unittest, io
from pathlib import Path

root = Path.cwd(); sys.path.insert(0, str(root))
name, out = sys.argv[1], Path(sys.argv[2])
counts = {}; state = {'current': None, 'depth': 0}


def wrap(fn):
    @functools.wraps(fn)
    def inner(*a, **k):
        cur = state['current']
        if cur is not None and state['depth'] == 0:
            counts[cur] = counts.get(cur, 0) + 1
        state['depth'] += 1
        try: return fn(*a, **k)
        finally: state['depth'] -= 1
    return inner


for attr in list(vars(unittest.TestCase)):
    if (attr.startswith('assert') or attr == 'fail') and callable(getattr(unittest.TestCase, attr)) and not attr.startswith('assertRaises') and not attr.startswith('assertWarns') and not attr.startswith('assertLogs') and not attr.startswith('assertNoLogs'):
        setattr(unittest.TestCase, attr, wrap(getattr(unittest.TestCase, attr)))
for attr in ('assertRaises', 'assertRaisesRegex', 'assertWarns', 'assertWarnsRegex', 'assertLogs', 'assertNoLogs'):
    orig = getattr(unittest.TestCase, attr)
    def counted(self, *a, _orig=orig, **k):
        if state['current'] is not None: counts[state['current']] = counts.get(state['current'], 0) + 1
        return _orig(self, *a, **k)
    setattr(unittest.TestCase, attr, counted)
rows = {}


class Result(unittest.TextTestResult):
    def startTest(self, test):
        state['current'] = test.id(); state['depth'] = 0; counts.setdefault(test.id(), 0); super().startTest(test)

    def stopTest(self, test):
        super().stopTest(test); state['current'] = None

    def _row(self, test):
        return rows.setdefault(test.id(), {'outcome': None, 'seconds': None})

    def addSuccess(self, test): super().addSuccess(test); self._row(test)['outcome'] = self._row(test)['outcome'] or 'ok'
    def addFailure(self, test, err): super().addFailure(test, err); self._row(test)['outcome'] = 'FAIL'
    def addError(self, test, err): super().addError(test, err); self._row(test)['outcome'] = 'ERROR'
    def addSkip(self, test, reason): super().addSkip(test, reason); self._row(test)['outcome'] = 'skip'

    def addSubTest(self, test, subtest, err):
        super().addSubTest(test, subtest, err)
        if err is not None: self._row(test)['outcome'] = 'FAIL'

    def addDuration(self, test, elapsed): super().addDuration(test, elapsed); self._row(test)['seconds'] = round(elapsed, 3)


suite = unittest.defaultTestLoader.loadTestsFromName('tests_integrated.' + name)
t1 = time.time(); result = unittest.TextTestRunner(stream=io.StringIO(), verbosity=1, resultclass=Result).run(suite)
for k, v in rows.items(): v['executed_assertions'] = counts.get(k, 0)
out.write_text(json.dumps({'module': name, 'run_seconds': round(time.time() - t1, 3), 'tests': rows}, indent=1))
