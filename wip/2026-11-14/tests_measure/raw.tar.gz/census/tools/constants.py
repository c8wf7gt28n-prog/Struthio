"""Per test: assertions that only restate a module constant (UPPER_CASE name, or a subscript / tuple of them) against a literal
or against another constant; assertions that compare against a sentence-like literal (wording); and normalised assertion
fingerprints for the cross-module near-duplicate search.
usage: constants.py <static.json> <out.json>"""
import ast, json, re, sys, hashlib

static = json.load(open(sys.argv[1]))
UPPER = re.compile(r'^[A-Z][A-Z0-9_]{1,}$')


def is_literal(n):
    if isinstance(n, ast.Constant): return True
    if isinstance(n, (ast.Tuple, ast.List, ast.Set)): return all(is_literal(e) for e in n.elts)
    if isinstance(n, ast.Dict): return all(k is None or is_literal(k) for k in n.keys) and all(is_literal(v) for v in n.values)
    if isinstance(n, ast.UnaryOp): return is_literal(n.operand)
    if isinstance(n, ast.BinOp): return is_literal(n.left) and is_literal(n.right)
    return False


def is_const_ref(n):
    if isinstance(n, ast.Attribute): return bool(UPPER.match(n.attr)) or (is_const_ref(n.value) and not isinstance(n.value, ast.Name))
    if isinstance(n, ast.Name): return bool(UPPER.match(n.id))
    if isinstance(n, ast.Subscript):
        if isinstance(n.slice, ast.Constant) and isinstance(n.slice.value, str) and UPPER.match(n.slice.value) and isinstance(n.value, (ast.Name, ast.Attribute, ast.Subscript)): return True
        return is_const_ref(n.value) and (is_literal(n.slice) or is_const_ref(n.slice))
    if isinstance(n, (ast.Tuple, ast.List, ast.Set)): return bool(n.elts) and all(is_const_ref(e) or is_literal(e) for e in n.elts) and any(is_const_ref(e) for e in n.elts)
    if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in ('len', 'set', 'tuple', 'list', 'sorted'): return all(is_const_ref(a) for a in n.args) and bool(n.args)
    return False


def sentence(n):
    for x in ast.walk(n):
        if isinstance(x, ast.Constant) and isinstance(x.value, str) and len(x.value.split()) >= 3 and re.search(r'[A-Za-z]{3}', x.value): return True
    return False


out = {}
for r in static['tests']:
    const_only = 0; wording = 0; fps = []; total = 0
    for a in r['asserts']:
        try: node = ast.parse(a, mode='eval').body
        except SyntaxError: continue
        total += 1
        name = node.func.attr; args = node.args
        cmp = args[:2] if name in ('assertEqual', 'assertIs', 'assertNotEqual', 'assertIn', 'assertNotIn', 'assertCountEqual', 'assertGreaterEqual', 'assertLessEqual', 'assertGreater', 'assertLess', 'assertTrue', 'assertFalse', 'assertIsNone', 'assertIsNotNone', 'assertRegex') else args[:1]
        if len(cmp) == 2 and ((is_const_ref(cmp[0]) and (is_literal(cmp[1]) or is_const_ref(cmp[1]))) or (is_const_ref(cmp[1]) and is_literal(cmp[0]))):
            const_only += 1
        elif len(cmp) == 1 and isinstance(cmp[0], ast.Compare) and is_const_ref(cmp[0].left) and all(is_literal(c) or is_const_ref(c) for c in cmp[0].comparators):
            const_only += 1
        if name in ('assertEqual', 'assertIn', 'assertNotIn', 'assertRegex', 'assertNotRegex', 'assertTrue') and any(sentence(c) for c in cmp):
            wording += 1
        # fingerprint: the compared parts without the message, aliases left as written (module aliases differ: also strip them)
        core = name + '(' + ', '.join(ast.unparse(c) for c in cmp) + ')'
        fps.append(core)
    out[r['id']] = {'asserts_parsed': total, 'constant_restatements': const_only, 'wording_assertions': wording,
                    'constant_only': total > 0 and const_only == total, 'fingerprints': fps}
json.dump(out, open(sys.argv[2], 'w'), indent=1)
co = [k for k, v in out.items() if v['constant_only']]
print('constant-only tests', len(co)); [print('  ', k.split('.', 1)[1]) for k in co]
mostly = [(k, v['constant_restatements'], v['asserts_parsed']) for k, v in out.items() if not v['constant_only'] and v['constant_restatements'] and v['constant_restatements'] / v['asserts_parsed'] >= 0.5]
print('half or more', len(mostly)); [print('  ', k.split('.', 1)[1], c, t) for k, c, t in mostly]
