"""Run one tests_integrated module (the way `python -m unittest tests_integrated.X` does, one module per process) and write a
JSON record: every test id with its outcome and its own duration, plus module-level errors (setUpClass, import)."""
import json, sys, time, unittest, io
from pathlib import Path

root = Path.cwd(); sys.path.insert(0, str(root))
name, out = sys.argv[1], Path(sys.argv[2])
t0 = time.time()
rows = {}


class Result(unittest.TextTestResult):
    def _row(self, test):
        return rows.setdefault(test.id(), {'outcome': None, 'seconds': None, 'detail': ''})

    def addSuccess(self, test):
        super().addSuccess(test); self._row(test)['outcome'] = self._row(test)['outcome'] or 'ok'

    def addFailure(self, test, err):
        super().addFailure(test, err); r = self._row(test); r['outcome'] = 'FAIL'; r['detail'] = self.failures[-1][1][-1500:]

    def addError(self, test, err):
        super().addError(test, err); r = self._row(test); r['outcome'] = 'ERROR'; r['detail'] = self.errors[-1][1][-1500:]

    def addSkip(self, test, reason):
        super().addSkip(test, reason); r = self._row(test); r['outcome'] = 'skip'; r['detail'] = reason

    def addExpectedFailure(self, test, err):
        super().addExpectedFailure(test, err); self._row(test)['outcome'] = 'xfail'

    def addUnexpectedSuccess(self, test):
        super().addUnexpectedSuccess(test); self._row(test)['outcome'] = 'xpass'

    def addSubTest(self, test, subtest, err):
        super().addSubTest(test, subtest, err)
        if err is not None:
            r = self._row(test); r['outcome'] = 'FAIL'; r['detail'] = (r['detail'] + '\n[subtest] ' + str(subtest))[-1500:]

    def addDuration(self, test, elapsed):
        super().addDuration(test, elapsed); self._row(test)['seconds'] = round(elapsed, 3)


load_error = None
try:
    suite = unittest.defaultTestLoader.loadTestsFromName('tests_integrated.' + name)
except Exception as exc:  # noqa
    load_error = repr(exc); suite = unittest.TestSuite()
stream = io.StringIO()
runner = unittest.TextTestRunner(stream=stream, verbosity=1, resultclass=Result)
t1 = time.time()
result = runner.run(suite)
t2 = time.time()
out.write_text(json.dumps({'module': name, 'load_error': load_error, 'import_seconds': round(t1 - t0, 3),
                           'run_seconds': round(t2 - t1, 3), 'tests_run': result.testsRun,
                           'was_successful': result.wasSuccessful(), 'tests': rows,
                           'loaded_workbench': sorted(m for m in list(sys.modules) if m == 'workbench' or m.startswith('workbench.')),
                           'tail': stream.getvalue()[-3000:]}, indent=1))
sys.exit(0 if result.wasSuccessful() and not load_error else 1)
