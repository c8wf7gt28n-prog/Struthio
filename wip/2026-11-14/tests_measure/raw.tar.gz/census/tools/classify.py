"""Kind of each test (BEHAVIOUR / CONTRACT / LOOK / TEXT): the hand table kinds_hand.txt (module default plus name-fragment
overrides, read from the test names and assertion bodies), with a keyword score kept beside it as a cross-check.
usage: classify.py <static.json> <kinds_hand.txt> <out.json>"""
import json, re, sys, collections

static = json.load(open(sys.argv[1]))
K = {'B': 'BEHAVIOUR', 'C': 'CONTRACT', 'L': 'LOOK', 'T': 'TEXT'}
table = {}
for line in open(sys.argv[2]):
    line = line.strip()
    if not line or line.startswith('#'): continue
    mod, rest = line.split(':', 1)
    default, _, over = rest.partition('|')
    table[mod.strip()] = (K[default.strip()], [(f.split('=')[0], K[f.split('=')[1]]) for f in over.split()])
LOOK = re.compile(r'colou?r|palette|pixel|\bpx\b|width|height|font|glyph|icon|band|grain|tone|coat|glow|neon|layout|margin|gap|centred|'
                  r'mirror|geometry|rect|inset|pose|draw|paint|alpha|stroke|scale|tile|hairline|pointer|align|spacing|QColor|#[0-9a-fA-F]{6}', re.I)
TEXT = re.compile(r'\bwords?\b|says|named|label|title|tooltip|wording|\.text\(\)|caption|message|phrase|literal|heading', re.I)
used = collections.Counter(); rows = []
for r in static['tests']:
    default, over = table[r['module']]
    kind, how = default, 'module-default'
    for frag, k in over:
        if frag in r['id'].split('.', 2)[2]:
            kind, how = k, 'named'; used[(r['module'], frag)] += 1; break
    src = r['source']
    rows.append({'id': r['id'], 'kind': kind, 'kind_source': how,
                 'look_signals': len(LOOK.findall(src)), 'text_signals': len(TEXT.findall(src))})
unused = [(m, f) for m, (d, o) in table.items() for f, k in o if (m, f) not in used]
json.dump(rows, open(sys.argv[3], 'w'), indent=1)
print(collections.Counter(r['kind'] for r in rows)); print('unused overrides', unused)
