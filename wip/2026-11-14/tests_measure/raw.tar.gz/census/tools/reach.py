"""Static reachability of workbench modules from the program's start points (the start scripts' python -m workbench.X), over
import statements anywhere in a module (lazy ones included) and 'workbench.x' strings (import_module, -m children). Joined
with importmap.json: modules no test loads, split into reachable from a start (live, untested) and reachable from nothing.
usage: reach.py <tree> <importmap.json> <out.json>"""
import ast, glob, json, re, sys
from pathlib import Path

TREE = Path(sys.argv[1]); imap = json.load(open(sys.argv[2]))
WB = {}
for p in glob.glob(str(TREE / 'workbench/**/*.py'), recursive=True):
    m = Path(p).relative_to(TREE).with_suffix('').as_posix().replace('/', '.'); WB[m[:-9] if m.endswith('.__init__') else m] = p
VIEWDIR = {Path(p).stem for p in glob.glob(str(TREE / 'workbench/view_modules/*.py'))}


def edges(m):
    src = Path(WB[m]).read_text(errors='replace'); out = set()
    try: tree = ast.parse(src)
    except SyntaxError: return out
    pkg = m.rsplit('.', 1)[0] if not WB[m].endswith('__init__.py') else m
    for n in ast.walk(tree):
        if isinstance(n, ast.Import):
            for a in n.names:
                if a.name in WB: out.add(a.name)
        elif isinstance(n, ast.ImportFrom):
            base = n.module or ''
            if n.level: base = '.'.join(pkg.split('.')[:len(pkg.split('.')) - n.level + 1] + ([n.module] if n.module else []))
            for a in n.names:
                if base + '.' + a.name in WB: out.add(base + '.' + a.name)
                elif base in WB: out.add(base)
        elif isinstance(n, ast.Constant) and isinstance(n.value, str):
            for s in re.findall(r'workbench[./][A-Za-z_][\w./]*', n.value):
                s = s.replace('/', '.').removesuffix('.py')
                parts = s.split('.')
                for i in range(len(parts), 1, -1):
                    if '.'.join(parts[:i]) in WB: out.add('.'.join(parts[:i])); break
            if n.value in VIEWDIR: out.add('workbench.view_modules.' + n.value)
    return out


graph = {m: edges(m) for m in WB}
scripts = ' '.join(Path(p).read_text(errors='replace') for p in glob.glob(str(TREE / '*.sh')) + glob.glob(str(TREE / '*.cmd')) + [str(TREE / 'arc1')] if Path(p).is_file())
roots = {('workbench.' + s) for s in re.findall(r'-m workbench\.([\w.]+)', scripts) if 'workbench.' + s in WB} | {'workbench.launch'}
seen = set(); stack = list(roots)
while stack:
    m = stack.pop()
    if m in seen: continue
    seen.add(m); stack.extend(graph[m] - seen)
not_loaded = imap['not_loaded_by_any_test']
live = [r for r in not_loaded if r['module'] in seen]; dead = [r for r in not_loaded if r['module'] not in seen]
importers = {m: sorted(k for k, v in graph.items() if m in v) for m in WB}
out = {'roots': sorted(roots), 'reachable_from_start': len(seen), 'modules': len(WB),
       'unreachable_from_start': sorted(m for m in WB if m not in seen),
       'not_loaded_by_tests_but_reachable': [dict(r, importers=importers[r['module']][:8]) for r in sorted(live, key=lambda r: -r['lines'])],
       'not_loaded_by_tests_and_unreachable': [dict(r, importers=importers[r['module']][:8]) for r in sorted(dead, key=lambda r: -r['lines'])]}
json.dump(out, open(sys.argv[3], 'w'), indent=1)
print('roots', sorted(roots)); print('reachable', len(seen), 'of', len(WB), 'unreachable', len(WB) - len(seen))
print('not loaded by tests:', len(not_loaded), '| reachable (live, untested):', len(live), sum(r['lines'] for r in live), '| unreachable:', len(dead), sum(r['lines'] for r in dead))
print('live untested:', ' '.join('%s(%d)' % (r['module'][10:], r['lines']) for r in sorted(live, key=lambda r: -r['lines'])[:30]))
print('unreachable untested:', ' '.join('%s(%d)' % (r['module'][10:], r['lines']) for r in sorted(dead, key=lambda r: -r['lines'])[:40]))
