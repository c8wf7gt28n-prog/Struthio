"""Import map: test module -> source modules, (a) named in its import statements or patch/import strings (static, direct) and
(b) loaded in its process while it ran (runtime, transitive; from run_one's loaded_workbench). Then the workbench modules no test
module imports directly, and those no test module even loads; each also checked against the tools/check_*_ui.py scripts' imports.
usage: importmap.py <tree> <runs_dir> <out.json>"""
import ast, glob, json, re, sys
from pathlib import Path

TREE = Path(sys.argv[1]); RUNS = Path(sys.argv[2])
WB = set()
for p in glob.glob(str(TREE / 'workbench/**/*.py'), recursive=True):
    m = Path(p).relative_to(TREE).with_suffix('').as_posix().replace('/', '.'); WB.add(m[:-9] if m.endswith('.__init__') else m)
LINES = {m: len((TREE / (m.replace('.', '/') + ('/__init__.py' if (TREE / m.replace('.', '/')).is_dir() else '.py'))).read_text(errors='replace').splitlines()) for m in WB}


def direct(path):
    tree = ast.parse(Path(path).read_text()); found = set()
    for n in ast.walk(tree):
        if isinstance(n, ast.Import):
            for a in n.names:
                if a.name.startswith('workbench'): found.add(a.name)
        elif isinstance(n, ast.ImportFrom) and n.module and n.module.startswith('workbench'):
            for a in n.names:
                full = n.module + '.' + a.name
                found.add(full if full in WB else n.module)
        elif isinstance(n, ast.Constant) and isinstance(n.value, str):
            for s in re.findall(r'\bworkbench\.[A-Za-z_][\w.]*', n.value):
                parts = s.split('.')
                for i in range(len(parts), 1, -1):
                    if '.'.join(parts[:i]) in WB: found.add('.'.join(parts[:i])); break
            for s in re.findall(r'\bworkbench/([\w/]+)\.py', n.value):
                if 'workbench.' + s.replace('/', '.') in WB: found.add('workbench.' + s.replace('/', '.'))
    return {f for f in found if f in WB}


tests = sorted(glob.glob(str(TREE / 'tests_integrated/*.py')))
static = {Path(p).stem: sorted(direct(p)) for p in tests}
runtime = {}
for p in tests:
    name = Path(p).stem; seen = set()
    for f in glob.glob(str(RUNS / 'run*' / (name + '.json'))):
        try: seen |= set(json.load(open(f)).get('loaded_workbench', []))
        except ValueError: pass
    runtime[name] = sorted(m for m in seen if m in WB)
ui = {}
for p in sorted(glob.glob(str(TREE / 'tools/check_*_ui.py'))):
    ui[Path(p).name] = sorted(direct(p))
direct_any = set().union(*static.values()); loaded_any = set().union(*runtime.values()); ui_any = set().union(*ui.values())
no_direct = sorted(WB - direct_any); no_load = sorted(WB - loaded_any)
out = {'test_module_imports_direct': static, 'test_module_loads_runtime': {k: v for k, v in runtime.items()},
       'ui_check_imports_direct': ui,
       'workbench_modules': len(WB), 'workbench_lines': sum(LINES.values()),
       'imported_directly_by_some_test': len(direct_any), 'loaded_by_some_test': len(loaded_any),
       'not_imported_directly_by_any_test': [{'module': m, 'lines': LINES[m], 'loaded_by_tests': m in loaded_any, 'imported_by_ui_checks': m in ui_any} for m in no_direct],
       'not_loaded_by_any_test': [{'module': m, 'lines': LINES[m], 'imported_by_ui_checks': m in ui_any} for m in no_load]}
json.dump(out, open(sys.argv[3], 'w'), indent=1)
print('workbench modules', len(WB), 'lines', sum(LINES.values()))
print('imported directly by some test', len(direct_any), 'loaded at runtime by some test', len(loaded_any))
print('not imported directly', len(no_direct), 'lines', sum(LINES[m] for m in no_direct))
print('not loaded at all', len(no_load), 'lines', sum(LINES[m] for m in no_load), 'of which ui-check imported', len(set(no_load) & ui_any))
