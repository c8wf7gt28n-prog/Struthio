"""Static census of tests_integrated: every test function with its line span, assertion count (direct, and through helpers in
the same module), the workbench / tools / sdk modules it reaches through names it uses, tautologies and constant-restatements.
usage: static.py <tree> <out.json>"""
import ast, glob, json, re, sys
from pathlib import Path

TREE = Path(sys.argv[1]).resolve(); OUT = Path(sys.argv[2])
WB = {Path(p).relative_to(TREE).with_suffix('').as_posix().replace('/', '.') for p in glob.glob(str(TREE / 'workbench/**/*.py'), recursive=True)}
WB = {m[:-9] if m.endswith('.__init__') else m for m in WB}
for p in glob.glob(str(TREE / '*.py')) + glob.glob(str(TREE / 'tools/*.py')) + glob.glob(str(TREE / 'sdk/**/*.py'), recursive=True):
    m = Path(p).relative_to(TREE).with_suffix('').as_posix().replace('/', '.'); WB.add(m[:-9] if m.endswith('.__init__') else m)
ROOTS = ('workbench', 'tools', 'sdk', 'tests_integrated', 'INSTALL_LS', 'prepare_release')
SCRIPTS = {Path(p).name: Path(p).relative_to(TREE).as_posix() for p in glob.glob(str(TREE / '*.sh')) + glob.glob(str(TREE / '*.cmd')) + glob.glob(str(TREE / 'tools/*.py')) + glob.glob(str(TREE / 'tools/*.sh'))}
ASSERT_RE = re.compile(r'^(assert|fail)')


def is_assert_call(node):
    if isinstance(node, ast.Call):
        f = node.func
        if isinstance(f, ast.Attribute) and ASSERT_RE.match(f.attr) and isinstance(f.value, ast.Name) and f.value.id in ('self', 'cls', 'case', 'test', 't', 'tc'):
            return True
    return False


def own_module(name):
    """the longest known module prefix of a dotted name"""
    parts = name.split('.')
    for i in range(len(parts), 0, -1):
        cand = '.'.join(parts[:i])
        if cand in WB or cand.startswith(('tools.', 'sdk.', 'tests_integrated.')):
            return cand
    return None


def import_bindings(nodes):
    """alias -> module for imports among nodes (walks them)"""
    out = {}
    for node in nodes:
        for n in ast.walk(node):
            if isinstance(n, ast.Import):
                for a in n.names:
                    if a.name.split('.')[0] in ROOTS:
                        if a.asname: out[a.asname] = a.name
                        else: out[a.name.split('.')[0]] = a.name.split('.')[0]; out.setdefault('__dotted__' + a.name, a.name)
            elif isinstance(n, ast.ImportFrom) and n.module and n.module.split('.')[0] in ROOTS:
                for a in n.names:
                    full = n.module + '.' + a.name
                    mod = full if (full in WB or n.module in ('tools', 'sdk', 'tests_integrated') or n.module == 'workbench') else n.module
                    out[a.asname or a.name] = mod
    return out


def strings_naming_modules(node):
    found = set()
    for n in ast.walk(node):
        if isinstance(n, ast.Constant) and isinstance(n.value, str) and re.match(r'^(workbench|tools)\.[\w.]+$', n.value):
            m = own_module(n.value)
            if m: found.add(m)
        if isinstance(n, ast.Constant) and isinstance(n.value, str) and re.match(r'^(workbench|tools)/[\w/]+\.py$', n.value):
            found.add(n.value[:-3].replace('/', '.'))
        if isinstance(n, ast.Constant) and isinstance(n.value, str):
            base = n.value.rsplit('/', 1)[-1]
            if base in SCRIPTS:
                sp = SCRIPTS[base]; found.add(sp[:-3].replace('/', '.') if sp.endswith('.py') else 'script:' + sp)
    return found


def names_used(node):
    s = set()
    for n in ast.walk(node):
        if isinstance(n, ast.Name): s.add(n.id)
        elif isinstance(n, ast.Attribute):
            # dotted chains like workbench.x.y
            chain = []; cur = n
            while isinstance(cur, ast.Attribute): chain.append(cur.attr); cur = cur.value
            if isinstance(cur, ast.Name): s.add(cur.id + '.' + '.'.join(reversed(chain)))
    return s


rows = []; modules = {}
for path in sorted(glob.glob(str(TREE / 'tests_integrated/*.py'))):
    mod = Path(path).stem; src = Path(path).read_text(); tree = ast.parse(src); lines = src.splitlines()
    top_imports = import_bindings([n for n in tree.body if isinstance(n, (ast.Import, ast.ImportFrom))])
    module_setup = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in ('setUpModule', 'tearDownModule')]
    # helpers: module-level functions and class methods not named test*
    funcs = {}
    for n in tree.body:
        if isinstance(n, ast.FunctionDef): funcs[n.name] = n
        if isinstance(n, ast.ClassDef):
            for m in n.body:
                if isinstance(m, ast.FunctionDef) and not m.name.startswith('test'): funcs.setdefault(n.name + '.' + m.name, m); funcs.setdefault(m.name, m)
    direct = {k: sum(1 for x in ast.walk(v) if is_assert_call(x) or isinstance(x, ast.Assert)) for k, v in funcs.items()}

    def called(node):
        out = set()
        for x in ast.walk(node):
            if isinstance(x, ast.Call):
                f = x.func
                if isinstance(f, ast.Name) and f.id in funcs: out.add(f.id)
                if isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name) and f.value.id in ('self', 'cls') and f.attr in funcs: out.add(f.attr)
        return out

    helper_asserts = {}
    def helper_total(name, seen=()):
        if name in seen: return 0
        if name in helper_asserts: return helper_asserts[name]
        t = direct.get(name, 0) + sum(helper_total(c, seen + (name,)) for c in called(funcs[name]))
        helper_asserts[name] = t; return t

    class_info = {}
    for cls in [n for n in tree.body if isinstance(n, ast.ClassDef)]:
        setup_nodes = [m for m in cls.body if isinstance(m, ast.FunctionDef) and m.name in ('setUp', 'setUpClass', 'tearDown', 'tearDownClass', 'asyncSetUp')]
        decorators = [ast.unparse(d) for d in cls.decorator_list]
        for m in cls.body:
            if not (isinstance(m, (ast.FunctionDef, ast.AsyncFunctionDef)) and m.name.startswith('test')): continue
            body_src = '\n'.join(lines[m.lineno - 1:m.end_lineno])
            setup_nodes = setup_nodes + module_setup
            local_imports = import_bindings([m] + setup_nodes)
            bindings = dict(top_imports); bindings.update(local_imports)
            used = names_used(m)
            for h in called(m):
                used |= names_used(funcs[h])
                bindings.update(import_bindings([funcs[h]]))
            for s in setup_nodes: used |= names_used(s)
            reached = set()
            for alias, target in bindings.items():
                if alias.startswith('__dotted__'):
                    if any(u == target or u.startswith(target + '.') for u in used): reached.add(target)
                    continue
                if alias in used or any(u.startswith(alias + '.') for u in used):
                    if target in ('workbench', 'tools', 'sdk'):
                        for u in used:
                            if u.startswith(alias + '.'):
                                mm = own_module(u)
                                if mm: reached.add(mm)
                    else:
                        reached.add(target)
            reached |= strings_naming_modules(m)
            for s in setup_nodes: reached |= strings_naming_modules(s)
            n_direct = sum(1 for x in ast.walk(m) if is_assert_call(x) or isinstance(x, ast.Assert))
            helpers = sorted(called(m)); n_helper = sum(helper_total(h) for h in helpers)
            # assertion calls list (unparsed) for duplicate search
            calls = [ast.unparse(x) for x in ast.walk(m) if is_assert_call(x)]
            kinds = {}
            for x in ast.walk(m):
                if is_assert_call(x): kinds[x.func.attr] = kinds.get(x.func.attr, 0) + 1
            taut = [ast.unparse(x) for x in ast.walk(m) if is_assert_call(x) and len(x.args) >= 2 and ast.dump(x.args[0]) == ast.dump(x.args[1])]
            rows.append({'id': 'tests_integrated.%s.%s.%s' % (mod, cls.name, m.name), 'module': mod, 'class': cls.name, 'name': m.name,
                         'line': m.lineno, 'end_line': m.end_lineno, 'lines': m.end_lineno - m.lineno + 1,
                         'class_decorators': decorators,
                         'assert_direct': n_direct, 'assert_via_helpers': n_helper, 'helpers': helpers,
                         'assert_kinds': kinds, 'asserts': calls, 'tautologies': taut,
                         'imports': sorted(r for r in reached if r and (r.split('.')[0] in ROOTS or r.startswith('script:')) and not r.startswith('tests_integrated')),
                         'raises_check': any(isinstance(x, ast.With) and any('assertRaises' in ast.unparse(i.context_expr) for i in x.items) for x in ast.walk(m)),
                         'source': body_src})
    modules[mod] = {'lines': len(lines), 'top_imports': top_imports}
OUT.write_text(json.dumps({'tests': rows, 'modules': modules}, indent=1))
print(len(rows), 'tests')
