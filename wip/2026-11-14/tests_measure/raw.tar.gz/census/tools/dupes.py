"""Near-duplicate checks across modules: (1) the same assertion (compared parts, module aliases resolved to module paths, the
message dropped) in tests of two different modules; (2) test bodies whose identifier+literal token sets overlap (Jaccard) across
modules.  usage: dupes.py <tree> <static.json> <constants.json> <out.json>"""
import ast, json, re, sys, itertools, collections
from pathlib import Path

TREE = Path(sys.argv[1]); static = json.load(open(sys.argv[2])); consts = json.load(open(sys.argv[3]))
bind_cache = {}


def bindings(module):
    if module in bind_cache: return bind_cache[module]
    tree = ast.parse((TREE / 'tests_integrated' / (module + '.py')).read_text()); b = {}
    for n in ast.walk(tree):
        if isinstance(n, ast.ImportFrom) and n.module and n.module.startswith('workbench'):
            for a in n.names: b[a.asname or a.name] = n.module + '.' + a.name if n.module == 'workbench' else n.module + '.' + a.name
        if isinstance(n, ast.Import):
            for a in n.names:
                if a.asname: b[a.asname] = a.name
    bind_cache[module] = b; return b


class Resolve(ast.NodeTransformer):
    def __init__(self, b): self.b = b
    def visit_Name(self, n):
        if n.id in self.b: return ast.copy_location(ast.Name(id=self.b[n.id], ctx=n.ctx), n)
        return n


rows = {r['id']: r for r in static['tests']}
by_fp = collections.defaultdict(set)
for tid, c in consts.items():
    mod = rows[tid]['module']; b = bindings(mod)
    for fp in c['fingerprints']:
        try: node = ast.parse(fp, mode='eval').body
        except SyntaxError: continue
        norm = ast.unparse(Resolve(b).visit(node))
        if len(norm) < 40: continue   # tiny checks (assertTrue(ok)) say nothing
        if not re.search(r'workbench\.|[A-Z]{3,}', norm): continue   # only checks that name program code or constants
        by_fp[norm].add(tid)
same_assert = []
for fp, tids in by_fp.items():
    mods = {rows[t]['module'] for t in tids}
    if len(mods) > 1: same_assert.append({'assertion': fp, 'tests': sorted(tids)})

TOK = re.compile(r"[A-Za-z_][A-Za-z0-9_]{2,}|'[^']{4,}'")
STOP = set('self assertEqual assertTrue assertFalse assertIn assertNotIn assertIs assertIsNone assertIsNotNone assertGreater assertLess '
           'assertGreaterEqual assertLessEqual assertRaises def test with for None True False lambda return import from and not '
           'Path temp tempfile TemporaryDirectory folder patch object dict list set tuple len str int range enumerate'.split())
toks = {}
for r in static['tests']:
    t = {x for x in TOK.findall(r['source']) if x not in STOP and not x.startswith('test_')}
    if len(t) >= 12: toks[r['id']] = t
similar = []
ids = sorted(toks)
for a, b in itertools.combinations(ids, 2):
    if rows[a]['module'] == rows[b]['module']: continue
    inter = len(toks[a] & toks[b])
    if inter < 10: continue
    j = inter / len(toks[a] | toks[b])
    if j >= 0.40: similar.append({'a': a, 'b': b, 'jaccard': round(j, 2), 'shared': sorted(toks[a] & toks[b])[:25]})
similar.sort(key=lambda x: -x['jaccard'])
json.dump({'same_assertion_across_modules': same_assert, 'similar_bodies_across_modules': similar}, open(sys.argv[4], 'w'), indent=1)
print('same assertion across modules:', len(same_assert))
for s in same_assert[:60]: print('  ', s['assertion'][:150], '|', ' & '.join(t.split('.', 1)[1] for t in s['tests']))
print('similar bodies:', len(similar))
for s in similar[:40]: print('  ', s['jaccard'], s['a'].split('.', 1)[1], '~', s['b'].split('.', 1)[1])
