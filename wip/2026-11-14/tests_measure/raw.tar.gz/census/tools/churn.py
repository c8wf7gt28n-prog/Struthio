"""Churn of every tests_integrated file in /home/user/Struthio up to d1df337 (git log --follow): the commits that touched it, the
test functions each commit added / changed / removed (bodies compared by AST between the commit and its parent), and whether the
same commit also changed look or theme files (palettes, brand, glyphs, faces, desk geometry, pictures, fonts).
Read-only on the repository.  usage: churn.py <repo> <rev> <out.json>"""
import ast, json, re, subprocess, sys, collections

REPO, REV, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
LOOK_FILE = re.compile(r'^(workbench/(qt_theme|boss_theme|theme2|graphite_brand|glyph_set|tool_faces|page_light|menu_catch|chain_icons|'
                       r'editorial_art|idle_display_art|kasandra_art|desk_qt|pane_qt|equalizer_qt|writing_marker)\.py|'
                       r'workbench/nav_icons/.*|branding/.*|.*\.(png|svg|webp|jpg|ttf|otf|qss))$')
LOOK_SUBJECT = re.compile(r'look|colour|color|palette|glow|neon|amber|green|purple|white boxes|pointer|icon|glyph|face|monogram|'
                          r'appearance|typewriter|sleek|tidy|plate|eye|pass for the eye|simple at rest|picture|light in it|telephone poles|'
                          r'trace|catch|lands|after hours|shape', re.I)


def git(*a):
    return subprocess.run(['git', '-C', REPO] + list(a), capture_output=True, text=True).stdout


def tests_in(src):
    try: tree = ast.parse(src)
    except SyntaxError: return {}
    out = {}
    for c in tree.body:
        if isinstance(c, ast.ClassDef):
            for m in c.body:
                if isinstance(m, ast.FunctionDef) and m.name.startswith('test'):
                    out[c.name + '.' + m.name] = ast.dump(m, include_attributes=False)
    return out


files = sorted(l for l in git('ls-tree', '--name-only', REV, 'tests_integrated/').split() if l.endswith('.py'))
result = {}
for f in files:
    log = git('log', '--follow', '--format=@%H %s', '--name-status', REV, '--', f)
    commits = []; cur = None
    for line in log.splitlines():
        if line.startswith('@'):
            h, s = line[1:].split(' ', 1); cur = {'commit': h[:7], 'subject': s, 'path': None}; commits.append(cur)
        elif line.strip() and cur is not None:
            parts = line.split('\t'); cur['path'] = parts[-1]; cur['old_path'] = parts[1] if parts[0].startswith('R') else parts[-1]
    rows = []
    for c in commits:
        changed = git('show', '--name-only', '--format=', c['commit']).split()
        look_files = [x for x in changed if LOOK_FILE.match(x)]
        after = tests_in(git('show', '%s:%s' % (c['commit'], c['path'])))
        parent_ok = subprocess.run(['git', '-C', REPO, 'rev-parse', '--verify', '-q', c['commit'] + '^'], capture_output=True).returncode == 0
        before = tests_in(git('show', '%s^:%s' % (c['commit'], c['old_path']))) if parent_ok else {}
        added = sorted(set(after) - set(before)); removed = sorted(set(before) - set(after))
        modified = sorted(k for k in set(after) & set(before) if after[k] != before[k])
        rows.append({'commit': c['commit'], 'subject': c['subject'], 'files_in_commit': len(changed), 'look_files': look_files[:20],
                     'n_look_files': len(look_files), 'look_subject': bool(LOOK_SUBJECT.search(c['subject'])),
                     'is_import': not parent_ok, 'added': added, 'modified': modified, 'removed': removed})
    result[f.split('/')[-1][:-3]] = rows
per_test = collections.defaultdict(lambda: {'commits': 0, 'look_commits': 0, 'subjects': []})
for mod, rows in result.items():
    for r in rows:
        if r['is_import']: continue
        for t in r['modified'] + r['added']:
            k = mod + '.' + t; per_test[k]['commits'] += 1
            if r['n_look_files'] or r['look_subject']: per_test[k]['look_commits'] += 1
            per_test[k]['subjects'].append(r['commit'] + ' ' + r['subject'][:80])
json.dump({'files': result, 'per_test': per_test}, open(OUT, 'w'), indent=1)
for mod, rows in result.items():
    real = [r for r in rows if not r['is_import']]
    print(mod, 'commits', len(rows), 'after import', len(real), 'with look files', sum(1 for r in real if r['n_look_files']),
          'look subject', sum(1 for r in real if r['look_subject']))
