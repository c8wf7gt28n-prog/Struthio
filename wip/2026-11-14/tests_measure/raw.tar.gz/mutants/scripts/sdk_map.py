"""Line map for files outside workbench/ that the mutants part samples (sdk/cli/arc1cli/typed_pipeline.py), built from the
coverage part's second run (data_other/), in the same shape as line_map.json."""
import collections, json, sqlite3, sys
from pathlib import Path
C = Path('/tmp/claude-0/-home-user-Struthio/62270cd8-8155-590e-b29e-91307882a142/scratchpad/work/testclean/coverage')
sys.path.insert(0, str(C / 'lib'))
import coverage
from coverage.python import PythonFileReporter
WANT = sys.argv[1:] or ['sdk/cli/arc1cli/typed_pipeline.py']
lm = json.loads((C / 'line_map.json').read_text())
mods = lm['modules']
cov = coverage.Coverage(config_file=False, branch=True, data_file=None)
out = {'modules': mods, 'files': {}, 'statements': {}}
for rel in WANT:
    p = str(C / 'tree' / rel)
    fr = PythonFileReporter(p, cov); st = fr.lines()
    m2l = collections.defaultdict(set)
    for i, m in enumerate(mods):
        d = C / 'data_other' / m
        if not d.is_dir(): continue
        for f in d.glob('.coverage*'):
            con = sqlite3.connect(str(f))
            ids = [fid for fid, path in con.execute('select id, path from file') if path == p]
            for fid in ids:
                for a, b in con.execute('select fromno, tono from arc where file_id=?', (fid,)):
                    m2l[i].update(x for x in (a, b) if x > 0)
            con.close()
    lines = collections.defaultdict(list)
    for i, ls in m2l.items():
        for l in fr.translate_lines(ls) & st: lines[str(l)].append(i)
    out['files'][rel] = {k: sorted(v) for k, v in sorted(lines.items(), key=lambda kv: int(kv[0]))}
    out['statements'][rel] = sorted(st)
    print(rel, len(st), len(lines), collections.Counter(mods[i] for v in lines.values() for i in v).most_common())
Path(sys.argv[0]).resolve().parent.parent.joinpath('sdk_line_map.json').write_text(json.dumps(out))
