"""Shared helpers for the mutants part: run one test module of a tree at nice 19 in a private pid namespace with a fresh
empty HOME, and read back the per-test JSON lines that runmod.py wrote."""
import json, os, re, shutil, subprocess, time
from pathlib import Path

S = Path('/tmp/claude-0/-home-user-Struthio/62270cd8-8155-590e-b29e-91307882a142/scratchpad')
W = S / 'work/testclean/mutants'
PY = str(S / 'work/venv/bin/python')
RUNMOD = str(W / 'scripts/runmod.py')
BASE = json.loads((S / 'work/modules_082.json').read_text())


def bad_ids(module):
    """modules_082.json 'bad' entries look like 'name (pkg.mod.Class.name)': return the dotted ids."""
    return [re.search(r'\((\S+)\)', b).group(1) for b in (BASE.get(module, {}).get('bad') or [])]


def run_module(tree, module, tag, timeout, failfast=False, exclude=(), only=None):
    home = W / 'homes' / tag
    if home.exists(): shutil.rmtree(home, ignore_errors=True)
    home.mkdir(parents=True)
    out = W / 'logs' / (tag + '.jsonl')
    if out.exists(): out.unlink()
    env = dict(os.environ, QT_QPA_PLATFORM='offscreen', PYTHONDONTWRITEBYTECODE='1', HOME=str(home))
    for k in ('COVERAGE_PROCESS_START', 'COVERAGE_PROCESS_CONFIG', 'PYTHONPATH'):
        env.pop(k, None)
    cmd = ['nice', '-n', '19', 'unshare', '--pid', '--fork', '--mount-proc', '--kill-child',
           PY, '-B', RUNMOD, str(tree), module, str(out)] + (['--failfast'] if failfast else [])
    if exclude: cmd += ['--exclude'] + list(exclude)
    if only: cmd += ['--only'] + list(only)
    t = time.time()
    try:
        r = subprocess.run(cmd, cwd=str(tree), env=env, capture_output=True, text=True, timeout=timeout)
        code = r.returncode; tail = (r.stderr or '')[-3000:]
    except subprocess.TimeoutExpired as exc:
        code = 'timeout'; tail = (exc.stderr.decode('utf-8', 'replace') if isinstance(exc.stderr, bytes) else (exc.stderr or ''))[-3000:]
    sec = round(time.time() - t, 2)
    rows = []
    if out.exists():
        for line in out.read_text().splitlines():
            try: rows.append(json.loads(line))
            except Exception: pass
    shutil.rmtree(home, ignore_errors=True)
    ends = [r for r in rows if r.get('ev') == 'end']
    bad = [r for r in ends if r['outcome'] in ('fail', 'error', 'xpass')]
    done = next((r for r in rows if r.get('ev') == 'done'), None)
    load_error = next((r for r in rows if r.get('ev') == 'load_error'), None)
    running = None
    starts = [r['id'] for r in rows if r.get('ev') == 'start']
    if starts and (not ends or ends[-1]['id'] != starts[-1]): running = starts[-1]
    return {'code': code, 'sec': sec, 'n_end': len(ends), 'bad': [{'id': b['id'], 'outcome': b['outcome'], 'err': b['err']} for b in bad],
            'done': done, 'load_error': load_error, 'running_at_stop': running, 'tail': tail if code not in (0,) else '',
            'tests': [(r['id'], r['outcome'], r['sec']) for r in ends]}
