"""Record a hand classification of a surviving mutant into classify.json.
usage: cls.py ID equivalent|gap "why / what went unguarded" [severity]
severity of a gap: real (behaviour a person or the data would see), low (drawing / layout only), boundary (a limit moved by
one unit, seen only exactly at the limit)."""
import json, sys
from mutlib import W
p = W / 'classify.json'
d = json.loads(p.read_text()) if p.exists() else {}
i, c, why = sys.argv[1], sys.argv[2], sys.argv[3]
assert c in ('equivalent', 'gap')
sev = sys.argv[4] if len(sys.argv) > 4 else ('real' if c == 'gap' else None)
if why.startswith('low:'): sev = 'low'; why = why[4:].strip()
assert sev in (None, 'real', 'low', 'boundary')
d[i] = {'class': c, 'why': why, 'severity': sev}
p.write_text(json.dumps(d, indent=1, sort_keys=True))
print(i, c)
