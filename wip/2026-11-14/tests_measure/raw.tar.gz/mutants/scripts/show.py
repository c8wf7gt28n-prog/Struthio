"""Print the survivors (or given ids) with their source context, for classifying equivalent mutants by hand.
usage: show.py [ID ...] [--ctx N]"""
import json, sys
from mutlib import W
args = sys.argv[1:]
ctx = 6
if '--ctx' in args:
    i = args.index('--ctx'); ctx = int(args[i + 1]); del args[i:i + 2]
rows = {}
for line in (W / 'results.jsonl').read_text().splitlines():
    r = json.loads(line); rows[r['id']] = r
ids = args or [k for k, r in sorted(rows.items()) if all(v['v'] == 'survived' for v in r['modules'].values())]
for i in ids:
    r = rows.get(i)
    if not r: print(i, 'not run'); continue
    src = (W / 'pristine' / r['file']).read_text().splitlines()
    print('=' * 100)
    print(i, '%s:%d' % (r['file'], r['line']), r['kind'], r['detail'], 'in', r['func'])
    print('   ', repr(r['old'][:200]), '->', repr(r['new'][:200]))
    print('   modules:', {m: v['v'] + ('*' if v['restricted_to'] else '') for m, v in r['modules'].items()})
    lo = max(0, r['line'] - 1 - ctx); hi = min(len(src), r['line'] + ctx)
    for n in range(lo, hi):
        print('%s%5d %s' % ('>>' if n + 1 == r['line'] else '  ', n + 1, src[n][:160]))
