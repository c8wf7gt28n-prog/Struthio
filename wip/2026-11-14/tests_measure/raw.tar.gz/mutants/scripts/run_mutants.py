"""Run the sampled mutants, one at a time per worker, in tree_a and tree_b (two workers, so never more than two test
processes). For each mutant: write the mutated file into the worker's tree, run every test module that covers the mutated
line (coverage line_map.json; sdk_line_map.json for typed_pipeline), each in its own process at nice 19 in a private pid
namespace with a fresh HOME, failfast, the module's known failing ids excluded, timeout 3x its control wall time (30 s
floor); then put the pristine file back.
The three slow modules (test_desk_acts, test_desk_scenes, test_context_menu, ~60-190 s each) run only the tests that the
per-test coverage map says execute the line (the whole module when no single test does, i.e. the line runs in setUp only);
see report. Results are appended to results.jsonl (resumable); mutants run in a shuffled order so a cut-off leaves a fair
sample.
usage: run_mutants.py [--deadline EPOCH] [--full-slow [--slow-only]] [--ids M001 ...] [--out results.jsonl]"""
import json, random, sys, threading, time
from pathlib import Path
from mutlib import W, bad_ids, run_module
from mutator import apply

args = sys.argv[1:]
def opt(name, default=None):
    if name not in args: return default
    i = args.index(name) + 1; vals = []
    while i < len(args) and not args[i].startswith('--'):
        vals.append(args[i]); i += 1
    return vals
DEADLINE = float(opt('--deadline', ['1e12'])[0])
FULL_SLOW = '--full-slow' in args
SLOW_ONLY = '--slow-only' in args   # with --full-slow: re-run just the slow modules, in full, for survivors
IDS = opt('--ids')
OUT = W / (opt('--out', ['results.jsonl'])[0])

sample = json.loads((W / 'sample.json').read_text())['mutants']
base = json.loads((W / 'baseline.json').read_text())
tlm = json.loads((W.parent / 'coverage/test_line_map.json').read_text())
TESTS = tlm['tests']
SLOW = {'test_desk_acts', 'test_desk_scenes', 'test_context_menu'}
done = set()
if OUT.exists():
    for line in OUT.read_text().splitlines():
        try: done.add(json.loads(line)['id'])
        except Exception: pass
todo = [m for m in sample if m['id'] not in done and (not IDS or m['id'] in IDS)]
random.Random(7).shuffle(todo)
lock = threading.Lock()


def covering_tests(mut, module):
    rows = tlm['files'].get(mut['file'], {}).get(str(mut['line']), [])
    ids = [TESTS[i].split('|', 1)[1] for i in rows if TESTS[i].split('|', 1)[0] == module]
    return ids


def timeout_for(module, only):
    b = base[module]
    if not only: return max(30.0, 3 * b['sec'])
    t = {tid: sec for tid, _, sec in b['tests']}
    overhead = max(0.0, b['sec'] - sum(t.values()))
    return max(30.0, 3 * (overhead + sum(t.get(i, 5.0) for i in only)))


def one(mut, tree, wname):
    path = W / tree / mut['file']
    pristine = (W / 'pristine' / mut['file']).read_text()
    assert path.read_text() == pristine, 'tree not pristine: %s %s' % (tree, mut['file'])
    rec = {'id': mut['id'], 'file': mut['file'], 'line': mut['line'], 'kind': mut['kind'], 'detail': mut['detail'],
           'old': mut['old'], 'new': mut['new'], 'func': mut['func'], 'stratum': mut['stratum'], 'tree': tree,
           'modules': {}, 't0': time.time()}
    try:
        path.write_text(apply(pristine, mut))
        order = sorted(mut['modules'], key=lambda m: base.get(m, {}).get('sec', 5))
        if SLOW_ONLY: order = [m for m in order if m in SLOW]
        for m in order:
            only = None
            if m in SLOW and not FULL_SLOW:
                only = covering_tests(mut, m) or None
            tmo = timeout_for(m, only)
            r = run_module(W / tree, m, 'mut_%s_%s' % (wname, m), timeout=tmo, failfast=True,
                           exclude=bad_ids(m), **({'only': only} if only else {}))
            if r['code'] == 'timeout': v = 'timeout'
            elif r['code'] == 0 and r['done'] and r['done'].get('ok'): v = 'survived'
            else: v = 'killed'
            rec['modules'][m] = {'v': v, 'code': r['code'], 'sec': r['sec'], 'timeout': round(tmo, 1),
                                 'restricted_to': sorted(only) if only else None, 'ran': r['n_end'],
                                 'killers': [b['id'] for b in r['bad']],
                                 'err': (r['bad'][0]['err'][-700:] if r['bad'] and r['bad'][0]['err'] else
                                         (r['load_error'] or {}).get('err') or (r['tail'][-500:] if v != 'survived' else None)),
                                 'running_at_stop': r['running_at_stop']}
    finally:
        path.write_text(pristine)
    rec['sec'] = round(time.time() - rec.pop('t0'), 1)
    with lock:
        with OUT.open('a') as f: f.write(json.dumps(rec) + '\n')
    vs = [x['v'] for x in rec['modules'].values()]
    print(mut['id'], mut['file'].split('/')[-1], mut['line'], mut['kind'], 'K%d S%d T%d' % (vs.count('killed'), vs.count('survived'), vs.count('timeout')), rec['sec'], flush=True)


def worker(tree, wname):
    while True:
        with lock:
            if not todo or time.time() > DEADLINE: return
            mut = todo.pop(0)
        one(mut, tree, wname)


th = [threading.Thread(target=worker, args=(t, n)) for t, n in (('tree_a', 'a'), ('tree_b', 'b'))]
for t in th: t.start()
for t in th: t.join()
print('DONE; left', len(todo), flush=True)
