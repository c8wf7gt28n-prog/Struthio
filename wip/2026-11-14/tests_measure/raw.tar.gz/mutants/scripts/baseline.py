"""Control run for the mutants part: every module of the line map, unmutated, in tree_a and tree_b (one worker each, so never
more than two test processes), the known failing ids of modules_082.json excluded. Gives each module's wall time (for the
3x timeout) and shows that the kept tests all pass, so any failure under a mutant is a kill.
usage: baseline.py [module ...]"""
import json, sys, threading
from mutlib import W, BASE, bad_ids, run_module

lm = json.loads((W.parent / 'coverage/line_map.json').read_text())
mods = sys.argv[1:] or sorted(lm['modules'], key=lambda m: -BASE.get(m, {}).get('seconds', 3))
OUT = W / 'baseline.json'
rows = json.loads(OUT.read_text()) if OUT.exists() else {}
lock = threading.Lock(); q = list(mods)


def worker(tree, wname):
    while True:
        with lock:
            if not q: return
            m = q.pop(0)
        r = run_module(W / tree, m, 'base_%s_%s' % (wname, m), timeout=1200, failfast=False, exclude=bad_ids(m))
        r.pop('tests_detail', None)
        with lock:
            rows[m] = {'tree': tree, 'code': r['code'], 'sec': r['sec'], 'n': r['n_end'], 'bad': r['bad'],
                       'excluded': bad_ids(m), 'base_sec_082': BASE.get(m, {}).get('seconds'),
                       'tests': r['tests'], 'done': r['done'], 'tail': r['tail'][-800:]}
            OUT.write_text(json.dumps(rows, indent=1))
        print(m, r['code'], r['n_end'], len(r['bad']), r['sec'], flush=True)


th = [threading.Thread(target=worker, args=(t, n)) for t, n in (('tree_a', 'a'), ('tree_b', 'b'))]
for t in th: t.start()
for t in th: t.join()
print('DONE', len(rows), flush=True)
