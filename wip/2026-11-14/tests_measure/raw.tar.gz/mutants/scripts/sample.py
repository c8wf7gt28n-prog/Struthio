"""Enumerate every mutation site on covered function-body lines, then draw the sample: about two thirds over the owner's
named modules (kinds balanced inside each file), about a third spread one per file over everything else.
usage: sample.py SEED N_NAMED_PER_FILE N_OTHER [--dry]"""
import collections, json, math, random, sys
from pathlib import Path
from mutator import sites, check
from mutlib import W, BASE

SEED, PER, NOTHER = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
DRY = '--dry' in sys.argv
TREE = W / 'pristine'
lm = json.loads((W.parent / 'coverage/line_map.json').read_text())
sdk = json.loads((W / 'sdk_line_map.json').read_text())
MODS = lm['modules']
files = dict(lm['files']); files.update(sdk['files'])
bl = json.loads((W / 'baseline.json').read_text()) if (W / 'baseline.json').exists() else {}


def wall(m):
    return bl[m]['sec'] if m in bl else BASE.get(m, {}).get('seconds', 3.0) + 0.3


NAMED = ['engineering_kernel', 'stacy_hand', 'desk_acts', 'desk_doers', 'resource_control', 'model_settings', 'local_brain',
         'line_steps', 'typed_pipeline', 'field_ripple', 'field_page', 'files_service', 'context_menu', 'release_integrity',
         'stacy_foundation', 'change_sets', 'continuing_work']
NAMED_FILES = {('sdk/cli/arc1cli/%s.py' if n == 'typed_pipeline' else 'workbench/%s.py') % n for n in NAMED}

pool = collections.defaultdict(list)
for rel, cov in sorted(files.items()):
    p = TREE / rel
    if not p.exists() or not rel.endswith('.py'): continue
    text = p.read_text()
    try: ss = sites(text, rel)
    except SyntaxError: continue
    for s in ss:
        mods = cov.get(str(s['line']))
        if not mods: continue
        s['modules'] = [MODS[i] for i in mods]
        s['cost'] = round(sum(wall(m) for m in s['modules']), 1)
        pool[rel].append(s)

rng = random.Random(SEED)


def draw(rel, n):
    ss = pool[rel]; got = []; used = set()
    by_kind = collections.defaultdict(list)
    for s in ss: by_kind[s['kind']].append(s)
    kinds = sorted(by_kind)
    tries = 0
    while len(got) < n and tries < 200:
        tries += 1
        k = kinds[len(got) % len(kinds)] if len(got) < len(kinds) else rng.choice(kinds)
        if len(got) == 0: rng.shuffle(kinds); k = kinds[0]
        cand = [s for s in by_kind[k] if (s['line'], s['kind']) not in used and s['line'] not in {u[0] for u in used}]
        if not cand: continue
        s = rng.choice(cand)
        if not check((TREE / rel).read_text(), s, rel): continue
        used.add((s['line'], s['kind'])); got.append(s)
    return got


sample = []
for rel in sorted(NAMED_FILES):
    got = draw(rel, PER)
    for s in got: s['stratum'] = 'named'
    sample += got
others = [r for r in pool if r not in NAMED_FILES and pool[r]]
weights = [math.sqrt(len(pool[r])) for r in others]
chosen = []
while len(chosen) < NOTHER and others:
    r = rng.choices(others, weights)[0]
    i = others.index(r); others.pop(i); weights.pop(i)
    got = draw(r, 1)
    if got:
        got[0]['stratum'] = 'other'; chosen += got
sample += chosen
for i, s in enumerate(sample): s['id'] = 'M%03d' % (i + 1)

tot = collections.Counter(); cost = collections.Counter()
for s in sample: tot[s['stratum']] += 1; cost[s['stratum']] += s['cost']
print('pool sites', sum(len(v) for v in pool.values()), 'in', len(pool), 'files; named pool',
      {r.split('/')[-1]: len(pool[r]) for r in sorted(NAMED_FILES)})
print('sample', dict(tot), 'kinds', dict(collections.Counter(s['kind'] for s in sample)))
print('worst-case worker seconds (every mutant survives)', dict(cost), round(sum(cost.values())))
print('by file', collections.Counter(s['file'].split('/')[-1] for s in sample).most_common(25))
heavy = collections.Counter(m for s in sample for m in s['modules'])
print('module runs needed', sum(heavy.values()), heavy.most_common(12))
if not DRY:
    (W / 'sample.json').write_text(json.dumps({'seed': SEED, 'per_named_file': PER, 'n_other': NOTHER, 'mutants': sample}, indent=1))
    (W / 'pool_counts.json').write_text(json.dumps({r: collections.Counter(s['kind'] for s in v) for r, v in pool.items()}, indent=1))
