"""Build kill_matrix.json from results.jsonl (+ results_full.jsonl re-runs of the slow modules when present) and the hand
classification of survivors in classify.json.
usage: analyze.py"""
import collections, json
from mutlib import W

sample = {m['id']: m for m in json.loads((W / 'sample.json').read_text())['mutants']}
base = json.loads((W / 'baseline.json').read_text())
rows = {}
for name in ('results.jsonl',):
    for line in (W / name).read_text().splitlines():
        r = json.loads(line); rows[r['id']] = r
# re-runs of a mutant's slow modules in full (results_full.jsonl) replace the restricted verdict for those modules
full = W / 'results_full.jsonl'
if full.exists():
    for line in full.read_text().splitlines():
        r = json.loads(line)
        if r['id'] in rows:
            for m, v in r['modules'].items():
                v['rerun_full'] = True
                rows[r['id']]['modules'][m] = v
cls = json.loads((W / 'classify.json').read_text()) if (W / 'classify.json').exists() else {}
lm = json.loads((W.parent / 'coverage/line_map.json').read_text())
MODS = lm['modules']
FOCUSED_OUT = {'test_exact_math_solvers'}

code = {'killed': 'K', 'survived': 'S', 'timeout': 'T'}
# Two kinds of kill that say nothing about behaviour:
#  E  the disk was full (No space left / disk I/O error): the verdict is void.
#  D  a digest kill: project/stacy_seed/current/manifest.json records the sha256 of 345 .py files; any byte changed in one of
#     them makes the program seed "not current", so the line panel cannot read its source and three broad tests fail the
#     same way whatever the mutant did (desk_acts 'then.keep' -> 'offers no rows to keep'; desk_scenes 'menu.panel.preview'
#     got []; context_menu ops lack 'ledger.address.read'). A comment edit would be killed the same way.
SEED = set(json.loads((W / 'seed_manifest_py.json').read_text()))
DIGEST_SIG = ('offers no rows to keep', "'menu.panel.preview', 'want': [{'count': 2}], 'got': []", "'ledger.address.read'")
ENV_SIG = ('No space left', 'Errno 28', 'disk I/O error', 'database or disk is full')


def verdict(r, v):
    if v['v'] != 'killed': return code[v['v']]
    e = v.get('err') or ''
    if any(x in e for x in ENV_SIG): return 'E'
    if r['file'] in SEED and any(x in e for x in DIGEST_SIG): return 'D'
    return 'K'


matrix = {i: {m: verdict(r, v) for m, v in r['modules'].items()} for i, r in sorted(rows.items())}


def detected(i):  # behaviour detections only (not digest kills, not void runs)
    return [m for m, c in matrix[i].items() if c in 'KT']


mutants = []
for i, r in sorted(rows.items()):
    det = detected(i)
    vs = set(matrix[i].values())
    st = ('killed' if 'K' in vs else 'timeout' if 'T' in vs else 'digest_only' if 'D' in vs
          else 'void' if vs <= {'E'} or ('E' in vs and r['id'] not in cls) else 'survived')
    c = cls.get(i, {})
    s = sample[i]
    mutants.append({'id': i, 'file': r['file'], 'line': r['line'], 'func': r['func'], 'kind': r['kind'], 'detail': r['detail'],
                    'old': r['old'], 'new': r['new'], 'stratum': r['stratum'], 'status': st, 'detected_by': sorted(det),
                    'covering_modules': s['modules'],
                    'verdicts': {m: dict(v=v['v'], sec=v['sec'], killers=v['killers'],
                                         restricted_to=v['restricted_to'], timeout=v['timeout'],
                                         **({'rerun_full': True} if v.get('rerun_full') else {}),
                                         **({'err': v['err'][-400:]} if v['v'] != 'survived' and v.get('err') else {}))
                                 for m, v in r['modules'].items()},
                    'equivalent': c.get('class') == 'equivalent' if st in ('survived', 'digest_only') else False,
                    'classification': c if st in ('survived', 'digest_only') else None, 'seconds': r['sec']})

allmods = sorted({m for i in matrix for m in matrix[i]} | set(MODS))
per_module = {}
for m in allmods:
    cov = [i for i in matrix if m in matrix[i]]
    k = [i for i in cov if matrix[i][m] == 'K']
    dk = [i for i in cov if matrix[i][m] == 'D']
    t = [i for i in cov if matrix[i][m] == 'T']
    uniq = [i for i in cov if matrix[i][m] in 'KT' and detected(i) == [m]]
    uniq_f = [i for i in cov if matrix[i][m] in 'KT' and [x for x in detected(i) if x not in FOCUSED_OUT] == [m]]
    secs = sum(rows[i]['modules'][m]['sec'] for i in cov)
    per_module[m] = {'covered_mutants': len(cov), 'killed': len(k), 'timeouts': len(t), 'digest_kills': len(dk),
                     'void_disk_full': sum(1 for i in cov if matrix[i][m] == 'E'),
                     'survived': sum(1 for i in cov if matrix[i][m] == 'S'), 'unique_kills': len(uniq), 'unique_ids': uniq,
                     'unique_kills_focused_only': len(uniq_f), 'seconds_spent': round(secs, 1),
                     'base_seconds': base.get(m, {}).get('sec'),
                     'kills_per_minute_of_baseline': round(len(k + t) / (base[m]['sec'] / 60), 2) if m in base and base[m]['sec'] else None}

surv = [x for x in mutants if x['status'] in ('survived', 'digest_only')]
void = [x for x in mutants if x['status'] == 'void']
eq = [x for x in surv if x['equivalent']]
gaps = [x for x in surv if not x['equivalent']]
n = len(mutants) - len(void); ne = n - len(eq)
det_n = sum(1 for x in mutants if x['status'] in ('killed', 'timeout'))
det_raw = det_n + sum(1 for x in mutants if x['status'] == 'digest_only')
by_file = collections.defaultdict(lambda: collections.Counter())
for x in mutants:
    key = x['file'].split('/')[-1][:-3]
    by_file[key][x['status'] if x['status'] in ('killed', 'timeout', 'void') else ('equivalent' if x['equivalent'] else 'gap')] += 1
by_kind = collections.defaultdict(lambda: collections.Counter())
for x in mutants:
    by_kind[x['kind']][x['status'] if x['status'] in ('killed', 'timeout', 'void') else ('equivalent' if x['equivalent'] else 'gap')] += 1
summary = {
    'sampled': len(sample), 'run': n, 'not_run': sorted(set(sample) - set(rows)),
    'killed': sum(1 for x in mutants if x['status'] == 'killed'), 'timeout_only': sum(1 for x in mutants if x['status'] == 'timeout'),
    'digest_only': sum(1 for x in mutants if x['status'] == 'digest_only'),
    'void_disk_full': [x['id'] for x in void],
    'survived_all_behaviour_checks': len(surv), 'equivalent': len(eq), 'gaps': len(gaps),
    'gaps_by_severity': dict(collections.Counter((x['classification'] or {}).get('severity') or 'unclassified' for x in gaps)),
    'mutation_score_excluding_equivalent': round(det_n / ne, 3) if ne else None,
    'mutation_score_counting_digest_kills': round(det_raw / ne, 3) if ne else None,
    'digest_kill_module_verdicts': sum(1 for i in matrix for c in matrix[i].values() if c == 'D'),
    'void_module_verdicts_disk_full': sum(1 for i in matrix for c in matrix[i].values() if c == 'E'),
    'named_stratum': {k: sum(1 for x in mutants if x['stratum'] == 'named' and (x['status'] if x['status'] in ('killed', 'timeout', 'void') else ('equivalent' if x['equivalent'] else 'gap')) == k) for k in ('killed', 'timeout', 'void', 'equivalent', 'gap')},
    'other_stratum': {k: sum(1 for x in mutants if x['stratum'] == 'other' and (x['status'] if x['status'] in ('killed', 'timeout', 'void') else ('equivalent' if x['equivalent'] else 'gap')) == k) for k in ('killed', 'timeout', 'void', 'equivalent', 'gap')},
    'module_runs': sum(len(r['modules']) for r in rows.values()),
    'worker_seconds': round(sum(r['sec'] for r in rows.values()), 1),
    'modules_with_zero_unique_kills': sorted(m for m, v in per_module.items() if v['covered_mutants'] and not v['unique_kills']),
    'modules_covering_no_sampled_mutant': sorted(m for m, v in per_module.items() if not v['covered_mutants']),
}
out = {'summary': summary, 'by_file': {k: dict(v) for k, v in sorted(by_file.items())},
       'by_kind': {k: dict(v) for k, v in sorted(by_kind.items())},
       'per_module': dict(sorted(per_module.items(), key=lambda kv: (-kv[1]['unique_kills'], -kv[1]['killed']))),
       'matrix': matrix, 'mutants': mutants,
       'survivors_gaps': [{k: x[k] for k in ('id', 'file', 'line', 'func', 'kind', 'detail', 'old', 'new', 'covering_modules')}
                          | {'severity': (x['classification'] or {}).get('severity'), 'unguarded': (x['classification'] or {}).get('why'),
                             'slow_modules_restricted': sorted(m for m, v in x['verdicts'].items() if v['restricted_to'] and not v.get('rerun_full'))}
                          for x in sorted(gaps, key=lambda x: (['real', 'low', 'boundary', None].index((x['classification'] or {}).get('severity')), x['id']))],
       'survivors_equivalent': [{k: x[k] for k in ('id', 'file', 'line', 'func', 'kind', 'detail', 'old', 'new')}
                                | {'why_equivalent': (x['classification'] or {}).get('why')} for x in eq]}
# the tests that killed, and how often each one ran and passed under other mutants (a flakiness check that costs no run:
# a run that survived passed every test it ran: the restricted list, or the whole module less the known failures)
all_tests = {m: [t[0] for t in base[m]['tests']] for m in base}
killer = collections.defaultdict(lambda: {'kills': [], 'passed_in_other_runs': 0})
for i, r in rows.items():
    for m, v in r['modules'].items():
        for t in v['killers']:
            killer[t]['kills'].append(i)
for i, r in rows.items():
    for m, v in r['modules'].items():
        if v['v'] != 'survived': continue
        for t in (v['restricted_to'] or all_tests.get(m, [])):
            if t in killer: killer[t]['passed_in_other_runs'] += 1
out['killer_tests'] = {t: {'kills': len(v['kills']), 'mutants': v['kills'], 'passed_in_other_runs': v['passed_in_other_runs']}
                       for t, v in sorted(killer.items(), key=lambda kv: -len(kv[1]['kills']))}
(W / 'kill_matrix.json').write_text(json.dumps(out, indent=1))
print(json.dumps(summary, indent=1))
for m, v in out['per_module'].items():
    if v['covered_mutants']:
        print('%-28s cov %3d K %3d D %2d T %2d S %3d uniq %2d (focused %2d) spent %7.1f base %6.1f' % (
            m, v['covered_mutants'], v['killed'], v['digest_kills'], v['timeouts'], v['survived'], v['unique_kills'], v['unique_kills_focused_only'],
            v['seconds_spent'], v['base_seconds'] or 0))
