"""A small AST mutator with no dependency beyond the standard library.

Sites are found with `ast` inside function bodies only (module-level lines run on import in every module, so a mutant there
says nothing about which tests guard behaviour). Each mutant is applied as a minimal text edit on the exact source segment of
one node, so every other line, comment and line number of the file is unchanged. Kinds:
  cmp     flip one comparison operator: < <=, > >=, == !=, is / is not, in / not in
  if      negate the condition of an if / elif: `if X:` -> `if not (X):`
  ret     `return X` -> `return not (X)` when X is boolean-valued, else `return None`
  num     an int or float constant in a function body + 1
  call    delete a call statement (it becomes the no-op expression `None`)
Logging and print calls are not offered for `call` (deleting them changes nothing a test could observe).
"""
import ast, re

CMP_FLIP = {ast.Lt: ('<', '<='), ast.LtE: ('<=', '<'), ast.Gt: ('>', '>='), ast.GtE: ('>=', '>'), ast.Eq: ('==', '!='),
            ast.NotEq: ('!=', '=='), ast.Is: ('is', 'is not'), ast.IsNot: ('is not', 'is'), ast.In: ('in', 'not in'),
            ast.NotIn: ('not in', 'in')}
CMP_RE = {'<': r'<(?!=)', '<=': r'<=', '>': r'>(?!=)', '>=': r'>=', '==': r'==', '!=': r'!=', 'is': r'\bis\b(?!\s+not\b)',
          'is not': r'\bis\s+not\b', 'in': r'(?<!not )\bin\b', 'not in': r'\bnot\s+in\b'}
BOOL_CALLS = {'isinstance', 'issubclass', 'hasattr', 'callable', 'bool', 'any', 'all', 'startswith', 'endswith', 'exists',
              'is_file', 'is_dir', 'isdigit', 'isalpha', 'isalnum', 'isidentifier', 'is_absolute', 'match', 'fullmatch',
              'isVisible', 'isEnabled', 'isChecked', 'isHidden', 'isinf', 'isnan', 'isfinite', 'is_relative_to'}
QUIET = re.compile(r'^(print|(\w+\.)*(log|logger|logging|_log|LOG|_logger)\.\w+|warnings\.warn|traceback\.print_exc|'
                   r'(\w+\.)*(debug|info|warning|exception)|sys\.stderr\.write|sys\.stdout\.write)$')


def dotted(fn):
    if isinstance(fn, ast.Name): return fn.id
    if isinstance(fn, ast.Attribute):
        base = dotted(fn.value)
        return (base + '.' if base else '') + fn.attr
    return ''


def boolish(e):
    if isinstance(e, (ast.Compare, ast.BoolOp)): return True
    if isinstance(e, ast.UnaryOp) and isinstance(e.op, ast.Not): return True
    if isinstance(e, ast.Constant) and isinstance(e.value, bool): return True
    if isinstance(e, ast.Call):
        n = dotted(e.func).rsplit('.', 1)[-1]
        return n in BOOL_CALLS
    return False


class Src:
    def __init__(self, text):
        self.text = text
        self.lines = text.splitlines(keepends=True)
        self.starts = [0]
        for l in self.lines: self.starts.append(self.starts[-1] + len(l))

    def off(self, lineno, col):  # ast col offsets are UTF-8 byte offsets
        line = self.lines[lineno - 1]
        return self.starts[lineno - 1] + len(line.encode('utf-8')[:col].decode('utf-8', 'replace'))

    def span(self, node):
        return self.off(node.lineno, node.col_offset), self.off(node.end_lineno, node.end_col_offset)


def expr_children(stmt):
    """The expressions that belong to this statement itself (not to statements nested in its body)."""
    out = []
    for name, val in ast.iter_fields(stmt):
        if name in ('body', 'orelse', 'finalbody', 'handlers', 'cases', 'decorator_list', 'returns', 'annotation',
                    'type_params', 'args'):
            continue
        if isinstance(val, ast.expr): out.append(val)
        elif isinstance(val, list):
            for v in val:
                if isinstance(v, ast.expr): out.append(v)
                elif isinstance(v, ast.withitem): out.append(v.context_expr)
    return out


def walk_expr(e):
    """ast.walk over an expression, not entering lambdas or f-string format specs."""
    todo = [e]
    while todo:
        n = todo.pop()
        if isinstance(n, ast.Lambda): continue
        yield n
        for name, c in ast.iter_fields(n):
            if isinstance(n, ast.FormattedValue) and name == 'format_spec': continue
            if isinstance(c, ast.AST): todo.append(c)
            elif isinstance(c, list): todo.extend(x for x in c if isinstance(x, ast.AST))


def sites(text, rel):
    tree = ast.parse(text)
    src = Src(text)
    out = []

    def add(kind, stmt, node, start, end, new, func, detail):
        old = text[start:end]
        if old == new: return
        out.append({'file': rel, 'kind': kind, 'line': stmt.lineno, 'node_line': node.lineno, 'start': start, 'end': end,
                    'old': old, 'new': new, 'func': func, 'detail': detail})

    def pad(new, old):  # keep the line count of the replaced segment
        k = old.count('\n')
        return new if not k else '(' + new + '\n' * k + ')'

    def visit_body(stmts, func, in_func):
        for s in stmts:
            visit_stmt(s, func, in_func)

    def visit_stmt(s, func, in_func):
        if isinstance(s, (ast.FunctionDef, ast.AsyncFunctionDef)):
            visit_body(s.body, (func + '.' if func else '') + s.name, True)
            return
        if isinstance(s, ast.ClassDef):
            visit_body(s.body, (func + '.' if func else '') + s.name, in_func)
            return
        if in_func:
            stmt_sites(s, func)
        for name in ('body', 'orelse', 'finalbody'):
            visit_body(getattr(s, name, []) or [], func, in_func)
        for h in getattr(s, 'handlers', []) or []:
            visit_body(h.body, func, in_func)
        for c in getattr(s, 'cases', []) or []:
            visit_body(c.body, func, in_func)

    def stmt_sites(s, func):
        if isinstance(s, ast.If):
            a, b = src.span(s.test)
            add('if', s, s.test, a, b, 'not (' + text[a:b] + ')', func, 'negate condition')
        if isinstance(s, ast.Return) and s.value is not None and not (isinstance(s.value, ast.Constant) and s.value.value is None):
            a, b = src.span(s.value)
            if boolish(s.value):
                add('ret', s, s.value, a, b, 'not (' + text[a:b] + ')', func, 'return negation')
            else:
                add('ret', s, s.value, a, b, pad('None', text[a:b]), func, 'return None')
        if isinstance(s, ast.Expr):
            v = s.value.value if isinstance(s.value, ast.Await) else s.value
            if isinstance(v, ast.Call) and not QUIET.match(dotted(v.func) or '-'):
                a, b = src.span(s)
                add('call', s, s, a, b, pad('None', text[a:b]), func, 'delete call ' + (dotted(v.func) or '?'))
        for e in expr_children(s):
            for n in walk_expr(e):
                if isinstance(n, ast.Compare):
                    ops = [n.left] + n.comparators
                    for i, op in enumerate(n.ops):
                        a = src.off(ops[i].end_lineno, ops[i].end_col_offset)
                        b = src.off(ops[i + 1].lineno, ops[i + 1].col_offset)
                        gap = text[a:b]
                        o, nw = CMP_FLIP[type(op)]
                        m = re.search(CMP_RE[o], gap)
                        if not m: continue
                        add('cmp', s, n, a, b, gap[:m.start()] + nw + gap[m.end():], func, '%s -> %s' % (o, nw))
                elif isinstance(n, ast.Constant) and type(n.value) in (int, float):
                    a, b = src.span(n)
                    add('num', s, n, a, b, repr(n.value + 1), func, '%r -> %r' % (n.value, n.value + 1))

    visit_body(tree.body, None, False)
    return out


def apply(text, site):
    new = text[:site['start']] + site['new'] + text[site['end']:]
    return new


def check(text, site, rel):
    new = apply(text, site)
    try:
        t2 = ast.parse(new)
        compile(new, rel, 'exec')
    except SyntaxError:
        return False
    return new.count('\n') == text.count('\n') and ast.dump(t2) != ast.dump(ast.parse(text))
