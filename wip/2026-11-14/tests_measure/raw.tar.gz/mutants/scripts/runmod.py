"""Run one tests_integrated module inside a tree, the way `python -m unittest tests_integrated.<m>` would, but:
- tests listed in --exclude (known baseline failures) are dropped before the run;
- --failfast stops at the first failure or error (a kill is a module-level verdict);
- every test outcome and duration is appended to OUT as one JSON line as it finishes (survives a timeout kill).
usage: runmod.py TREE MODULE OUT [--failfast] [--exclude ID ...] [--only ID ...]
(--only keeps just those test ids: used for the three slow modules, see run_mutants.py)"""
import json, os, sys, time, unittest

TREE, MODULE, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
rest = sys.argv[4:]
failfast = '--failfast' in rest
def opt(name):
    if name not in rest: return None
    i = rest.index(name) + 1; vals = []
    while i < len(rest) and not rest[i].startswith('--'):
        vals.append(rest[i]); i += 1
    return set(vals)
exclude = opt('--exclude') or set()
only = opt('--only')
os.chdir(TREE)
sys.path.insert(0, TREE)
out = open(OUT, 'a', buffering=1)


def emit(**row):
    out.write(json.dumps(row) + '\n')


def flatten(suite):
    for t in suite:
        if isinstance(t, unittest.TestSuite):
            yield from flatten(t)
        else:
            yield t


class Result(unittest.TextTestResult):
    def startTest(self, test):
        self._t0 = time.time()
        emit(ev='start', id=test.id())
        super().startTest(test)

    def _row(self, test, outcome, err=None):
        emit(ev='end', id=test.id(), outcome=outcome, sec=round(time.time() - getattr(self, '_t0', time.time()), 3),
             err=(self._exc_info_to_string(err, test)[-1500:] if err else None))

    def addSuccess(self, test):
        super().addSuccess(test); self._row(test, 'pass')

    def addFailure(self, test, err):
        super().addFailure(test, err); self._row(test, 'fail', err)

    def addError(self, test, err):
        super().addError(test, err); self._row(test, 'error', err)

    def addSkip(self, test, reason):
        super().addSkip(test, reason); self._row(test, 'skip')

    def addExpectedFailure(self, test, err):
        super().addExpectedFailure(test, err); self._row(test, 'xfail')

    def addUnexpectedSuccess(self, test):
        super().addUnexpectedSuccess(test); self._row(test, 'xpass')

    def addSubTest(self, test, subtest, err):
        super().addSubTest(test, subtest, err)
        if err is not None:
            kind = 'fail' if issubclass(err[0], test.failureException) else 'error'
            emit(ev='end', id=subtest.id(), outcome=kind, sec=0,
                 err=self._exc_info_to_string(err, test)[-1500:])


t0 = time.time()
try:
    suite = unittest.defaultTestLoader.loadTestsFromName('tests_integrated.' + MODULE)
except Exception as exc:  # import of the test module failed: every test is an error
    emit(ev='load_error', err=repr(exc)[-1500:]); emit(ev='done', ok=False, sec=round(time.time() - t0, 2)); sys.exit(2)
kept = unittest.TestSuite()
dropped = []
# keep the loader's order and class grouping; drop only the excluded ids
def keep(s):
    new = unittest.TestSuite()
    for t in s:
        if isinstance(t, unittest.TestSuite):
            new.addTest(keep(t))
        elif t.id() in exclude or (only is not None and t.id() not in only):
            dropped.append(t.id())
        else:
            new.addTest(t)
    return new
kept = keep(suite)
emit(ev='plan', n=sum(1 for _ in flatten(kept)), dropped=dropped)
runner = unittest.TextTestRunner(stream=sys.stderr, verbosity=1, failfast=failfast, resultclass=Result)
res = runner.run(kept)
emit(ev='done', ok=res.wasSuccessful(), ran=res.testsRun, failures=len(res.failures), errors=len(res.errors),
     sec=round(time.time() - t0, 2))
out.close()
sys.exit(0 if res.wasSuccessful() else 1)
