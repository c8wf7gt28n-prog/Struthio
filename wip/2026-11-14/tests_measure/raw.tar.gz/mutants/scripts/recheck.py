"""Re-run single kills whose failure text looks environmental (full disk, or 'This line panel offers no rows to keep'),
one mutant per worker, the slow module restricted to the named test; plus an unmutated control of the same test.
usage: recheck.py OUT ID:MODULE:TEST [ID:MODULE:TEST]   (ID 'control' = no mutation)"""
import json, sys, threading
from mutlib import W, bad_ids, run_module
from mutator import apply
sample = {m['id']: m for m in json.loads((W / 'sample.json').read_text())['mutants']}
OUT = W / sys.argv[1]; jobs = sys.argv[2:]
rows = json.loads(OUT.read_text()) if OUT.exists() else {}
lock = threading.Lock()
def one(job, tree, wname):
    i, m, t = job.split(':')
    mut = sample.get(i)
    path = W / tree / mut['file'] if mut else None
    pristine = (W / 'pristine' / mut['file']).read_text() if mut else None
    try:
        if mut: path.write_text(apply(pristine, mut))
        r = run_module(W / tree, m, 're_%s_%s' % (wname, m), timeout=600, failfast=True, exclude=bad_ids(m), only=[t])
    finally:
        if mut: path.write_text(pristine)
    v = 'timeout' if r['code'] == 'timeout' else 'survived' if r['code'] == 0 and r['done'] and r['done'].get('ok') else 'killed'
    with lock:
        rows[job + ':' + str(len(rows))] = {'v': v, 'sec': r['sec'], 'killers': [b['id'] for b in r['bad']],
                                            'err': (r['bad'][0]['err'][-500:] if r['bad'] and r['bad'][0]['err'] else r['tail'][-500:])}
        OUT.write_text(json.dumps(rows, indent=1))
    print(job, v, r['sec'], flush=True)
th = [threading.Thread(target=one, args=(j, t, n)) for j, (t, n) in zip(jobs, (('tree_a', 'a'), ('tree_b', 'b')))]
for x in th: x.start()
for x in th: x.join()
