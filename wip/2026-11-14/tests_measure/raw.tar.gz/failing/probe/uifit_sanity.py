"""ui_fit's tool-button room still finds a word that is really cut, and passes one drawn whole."""
import sys,os
sys.path.insert(0,os.path.join(os.getcwd(),'tools'))
from PySide6.QtWidgets import QApplication,QToolButton,QWidget
app=QApplication([])
import ui_fit
host=QWidget();host.resize(400,60);host.setStyleSheet('QWidget{background:#0b0e0d;} QToolButton{color:#f4e8ce;background:transparent;border:0;padding:5px 10px;}')
cut=QToolButton(host);cut.setText('Properties');cut.setGeometry(10,10,50,30)
whole=QToolButton(host);whole.setText('Work');whole.setGeometry(100,10,70,30)
host.show();app.processEvents()
print('cut flagged:',bool(ui_fit.whole_words(cut)),'| whole flagged:',bool(ui_fit.whole_words(whole)))
