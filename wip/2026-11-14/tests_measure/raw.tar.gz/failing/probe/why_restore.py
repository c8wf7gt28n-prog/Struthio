"""Why the restored worker is torn down in test_failed_activation...: print the exception the restore path swallows."""
import sys,traceback,unittest
from unittest.mock import patch
sys.path.insert(0,'.')
from tests_integrated import test_model_settings as t
from workbench import local_brain as brain, activity
seen=[]
real=brain.verify_resident
def spy(value,worker):
    try:return real(value,worker)
    except BaseException as exc:seen.append(('verify_resident',worker.get('pid'),type(exc).__name__,str(exc)[:200]));raise
rec=[]
case=t.ModelSettingsTests('test_failed_activation_retains_original_restore_and_reports_owned_restored_worker')
with patch.object(brain,'verify_resident',side_effect=spy),patch.object(activity,'record',side_effect=lambda *a,**k:rec.append(a[1:])):
    r=unittest.TextTestRunner(verbosity=0,stream=open('/dev/null','w')).run(unittest.TestSuite([case]))
print('result failures',len(r.failures),'errors',len(r.errors))
print('verify_resident raised:',seen)
print('activity:',rec)
