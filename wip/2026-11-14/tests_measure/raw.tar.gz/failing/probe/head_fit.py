"""The head's buttons at 1920x1200 (Home, 14 pt): text, icon, width, size hint, ui_fit's verdict; and a picture of the head."""
import os,sys,tempfile,json
from pathlib import Path
RUN=Path(tempfile.mkdtemp(prefix='head-probe-'));OUT=Path(sys.argv[1])
os.environ.update(ARC_LEDGER_EMBEDDED='1',ARC_LEDGER_DISABLE_BOOK_WATCHER='1',ARC1_WORKBENCH_CONFIG_HOME=str(RUN/'profile'),ARC_LEDGER_CONCERN=str(RUN/'Concern'))
sys.path.insert(0,os.getcwd());sys.path.insert(0,os.path.join(os.getcwd(),'tools'))
from unittest.mock import patch
from workbench.engineering_kernel import Kernel
from workbench import qt_app
app=qt_app.make_app()
from workbench.qt_app import WorkbenchWindow
from workbench.session import Session
from PySide6.QtWidgets import QToolButton
import ui_fit
root=RUN/'ws';root.mkdir()
with patch.object(Kernel,'launch'),patch.object(Kernel,'submit'):
    w=WorkbenchWindow(root,Session(RUN/'profile/session.json',root),restore=False)
    for size in ((1920,1200),(1366,768)):
        w.resize(*size);w.show()
        for _ in range(30):app.processEvents()
        if hasattr(w,'a_home'):w.a_home.trigger()
        for _ in range(30):app.processEvents()
        top=w.shell2.top;rows=[]
        for b in top.findChildren(QToolButton):
            if b.isVisible():rows.append(dict(text=b.text(),icon=not b.icon().isNull(),style=int(b.toolButtonStyle().value) if hasattr(b.toolButtonStyle(),'value') else str(b.toolButtonStyle()),w=b.width(),hint=b.sizeHint().width(),min=b.minimumSizeHint().width(),adv=b.fontMetrics().horizontalAdvance(b.text())))
        clipped,elsewhere=ui_fit.regions(w,w.ribbon_dock,w.central_stack)
        print(json.dumps(dict(size=size,buttons=rows,clipped=ui_fit.describe(clipped))))
        img=w.ribbon_dock.grab();img.save(str(OUT/('head_%dx%d.png'%size)))
        p=top.programs;r=p.geometry();g=p.grab();g=g.scaled(g.width()*3,g.height()*3);g.save(str(OUT/('apps_%dx%d_x3.png'%size)))
