"""How much room the style gives a head tool button's words: candidate measures against what the grab shows."""
import os,sys,tempfile,json
from pathlib import Path
RUN=Path(tempfile.mkdtemp(prefix='toolroom-'))
os.environ.update(ARC_LEDGER_EMBEDDED='1',ARC_LEDGER_DISABLE_BOOK_WATCHER='1',ARC1_WORKBENCH_CONFIG_HOME=str(RUN/'profile'),ARC_LEDGER_CONCERN=str(RUN/'Concern'))
sys.path.insert(0,os.getcwd())
from unittest.mock import patch
from workbench.engineering_kernel import Kernel
from workbench import qt_app
app=qt_app.make_app()
from workbench.qt_app import WorkbenchWindow
from workbench.session import Session
from PySide6.QtWidgets import QToolButton,QStyle,QStyleOptionToolButton
from PySide6.QtGui import QColor
root=RUN/'ws';root.mkdir()
with patch.object(Kernel,'launch'),patch.object(Kernel,'submit'):
    w=WorkbenchWindow(root,Session(RUN/'profile/session.json',root),restore=False);w.resize(1920,1200);w.show()
    for _ in range(30):app.processEvents()
    for b in w.shell2.top.findChildren(QToolButton):
        if not b.isVisible() or not b.text():continue
        opt=QStyleOptionToolButton();b.initStyleOption(opt)
        sc=b.style().subControlRect(QStyle.CC_ToolButton,opt,QStyle.SC_ToolButton,b)
        ce=b.style().subElementRect(QStyle.SE_ToolButtonLayoutItem,opt,b) if hasattr(QStyle,'SE_ToolButtonLayoutItem') else None
        # the drawn ink: columns of the grab that differ from the button's background, left and right extent
        img=b.grab().toImage();bg=img.pixelColor(0,img.height()//2)
        cols=[x for x in range(img.width()) if any(abs(img.pixelColor(x,y).lightness()-bg.lightness())>40 for y in range(img.height()-3))]
        print(json.dumps(dict(text=b.text(),name=b.objectName(),w=b.width(),hint=b.sizeHint().width(),adv=b.fontMetrics().horizontalAdvance(b.text()),
            subcontrol=sc.width(),ink=[cols[0],cols[-1]] if cols else None,ink_w=(cols[-1]-cols[0]+1) if cols else 0,menu=b.menu() is not None,popup=int(b.popupMode().value))))
