"""The Apps button and the head at 1366x768 at 18 pt: is '[#] Apps' drawn whole?"""
import os,sys,tempfile,json
from pathlib import Path
RUN=Path(tempfile.mkdtemp(prefix='apps18-'));OUT=Path(sys.argv[1])
os.environ.update(ARC_LEDGER_EMBEDDED='1',ARC_LEDGER_DISABLE_BOOK_WATCHER='1',ARC1_WORKBENCH_CONFIG_HOME=str(RUN/'profile'),ARC_LEDGER_CONCERN=str(RUN/'Concern'))
sys.path.insert(0,os.getcwd())
from unittest.mock import patch
from workbench.engineering_kernel import Kernel,operator
from workbench import qt_app,ledger_control
app=qt_app.make_app()
from workbench.qt_app import WorkbenchWindow
from workbench.session import Session
root=RUN/'ws';root.mkdir()
with patch.object(Kernel,'launch'),patch.object(Kernel,'submit'):
    w=WorkbenchWindow(root,Session(RUN/'profile/session.json',root),restore=False);w.resize(1366,768);w.show()
    for _ in range(30):app.processEvents()
    k=w.ledger_bridge.kernel
    row=next(r for r in ledger_control.settings(k)['settings'] if r['key']=='reading.ui_pt')
    print(k.dispatch('ledger.settings.set',{'key':'reading.ui_pt','value':18.0,'expected_revision':row['revision']},operator())['ok'])
    w.ledger_bridge.sync_profile(force=True)
    for _ in range(60):app.processEvents()
    b=w.shell2.top.programs;img=b.grab().toImage();bg=img.pixelColor(0,img.height()//2)
    cols=[x for x in range(img.width()) if any(abs(img.pixelColor(x,y).lightness()-bg.lightness())>40 for y in range(1,img.height()-3))]
    print(json.dumps(dict(w=b.width(),hint=b.sizeHint().width(),adv=b.fontMetrics().horizontalAdvance(b.text()),ink=[cols[0],cols[-1]] if cols else None,font=b.font().pixelSize(),pt=b.font().pointSizeF())))
    g=b.grab();g.scaled(g.width()*3,g.height()*3).save(str(OUT/'apps_1366_18pt_x3.png'));w.ribbon_dock.grab().save(str(OUT/'head_1366_18pt.png'))
