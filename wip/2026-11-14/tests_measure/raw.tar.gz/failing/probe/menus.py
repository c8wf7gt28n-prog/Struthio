"""Every action of the head's menus (titles and whether each is visible), from the real window with no model."""
import os,sys,tempfile,json
from pathlib import Path
RUN=Path(tempfile.mkdtemp(prefix='menus-probe-'))
os.environ.update(ARC_LEDGER_EMBEDDED='1',ARC_LEDGER_DISABLE_BOOK_WATCHER='1',ARC1_WORKBENCH_CONFIG_HOME=str(RUN/'profile'),ARC_LEDGER_CONCERN=str(RUN/'Concern'))
sys.path.insert(0,os.getcwd())
from unittest.mock import patch
from workbench.engineering_kernel import Kernel
from PySide6.QtWidgets import QApplication,QMenu
from workbench import qt_app
app=qt_app.make_app() if hasattr(qt_app,'make_app') else QApplication([])
from workbench.qt_app import WorkbenchWindow
from workbench.session import Session
root=RUN/'ws';root.mkdir()
with patch.object(Kernel,'launch'),patch.object(Kernel,'submit'):
    w=WorkbenchWindow(root,Session(RUN/'profile/session.json',root),restore=False);w.resize(1920,1200);w.show()
    for _ in range(20):app.processEvents()
    out={}
    def walk(menu,path):
        for a in menu.actions():
            if a.isSeparator():continue
            t=a.text().replace('&','')
            if a.menu():walk(a.menu(),path+[t])
            else:out.setdefault(' > '.join(path),[]).append(t)
    for name,m in getattr(w,'command_menus',{}).items():walk(m,[name])
    top=w.shell2.top
    shown=[b.text() for b in top.findChildren(__import__('PySide6.QtWidgets',fromlist=['QToolButton']).QToolButton) if b.isVisible()]
    print(json.dumps(dict(head_buttons=shown,menus=out,groups=list(getattr(w,'menu_groups',{}).keys())),indent=0)[:6000])
    print('PLEASANTRIES_IN', [k for k,v in out.items() if any('Pleasantries' in t for t in v)])
