STRUTHIO SLIM4 - PCB R22 - JLCPCB ORDER FILES
=============================================

Upload to JLCPCB (PCB + PCBA):
  SLIM4_R22_GERBER_DRILL.zip   Gerber X2 (13 layers), Excellon drill (PTH and NPTH separate), job file
  SLIM4_R22_BOM.csv            bill of materials, one line per part type, every line with an LCSC number
  SLIM4_R22_CPL.csv            placement: designator, centre X/Y (mm), side, rotation

BOARD OPTIONS
  Layers                 6  (F.Cu, In1 GND plane, In2 power planes, In3 signal, In4 GND plane, B.Cu)
  Thickness              1.2 mm  - REQUIRED: the enclosure is designed around 1.2 mm
  Size                   99.3 x 125.1 mm, non-rectangular, with an internal battery window
  Stackup                JLCPCB standard 6-layer 1.2 mm stackup
  Copper weight          1 oz outer / 0.5 oz inner
  Min track / space      0.1 mm / 0.1 mm
  Vias                   272 through vias, 0.2 mm drill / 0.45 mm pad; no blind or buried vias
  Via covering           EPOXY FILLED AND CAPPED (via-in-pad, POFV; JLCPCB's default for 6 layers).
                         Needed: 2 vias sit in SMD pads (R403 pad 1, C408 pad 2),
                         and every other via must stay covered (no mask openings are plotted)
  Plated slots           J2 0.6 x 1.4 mm, J2 0.6 x 1.7 mm (USB-C shell legs)
  Non-plated holes       J2 dia 0.65 mm, SW dia 1.1 mm
  Surface finish         ENIG (0.35 mm-pitch ESP32-P4 and QFN/WSON/X2SON parts need flat pads)
  Mask / silk            green / white
  Impedance control      not needed: MIPI-DSI runs are 29-40 mm, USB is full speed (12 Mbit/s)
  Quantity               5 boards, 2 assembled (or as many as you want to assemble)

ASSEMBLY
  Sides                  BOTH: 162 parts on the back (B.Cu) and 4 on the front (the four Omron
                         D2LS switches SW1-SW4, which the case buttons press)
  Parts                  166 placements, 50 BOM lines; LCSC numbers for all of them
                         C310   CL05B224KO5NNNC        C16772  (from BOM_SOURCING_R21.json)
                         J1     FH12-20S-0.5SH(55)     C596730  (from BOM_SOURCING_R21.json)
                         J2     USB4105-GF-A-120       C5184243  (from BOM_SOURCING_R21.json)
                         U1     ESP32-P4NRW32X         C54540373  (from BOM_SOURCING_R21.json)
                         U2     W25Q512JVEIQ TR        C7389628  (from BOM_SOURCING_R21.json)
                         U4     TPS63070RNMR           C109322  (from BOM_SOURCING_R21.json)
                         U8     MAX98357AETE+T         C910544  (from BOM_SOURCING_R21.json)
                         U9     MAX98357AETE+T         C910544  (from BOM_SOURCING_R21.json)
                         U10    BQ24074RGTR            C54313  (from BOM_SOURCING_R21.json)
                         U13    TUSB320LAIRWBR         C132554  (from BOM_SOURCING_R21.json)

  Rotations              KiCad's. In JLCPCB's placement preview check pin 1 / polarity of every
                         IC, diode, connector and crystal and correct the rotation there if their
                         library part is drawn at a different zero angle. Pay attention to:
                         U1 (ESP32-P4, QFN-104), U2, U4, U8-U14, D1, D2, Q1, Y1, J1-J5.

U1 STOCK (check before ordering)
  On 2026-10-07 JLCPCB had 0 of the ESP32-P4NRW32X (C54540373); every other line was in stock.
  Pre-order it through JLCPCB Global Sourcing, or consign v3.x chips (ordering code ending in X)
  bought from an Espressif-authorised source. Do not substitute ESP32-P4NRW32 (no X, revision v1.x).

NOT ON THE BOARD (buy separately)
  Display     Startek KD047HDFID001: 4.7 in 720 x 1280 IPS, ST7703, 450 nits, 61.0 x 110.6 x 1.8 mm.
              It plugs into J1 through the custom display flex (see DISPLAY_PORT.md); ask Startek for the
              full datasheet (FPC pin definition and initialisation code) when ordering.
  Battery     any 1-cell Li-ion/LiPo with its own protection board, about 34 x 52 x 7 mm max (703450 class),
              on a JST SH 1.0 mm 2-pin plug: J3 pin 1 = BAT+ (red), pin 2 = BAT- (black). CHECK THE POLARITY
              before plugging in: cell leads are wired both ways and the board has no reverse protection.
  Speakers    2 x 18 x 13 mm speakers (Same Sky CMS-18138A-SP fits the case) on JST SH 1.0 mm 2-pin
              plugs: J4 left, J5 right; pin 1 = +. One cable type for battery and speakers.

CHECKS RUN ON THESE FILES
  KiCad 7.0.11 DRC: Found 0 DRC violations / Found 0 unconnected pads / Found 0 Footprint errors  (REFERENCE/DRC_REPORT_KICAD7.txt)
  Zone fills current: yes;  solder-mask openings at vias: 0
  Board: 166 footprints, 115 nets, 2687 track segments, 272 vias
  Electrical and land-pattern review: ELECTRICAL_REVIEW_R22.md
