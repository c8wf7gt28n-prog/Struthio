STRUTHIO SLIM4 - DISPLAY FLEX R1 - JLCPCB FLEX PCB ORDER
*** PREVIEW: the panel pin map is a placeholder. DO NOT ORDER THESE FILES. ***
*** Fill panel_pinmap.csv from Startek's KD047HDFID001 datasheet and run without --preview. ***

Joins the Startek KD047HDFID001 panel tail (31 pins, 0.3 mm) to the R22 board's J1 (FH12-20, 0.5 mm).

Upload to JLCPCB as a FLEX PCB:
  SLIM4_DISPLAY_FLEX_R1_PREVIEW_GERBER_DRILL.zip   copper F/B, coverlay openings (mask), paste, silk, outline,
                             User.1 = stiffener at the J1 end, User.2 = stiffener under the FH26
  SLIM4_DISPLAY_FLEX_R1_PREVIEW_BOM.csv / _CPL.csv one part on the top side: J1 FH26W-31S-0.3SHW(60), LCSC C2973806

FLEX OPTIONS
  Layers                 2, polyimide, 1/2 oz copper, yellow coverlay
  Size                   22.6 x 70.1 mm
  Gold fingers (J1 end)  20 x 0.30 mm at 0.50 mm pitch on the BOTTOM side, ENIG
  Stiffener, J1 end      polyimide on the TOP side over the last 6.0 mm (User.1), thickness chosen so the
                         finger end is 0.30 mm total (FH12 accepts 0.30 +/- 0.05 mm; usually 0.2 mm PI)
  Stiffener, panel end   0.2 mm FR4 or PI on the BOTTOM side under the FH26 connector (User.2)
  Min track / space      0.10 / 0.08 mm; vias 0.45 / 0.20 mm
  Surface finish         ENIG
  Quantity               5, with the FH26 connector assembled (one-side SMT)

ASSEMBLY
  Panel tail into the FH26 with its contacts ("conduct side") facing the flex.
  Gold fingers into the board's J1 with the fingers facing the board (FH12 is bottom contact),
  pin 1 (silk "1") towards the board's pin 1.

BEFORE ORDERING: print SLIM4_DISPLAY_FLEX_R1_PREVIEW_FIT_TEMPLATE_1to1.pdf at 100 %, cut it out and route it through
the printed case from the panel tail to J1. Change --length in generate_flex.py if it is short or long.

CHECKS: KiCad DRC 0 violations, 0 unconnected pads, 54 vias.
