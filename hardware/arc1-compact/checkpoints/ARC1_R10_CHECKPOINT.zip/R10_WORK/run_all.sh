#!/bin/sh
# ARC-1 R10 -- runs every R10 check in this tree and records exit statuses in qa/RUN_ALL.log.
# Needs: python3, cc, iverilog/vvp, verilator, yosys, nextpnr-ecp5. P&R targets take ~15 min in total.
cd "$(dirname "$0")" || exit 2
LOG=qa/RUN_ALL.log
: > "$LOG"
fail=0
step() { d=$1; shift; printf '== %s: %s\n' "$d" "$*" | tee -a "$LOG"
         (cd "$d" && "$@") >> "$LOG" 2>&1; rc=$?; printf '   exit %d\n' "$rc" | tee -a "$LOG"; [ "$rc" -eq 0 ] || fail=1; }
step architecture python3 gen_interface_matrix.py
step fpga12 make lint rgmii sim build seeds report
step fpga45 make ref sim seeds sim45 seeds45
step f133/graphics_link make all
step . git diff --exit-code -- architecture/R10_interface_matrix.csv architecture/R10_PINMUX_CONFLICTS.md
[ "$fail" -eq 0 ] && echo R10_RUN_ALL_PASS | tee -a "$LOG" || echo R10_RUN_ALL_FAIL | tee -a "$LOG"
exit "$fail"
