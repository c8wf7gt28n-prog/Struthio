# ARC-1 R19 — T120F484 + T20F256 physical pin audit

**Status: manufacturer BGA coordinates extracted; candidate electrical assignment remains UNVERIFIED by Efinity.**

## Source authority

- `t120_pinout-v1.4.xlsx`, `T120F484` sheet, Efinix v1.4, March 2025. Contains precisely **484 nonempty unique BGA ball coordinates**.
- `t20_pinout-v3.5.xlsx`, `T20F256` sheet, Efinix v3.5, March 2025. Contains precisely **256 nonempty unique BGA ball coordinates**.
- Current supporting primary documentation: [T120 datasheet v4.0](https://www.efinixinc.com/docs/trion120-ds-v4.0.pdf), [T20 datasheet v6.0](https://www.efinixinc.com/docs/trion20-ds-v6.0.pdf), [Trion Interfaces User Guide](https://www.efinixinc.com/docs/trion-interfaces-ug-v8.9.pdf), [Efinix documentation index](https://www.efinixinc.com/support/docs.php?p=t).

The source XLSX sheets, not this report, are the authority for package ball names. The workbook preserves all records and annotates provisional net uses.

## Findings that are confirmed by the pinout XLSX

| Item | T120F484 | T20F256 |
|---|---:|---:|
| Physical BGA balls in table | 484 | 256 |
| Named user GPIO resources (including LVDS-as-GPIO) | 256 | 195 |
| Physical dedicated DDR pins | 74 (BANK3E) | Not present in this package pin sheet |
| Dedicated configuration pins | CDONE, CRESET_N | CDONE, CRESET_N |
| JTAG pins | TCK, TDI, TDO, TMS | TCK, TDI, TDO, TMS |

T120 F484 dedicated DDR samples: `DDR_DQ[0] = K21`, `DDR_DQ[31] = AA18`, `DDR_DQS[0] = L21`, `DDR_DQS_N[0] = L22`, `DDR_CK = N21`, `DDR_CK_N = P21`. **This verifies the FPGA end of the DDR netlist only.** The DDR physical bank has generic DDR labels (`DDR_A`, `DDR_BA`, `DDR_RAS_N` etc.). In the LPDDR2 mode, Alliance exposes multiplexed `CA[9:0]`; do not connect those labels to RAM CA pins by guesswork. The generated DDR_0 configuration and Efinix LPDDR2-specific package mapping must dictate final RAM interconnect.

For DDR PHY reference clock, the T120 spreadsheet marks `GPIOR_186_PLLIN0 / M15` and `GPIOB_RXP09_CLKP0 / R12` as possible DDR PHY reference resources. They are **reserved, not selected** until an Efinity-generated interface validates the required PLL_BR0 path and oscillator placement.

## Candidate allocation — physical balls real, Efinity assignments NOT proven

| Proposed net group | T120 bank(s) | T20 bank(s) | Proposed rail | Signals |
|---|---|---|---:|---:|
| LCD RGB666 + PCLK/HSYNC/VSYNC/DE + reset/serial | BANK1C (16), BANK1D (10) | — | 1.8 V | 26 |
| F133 SDC1 four-bit SDIO | BANK1F (5), BANK1G (1) | — | 3.3 V | 6 |
| Half-duplex/synchronous T20 accelerator bridge | BANK2A (12), BANK2B (10) | BANK1D (16), BANK1B (6) | 1.8 V | 16 data + 6 controls |
| T20 configuration/control signals | BANK2C (5) | BANK1A dual-use config pins (3) + dedicated CDONE/CRESET_N (2) | proposal 1.8 V | 5 |

**Critical independent supply groups (T120)**:

- `VCCIO1B_1C`: BANK1B and BANK1C; proposed 1.8 V.
- `VCCIO1D_1E`: BANK1D and BANK1E; proposed 1.8 V.
- `VCCIO1F_1G`: BANK1F and BANK1G; proposed 3.3 V.
- `VCCIO2A`, `VCCIO2B`, `VCCIO2C`: separately powered banks proposed at 1.8 V for accelerator link and programming.
- `VCCIO3D_TR_BR`: includes DDR reference candidate M15 and a 16-GPIO bank; no 1.8/3.3 rail assigned yet.
- `VCCIO_DDR`: dedicated LPDDR2 interface, 1.2 V (not general GPIO).

**T20 shared rails**: BANK1B/BANK1C use `VCCIO1B_1C` and BANK1D/BANK1E use `VCCIO1D_1E`. Both groups are proposed 1.8 V. The BANK1A config GPIO supply is also proposed 1.8 V subject to FPGA configuration-mode verification.

All proposed group voltages have been checked in the generated net map: **no proposed merged-bank rail is assigned contradictory voltage values.** This is a spreadsheet-level consistency result, not a proof that the GPIO and clock implementation compiles or routes.

For the 16-bit accelerator bridge, the T120 candidate uses LVDS-capable pins as single-ended GPIO: 12 in BANK2A and 10 in BANK2B. This keeps each bank at or below Efinix's recommended limit of **14 such outputs/bidirectional pins per bank**, but the actual source-synchronous clock paths, I/O voltage, timing closure, bank placement and ownership still require Efinity verification. DDR is not being accessed over this bridge.

**Illustrative candidate links only:**

| ARC-1 net | Device | Physical ball | Manufacturer pin name |
|---|---|---|---|
| `LCD_R0` | T120 | P5 | GPIOL_47 |
| `LCD_PCLK` | T120 | M6 | GPIOL_66_CLK0 |
| `SDC1_CLK` | T120 | E4 | GPIOL_164_PLLIN0 |
| `SDC1_CMD` | T120 | J1 | GPIOL_119 |
| `SDC1_DAT0` | T120 | H4 | GPIOL_121 |
| `T20_CFG_CCK` | T20 | M3 | GPIOL_01_CCK |
| `T20_CFG_CSI` | T20 | N3 | GPIOL_04_CSI |
| `T20_CFG_CRESET_N` | T20 | P1 | CRESET_N |
| `T20_CFG_CDONE` | T20 | R1 | CDONE |

## Power-grade correction and why it matters

The current datasheets distinguish **I4** from **I4L**. For the *selected* `T120F484I4` and `T20F256I4` (non-L), the normal `VCC` and `VCCA_PLL` supplies are **nominal 1.2 V** (recommended 1.15–1.25 V). The **I4L** variants run their cores at **nominal 1.1 V** (recommended 1.05–1.15 V). Earlier discussion briefly conflated these speed grades; that was corrected. The R19 1.2 V core power specification is correct **provided I4 remains the ordering suffix**.

The selected T120 `VCCIO_DDR` rail and the selected LPDDR2 `VDD2/VDDCA/VDDQ` supplies are also nominal 1.2 V, but load/transient isolation, sequencing and power-budget decisions are still open. Do not assume a single unfiltered supply suffices for all 1.2 V domains.

## Gate status / STOP conditions

1. **G02 — Physical pin data: PASS.** Both manufacturer F484/F256 ball tables are now present and have unique, complete coordinates.
2. **G02 — Legal assignment: OPEN.** Efinity must accept all bank voltages, DDR_0, SDIO clock pin, LCD output clocks, programming/recovery pins, and source-synchronous T20 link. NO PCB pin-lock before this test.
3. **G03 — LPDDR2 interconnect: OPEN.** Generic FPGA DDR pin nomenclature must be resolved to Alliance CA/strobes/controls using generated LPDDR2 pinout, not by direct name matching.
4. **G04 — SDIO FPGA peripheral: OPEN.** An input clock pad reservation does not provide a synthesized CMD5/CMD52/CMD53-compatible device.
5. **G05 — LCD panel: OPEN.** Panel-specific ST7701S initialization, verified RGB timing and 45-pin FPC mating connector remain required.
6. **G06 — Power design: OPEN.** Regulator MPNs, load estimates, power-good, configuration isolation and brownout response remain required.
7. **G07 — Complete pin budget: PARTIAL.** The working plan intentionally excludes full audio, boot/storage, external debug, USB, controls and supervisor. These must be allocated before final release. Do not infer that their omission from this provisional net map means they are unnecessary.
8. **T20 programming: OPEN.** The exact passive-SPI pin semantics and config bank voltage/controls require review, even though the dedicated balls are established.

## Next engineering action

Import `T120F484` and `T20F256` package definitions into Efinity Interface Designer. Build an empty top-level project with DDR_0 ×32 LPDDR2 256 Mbit and all candidate interface GPIO/clock blocks, assign proposed banks, and save the generated pinout/conflict/timing reports. **If rejected, revise the candidate allocation in Efinity before editing the motherboard schematic.** Keep `R19_pinlock.csv` unreleased until every P0 gate passes.

## Files in this package

- `ARC1_R19_VERIFIED_BALLS_PROVISIONAL_BANKPLAN.xlsx`: auditable bank budget, candidate nets, full T120 and T20 ball listings, 74 DDR resource pins and verification gates.
- `ARC1_T120_physical_pin_inventory.csv`, `ARC1_T20_physical_pin_inventory.csv`: flattened full package coordinates with draft allocations.
- `ARC1_provisional_signal_mapping.csv`: one row per candidate/reserved logical net and physical ball.
- The *original* Efinix pinout XLSX files, copied without modifications for long-term archive.

No bitstream has been generated, no synthesis has been run, and no physical electrical circuit has been tested in this pass.
