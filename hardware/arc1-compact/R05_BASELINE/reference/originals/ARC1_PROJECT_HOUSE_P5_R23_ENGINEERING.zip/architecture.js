/* ARC-1 R22 source feasibility arithmetic. No assignments or hardware signoff. */
(()=>{'use strict';
const WORKBOOK_HASH='8a6ecd5700c5895cfe306dfe3c37bac2d40feebe2b7ea4e8c43291eab831bc6d';
const GATE_IDS=Array.from({length:11},(_,i)=>'G'+String(i+1).padStart(2,'0'));
const requireValue=(condition,message)=>{if(!condition)throw Error(message);};
const finitePositive=value=>typeof value==='number'&&Number.isFinite(value)&&value>0;
function summarizeFacts(facts){
 requireValue(facts?.schema==='arc1-f484-resource-facts-v1','Unsupported resource-facts schema.');
 requireValue(facts.source?.sha256===WORKBOOK_HASH&&facts.source.sheet==='T120F484','F484 workbook provenance does not match the provided authority.');
 requireValue(Array.isArray(facts.rows)&&facts.rows.length===484,'Expect exactly 484 package rows, not an ARC-1 netlist.');
 const seen=new Set();
 for(const row of facts.rows){
  requireValue(row&&/^[A-Z]{1,2}\d{1,2}$/.test(row.ball)&&!seen.has(row.ball),'Invalid or duplicated source ball.');
  seen.add(row.ball);
  for(const field of ['bank','name','configuration','ddr','lvds','ddio','clockRegion'])requireValue(typeof row[field]==='string','Source field missing: '+field+'.');
  requireValue(!Object.hasOwn(row,'net')&&!Object.hasOwn(row,'assignedNet'),'Package facts must not contain assigned electrical nets.');
  requireValue(['','Yes'].includes(row.ddio),'Unknown workbook DDIO annotation.');
  const ddioBank=/^BANK1[A-G]$/.test(row.bank)||['BANK3D','TR','BR'].includes(row.bank);
  requireValue((row.ddio==='Yes')===(row.name.startsWith('GPIO')&&ddioBank),'DDIO annotation contradicts the F484 bank/resource class.');
 }
 const gpio=facts.rows.filter(row=>row.name.startsWith('GPIO'));
 const ddio=gpio.filter(row=>row.ddio==='Yes');
 const tx=new Set(gpio.filter(row=>/_TX\d+$/.test(row.lvds)).map(row=>row.lvds));
 const rx=new Set(gpio.filter(row=>/_RX\d+$/.test(row.lvds)).map(row=>row.lvds));
 requireValue(gpio.length===256&&ddio.length===96&&tx.size===40&&rx.size===40,'Source resource counts differ from the archived F484 inventory.');
 for(const group of [...tx,...rx])requireValue(gpio.filter(row=>row.lvds===group).length===2,'Incomplete source differential pair '+group+'.');
 const bankCounts={};
 for(const row of gpio){if(!bankCounts[row.bank])bankCounts[row.bank]={gpio:0,ddio:0,configurationCandidates:0};const bank=bankCounts[row.bank];bank.gpio++;if(row.ddio==='Yes')bank.ddio++;if(row.configuration)bank.configurationCandidates++;}
 return {gpioPerChip:gpio.length,ddioPerChip:ddio.length,configDdioPins:ddio.filter(row=>row.configuration).length,
  ddrReferenceDdioPins:ddio.filter(row=>row.ddr).length,
  conservativeUnannotatedDdioPins:ddio.filter(row=>!row.configuration&&!row.ddr).length,
  lvdsTxPairs:tx.size,lvdsRxPairs:rx.size,hardDdrControllersPerChip:1,bankCounts};
}
function analyze(record,facts){
 if(record?.schema==='arc1-r23-architecture-review-v1'){
  requireValue(globalThis.ARC1R23Architecture?.analyze,'R23 analysis module is unavailable.');
  return globalThis.ARC1R23Architecture.analyze(record,facts);
 }
 requireValue(record?.schema==='arc1-architecture-review-v1'&&record.stage==='SOURCE_REVIEW_ONLY','Architecture analysis is source review only.');
 requireValue(record.fabrication==='NO-GO'&&record.gateStatus==='OPEN','Hardware release assertions are not accepted by this analyzer.');
 requireValue(Array.isArray(record.gates)&&record.gates.length===11&&new Set(record.gates.map(g=>g.id)).size===11&&GATE_IDS.every(id=>record.gates.some(g=>g.id===id&&g.state==='OPEN')),'Every G01–G11 gate must remain OPEN.');
 requireValue(Array.isArray(record.sources)&&Array.isArray(record.decisions)&&Array.isArray(record.experiments),'Missing auditable architecture records.');
 const sourceIds=new Set(record.sources.map(s=>s.id));
 requireValue(sourceIds.size===record.sources.length,'Duplicate source identifiers.');
 for(const source of record.sources)requireValue(typeof source.id==='string'&&source.id&&typeof source.title==='string'&&source.title&&typeof source.version==='string'&&source.version&&typeof source.locator==='string'&&source.locator,'Incomplete source reference metadata.');
 const decisionIds=new Set();
 for(const decision of record.decisions){
  requireValue(!decisionIds.has(decision.id)&&['SELECTED_CONDITIONAL','PROPOSED','REJECTED'].includes(decision.state),'Unsupported or duplicate architecture decision.');decisionIds.add(decision.id);
  requireValue(decision.sourceIds?.length&&decision.sourceIds.every(id=>sourceIds.has(id)),'Decision references missing sources.');
  requireValue(decision.gateIds?.length&&decision.gateIds.every(id=>GATE_IDS.includes(id)),'Decision references missing gates.');
 }
 const experimentIds=new Set();
 for(const experiment of record.experiments){
  requireValue(experiment.state==='OPEN'&&!experimentIds.has(experiment.id),'Experiment completion requires real artifacts, outside this review.');experimentIds.add(experiment.id);
  for(const key of ['requiredArtifacts','acceptance','stopConditions'])requireValue(Array.isArray(experiment[key])&&experiment[key].length,'Experiment contract missing '+key+'.');
  requireValue(experiment.gateIds?.length&&experiment.gateIds.every(id=>GATE_IDS.includes(id)),'Experiment references missing gates.');
 }
 for(const constraint of record.documentedConstraints||[]){
  requireValue(['DOCUMENTED_CAPABILITY','DOCUMENTED_CAPABILITY_REQUIRES_VENDOR_CONFIRMATION'].includes(constraint.stage)&&constraint.measured===null,'Source constraints cannot claim measured hardware proof.');
  requireValue(constraint.sourceIds?.length&&constraint.sourceIds.every(id=>sourceIds.has(id))&&constraint.gateIds?.length&&constraint.gateIds.every(id=>GATE_IDS.includes(id)),'Constraint source or gate reference missing.');
 }
 const resourceBudget=summarizeFacts(facts),inputs=record.calculationInputs;
 requireValue(inputs&&inputs.hostTargetBitsPerSecond===1000000000&&inputs.lvdsDocumentedLaneCeilingMbps===800&&inputs.lvdsSerializationFactor===7,'Unexpected source/target interface assumptions.');
 requireValue(inputs.fpgaMemoryBits===1073741824&&inputs.fpgaMemoryDqBits===32&&inputs.fpgaMemoryTargetMtps===800,'Unexpected R22 candidate memory goals.');
 requireValue(inputs.parallelClockMHz===null&&inputs.achievedLinkBytesPerSecond===null,'An unmeasured A/B operating clock or throughput must remain UNKNOWN.');
 requireValue(Array.isArray(inputs.modes)&&inputs.modes.length>0,'Missing display calculation inputs.');
 const hostRawBytesPerSecond=inputs.hostTargetBitsPerSecond/8;
 const modes=inputs.modes.map(mode=>{
  for(const key of ['width','height','totalWidth','totalHeight','fps','framebufferBytesPerPixel'])requireValue(finitePositive(mode[key]),'Invalid display arithmetic input '+key+'.');
  requireValue(mode.totalWidth>=mode.width&&mode.totalHeight>=mode.height,'Timing totals cannot be smaller than active video.');
  requireValue(mode.sourceIds?.length&&mode.sourceIds.every(id=>sourceIds.has(id)),'Display timing source reference missing.');
  const frameBytes=mode.width*mode.height*mode.framebufferBytesPerPixel,scanoutBytesPerSecond=frameBytes*mode.fps;
  const pixelClockMHz=mode.totalWidth*mode.totalHeight*mode.fps/1000000;
  const singleLinkMbps=pixelClockMHz*inputs.lvdsSerializationFactor,dualLinkMbps=singleLinkMbps/2;
  requireValue([frameBytes,scanoutBytesPerSecond,pixelClockMHz,singleLinkMbps,dualLinkMbps,hostRawBytesPerSecond/frameBytes].every(Number.isFinite),'Display arithmetic exceeds finite numeric range.');
  return {...mode,frameBytes,scanoutBytesPerSecond,pixelClockMHz,singleLinkMbps,dualLinkMbps,
   hostRawCeilingExceeded:scanoutBytesPerSecond>hostRawBytesPerSecond,
   singleLinkExceedsLvdsLimit:singleLinkMbps>inputs.lvdsDocumentedLaneCeilingMbps,
   dualLinkExceedsLvdsLimit:dualLinkMbps>inputs.lvdsDocumentedLaneCeilingMbps,
   hostRawFrameRateCeiling:hostRawBytesPerSecond/frameBytes,measuredScanoutBytesPerSecond:null};
 });
 requireValue(Array.isArray(inputs.parallelWidthsPerDirection)&&inputs.parallelWidthsPerDirection.every(width=>[16,32].includes(width)),'Undeclared parallel width study.');
 const linkCandidates=inputs.parallelWidthsPerDirection.map(width=>({widthPerDirection:width,ddioDataPinsPerChip:2*width,bytesPerClockPerDirection:2*width/8,
  clockMHz:null,rawBytesPerSecond:null,remainingConservativeDdioAfterData:resourceBudget.conservativeUnannotatedDdioPins-2*width,
  rgmiiPhysicalPinsBudget:12,remainingConservativeDdioAfterDataAndRgmii:resourceBudget.conservativeUnannotatedDdioPins-2*width-12,
  note:'Conservative 12-pin RGMII budget; not all clock pins require DDIO data logic. A/B clocks, control, rescue and real configuration mode still need allocation.'}));
 requireValue(Array.isArray(inputs.serializedLanesPerDirection)&&inputs.serializedLanesPerDirection.every(lanes=>[4,8,16].includes(lanes)),'Undeclared native-LVDS lane study.');
 const serializedLinkCandidates=inputs.serializedLanesPerDirection.map(lanes=>({lanesPerDirection:lanes,lvdsTxPairsForData:lanes,lvdsRxPairsForData:lanes,
  sourceLaneCeilingMbps:inputs.lvdsDocumentedLaneCeilingMbps,theoreticalRawBytesPerSecond:lanes*inputs.lvdsDocumentedLaneCeilingMbps*1000000/8,
  achievedLaneMbps:null,achievedBytesPerSecond:null,clockPairs:null,note:'Data-pair counts only; forwarding, clock/PLL legality, deskew, framing overhead and timing are unverified.'}));
 const memory={perChipBytes:inputs.fpgaMemoryBits/8,perChipMiB:inputs.fpgaMemoryBits/8/1048576,
  candidateRawBytesPerSecond:inputs.fpgaMemoryDqBits/8*inputs.fpgaMemoryTargetMtps*1000000,measuredBytesPerSecond:null,
  sharedAddressSpace:false,combinedBytesAreIndependentPools:true};
 const findings=[
  {id:'AF01',title:'Retain local rendering and scanout',message:'Both RGBA32 display examples exceed the raw host ceiling. Commands/assets go to A; its local DDR serves rendering and scanout. Sustainable bandwidth remains unmeasured.',sourceIds:['R22-AUTHORITY','LINUX-MODES'],gateIds:['G01','G02','G04']},
  {id:'AF02',title:'Dual-link study for standard 1080p60',message:'A single 7:1 1080p60 LVDS lane calculates to 1039.5 Mbit/s, exceeding the source limit. Dual pixel links calculate to 519.75 Mbit/s per data lane; bridge mapping and F484 legality still need proof.',sourceIds:['T120-DS','ITE-6263','LINUX-MODES'],gateIds:['G02','G08']},
  {id:'AF03',title:'96 DDIO pins, with overlapping alternatives',message:'Conservative quarantine of all configuration and DDR-reference candidates leaves 76 DDIO pins. The 32+32 data study plus a conservative 12-pin host budget consumes that pool before extra A/B resources. Mode-specific reuse and native LVDS need a complete vendor study.',sourceIds:['T120-PINOUT','T120-DS'],gateIds:['G03','G04','G08']},
  {id:'AF04',title:'Recovery must survive absent FPGA user logic',message:'A user-RTL SPI service cannot recover unconfigured A. Preserve independently reachable A/B configuration/reset and service paths with reviewed bus/power-state ownership.',sourceIds:['R22-AUTHORITY','T120-DS'],gateIds:['G05','G07','G09']},
  {id:'AF05',title:'Documented memory class, unverified exact implementation',message:'1 Gbit x32 LPDDR2 at the candidate 800 rate is in the documented controller configuration class. This does not establish Alliance CA mapping, calibration, paired pin legality or useful DDR throughput.',sourceIds:['T120-DS','ALLIANCE-DDR'],gateIds:['G01','G08']},
  {id:'AF06',title:'Exact supply classes matter',message:'Selected regular I4 FPGA core/PLL uses the documented nominal 1.2 V class. The Alliance memory also requires its near-1.8 V VDD1 class alongside its near-1.2 V memory/I/O classes. Regulators, sequencing and currents remain unverified.',sourceIds:['T120-DS','ALLIANCE-DDR'],gateIds:['G01','G07']},
  {id:'AF07',title:'Ten-year memory power-loss qualification is a blocker',message:'The public preliminary Alliance data limits uncontrolled power-offs to 400 over device life. Obtain current vendor confirmation and prove controlled shutdown/power-loss handling before accepting this exact part for the ten-year goal.',sourceIds:['ALLIANCE-DDR','R22-AUTHORITY'],gateIds:['G01','G07','G09','G11']},
  {id:'AF08',title:'DDR startup owns clock resources',message:'The DDR PHY requires documented PLL_BR0/CLKOUT0 and I/O-pad reference behavior. A workbook LVDS DDR-reference alternative is not automatically a legal primary startup clock; resolve the warning in the actual project.',sourceIds:['T120-DS','T120-PINOUT'],gateIds:['G01','G08']},
  {id:'AF09',title:'Reallocate the HDMI reference for F484',message:'The F576 example uses ten data pairs plus one shared clock. F484 lacks several referenced TX resources and the reset resource. A different exact-package allocation and qualified bridge mode are required; no reference ball map is copied.',sourceIds:['T120-HDMI-REF','T120-PINOUT'],gateIds:['G02','G08']}
 ];
 return {status:'SOURCE_REVIEW_ONLY',fabrication:'NO-GO',gates:record.gates.map(g=>({...g})),calculations:{hostRawBytesPerSecond,modes,linkCandidates,serializedLinkCandidates,resourceBudget,memory},findings};
}
globalThis.ARC1Architecture=Object.freeze({WORKBOOK_HASH,summarizeFacts,analyze});
})();
