#!/usr/bin/env python3
"""Optional independent, standard-library audit of original XLSX vs derived facts.

No net assignments, voltage choices, Efinity output or hardware signoff is produced.
Run from any directory: python scripts/verify-package-facts.py.
"""
import hashlib
import json
import pathlib
import re
import xml.etree.ElementTree as ET
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
EXPECTED_HASH = "8a6ecd5700c5895cfe306dfe3c37bac2d40feebe2b7ea4e8c43291eab831bc6d"
PATH = ROOT / "engineering/T120_pinout_v1.4.xlsx"
FACTS = json.loads((ROOT / "engineering/architecture/spreadsheetfacts.json").read_text())
assert hashlib.sha256(PATH.read_bytes()).hexdigest() == EXPECTED_HASH
assert FACTS["source"]["sha256"] == EXPECTED_HASH
assert FACTS["source"]["sheet"] == "T120F484"
NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
COLUMNS = {"bank": "A", "name": "B", "configuration": "C", "ddr": "D",
           "lvds": "E", "ddio": "F", "clockRegion": "G", "ball": "H"}
with zipfile.ZipFile(PATH) as archive:
    workbook = ET.fromstring(archive.read("xl/workbook.xml"))
    sheet = next(s for s in workbook.findall("m:sheets/m:sheet", NS) if s.attrib["name"] == "T120F484")
    rel_id = sheet.attrib["{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"]
    rels = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
    target = next(rel.attrib["Target"] for rel in rels if rel.attrib["Id"] == rel_id)
    sheet_path = target.lstrip("/") if target.startswith("/") else "xl/" + target
    shared = ET.fromstring(archive.read("xl/sharedStrings.xml"))
    strings = ["".join(si.itertext()) for si in shared.findall("m:si", NS)]
    records = {}
    for row in ET.fromstring(archive.read(sheet_path)).findall(".//m:row", NS):
        values = {}
        for cell in row.findall("m:c", NS):
            column = re.sub(r"\d", "", cell.attrib["r"])
            value = cell.find("m:v", NS)
            if value is not None:
                values[column] = strings[int(value.text)] if cell.attrib.get("t") == "s" else value.text
        ball = values.get("H", "")
        if re.fullmatch(r"[A-Z]{1,2}\d{1,2}", ball):
            assert ball not in records
            records[ball] = {field: values.get(column, "") for field, column in COLUMNS.items()}
assert len(records) == 484
assert len(FACTS["rows"]) == 484
for row in FACTS["rows"]:
    expected = records.pop(row["ball"])
    for field in COLUMNS:
        assert row[field] == expected[field], f"{row['ball']}/{field}: changed source definition"
assert not records
print("PASS: all 484 F484 rows match original workbook columns A–H exactly; no electrical nets assigned")
