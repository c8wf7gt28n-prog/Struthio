// Source review only. Prints calculated feasibility; cannot certify hardware.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import '../architecture.js';
import '../r23-architecture.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const read=name=>fs.readFileSync(path.join(root,name));
const record=JSON.parse(read('engineering/r23/architecture.json'));
const facts=JSON.parse(read('engineering/architecture/spreadsheetfacts.json'));
const hash=crypto.createHash('sha256').update(read('engineering/T120_pinout_v1.4.xlsx')).digest('hex');
if(hash!==ARC1Architecture.WORKBOOK_HASH||hash!==facts.source.sha256)throw Error('Original workbook integrity failure');
const result=ARC1Architecture.analyze(record,facts);
console.log(JSON.stringify(result,null,2));
