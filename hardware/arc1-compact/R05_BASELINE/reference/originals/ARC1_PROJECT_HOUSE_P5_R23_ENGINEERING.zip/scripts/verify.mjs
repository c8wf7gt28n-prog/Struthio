// Offline consistency checks. No compiler/synthesis or physical PCB validation is claimed.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import '../architecture.js';
import '../r23-architecture.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const read=(name)=>fs.readFileSync(path.join(root,name),'utf8');
const exists=(name)=>fs.existsSync(path.join(root,name));
// Preserve hashes of original authorities even though software files have changed.
const originalHashes=new Map(read('SOURCE_HASHES.sha256').trim().split(/\r?\n/).map(line=>[line.slice(66),line.slice(0,64)]));
for(const file of ['CLAUDE.md','pins.json','engineering/T120_pinout_v1.4.xlsx','engineering/R22_T120_PACKAGE_BALLS_UNASSIGNED.csv','engineering/R22_TABLETOP_SYSTEM_WORK_ORDER.md','engineering/R22_EVIDENCE_POLICY.md']){
  const preservedPath=file==='CLAUDE.md'?'engineering/history/r22/CLAUDE.md':file;
  assert.equal(createHash('sha256').update(fs.readFileSync(path.join(root,preservedPath))).digest('hex'),originalHashes.get(file),'Changed immutable authority '+preservedPath);
}
const pins=JSON.parse(read('pins.json'));
const rawCSV=read('engineering/R22_T120_PACKAGE_BALLS_UNASSIGNED.csv').trim().split(/\r?\n/);
assert.equal(rawCSV.length,969,'Package CSV must contain 968 rows plus one header');
for(const line of rawCSV.slice(1))assert(/,MANUFACTURER PIN SOURCE \/ ARC1 NET NOT ASSIGNED$/.test(line),'Old net candidate found in clean R22 CSV');
assert.equal(pins.length,968,'Expect 484 ball definitions per T120');
const sets=new Map([['T120-A',new Map()],['T120-B',new Map()]]);
for(const r of pins){
  assert(sets.has(r.chip),`Unexpected FPGA instance: ${r.chip}`);
  assert(/^[A-Z]{1,2}\d{1,2}$/.test(r.ball),`Malformed ball: ${r.ball}`);
  assert(r.name&&typeof r.name==='string',`Missing name ${r.ball}`);
  assert.equal(r.net,'',`Unexpected assigned ARC-1 net: ${r.chip}/${r.ball}`);
  assert.match(r.status,/UNASSIGNED/,`Assigned R22 net status not permitted: ${r.chip}/${r.ball}`);
  const block=sets.get(r.chip);
  assert(!block.has(r.ball),`Duplicate physical ball ${r.chip}/${r.ball}`);
  block.set(r.ball,r);
}
for(const [chip,set] of sets)assert.equal(set.size,484,`Incomplete ${chip} package definition`);
const a=sets.get('T120-A'),b=sets.get('T120-B');
for(const [ball,p] of a){
  const q=b.get(ball);assert(q,`T120-B missing ${ball}`);
  for(const field of ['bank','name','role','ddr'])assert.equal(p[field],q[field],`${ball}: A/B vendor mapping mismatch for ${field}`);
}
const plan=JSON.parse(read('tasks/roadmap.json'));
assert.equal(plan.schema,'arc1-roadmap-v1');
assert.equal(read('engineering/r23/R23_DEVELOPER_TASKS.json'),read('tasks/roadmap.json'),'Current R23 task mirror out of sync');
assert.equal(read('engineering/R22_DEVELOPER_TASKS.json'),read('engineering/history/r22/roadmap.json'),'Historical R22 task mirror changed');
assert(plan.tasks.length>=8,'Missing developer/hardware work queue');
assert(plan.tasks.some(t=>t.id==='DEV-002'&&t.state==='implemented: interchange; native Efinity adapter OPEN'&&t.evidence.includes('tests/evidence_node.cjs')));
assert.equal(plan.gates.length,14);assert(plan.gates.every(g=>g.state==='OPEN'),'No hardware gate can close through software intake');
assert(plan.tasks.filter(t=>t.id.startsWith('HW-')).every(t=>t.gate_state==='OPEN'));
const historicalArchitecture=JSON.parse(read('engineering/architecture/architecture.json'));
const architecture=JSON.parse(read('engineering/r23/architecture.json'));
const resourceFacts=JSON.parse(read('engineering/architecture/spreadsheetfacts.json'));
const analysis=ARC1Architecture.analyze(architecture,resourceFacts);
assert.equal(analysis.status,'SOURCE_REVIEW_ONLY');assert.equal(analysis.fabrication,'NO-GO');
assert.deepEqual(architecture.gates,plan.gates,'Architecture/task gate records must agree');
assert(historicalArchitecture.decisions.some(d=>d.id==='AD10'&&d.state==='PROPOSED'),'Historical memory lifetime blocker cannot become a hardware approval');
assert.equal(ARC1Architecture.analyze(historicalArchitecture,resourceFacts).gates.length,11,'Historical R22 schema changed');
assert.equal(analysis.calculations.memoryPools.targetInstalledMiB,384);
assert.equal(analysis.calculations.memoryPools.candidateInstalledMiB,448);
assert.equal(analysis.calculations.videoClockStudy.documentedReachable,false);
const r23Source=architecture.sources.find(source=>source.id==='R23-AUTHORITY');
assert.equal(r23Source.sha256,'007186705ecdde8a22860b0c287a3baaeb622cf526f9c1b7b22f9ca66a9e0d2a');
assert.equal(createHash('sha256').update(fs.readFileSync(path.join(root,r23Source.path))).digest('hex'),r23Source.sha256,'Changed original R23 owner handoff');
for(const row of resourceFacts.rows){const pin=a.get(row.ball);assert(pin,'Derived resource facts contain unknown ball');for(const field of ['bank','name','ddr'])assert.equal(row[field],pin[field],'Derived/source mismatch '+row.ball+'/'+field);}
const ids=new Set();
for(const t of plan.tasks){assert(!ids.has(t.id),`duplicate task ${t.id}`);ids.add(t.id);assert(t.pass_condition&&t.deliverables.length,'Task needs tangible pass evidence');}
const index=read('index.html'),house=read('house.js'),viewer=read('viewer.js'),sw=read('sw.js'),manifest=read('manifest.webmanifest');
const mandatory=['index.html','house.css','house.js','viewer.css','viewer.js','evidence.js','evidence-ui.js','architecture.js','architecture-ui.js','manifest.webmanifest','sw.js','pins.json','CLAUDE.md','engineering/T120_pinout_v1.4.xlsx','engineering/R22_T120_PACKAGE_BALLS_UNASSIGNED.csv','engineering/R22_CLAUDE_CODE_HANDOFF.md','engineering/R22_EVIDENCE_POLICY.md','engineering/R22_TABLETOP_SYSTEM_WORK_ORDER.md','tasks/roadmap.json','engineering/R22_EVIDENCE_INTAKE.md','engineering/ARC1_EVIDENCE_SCHEMA.json','engineering/architecture/ARCHITECTURE_DECISION_RECORD.md','engineering/architecture/ARCHITECTURE_TEST_REPORT.md'];
for(const x of mandatory)assert(exists(x),`Missing required source ${x}`);
assert(index.includes('R23 / PASS 05'));
assert(house.includes('handoffPage')&&house.includes('loadDeveloperRoadmap')&&house.includes('exportSnapshot'));
assert(viewer.includes('No physical model loaded'));
for(const entry of ['House','Viewer','Systems','Lab','Manual','Archive'])assert(index.includes('>'+entry+'</span>'),`Missing bottom department ${entry}`);
const m=sw.match(/const ASSETS=(\[[^;]+\]);/);assert(m,'Invalid service-worker precache list');
const assets=JSON.parse(m[1]);
const unique=new Set();
for(let asset of assets){assert(!unique.has(asset),'Duplicate service-worker asset '+asset);unique.add(asset);if(asset==='./')continue;asset=asset.replace(/^\.\//,'');assert(exists(asset),'Missing offline precache asset '+asset);}
for(const file of ['evidence.js','evidence-ui.js','engineering/ARC1_EVIDENCE_SCHEMA.json','engineering/ARC1_EVIDENCE_TEMPLATE.json','engineering/ARC1_EVIDENCE_TEMPLATE.csv','engineering/R22_EVIDENCE_INTAKE.md'])assert(unique.has('./'+file),'Intake offline asset missing '+file);
for(const file of ['architecture.js','architecture-ui.js','engineering/architecture/architecture.json','engineering/architecture/spreadsheetfacts.json','engineering/architecture/ARCHITECTURE_DECISION_RECORD.md','engineering/architecture/MEMORY_REVIEW.md','engineering/architecture/HOST_LINK_REVIEW.md','engineering/architecture/DISPLAY_LINK_REVIEW.md','engineering/architecture/RECOVERY_POWER_REVIEW.md'])assert(unique.has('./'+file),'Architecture offline asset missing '+file);
for(const file of ['r23-architecture.js','r23-evidence.js','engineering/r23/architecture.json','engineering/r23/R23_SYSTEM_EVIDENCE_SCHEMA.json','engineering/r23/R23_SYSTEM_EVIDENCE_TEMPLATE.json','engineering/r23/ARC1_R23_Handoff.docx','engineering/r23/R23_ARCHITECTURE_DECISION_RECORD.md','engineering/r23/R23_TEST_REPORT.md','engineering/r23/R23_MIGRATION_RECORD.md'])assert(unique.has('./'+file),'Current R23 offline asset missing '+file);
assert(index.includes('<script src="evidence.js"></script>')&&index.includes('<script src="evidence-ui.js"></script>'));
assert(index.includes('<script src="architecture.js"></script>')&&index.includes('<script src="architecture-ui.js"></script>'));
assert(index.includes('<script src="r23-evidence.js"></script>')&&index.includes('<script src="r23-architecture.js"></script>'));
for(const f of ['house.js','viewer.js','house.css','viewer.css','index.html','manifest.webmanifest'])assert(!/\b(?:SLIM4|STRUTHIO)\b/i.test(read(f)),'Prior-project identity in active UI '+f);
for(const href of house.matchAll(/href=\\?"engineering\/([^"\\]+)\\?"/g)){
  const name=decodeURIComponent(href[1]);
  if(name.includes('${'))continue; // Runtime-generated Archive card, checked separately below.
  assert(exists('engineering/'+name),'Broken bundled engineering link '+name);
}
for(const entry of house.matchAll(/\['[^'\n]+','(R22_[^'\n]+\.(?:md|json)|T120_pinout_v1\.4\.xlsx|R19_T120_pin_inventory\.csv)'/g)){assert(exists('engineering/'+entry[1]),'Archive references missing '+entry[1]);}
for(const entry of house.matchAll(/\['[^'\n]+','(architecture\/[^'\n]+\.(?:md|json))'/g))assert(exists('engineering/'+entry[1]),'Archive architecture link missing '+entry[1]);
for(const entry of house.matchAll(/\['[^'\n]+','(r23\/[^'\n]+\.(?:md|json|docx))'/g))assert(exists('engineering/'+entry[1]),'Current Archive link missing '+entry[1]);
for(const entry of read('architecture-ui.js').matchAll(/href="(engineering\/[^"\n]+)"/g))assert(exists(entry[1]),'Architecture panel link missing '+entry[1]);
JSON.parse(manifest);
console.log(`PASS: ${pins.length} unassigned A/B package balls; ${plan.tasks.length} developer tasks; ${assets.length} offline assets; required source and identity checks.`);
