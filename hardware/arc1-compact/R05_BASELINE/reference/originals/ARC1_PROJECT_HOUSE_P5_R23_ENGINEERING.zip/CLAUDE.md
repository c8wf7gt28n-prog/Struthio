# ARC-1 Project House — R23 continuation authority

Read this file, the **full** `engineering/r23/ARC1_R23_Handoff.docx`, its text extraction, the R23 decision record and migration record before work. R23 is the latest owner architecture; original R22 instructions are preserved at `engineering/history/r22/CLAUDE.md`. Historical R22 work order/evidence policy remain unchanged. R23 overrides superseded topology and storage assumptions.

## Preserve the existing project

Run `npm test` before changing source. Keep the existing design, six navigation departments, six Viewer tabs, local notes, dependency-free PWA and explicit unmodeled geometry. Use `tasks/roadmap.json` as the current queue; its R23 mirror is `engineering/r23/R23_DEVELOPER_TASKS.json`. Preserve historical authorities. Record changes, executed checks, source hashes and remaining evidence in each handoff.

## Owner-selected R23 architecture

- Tabletop console, external HDMI TV/monitor, wired USB gamepads; no internal LCD, handheld PCB, T20 or eMMC.
- F133-B with independent 64 MiB internal DDR2. T120F484I4 A is the permanent GPU; B is the game-personality accelerator. Each FPGA has its own 128 MiB x32 LPDDR2 target.
- BT820B composition target has independent 64 MiB x16 LPDDR2. Four physical pools target 384 MiB. Named AS4C64M16MD2A-25BIN is actually 1 Gbit = 128 MiB, implying 448 MiB if installed; preserve the mismatch as OPEN. Do not silently change the target or relabel physical RAM as 64 MiB usable.
- Video target is A LVDS→BT LVDS RX/composition→BT LVDS TX→IT6263N candidate→HDMI. Standard 720p60/1080p60 and exact bridge support are unverified. AN086 v1.4's documented clock set does not produce 74.25 MHz; AN097 alternate-blanking HDMI examples offer a qualification path, not exact-rate/ITE proof.
- Three separate dedicated 16 MiB SPI NORs, one each for F133/A/B; capacity locked, exact SKU/partition/image fit OPEN. Separate SPI NAND games, model/capacity/ECC/filesystem OPEN. Cold boot each FPGA from its own NOR; study passive/RAM-staged B game loading with exclusive bus ownership and NOR isolation rather than default per-launch NOR writes.
- RGMII CPU→A candidate with independent SPI rescue; useful direct full-duplex A↔B transport, width/clocks OPEN. BT command master, asset transfer, audio and external I²S clock master remain OPEN.

## Evidence and integrity

`pins.json` contains 968 manufacturer package definitions, 484 per FPGA, **not PCB nets**. Keep it, the original Efinix workbook and clean unassigned CSV byte-identical. Derived resource facts are source counts, not assignments. Never invent CAD, pins, voltages, geometry, currents, actual image sizes, drivers or measured throughput.

Evidence stages are SELECTED DESIGN, MANUFACTURER DOCUMENTED, PROPOSED IMPLEMENTATION, EDA VERIFIED, PROTOTYPE MEASURED and MANUFACTURING RELEASED. Keep them separate. **G01–G14 OPEN; hardware/fabrication NO-GO.** Source arithmetic, report declarations, hashes and passing software tests cannot close a gate.

Keep legacy `evidence.js`/`arc1-evidence-v1` behavior for historical A/B pin reports; it covers only 11 historical gates. Current `r23-evidence.js` uses explicit `arc1-r23-system-evidence-v1` JSON, preserves raw bytes/provenance, checks memory/NOR/NAND/video declarations and always returns 14 OPEN gates. Neither is a native Efinity parser. Implement an adapter only after inspecting genuine unedited exports. Hash equality identifies bytes, not origin, loadable length or signoff.

Current source review is `engineering/r23/architecture.json` and `r23-architecture.js`; historical R22 arithmetic remains intact. Manufacturer documents establish capability only. Current BT DDR preset documentation omits LPDDR2/512 Mbit entries despite datasheet support; obtain exact vendor initialization guidance. Alliance's preliminary 400 uncontrolled-power-off lifetime limit and current lifecycle/errata require clarification. No vendor PDF/IP is redistributed without rights.

## Next bounded work

Obtain independent original A/B Efinity projects and full DDR/bank/pin/clock/STA/warning reports. Resolve BT 64 MiB exact part/init and the end-to-end 60 Hz clock/mapping strategy in parallel. Extract genuine CPU/A/B loadable image lengths before partition promises. Then combine DDR, host, video, A/B, configuration, debug and storage in the full package study. Proceed to fault-tested protocols, power/recovery, real CAD and measured prototype acceptance as evidence supports them.

Run meaningful negative/provenance/regression tests and `python scripts/verify-package-facts.py` if Python is available. Real-browser attempts are blocked in this workspace by HTTP/socket/Chromium permissions; synthetic DOM/service-worker tests are not an interactive browser pass. Do not claim Efinity, RTL simulation, synthesis, STA, electrical or bench work that was not executed. Referenced old U2/U3/U4 documents are absent; their contents are BLOCKED, not reconstructed.

`SOURCE_HASHES.sha256` remains the original R22 manifest; its original CLAUDE entry maps to the archived R22 copy. `WORKING_SOURCE_HASHES.sha256` records this delivery. Fourteen roadmap workstreams are recommended roles, not claims about actual agent identities or completed work.
