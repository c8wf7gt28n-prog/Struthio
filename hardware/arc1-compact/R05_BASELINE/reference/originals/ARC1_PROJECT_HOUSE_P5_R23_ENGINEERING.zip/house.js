/* ARC-1 Project House, Pass 05 / R23. R.A. Peddycoart.
   Standalone offline engineering PWA. Legacy project geometry/data is not packaged. */
(()=>{'use strict';
const $=s=>document.querySelector(s);
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const systems=[
 {
  "id": "cpu",
  "title": "F133-B · System CPU",
  "subtitle": "64 MiB in-package DDR2 / launcher and game logic",
  "group": "HOST",
  "stage": "documented",
  "spec": [
   [
    "Silicon",
    "Allwinner F133-B"
   ],
   [
    "Memory",
    "64 MiB independent system DDR2"
   ],
   [
    "Boot",
    "Dedicated 16 MiB NOR-F133; SKU and partitions OPEN"
   ],
   [
    "Fast link",
    "RGMII to T120-A; independent SPI rescue"
   ],
   [
    "USB",
    "Wired USB HID gamepads; hub/topology OPEN"
   ]
  ],
  "known": "Manufacturer documents host memory and peripheral capability. R23 selects a dedicated boot NOR and separate game SPI NAND; no working board is established.",
  "needs": [
   "Prove crossed RGMII/fixed-link endpoint and exact F133 pinmux.",
   "Qualify independent NOR boot, SPI NAND ownership and rescue when FPGA user logic fails.",
   "Verify USB host/HID firmware, current limit, ESD and reconnection."
  ],
  "doc": "r23/R23_ARCHITECTURE_DECISION_RECORD.md"
 },
 {
  "id": "gpua",
  "title": "T120-A · Permanent GPU",
  "subtitle": "128 MiB independent LPDDR2 / video toward BT820B",
  "group": "GRAPHICS",
  "stage": "provisional",
  "spec": [
   [
    "Silicon",
    "T120F484I4"
   ],
   [
    "Local RAM",
    "128 MiB ×32 LPDDR2 target through DDR_0"
   ],
   [
    "Video",
    "LVDS → BT820B live-video composition target"
   ],
   [
    "Boot",
    "Dedicated 16 MiB NOR-T120-A; actual image fit OPEN"
   ],
   [
    "Responsibilities",
    "GPU ABI, render buffers, DDR arbitration, bounded B dispatch"
   ]
  ],
  "known": "T120 package and hard-DDR capabilities are source documented. The R23 FPGA-to-BT820B path has no validated full pinplan, clock tree or working monitor.",
  "needs": [
   "Generate authentic F484 DDR, LVDS, RGMII and A/B combined constraints.",
   "Validate the BT820B input pixel format, clock relationship, latency and memory traffic.",
   "Measure bitstream length and retain independent JTAG/configuration rescue."
  ],
  "doc": "r23/VIDEO_CHAIN_REVIEW.md"
 },
 {
  "id": "gpub",
  "title": "T120-B · Game-defined Processor",
  "subtitle": "128 MiB independent LPDDR2 / one game image at a time",
  "group": "ACCELERATOR",
  "stage": "provisional",
  "spec": [
   [
    "Silicon",
    "T120F484I4"
   ],
   [
    "Local RAM",
    "128 MiB ×32 LPDDR2 target through its own DDR_0"
   ],
   [
    "Boot",
    "Dedicated 16 MiB NOR-T120-B; partition fit OPEN"
   ],
   [
    "Loading",
    "Verified passive or RAM-staged configuration route to evaluate"
   ],
   [
    "Safety",
    "Bounded memory grants; B cannot stall A or final display"
   ]
  ],
  "known": "The second FPGA owns its own memory channel. Default NOR rewriting on each game launch is not selected and endurance has not been proved.",
  "needs": [
   "Independently generate B DDR, bank and link timing evidence.",
   "Quiesce traffic, revoke grants, reconfigure, retrain DDR and identify the new personality.",
   "Verify invalid B image cannot obstruct CPU, A, display diagnostics or independent rescue."
  ],
  "doc": "r23/R23_ARCHITECTURE_DECISION_RECORD.md"
 },
 {
  "id": "rama",
  "title": "LPDDR2-A · GPU Memory",
  "subtitle": "128 MiB ×32 target / separate dynamic allocation pool",
  "group": "MEMORY",
  "stage": "provisional",
  "spec": [
   [
    "Candidate",
    "AS4C32M32MD2A-25BIN"
   ],
   [
    "Density",
    "1 Gbit / 32M ×32 = 128 MiB"
   ],
   [
    "Rate",
    "800 MT/s target; 3.2 GB/s theoretical local ceiling"
   ]
  ],
  "known": "Candidate organization matches the selected capacity arithmetically; exact controller, rails, package nets, clock and SI remain unverified.",
  "needs": [
   "Archive authentic Efinity DDR_0 geometry and generated pin/PLL reports.",
   "Qualify startup, calibration, sustained stress and safe power-off."
  ],
  "doc": "r23/R23_ARCHITECTURE_DECISION_RECORD.md"
 },
 {
  "id": "ramb",
  "title": "LPDDR2-B · Accelerator Memory",
  "subtitle": "128 MiB ×32 target / independent memory ownership",
  "group": "MEMORY",
  "stage": "provisional",
  "spec": [
   [
    "Candidate",
    "AS4C32M32MD2A-25BIN"
   ],
   [
    "Pool",
    "Physically separate from CPU, A and BT820B"
   ],
   [
    "Allocation",
    "No fixed 16 MiB game limit on available local memory"
   ]
  ],
  "known": "The 128 MiB B target is not a shared extension of A memory; transfers require explicit bounded protocol/DMA staging.",
  "needs": [
   "Generate and validate DDR_0 independently for B.",
   "Establish calibration and ownership lifecycle after reconfiguration."
  ],
  "doc": "r23/R23_ARCHITECTURE_DECISION_RECORD.md"
 },
 {
  "id": "bt820",
  "title": "BT820B · 2D / Video Assist",
  "subtitle": "Composition target / independent 64 MiB memory goal",
  "group": "COMPOSITION",
  "stage": "provisional",
  "spec": [
   [
    "Role",
    "Display-list/UI and live-video final composition target"
   ],
   [
    "Input",
    "T120-A LVDS TX → BT820B LVDS RX"
   ],
   [
    "Output",
    "BT820B LVDS TX → IT6263N → external HDMI"
   ],
   [
    "Control",
    "SPI/QSPI command/asset master and arbitration OPEN"
   ],
   [
    "Modes",
    "720p60 / 1080p60 output targets; complete clock chain OPEN"
   ]
  ],
  "known": "Manufacturer documents memory and dual-LVDS functions. This does not prove live-video overlays, bounded latency or the R23 monitor modes. BT820B is not selected as a general 3D triangle GPU.",
  "needs": [
   "Obtain exact memory initialization, live-video and register/clock evidence.",
   "Resolve 720p 74.25 MHz clock derivation and qualify dual-link 1080p timing.",
   "Select a control master and measure transfers between independent memory pools."
  ],
  "doc": "r23/BT820_MEMORY_VIDEO_REVIEW.md"
 },
 {
  "id": "rambt",
  "title": "LPDDR2-BT · Video Memory",
  "subtitle": "64 MiB ×16 target / named candidate capacity conflict",
  "group": "MEMORY",
  "stage": "open",
  "spec": [
   [
    "Selected target",
    "64 MiB = 512 Mbit, ×16 LPDDR2"
   ],
   [
    "Named candidate",
    "AS4C64M16MD2A-25BIN = 1 Gbit = 128 MiB"
   ],
   [
    "Conflict",
    "Candidate exceeds target by 64 MiB; SKU decision OPEN"
   ],
   [
    "Totals",
    "384 MiB selected target; 448 MiB with named 128 MiB BT candidate"
   ],
   [
    "Rate",
    "800 MT/s target; 1.6 GB/s theoretical local ceiling"
   ]
  ],
  "known": "The owner-selected target and named Alliance part do not match. No substitute memory part, larger installed capacity or controller compatibility is approved by this software.",
  "needs": [
   "Resolve the 512 Mbit target versus 1 Gbit named part explicitly.",
   "Verify exact BT820B controller geometry, initialization, pads, rails and PCB SI.",
   "Measure composition traffic, latency and independent memory stress."
  ],
  "doc": "r23/BT820_MEMORY_VIDEO_REVIEW.md"
 },
 {
  "id": "hostlink",
  "title": "RGMII · Host Link",
  "subtitle": "F133 MAC to permanent GPU / independent rescue retained",
  "group": "INTERCONNECT",
  "stage": "open",
  "spec": [
   [
    "Target",
    "1 Gbit/s line signaling"
   ],
   [
    "Raw ceiling",
    "125 MB/s per direction before protocol overhead"
   ],
   [
    "Bring-up",
    "Independent SPI/UART/configuration rescue"
   ],
   [
    "Ownership",
    "Cross TX outputs to peer RX; clock/skew proof OPEN"
   ]
  ],
  "known": "Documented RGMII and Linux fixed-link possibilities do not establish F133-to-FPGA electrical interoperability or useful throughput.",
  "needs": [
   "Validate actual F133 mux, driver and crossed endpoint timing.",
   "Retain diagnostics/configuration that work without A/B user logic."
  ],
  "doc": "r23/R23_ARCHITECTURE_DECISION_RECORD.md"
 },
 {
  "id": "bridge",
  "title": "T120-A ↔ T120-B Link",
  "subtitle": "Bounded jobs and explicit transfers between independent DDR pools",
  "group": "INTERCONNECT",
  "stage": "open",
  "spec": [
   [
    "Protocol",
    "HELLO, grants, generations, CRC, fences, timeouts and flow control"
   ],
   [
    "Candidates",
    "Parallel 16+16/32+32 and native LVDS lane studies"
   ],
   [
    "Clock/width",
    "UNKNOWN until full package/rail/timing study"
   ],
   [
    "Safety",
    "No unbounded B access or display backpressure"
   ]
  ],
  "known": "Resource-count arithmetic is a shortlist, not a legal pin allocation or achieved bandwidth.",
  "needs": [
   "Generate complete bank/clock/DDR constraints for both chips.",
   "Simulate CRC, reset isolation, independent memories and stalled traffic.",
   "Measure useful throughput under concurrent rendering and display."
  ],
  "doc": "r23/R23_ARCHITECTURE_DECISION_RECORD.md"
 },
 {
  "id": "hdmi",
  "title": "HDMI Output",
  "subtitle": "BT820B composition → IT6263N candidate → external monitor",
  "group": "DISPLAY",
  "stage": "provisional",
  "spec": [
   [
    "Connector",
    "Full-size HDMI Type A target"
   ],
   [
    "Modes",
    "720p60 / 1080p60 targets; clock feasibility OPEN"
   ],
   [
    "Pipeline",
    "T120-A → BT820B → IT6263N → HDMI"
   ],
   [
    "Audio",
    "Source and I²S/SPDIF ownership OPEN"
   ]
  ],
  "known": "The F576 development-board bridge example is historical source evidence, not an F484 or BT820B chain approval.",
  "needs": [
   "Validate dual-link format/channel mapping at both LVDS interfaces.",
   "Resolve PLL/pixel clocks and exact bridge initialization.",
   "Measure EDID/HPD/DDC, monitor output, audio and fault recovery."
  ],
  "doc": "r23/VIDEO_CHAIN_REVIEW.md"
 },
 {
  "id": "gamepad",
  "title": "Gamepad Input",
  "subtitle": "Off-the-shelf wired USB HID controllers",
  "group": "CONTROLS",
  "stage": "open",
  "spec": [
   [
    "Interface",
    "Two accessible USB-A sockets preferred"
   ],
   [
    "Host",
    "F133 USB host/OTG; hub topology OPEN"
   ],
   [
    "Safety",
    "Verified 5 V current limit, ESD and reconnect behavior"
   ]
  ],
  "known": "Controller capability is documented; working firmware, hub choice and protected sockets are not validated.",
  "needs": [
   "Verify host topology and HID enumeration.",
   "Test overcurrent, reconnect and supported controller quirks."
  ],
  "doc": "r23/R23_ARCHITECTURE_DECISION_RECORD.md"
 },
 {
  "id": "storage",
  "title": "Three NOR + Game SPI NAND",
  "subtitle": "3 ×16 MiB dedicated boot flash / separate NAND capacity OPEN",
  "group": "STORAGE",
  "stage": "open",
  "spec": [
   [
    "NOR-F133",
    "16 MiB dedicated CPU boot/recovery"
   ],
   [
    "NOR-T120-A",
    "16 MiB dedicated GPU configuration"
   ],
   [
    "NOR-T120-B",
    "16 MiB dedicated safe accelerator configuration"
   ],
   [
    "NOR total",
    "48 MiB across three physical devices"
   ],
   [
    "Games",
    "Separate SPI NAND; SKU, capacity, ECC/OOB and filesystem OPEN"
   ]
  ],
  "known": "Three dedicated NOR capacities are owner selected. Golden/active/rollback fit, programming ownership, NAND integrity and endurance have not been demonstrated. eMMC is prohibited.",
  "needs": [
   "Measure genuine F133/Efinity images before partition promises.",
   "Validate independent configuration and safe programmer handoff without contention.",
   "Test NAND bad blocks, ECC, wear leveling, atomic updates and power-loss rollback."
  ],
  "doc": "r23/THREE_NOR_NAND_REVIEW.md"
 },
 {
  "id": "power",
  "title": "Power / Thermal / Debug",
  "subtitle": "Four processing devices / three external LPDDR2 channels",
  "group": "SUPERVISION",
  "stage": "open",
  "spec": [
   [
    "Power",
    "External regulated input; no battery"
   ],
   [
    "Loads",
    "F133 + BT820B + two T120 + three LPDDR2 + bridge + USB"
   ],
   [
    "Reset",
    "Independent supervisor/reset/configuration ownership"
   ],
   [
    "Debug",
    "Both FPGA JTAG paths and CPU serial diagnostics"
   ]
  ],
  "known": "No measured R23 rail budget, PSU rating, cooling solution, enclosure dimension or fabrication-ready power tree exists.",
  "needs": [
   "Derive source-based rail estimates and sequence requirements.",
   "Measure simultaneous worst-case activity and thermal margins.",
   "Prove rescue with CPU absent, A unconfigured, B invalid and NAND corrupt."
  ],
  "doc": "r23/R23_ARCHITECTURE_DECISION_RECORD.md"
 },
 {
  "id": "compression",
  "title": "Asset Decompression",
  "subtitle": "BT820 format support and reusable FPGA IP must be qualified",
  "group": "GRAPHICS",
  "stage": "planned",
  "spec": [
   [
    "Scope",
    "License-audited BT820/FPGA formats and golden vectors"
   ],
   [
    "Transfers",
    "Explicit data movement; no assumed writes into T120 RAM"
   ],
   [
    "Performance",
    "Actual area/bandwidth/latency evidence required"
   ]
  ],
  "known": "Decoder availability does not establish cross-device memory access, format suitability or throughput.",
  "needs": [
   "Audit IP licenses and supported formats.",
   "Compare golden vectors, FPGA utilization and measured transfer benefit."
  ],
  "doc": "r23/R23_ARCHITECTURE_DECISION_RECORD.md"
 },
 {
  "id": "sdk",
  "title": "Platform Runtime & SDK",
  "subtitle": "One permanent board / versioned hardware personalities",
  "group": "SOFTWARE",
  "stage": "planned",
  "spec": [
   [
    "Interface",
    "Stable A GPU ABI and bounded B job protocol"
   ],
   [
    "Memory",
    "Four independent pools; no unified 384 MiB address space"
   ],
   [
    "Continuity",
    "Archive tools, licensed IP, sources and repair procedures through 2036"
   ]
  ],
  "known": "Owner-selected long-term goals do not freeze SDK function names or establish executable firmware.",
  "needs": [
   "Define manifests, memory capabilities, generations, fences and fault behavior.",
   "Preserve reproducible builds, golden images and independent programming."
  ],
  "doc": "r23/R23_ARCHITECTURE_DECISION_RECORD.md"
 }
];
const gates=[
 {
  "id": "G01",
  "title": "T120-A/B DDR_0",
  "status": "Open",
  "detail": "Authentic independent F484 Efinity ×32 1 Gbit LPDDR2 designs; rails, PLLs, pin maps and prototype calibration."
 },
 {
  "id": "G02",
  "title": "Video/HDMI electrical path",
  "status": "Open",
  "detail": "Legal T120-A → BT820B → IT6263N dual-LVDS mappings, clocks, modes, audio and monitor acceptance."
 },
 {
  "id": "G03",
  "title": "A ↔ B permanent link",
  "status": "Open",
  "detail": "Realized pin/rail/legal-clock plan, CRC/fences, independent memory transfers and robustness under rendering."
 },
 {
  "id": "G04",
  "title": "F133 host link",
  "status": "Open",
  "detail": "Actual RGMII/fixed-link driver endpoint, clock/skew/pinmux proof and independent SPI rescue."
 },
 {
  "id": "G05",
  "title": "Three NOR + NAND recovery",
  "status": "Open",
  "detail": "Three dedicated 16 MiB NORs, image fit, independent rescue ownership; corrupt game NAND cannot brick the platform."
 },
 {
  "id": "G06",
  "title": "USB devices",
  "status": "Open",
  "detail": "HID enumeration/reconnect, hub if required, protected 5 V supply, ESD and actual firmware."
 },
 {
  "id": "G07",
  "title": "Power and thermal",
  "status": "Open",
  "detail": "Full R23 source-based rail/sequence budgets and measured simultaneous worst-case activity and heat."
 },
 {
  "id": "G08",
  "title": "Whole-system pins + PCB",
  "status": "Open",
  "detail": "Complete FPGA constraints, bank rails, debug/configuration, ERC/DRC and SI; no hidden resource collisions."
 },
 {
  "id": "G09",
  "title": "Measured bring-up",
  "status": "Open",
  "detail": "Repeated cold boots, memory stress, video, controls, inter-chip traffic, fault injection and safe reconfiguration."
 },
 {
  "id": "G10",
  "title": "Video/asset IP and licenses",
  "status": "Open",
  "detail": "Supported decoder formats, legal reuse, golden vectors and measured area/throughput benefit."
 },
 {
  "id": "G11",
  "title": "2036 reproducibility",
  "status": "Open",
  "detail": "Archive exact sources, vendor tools/licenses, images, constraints, ABI tests and independent repair manuals."
 },
 {
  "id": "G12",
  "title": "BT820B memory + composition",
  "status": "Open",
  "detail": "Resolve 64 MiB target versus named 128 MiB part; verify exact ×16 LPDDR2 initialization, overlays and bounded latency."
 },
 {
  "id": "G13",
  "title": "NOR bitstream size & endurance",
  "status": "Open",
  "detail": "Authentic image sizes, erase/partition fit, write protection, power-loss outcomes and safe B game switching."
 },
 {
  "id": "G14",
  "title": "NAND filesystem",
  "status": "Open",
  "detail": "Actual ECC/OOB/bad-block handling, large package reads, wear leveling, atomic metadata and interrupted-update rollback."
 }
];
const chapters=[
 {
  "id": "identity",
  "name": "The tabletop platform",
  "desc": "R23 owner decisions, permanence and external equipment.",
  "body": "<h2>One permanent console</h2><p>R23 selects an F133-B host, T120-A permanent GPU, T120-B game-defined accelerator and BT820B composition target. Ordinary external HDMI screens and wired USB gamepads remain the platform interface. The six Project House departments preserve earlier useful software and source evidence.</p><p>The motherboard is not fabrication-ready. Physical geometry remains absent until sourced ARC-1 dimensions and CAD are accepted. R22 documents remain historical references; the R23 owner handoff and decision record govern active work.</p>"
 },
 {
  "id": "architecture",
  "name": "Four independent memory pools",
  "desc": "384 MiB target and the unresolved BT memory candidate mismatch.",
  "body": "<h2>Memory ownership</h2><p>F133-B has 64 MiB in-package DDR2. T120-A and T120-B each target independent 128 MiB ×32 LPDDR2. BT820B targets independent 64 MiB ×16 LPDDR2. Their selected total is 384 MiB across four physical pools; there is no unified address space.</p><h2>Named candidate conflict</h2><p>AS4C64M16MD2A-25BIN is 1 Gbit, or 128 MiB, not the selected 64 MiB BT pool. Installing the named candidate would make the proposed total 448 MiB. Resolving that mismatch requires an explicit SKU/geometry decision and compatibility proof; this PWA does not approve a substitute or larger capacity.</p><h2>Processor roles</h2><p>F133 runs authoritative game/platform logic. A owns rendering and protected GPU buffers. B executes bounded game-specific jobs in its own memory. BT820B is the 2D/live-video composition evaluation target, not a general 3D triangle GPU. All cross-pool traffic needs explicit, measured transfers.</p><h2>Allocation</h2><p>No fixed 16 MiB game budget is imposed on free FPGA memory. Ownership, protection and grants govern dynamic allocation.</p>"
 },
 {
  "id": "interconnect",
  "name": "RGMII and FPGA bridge",
  "desc": "Host rescue and bounded independent-memory transfers.",
  "body": "<h2>Host to GPU</h2><p>RGMII remains the high-speed host candidate. A working driver/fixed-link endpoint, crossed transmit/receive clocks, voltage/skew and exact F133 mux must be demonstrated. The 125 MB/s raw ceiling is arithmetic before overhead. Independent SPI and serial/configuration diagnostics must remain usable when user FPGA logic fails.</p><h2>A to B</h2><p>Compare useful parallel and native-LVDS candidates without locking a width or clock. Preserve HELLO/IDENTIFY, grants, generations, sequence IDs, CRC, timeouts, fences and flow control. A and B have separate memory controllers; results require bounded explicit transfer or DMA staging.</p><h2>BT820B command route</h2><p>The F133 or A SPI/QSPI control master, arbitration, asset upload throughput and bus ownership remain OPEN. Decoder outputs do not automatically appear in FPGA memory.</p>"
 },
 {
  "id": "video",
  "name": "BT820B composition and HDMI",
  "desc": "T120-A → BT820B → IT6263N pipeline; clocks remain OPEN.",
  "body": "<h2>Current video chain</h2><p>The R23 target is T120-A LVDS TX → BT820B LVDS RX, final 2D/live-video composition, then BT820B LVDS TX → IT6263N → HDMI monitor. The earlier direct A-to-HDMI bridge path is historical. Dual-channel maps, pixel formats, legal F484 pairs, rail levels, PLLs, latency and timing require end-to-end proof.</p><h2>Output mode targets</h2><p>720p60 and 1080p60 are monitor targets, not measured scene-rendering performance. The documented BT820B 38.4 MHz ×13/×15 PLL and integer-divisor model has not established the required 74.25 MHz 720p timing. Dual-link 1080p60 must also be qualified under current source limits. Mode gates remain OPEN.</p><h2>Audio and monitor handling</h2><p>Exact sound source and I²S/SPDIF ownership, bridge initialization, EDID, HPD, DDC and ESD remain unresolved. Lower internal render resolutions and scaling do not establish legal HDMI output timing.</p>"
 },
 {
  "id": "storage",
  "name": "Three NOR, SPI NAND and recovery",
  "desc": "Dedicated boot devices; measured image fit and NAND safety.",
  "body": "<h2>Three dedicated boot devices</h2><p>R23 locks one 16 MiB SPI NOR for F133, one for T120-A and one for T120-B: 48 MiB total across three independent chips. Exact SKUs, partition/erase geometry and boot compatibility remain OPEN. Do not promise golden plus active plus rollback slots until authentic generated images fit.</p><h2>Separate game library</h2><p>Game binaries, assets and B hardware images use separate SPI NAND. Its model and capacity remain OPEN. eMMC is prohibited. Qualify F133 controller ownership, ECC/OOB, factory and grown bad blocks, wear leveling, large reads, atomic metadata and power-loss rollback.</p><h2>Independent recovery</h2><p>External programming/configuration and serial diagnostics must survive unconfigured A, invalid B, failed CPU or corrupt NAND. Avoid contested flash buses. Do not rewrite B NOR on every game launch by default; first demonstrate a safe passive or RAM-staged configuration route and endurance.</p>"
 },
 {
  "id": "hardware",
  "name": "Mechanical, power and reset",
  "desc": "Full R23 loads, independent reset domains and physical evidence.",
  "body": "<h2>Power budget</h2><p>Budget F133, BT820B, both T120s, three external LPDDR2 channels, bridge, USB and flash simultaneously. Derive regulator and sequencing requirements from exact sources, then measure prototype activity. No PSU amperage, fanless promise, cooling design or rail budget is guessed.</p><h2>Case and board</h2><p>DC, HDMI, USB and service connectors require actual footprints, SI and mechanical clearance evidence. All geometry remains unmodeled; package ball definitions are not PCB nets. G01–G14 remain OPEN and motherboard release remains NO-GO.</p>"
 },
 {
  "id": "sdk",
  "name": "Ten-year graphics evolution",
  "desc": "Versioned GPU services, game hardware and reproducible repair.",
  "body": "<h2>Stable interfaces</h2><p>F133 submits commands; A evolves rendering under a stable ABI; B uses versioned manifests and bounded capabilities; BT820B composition and asset formats require actual support and measurements. SDK function names remain sketches until a reviewed contract is implemented.</p><h2>IP and assets</h2><p>Audit decoder and RTL licenses, generate golden vectors, and measure area, latency, bandwidth and explicit cross-memory transfer costs. Capability detection must distinguish targets from working services.</p><h2>2036 continuity</h2><p>Archive original tools/licenses, sources, native projects, golden images, constraints, SDK tests and independent repair/flash instructions. The ten-year goal concerns improving software on the same board; it is not a manufacturer supply guarantee.</p>"
 }
];
const files=[
['R23 owner architecture handoff','r23/ARC1_R23_Handoff.docx','Current owner decisions; selected targets, discrepancies and fourteen OPEN gates'],
['R23 architecture decisions','r23/R23_ARCHITECTURE_DECISION_RECORD.md','Active four-device topology, source conflicts and bounded acceptance experiments'],
['R23 architecture evidence records','r23/architecture.json','Machine-readable selected requirements, documented constraints and OPEN gates'],
['BT820B memory and video review','r23/BT820_MEMORY_VIDEO_REVIEW.md','64 MiB target versus 128 MiB named candidate; clocks and initialization remain OPEN'],
['R23 complete video-chain review','r23/VIDEO_CHAIN_REVIEW.md','T120-A to BT820B to IT6263N timing, mappings, composition and audio'],
['Three NOR and game SPI NAND review','r23/THREE_NOR_NAND_REVIEW.md','Three dedicated 16 MiB devices, image fit, rescue ownership and NAND safety'],
['R23 migration crosswalk','r23/R23_MIGRATION_RECORD.md','KEEP, ADAPT, RETIRE and BLOCKED inventory preserving historical R22 evidence'],
['R23 system evidence intake','r23/R23_SYSTEM_EVIDENCE_INTAKE.md','Declared JSON component, NOR, NAND and complete video evidence; no hardware certification'],
['R23 system evidence template','r23/R23_SYSTEM_EVIDENCE_TEMPLATE.json','Selected targets with explicit unknowns; not an authentic vendor export'],
['Historical R22 · R22 architecture decisions','architecture/ARCHITECTURE_DECISION_RECORD.md','Source review, conditional implementation decisions and ordered hardware experiments'],
['Historical R22 · Architecture evidence records','architecture/architecture.json','Machine-readable decisions, sources, calculations and OPEN gates'],
['F484 full resource facts','architecture/spreadsheetfacts.json','484 original package rows including configuration, LVDS, DDIO and clock columns'],
['Historical R22 · Memory viability review','architecture/MEMORY_REVIEW.md','Exact memory configuration, supplies, DDR clock and lifetime power-off qualification'],
['Historical R22 · Host link viability review','architecture/HOST_LINK_REVIEW.md','Exact F133 mux, crossed RGMII, storage/input partition and independent rescue'],
['Historical R22 · Display and A/B link review','architecture/DISPLAY_LINK_REVIEW.md','Dual-link HDMI and parallel/native-LVDS candidate qualification'],
['Historical R22 · Recovery and power review','architecture/RECOVERY_POWER_REVIEW.md','Independent configuration ownership, fault isolation, shutdown and power acceptance'],
['Historical R22 · Architecture verification and changes','architecture/ARCHITECTURE_TEST_REPORT.md','Executed software/source checks and remaining unperformed hardware experiments'],
['Historical R22 · R22 tabletop engineering work order','R22_TABLETOP_SYSTEM_WORK_ORDER.md','Selected architecture, physical interfaces and fabrication STOP gates'],
['Historical R22 · R22 first Efinity session','R22_EFINITY_FIRST_SESSION.md','Twin DDR_0, legal HDMI LVDS and inter-FPGA link checks'],
['R22 pin source status','R22_PIN_STATUS.md','968 ball records, unassigned electrical nets'],
['R22 reference register','R22_VENDOR_REFERENCE_LINKS.md','Primary manufacturer and vendor reference URLs'],
['T120 source pinout v1.4','T120_pinout_v1.4.xlsx','One official F484 pinout source used for BOTH identical devices'],
['R22 T120 pin inventory','R22_T120_PACKAGE_BALLS_UNASSIGNED.csv','Clean A/B physical ball export with no inherited nets'],
['Historical R22 · Developer handoff and operating rules','R22_CLAUDE_CODE_HANDOFF.md','Agent instructions, exact next steps, prohibited assumptions'],
['Engineering evidence rules','R22_EVIDENCE_POLICY.md','What a pass means and which proofs are missing'],
['DEV-002 evidence intake schema','R22_EVIDENCE_INTAKE.md','Declared JSON/CSV interchange, provenance and validation limits'],
['Evidence JSON template','ARC1_EVIDENCE_TEMPLATE.json','Empty schema template; not an authentic Efinity export'],
['Evidence CSV template','ARC1_EVIDENCE_TEMPLATE.csv','Declared interchange CSV example; not an authentic Efinity export'],
['Pass 05 implementation changes','R22_PROJECT_HOUSE_P05_CHANGELOG.md','Features and remaining open hardware gates'],
['Historical R22 · Developer tasks, machine-readable','R22_DEVELOPER_TASKS.json','Versioned work queue, owners and acceptance criteria']
];
let page=['home','viewer','systems','lab','manual','archive','handoff'].includes(location.hash.slice(1))?location.hash.slice(1):'home';
let currentChapter=null, pins=null, filterChip='ALL', pinQuery='',notes=[];
try{const v=JSON.parse(localStorage.getItem('arc1-house-notes-v1')||'[]');if(Array.isArray(v))notes=v.filter(o=>typeof o?.text==='string').slice(0,200);}catch{}
const label=(v)=>{const c=v==='Open'||v==='Conditional'?'open':v==='documented'?'verified':'planned';return `<span class="label-chip ${c}">${escape(v==='Open'?'OPEN':v==='documented'?'Documentation':v==='provisional'?'Proposed':v==='planned'?'Planned':v)}</span>`};
const saveNotes=()=>{try{localStorage.setItem('arc1-house-notes-v1',JSON.stringify(notes));return true;}catch{return false;}};
const footer=()=>`<div class="footer-line">ARC-1 PROJECT HOUSE · R.A. PEDDYCOART · R23 TABLETOP BASELINE<br>Documented package data; no completed custom motherboard.</div>`;
const home=()=>`<div class="hero"><div class="hero-top"><div class="section-kicker">TABLETOP CONSOLE · PERMANENT ELECTRONICS · EVOLVING SOFTWARE</div><h1>Two FPGAs. One console. Ten years of better games.</h1><p>R23 pairs the F133 host and twin T120 processors with a BT820B 2D/video composition target, external HDMI monitors and wired USB gamepads.</p><div class="action-row"><button class="primary-action" data-page="systems">Explore R23 systems →</button><button class="secondary-action" data-page="lab">R23 release gates</button></div></div><div class="hero-metrics"><div><strong>64 MiB</strong><span>F133 SYSTEM RAM</span></div><div><strong>2 × 128</strong><span>T120 LPDDR2 MiB TARGET</span></div><div><strong>64 MiB</strong><span>BT820B RAM TARGET</span></div></div></div>
<div class="quiet-banner danger-banner" style="margin-top:14px"><b>384 MiB selected RAM target across four independent pools.</b> The named BT memory candidate is 128 MiB, which would give 448 MiB; resolving the 64 MiB target/part mismatch remains OPEN. Three dedicated 16 MiB NORs are selected; separate game SPI NAND capacity remains OPEN.</div>
<div class="section-head"><h2>Tabletop assembly workspace</h2><small>Mechanical CAD not approved</small></div><button class="project-empty-preview" data-page="viewer" aria-label="Open ARC-1 assembly viewer"><span class="project-empty-glyph"><svg viewBox="0 0 64 64" fill="none" aria-hidden="true"><circle cx="32" cy="32" r="23" stroke="currentColor" stroke-width="2.5"/><path d="M15.7 48.3 48.3 15.7" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/></svg></span><span class="project-empty-label"><span class="section-kicker">VIEWER / PLACEHOLDER</span><strong>Tabletop dimensions and physical placement are not established.</strong><small>PCB, case, four-device system, HDMI and controls remain circle/slash placeholders →</small></span></button>
<div class="section-head"><h2>Logical architecture</h2><small>Connections are conceptual, not copper</small></div>${architecture()}
<div class="section-head"><h2>Departments</h2></div><div class="tile-grid">${[['systems','▦','Systems','Four devices, independent RAM and the R23 video chain'],['lab','⌁','Lab','Fourteen OPEN gates and local evidence checks'],['manual','≡','Manual','Current R23 responsibilities and recovery'],['archive','▤','Archive','R23 authority and preserved historical sources'],['viewer','⊘','Assembly Viewer','No physical geometry invented'],['handoff','⌘','Claude Code handoff','Developer tasks and evidence requirements']].map(([id,ic,n,desc])=>`<button class="tile-button" data-page="${id}"><span class="tile-top"><span class="tile-icon">${ic}</span><span class="tile-arrow">↗</span></span><span><b>${n}</b><small style="display:block">${desc}</small></span></button>`).join('')}<button class="tile-button" data-action="openAbout"><span class="tile-top"><span class="tile-icon">◷</span><span class="tile-arrow">↗</span></span><span><b>Ten-Year Commitment</b><small style="display:block">Useful interfaces and independent recovery on one permanent PCB</small></span></button></div>
<div class="section-head"><h2>Next desk experiments</h2></div><section class="panel pad"><div class="section-kicker">P0 / AUTHENTIC VENDOR EVIDENCE</div><h3>Generate both T120 DDR interfaces; resolve BT memory and clocks</h3><p class="small">Create independent F484 projects for 1 Gbit ×32 LPDDR2. In parallel, resolve the BT820B 64 MiB target/part mismatch and the complete T120-A → BT820B → IT6263N video timing. Collect genuine bitstream sizes before three-NOR partition claims.</p><div class="quiet-banner danger-banner">The 968 manufacturer ball definitions are <b>not PCB nets or a validated bank plan.</b> G01–G14 remain OPEN. Motherboard release remains NO-GO.</div><div class="action-row" style="margin-top:12px"><a href="engineering/r23/R23_ARCHITECTURE_DECISION_RECORD.md" class="secondary-action">Open R23 experiment record ↗</a><button class="secondary-action" data-page="lab">See remaining gates</button></div></section>${footer()}`;
const architecture=()=>`<div class="arch"><div class="arch-row"><button class="arch-block" data-detail="cpu">F133-B<small>64 MiB DDR2</small><small>NOR-F133 · 16 MiB</small></button><span class="arch-link">⇄</span><button class="arch-block focus" data-detail="gpua">T120-A<small>GPU · 128 MiB target</small><small>NOR-A · 16 MiB</small></button><span class="arch-link">⇄</span><button class="arch-block" data-detail="gpub">T120-B<small>Game · 128 MiB target</small><small>NOR-B · 16 MiB</small></button></div><div class="arch-memory">F133 RGMII → A · Independent SPI rescue · Direct A ⇄ B link</div><div class="arch-row"><button class="arch-block" data-detail="bt820">BT820B<small>A LVDS → live-video composition target</small><small>64 MiB ×16 target; named candidate 128 MiB</small></button></div><div class="arch-output">T120-A → BT820B → IT6263N → external HDMI screen</div><div class="arch-output"><button class="tiny-arch-button" data-detail="storage">Separate game SPI NAND · capacity OPEN</button></div><p class="arch-caption">Four independent RAM pools · 384 MiB selected target. All paths are conceptual; no pin allocation or measured video. Tap a device for evidence.</p></div>`;
const systemsPage=()=>`<div class="section-kicker">DEPARTMENT 02 / HARDWARE</div><h1>Physical systems</h1><p class="muted small">ARC-1 subsystems are separately documented. Hardware choices do not become verified PCB designs until their individual closure tests pass.</p>${globalThis.ARC1ArchitectureUI?.panel?.()||'<div class="quiet-banner danger-banner">Architecture review is unavailable. Reload the complete PWA package.</div>'}${architecture()}<div class="section-head"><h2>Subsystem register</h2><small>Tap to inspect</small></div><div class="system-list">${systems.map(s=>`<button class="system-button" data-detail="${s.id}"><span><span class="section-kicker">${s.group}</span><strong>${s.title}</strong><small>${s.subtitle}</small></span><span class="end">${label(s.stage)}<span class="arrow" style="display:block">›</span></span></button>`).join('')}</div><div class="section-head"><h2>FPGA pin explorer</h2><small>968 package balls</small></div><section class="panel pad"><p class="small">Search exact Efinix T120F484 ball definitions for both instance A and instance B. Candidate ARC-1 nets are clearly separated from vendor package functions.</p><div class="search-row"><label class="field">Ball, function, bank or net<input id="pinSearch" placeholder="e.g. K21, DDR_DQ0, BANK1C" value="${escape(pinQuery)}" autocomplete="off"></label><label class="field">Device<select id="chipFilter"><option value="ALL" ${filterChip==='ALL'?'selected':''}>Both FPGAs</option><option value="T120-A" ${filterChip==='T120-A'?'selected':''}>T120-A</option><option value="T120-B" ${filterChip==='T120-B'?'selected':''}>T120-B</option></select></label></div><div id="pinResults" aria-live="polite"><p class="muted small">Loading the bundled pin inventories…</p></div><div class="action-row"><a href="engineering/R22_PIN_STATUS.md" download class="secondary-action">Pin assignment status</a><a href="engineering/T120_pinout_v1.4.xlsx" download class="secondary-action">Efinix original XLSX</a></div></section>${footer()}`;
const labPage=()=>`<div class="section-kicker">DEPARTMENT 03 / LABORATORY</div><h1>Test and qualification</h1><div class="quiet-banner danger-banner">R23 four-device architecture and three dedicated NORs selected. <b>Motherboard PCB release is NO-GO.</b> These are engineering gates, not claimed test results.</div>${globalThis.ARC1ArchitectureUI?.panel?.()||'<div class="quiet-banner danger-banner">Architecture review is unavailable. Reload the complete PWA package.</div>'}${globalThis.ARC1EvidenceUI?.panel?.()||'<div class="quiet-banner danger-banner">Evidence intake is unavailable. Reload the complete PWA package.</div>'}<div class="section-head"><h2>Release gates</h2><small>Evidence and exact pass/fail</small></div><section class="panel pad">${gates.map(g=>`<div class="gate"><div class="gate-id">${g.id}</div><div class="gate-main"><div class="gate-head"><strong>${g.title}</strong>${label(g.status)}</div><p>${g.detail}</p></div></div>`).join('')}</section><div class="section-head"><h2>Efinity first session</h2></div><section class="panel pad"><p class="small">Read the R23 architecture and shutdown/clock constraints. Create TWO independent memory-only F484 projects, then combine DDR, RGMII, A/B links and T120-A LVDS toward BT820B. Study BT820B memory/video and all three dedicated NORs separately.</p><ol class="info-list"><li>Create the T120F484I4 projects A and B.</li><li>Configure each <code>DDR_0</code> as LPDDR2, ×32, 1 Gbit, target 800 MT/s using manufacturer timings.</li><li>Export controller-generated DDR pinouts and complete bank-voltage information.</li><li>Identify legal LVDS toward BT820B and A/B link signals; verify with Efinity. Resolve BT memory and complete video clocks separately.</li><li>Zip the generated project, reports, logs, warnings and any errors.</li></ol><div class="actions"><a class="primary-action" href="engineering/r23/R23_ARCHITECTURE_DECISION_RECORD.md">R23 vendor experiment handoff</a><button class="secondary-action" data-action="copyHandoff">Copy settings</button></div></section><div class="section-head"><h2>Engineering notes</h2><small>Saved locally on this device</small></div>${notesUI()}${footer()}`;
const notesUI=()=>`<section class="panel pad"><label class="field">Record a decision, question, or test outcome<textarea id="noteText" placeholder="Include what was tested, what evidence exists, and what remains unknown…"></textarea></label><div class="action-row" style="margin-top:10px"><button class="primary-action" data-action="saveNote">Save dated note</button><button class="secondary-action" data-action="exportNotes">Export notes JSON</button><button class="secondary-action" data-action="importNotes">Import</button></div><p class="context-note">Notes are user-entered records, not automatic PASS certifications.</p></section><div class="worklog" style="margin-top:12px">${notes.length?notes.slice().reverse().map(n=>`<div class="entry"><strong>${escape(n.topic||'Engineering note')}</strong><small>${escape(n.date||'Undated')}</small><p>${escape(n.text)}</p></div>`).join(''):'<p class="muted small">No local notes yet.</p>'}</div>`;

// Project House Pass 05: developer handoff is a read-only engineering launchpad.
// Machine-readable task work queue is tasks/roadmap.json; no task click can certify a hardware gate.
const handoffPage=()=>`<div class="section-kicker">DEVELOPMENT / CLAUDE CODE HANDOFF</div><h1>Continue ARC-1 development</h1><p class="muted small">Preserve Project House and follow the current R23 owner architecture while producing inspectable source, software and vendor evidence.</p><div class="quiet-banner"><b>Current release: Pass 05 / R23.</b> Current system JSON and legacy A/B pin intake are available in Lab. Neither certifies EDA success or closes a hardware gate.</div><div class="section-head"><h2>Start on desktop</h2></div><section class="panel pad"><p class="small" style="margin-bottom:8px"><b>1.</b> Open the extracted folder containing <code>CLAUDE.md</code>.<br><b>2.</b> Run <code>npm test</code>, then <code>npm run serve</code>.<br><b>3.</b> Read the full <code>engineering/r23/ARC1_R23_Handoff.docx</code>, R23 decision record and migration crosswalk.<br><b>4.</b> Use <b>Lab → Efinity evidence intake</b> for declared R23 system JSON or legacy A/B JSON/CSV. Pin checks cover only the two T120 inventories; all G01–G14 remain OPEN.</p><div class="action-row"><button class="secondary-action" data-action="copyDevBrief">Copy Claude Code brief</button><button class="secondary-action" data-action="exportSnapshot">Export project snapshot JSON</button></div><p class="context-note">The snapshot contains locally saved notes and recorded task definitions; nothing is uploaded automatically.</p></section><div class="section-head"><h2>Open development work</h2><small>Authoritative records in roadmap.json</small></div><section id="devTasks" aria-live="polite"><div class="panel pad muted small">Loading bundled task records…</div></section><div class="section-head"><h2>Engineering authority</h2></div><div class="doc-card"><h3>Current R23 authority and historical evidence</h3><p>Selected four-device topology, three NORs, SPI NAND, target conflicts and required acceptance evidence.</p><a href="engineering/r23/ARC1_R23_Handoff.docx">Full R23 owner handoff ↗</a><br><a href="engineering/r23/R23_ARCHITECTURE_DECISION_RECORD.md">R23 decision record ↗</a><br><a href="engineering/r23/R23_MIGRATION_RECORD.md">Migration crosswalk ↗</a><br><a href="engineering/R22_EVIDENCE_POLICY.md">Preserved evidence policy ↗</a><br><a href="tasks/roadmap.json" download>Current machine-readable roadmap ↗</a></div><div class="action-row"><button class="secondary-action" data-page="lab">← Laboratory</button><button class="secondary-action" data-page="archive">Source archive</button></div>${footer()}`;
let developerRoadmap=null;
async function loadDeveloperRoadmap(){const target=$('#devTasks');if(!target)return;try{if(!developerRoadmap){const response=await fetch('./tasks/roadmap.json');if(!response.ok)throw Error('HTTP '+response.status);const parsed=await response.json();if(parsed.schema!=='arc1-roadmap-v1'||!Array.isArray(parsed.tasks))throw Error('Invalid schema');developerRoadmap=parsed;}if(!$('#devTasks'))return;$('#devTasks').innerHTML=developerRoadmap.tasks.map(task=>`<article class="dev-task"><div class="dev-task-head"><code>${escape(task.id)}</code><strong>${escape(task.title)}</strong><span>${escape(task.priority)}</span></div><p class="small muted">${escape(task.state)} · ${escape(task.owner)}</p><p class="small"><b>Pass evidence:</b> ${escape(task.pass_condition)}</p></article>`).join('');}catch(e){if($('#devTasks'))$('#devTasks').innerHTML='<div class="quiet-banner danger-banner">The task file is unavailable. Host the extracted folder over HTTP(S), and inspect tasks/roadmap.json directly.</div>';}}
const developerBrief=`ARC-1 PROJECT HOUSE R23 / PASS 05 — CONTINUE DEVELOPMENT
Read CLAUDE.md, the full engineering/r23/ARC1_R23_Handoff.docx, R23_ARCHITECTURE_DECISION_RECORD.md and R23_MIGRATION_RECORD.md.
Selected tabletop architecture: F133-B 64 MiB; T120F484I4 A/B each target independent 128 MiB x32 LPDDR2; BT820B target independent 64 MiB x16 LPDDR2. Selected total 384 MiB, four independent pools, not unified RAM. Named AS4C64M16MD2A candidate is 128 MiB and would total 448 MiB: resolve mismatch explicitly.
Video target: T120-A LVDS -> BT820B composition -> IT6263N -> HDMI. 720p60/1080p60 clocks, mapping, composition and audio remain OPEN.
Three dedicated 16 MiB SPI NORs (CPU/A/B, 48 MiB total); separate game SPI NAND capacity OPEN; no eMMC. Do not promise rollback slots before real image fit or default to B NOR rewrite per game.
Retain RGMII candidate, independent SPI/configuration/UART rescue, bounded A/B jobs and useful link headroom. Generate authentic independent Efinity DDR projects, BT memory/video evidence, three-NOR image sizes and NAND ECC/power-loss tests.
Run npm test first. Use declared R23 system JSON or legacy A/B pin JSON/CSV intake; native Efinity adapters require authentic exports. G01-G14 remain OPEN; fabrication NO-GO.
Preserve six departments, visual identity, immutable 968 manufacturer balls and unmodeled viewer. Preserve historical evidence; no invented PCB geometry.
Deliver exact diffs, reproducible tests, source hashes, salvage inventory and remaining gates.`;
function exportSnapshot(){const record={format:'arc1-project-house-handoff',version:2,architecture:'R23 tabletop F133 + dual T120 + BT820B target',pwaPass:'05',exportedAt:new Date().toISOString(),hardwareStatus:'UNVALIDATED: manufacturing NO-GO',currentTask:'R23 migration and authentic hardware evidence',selectedMemoryMiB:{F133:64,'T120-A':128,'T120-B':128,BT820B:64},selectedTotalMiB:384,btNamedCandidateMiB:128,namedCandidateTotalMiB:448,capacityMismatchState:'OPEN',norCapacityMiB:16,norDeviceCount:3,nandCapacity:'OPEN',gates:gates.map(g=>({id:g.id,status:'OPEN'})),tasks:developerRoadmap?.tasks||[],notes:notes.slice(),sourceFiles:['CLAUDE.md','engineering/r23/ARC1_R23_Handoff.docx','engineering/r23/R23_ARCHITECTURE_DECISION_RECORD.md','engineering/r23/R23_MIGRATION_RECORD.md','engineering/R22_EVIDENCE_POLICY.md','tasks/roadmap.json']};const blob=new Blob([JSON.stringify(record,null,2)],{type:'application/json'});const a=document.createElement('a');const url=URL.createObjectURL(blob);a.href=url;a.download='ARC1_R23_PROJECT_HOUSE_SNAPSHOT.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);}
function copyDeveloperBrief(){if(navigator.clipboard?.writeText){navigator.clipboard.writeText(developerBrief).then(()=>alert('Developer handoff copied.')).catch(()=>alert(developerBrief));}else alert(developerBrief);}
const manualPage=()=>{const chapter=chapters.find(c=>c.id===currentChapter);return `<div class="section-kicker">DEPARTMENT 04 / REFERENCE LIBRARY</div>${chapter?`<button class="secondary-action" data-action="manualIndex" style="margin-bottom:16px">← Contents</button><h1>${escape(chapter.name)}</h1><p class="muted small">${escape(chapter.desc)}</p><article class="chapter">${chapter.body}</article>`:`<h1>ARC-1 engineering manual</h1><p class="muted small">Written as a technical reference, with documented features separated from proposed implementations and measurements.</p><div class="toc">${chapters.map((c,i)=>`<button data-chapter="${c.id}"><span class="number">${String(i+1).padStart(2,'0')}</span><span><strong>${escape(c.name)}</strong><small>${escape(c.desc)}</small></span><span class="tile-arrow">›</span></button>`).join('')}</div>`}${footer()}`};
const archivePage=()=>`<div class="section-kicker">DEPARTMENT 05 / RECORDS</div><h1>ARC-1 engineering archive</h1><p class="muted small">Only ARC-1 documentation, Efinix primary pin tables, engineering exports, and preliminary test sources are packaged. There are no archived unrelated designs, game assets, or inherited 3D models.</p><div class="quiet-banner"><b>Source discipline:</b> A physical viewer slot opens only when a traceable ARC-1 component envelope, mechanical drawing, or CAD model has been accepted for use. Concept meshes will be marked <b>ROUGH DRAFT</b>.</div><div class="section-head"><h2>Local source documents</h2><small>${files.length} items</small></div>${files.map(([title,name,desc])=>`<div class="doc-card"><h3>${escape(title)}</h3><p>${escape(desc)}</p><a href="engineering/${name.split('/').map(encodeURIComponent).join('/')}" download>Open / save source ↗</a></div>`).join('')}${footer()}`;
function showPage(id,updateHistory=true){if(!['home','viewer','systems','lab','manual','archive','handoff'].includes(id))return;page=id;$('#mainContent').innerHTML=({home,viewer:ARC1Viewer.page,systems:systemsPage,lab:labPage,manual:manualPage,archive:archivePage,handoff:handoffPage}[id])();document.querySelectorAll('.house-nav [data-page]').forEach(el=>{el.classList.toggle('active',el.dataset.page===id);if(el.dataset.page===id)el.setAttribute('aria-current','page');else el.removeAttribute('aria-current')});if(updateHistory)history.replaceState(null,'','#'+id);window.scrollTo(0,0);if(id==='systems')loadPins();if(id==='handoff')loadDeveloperRoadmap();if(id==='lab'){$('#mainContent').innerHTML+='<section class="panel pad developer-entrance"><div class="section-kicker">DEVELOPER CONTINUITY</div><h2>Hand off to Claude Code</h2><p class="small muted">Open the codebase, automated checks, priority engineering tasks, and evidence policy in one place.</p><button class="secondary-action" data-page="handoff">Open developer handoff →</button></section>';globalThis.ARC1EvidenceUI?.mount?.();}if(id==='systems'||id==='lab')globalThis.ARC1ArchitectureUI?.mount?.();}
function detail(id){const s=systems.find(x=>x.id===id);if(!s)return;$('#detailKicker').textContent=s.group+' / SYSTEM FILE';$('#detailBody').innerHTML=`<h2 id="detailTitle">${escape(s.title)}</h2><p>${escape(s.subtitle)}</p><div style="margin-bottom:14px">${label(s.stage)}</div>${s.spec.map(([k,v])=>`<div class="details-line"><span>${escape(k)}</span><strong>${escape(v)}</strong></div>`).join('')}<h3 style="margin-top:20px">Documented to date</h3><p>${escape(s.known)}</p><h3>Unresolved engineering work</h3><ul>${s.needs.map(t=>`<li>${escape(t)}</li>`).join('')}</ul><a class="secondary-action" href="engineering/${escape(s.doc)}" download>Review source / work order ↗</a>`;$('#detailBackdrop').hidden=false;$('#closeDetail').focus();}
function closeDetail(){$('#detailBackdrop').hidden=true;}
async function loadPins(){if(pins){renderPins();return;}try{const r=await fetch('./pins.json');if(!r.ok)throw Error('HTTP '+r.status);pins=await r.json();renderPins();}catch(e){const el=$('#pinResults');if(el)el.innerHTML='<div class="quiet-banner danger-banner">Cannot read bundled pin data. Serve this extracted ZIP over HTTP(S); opening index.html directly from Files may block local file requests.</div>';}}
function renderPins(){const out=$('#pinResults');if(!out||!pins)return;const term=pinQuery.toLowerCase().trim();let arr=pins.filter(r=>(filterChip==='ALL'||r.chip===filterChip)&&(!term||[r.ball,r.bank,r.name,r.ddr,r.net,r.role].some(v=>String(v).toLowerCase().includes(term))));const truncated=arr.length>65;const shown=arr.slice(0,65);out.innerHTML=`<div class="context-note">${arr.length} matching physical ball${arr.length!==1?'s':''}${truncated?' · showing first 65':''}. <b>Proposed nets are not Efinity approved; no PCB pin-lock.</b></div><div class="overflow-table" style="margin:9px 0 13px"><table class="data-table"><thead><tr><th style="width:55px">Device</th><th style="width:58px">Ball</th><th>Bank</th><th>Pin function / proposal</th></tr></thead><tbody>${shown.map(r=>`<tr><td>${escape(r.chip)}</td><td><code>${escape(r.ball)}</code></td><td>${escape(r.bank)}</td><td>${escape(r.name)}${r.ddr?`<div class="micro muted">${escape(r.ddr)}</div>`:''}${r.net?`<div class="micro" style="color:#925c21">Proposed: ${escape(r.net)}</div>`:''}</td></tr>`).join('')}</tbody></table></div>`;}
function saveNote(){const el=$('#noteText');const value=el?.value.trim()||'';if(!value)return alert('Enter a note first.');if(value.length>4000)return alert('Keep the note under 4,000 characters.');notes.push({date:new Date().toISOString(),topic:'ARC-1 R23',text:value});notes=notes.slice(-200);const ok=saveNotes();showPage('lab',false);if(!ok)alert('Local storage is unavailable. Export your notes to keep a copy.');}
function exportNotes(){const blob=new Blob([JSON.stringify({format:'arc1-house-notes',version:1,exportedAt:new Date().toISOString(),notes},null,2)],{type:'application/json'});const a=document.createElement('a');const u=URL.createObjectURL(blob);a.href=u;a.download='ARC1_PROJECT_HOUSE_NOTES.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),30000);}
async function importNotes(file){if(!file||file.size>1000000)return alert('Choose a notes JSON file smaller than 1 MB.');try{const data=JSON.parse(await file.text());if(data.format!=='arc1-house-notes'||data.version!==1||!Array.isArray(data.notes))throw Error('Not an ARC-1 notes export');const incoming=data.notes.filter(n=>typeof n.text==='string'&&n.text.length<=4000).map(n=>({topic:String(n.topic||'Imported').slice(0,80),date:String(n.date||'').slice(0,40),text:n.text})).slice(-200);notes=[...notes,...incoming].slice(-200);saveNotes();showPage('lab',false);}catch(e){alert('Unable to import notes: '+e.message);}finally{$('#importNotesFile').value='';}}
const handoff='ARC-1 R23 / AUTHENTIC VENDOR EVIDENCE\n2x T120F484I4: independent DDR_0 LPDDR2 x32 1 Gbit = 128 MiB, 800 MT/s target.\nA LVDS toward BT820B; then BT820B to IT6263N to HDMI. Entire clock/mode chain OPEN.\nBT820B target 64 MiB x16; named AS4C64M16MD2A is 128 MiB: resolve capacity mismatch.\nThree dedicated 16 MiB NORs for F133/A/B; separate SPI NAND capacity OPEN; no eMMC.\nExport original DDR/pin/PLL/bank/timing artifacts and actual image sizes.\nRetain RGMII, independent rescue, legal A/B link candidates, JTAG and reset isolation.\nRead engineering/r23/R23_ARCHITECTURE_DECISION_RECORD.md.\nG01-G14 OPEN; NOT EFINITY-VALIDATED OR PCB-APPROVED.';
function about(){$('#detailKicker').textContent='ARC-1 DEVELOPMENT CHARTER';$('#detailBody').innerHTML='<h2 id="detailTitle">The permanent tabletop console</h2><p>R23 selects F133-B, twin T120F484I4 and BT820B video/2D assist, with four independent RAM pools targeting 384 MiB. The named BT memory candidate conflicts with its 64 MiB target; the decision remains OPEN.</p><p>Three dedicated 16 MiB NORs provide separate CPU/A/B boot devices. Game SPI NAND capacity remains OPEN. Current video target: T120-A → BT820B → IT6263N → external HDMI.</p><p><b>Pass 05 / R23:</b> Selected architecture, manufacturer-sourced package functions and local software evidence checks. Physical ARC-1 CAD is not established; circle/slash placeholders remain deliberate.</p><div class="quiet-banner danger-banner">All fourteen hardware gates remain OPEN. Authentic vendor projects, image fit, end-to-end clocks, recovery, SI and prototype measurements are required. Motherboard release is NO-GO.</div><p style="margin-top:14px"><a href="engineering/r23/ARC1_R23_Handoff.docx" download>Read the full R23 owner handoff ↗</a></p>';$('#detailBackdrop').hidden=false;}
document.addEventListener('click',e=>{const v=e.target.closest('[data-viewer]');if(v){ARC1Viewer.action(v.dataset.viewer,v.dataset.value||'');showPage('viewer',false);return;}const el=e.target.closest('[data-page],[data-detail],[data-chapter],[data-action]');if(!el)return;if(el.dataset.page)showPage(el.dataset.page);if(el.dataset.detail)detail(el.dataset.detail);if(el.dataset.chapter){currentChapter=el.dataset.chapter;showPage('manual',false);}switch(el.dataset.action){case'manualIndex':currentChapter=null;showPage('manual',false);break;case'openAbout':about();break;case'saveNote':saveNote();break;case'exportNotes':exportNotes();break;case'importNotes':$('#importNotesFile').click();break;case'copyDevBrief':copyDeveloperBrief();break;case'exportSnapshot':exportSnapshot();break;case'copyHandoff':if(navigator.clipboard?.writeText){navigator.clipboard.writeText(handoff).then(()=>alert('Efinity settings copied.')).catch(()=>alert(handoff));}else alert(handoff);break;}});
document.addEventListener('input',e=>{if(e.target?.id==='pinSearch'){pinQuery=e.target.value;renderPins();}});
document.addEventListener('change',e=>{if(e.target?.dataset?.viewerCheck){ARC1Viewer.action('toggle',e.target.dataset.viewerCheck);showPage('viewer',false);return;}if(e.target?.id==='chipFilter'){filterChip=e.target.value;renderPins();}});
$('#closeDetail').onclick=closeDetail;$('#detailBackdrop').onclick=e=>{if(e.target.id==='detailBackdrop')closeDetail();};document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('#detailBackdrop').hidden)closeDetail();});$('#aboutButton').onclick=about;$('#importNotesFile').onchange=e=>importNotes(e.target.files?.[0]);
window.addEventListener('hashchange',()=>{const next=location.hash.slice(1);if(['home','viewer','systems','lab','manual','archive','handoff'].includes(next)&&next!==page)showPage(next,false);});
showPage(page,false);
if('serviceWorker' in navigator&&location.protocol!=='file:'){
 navigator.serviceWorker.register('./sw.js').then(()=>{$('#offlineFlag').textContent='Offline PWA';}).catch(()=>{$('#offlineFlag').textContent='Web mode';});

}
})();
