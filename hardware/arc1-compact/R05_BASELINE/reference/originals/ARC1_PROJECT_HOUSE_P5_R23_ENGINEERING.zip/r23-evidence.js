/* ARC-1 R23 system interchange. Read-only declarations, never hardware signoff.
   Legacy arc1-evidence-v1 and its manufacturer inventory remain independent. */
(()=>{'use strict';
const SCHEMA='arc1-r23-system-evidence-v1';
const MAX_REPORT_BYTES=2*1024*1024,MAX_ARTIFACT_BYTES=32*1024*1024,MAX_TOTAL_ARTIFACT_BYTES=64*1024*1024;
const MIB=1024*1024,NOR_CAPACITY=16*MIB;
const POOLS=Object.freeze({'F133-B':64,'T120-A':128,'T120-B':128,'BT820B':64});
// Exact part organizations in the R23 handoff and Alliance Rev.1.0 January 2018.
// These references expose a reported contradiction; they are not BOM approval.
const KNOWN_MEMORY=Object.freeze({'AS4C32M32MD2A-25BIN':{bits:1073741824,dqBits:32},'AS4C64M16MD2A-25BIN':{bits:1073741824,dqBits:16}});
const NOR_OWNERS=['F133-B','T120-A','T120-B'],VIDEO_PATH=['T120-A','BT820B','IT6263N','HDMI'];
const object=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const string=value=>typeof value==='string'&&value.trim().length>0&&value.length<=2048&&Array.from(value).length<=1024;
const integer=(value,zero=false)=>Number.isSafeInteger(value)&&(zero?value>=0:value>0);
const positive=value=>typeof value==='number'&&Number.isFinite(value)&&value>0;
const hash=value=>typeof value==='string'&&/^[a-f0-9]{64}$/.test(value);
const archivePath=value=>string(value)&&!(/^(?:\/|[A-Za-z]:)|(?:^|[\\/])\.\.(?:[\\/]|$)|[\u0000-\u001f\u007f\u2028\u2029]/.test(value)||value.includes('\\'));
const note=(code,path,message)=>({code,path,message});
const clone=value=>JSON.parse(JSON.stringify(value));
function timestamp(value){
 if(typeof value!=='string')return false;
 const m=value.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(?:Z|([+-])(\d{2}):(\d{2}))$/);
 if(!m)return false;
 const year=+m[1],month=+m[2],day=+m[3],leap=year%4===0&&(year%100!==0||year%400===0);
 return month>=1&&month<=12&&day>=1&&day<=[31,leap?29:28,31,30,31,30,31,31,30,31,30,31][month-1]&&+m[4]<=23&&+m[5]<=59&&+m[6]<=59&&(!m[7]||(+m[8]<=23&&+m[9]<=59))&&Number.isFinite(Date.parse(value));
}
function shapeErrors(report){
 const errors=[],error=(path,message)=>errors.push(note('SCHEMA',path,message));
 function keys(value,allowed,path){
  if(!object(value)){error(path,'Expected an object.');return false;}
  for(const key of Object.keys(value))if(!allowed.includes(key))error(path+'.'+key,'Undeclared field; the R23 format does not infer its meaning.');
  for(const key of allowed)if(!Object.hasOwn(value,key))error(path+'.'+key,'Required field missing; explicitly unknown values must be null.');
  return true;
 }
 const nullableString=(value,path)=>{if(value!==null&&!string(value))error(path,'Expected a nonempty string or null.');};
 const nullableInteger=(value,path,zero=false)=>{if(value!==null&&!integer(value,zero))error(path,'Expected a '+(zero?'nonnegative':'positive')+' safe integer or null.');};
 const nullableHash=(value,path)=>{if(value!==null&&!hash(value))error(path,'Expected lowercase SHA-256 or null.');};
 function rows(value,path,max,check){if(!Array.isArray(value)||value.length>max)error(path,'Expected an array of at most '+max+' rows.');else value.forEach((row,i)=>check(row,path+'['+i+']'));}
 if(!keys(report,['schema','source','memoryPools','norDevices','gameStorage','video','signoffs'],'report'))return errors;
 if(report.schema!==SCHEMA)error('schema','Expected '+SCHEMA+'; legacy pin reports use their separate importer.');
 if(keys(report.source,['kind','tool','toolVersion','project','revision','generatedAt','artifacts'],'source')){
  if(!['interchange','vendor-report'].includes(report.source.kind))error('source.kind','Expected interchange or vendor-report; a reported origin is not authenticated.');
  for(const key of ['tool','toolVersion','project','revision','generatedAt'])nullableString(report.source[key],'source.'+key);
  if(report.source.generatedAt!==null&&!timestamp(report.source.generatedAt))error('source.generatedAt','Expected a real ISO calendar timestamp with timezone or null.');
  rows(report.source.artifacts,'source.artifacts',200,(row,path)=>{if(keys(row,['path','sha256','kind'],path)){
   if(!archivePath(row.path))error(path+'.path','Expected a relative archive path without traversal, backslashes or control characters.');
   nullableHash(row.sha256,path+'.sha256');if(!string(row.kind))error(path+'.kind','Expected a declared artifact kind.');
  }});
 }
 rows(report.memoryPools,'memoryPools',20,(row,path)=>{if(keys(row,['device','selectedMiB','physicalCandidateBits','part','reportedMeasuredMiB'],path)){
  if(!string(row.device))error(path+'.device','Expected a component name.');
  if(!integer(row.selectedMiB))error(path+'.selectedMiB','Expected a positive safe integer in MiB.');
  nullableInteger(row.physicalCandidateBits,path+'.physicalCandidateBits');nullableString(row.part,path+'.part');
  if(row.reportedMeasuredMiB!==null&&!positive(row.reportedMeasuredMiB))error(path+'.reportedMeasuredMiB','Expected finite positive reported MiB or null.');
 }});
 rows(report.norDevices,'norDevices',20,(row,path)=>{if(keys(row,['owner','capacityBytes','eraseBlockBytes','metadataBytes','images'],path)){
  if(!string(row.owner))error(path+'.owner','Expected a NOR owner.');
  if(!integer(row.capacityBytes))error(path+'.capacityBytes','Expected a positive safe integer in bytes.');
  nullableInteger(row.eraseBlockBytes,path+'.eraseBlockBytes');nullableInteger(row.metadataBytes,path+'.metadataBytes',true);
  rows(row.images,path+'.images',200,(image,imagePath)=>{if(keys(image,['role','path','loadableBytes','sha256'],imagePath)){
   if(!string(image.role))error(imagePath+'.role','Expected an image role.');
   if(!archivePath(image.path))error(imagePath+'.path','Expected a relative archive path.');
   nullableInteger(image.loadableBytes,imagePath+'.loadableBytes');nullableHash(image.sha256,imagePath+'.sha256');
  }});
 }});
 if(keys(report.gameStorage,['technology','part','capacityBytes','eccEvidence'],'gameStorage')){
  if(!string(report.gameStorage.technology))error('gameStorage.technology','Expected a declared technology.');
  nullableString(report.gameStorage.part,'gameStorage.part');nullableInteger(report.gameStorage.capacityBytes,'gameStorage.capacityBytes');nullableString(report.gameStorage.eccEvidence,'gameStorage.eccEvidence');
 }
 if(keys(report.video,['path','pixelClockMHz','links','measuredFps','sourceArtifactPaths'],'video')){
  rows(report.video.path,'video.path',20,(value,path)=>{if(!string(value))error(path,'Expected a component name.');});
  for(const key of ['pixelClockMHz','measuredFps'])if(report.video[key]!==null&&!positive(report.video[key]))error('video.'+key,'Expected finite positive numeric value or null.');
  nullableInteger(report.video.links,'video.links');
  rows(report.video.sourceArtifactPaths,'video.sourceArtifactPaths',200,(value,path)=>{if(!archivePath(value))error(path,'Expected a relative archive path.');});
 }
 rows(report.signoffs,'signoffs',50,(row,path)=>{if(keys(row,['gate','status','artifactSha256'],path)){
  for(const key of ['gate','status'])if(!string(row[key]))error(path+'.'+key,'Expected a nonempty string.');nullableHash(row.artifactSha256,path+'.artifactSha256');
 }});
 return errors;
}
function parse(text){
 let report;
 try{
  if(typeof text!=='string')throw Error('Expected explicitly declared R23 JSON text.');
  if(new TextEncoder().encode(text).byteLength>MAX_REPORT_BYTES)throw Error('Report exceeds 2 MiB.');
  report=JSON.parse(text.replace(/^\uFEFF/,''));
 }catch(error){return {ok:false,report:null,parserErrors:[note('PARSE','input',error.message)]};}
 const parserErrors=shapeErrors(report);
 return {ok:parserErrors.length===0,report:parserErrors.length?null:report,parserErrors};
}
function blank(){return {status:'UNKNOWN',parserErrors:[],conflicts:[],unknowns:[],gates:Array.from({length:14},(_,i)=>({id:'G'+String(i+1).padStart(2,'0'),status:'OPEN'})),source:null,input:null,artifacts:[],memoryPools:[],norDevices:[],gameStorage:null,video:null,summary:{memoryPools:0,selectedTotalMiB:0,physicalCandidateTotalMiB:null,norDevices:0,norTotalCapacityBytes:0}};}
function validate(report){
 const result=blank(),errors=shapeErrors(report);
 if(errors.length){result.status='PARSER_ERROR';result.parserErrors=errors;return result;}
 result.source=clone(report.source);result.memoryPools=clone(report.memoryPools);result.gameStorage=clone(report.gameStorage);result.video=clone(report.video);
 const conflict=(code,path,message)=>result.conflicts.push(note(code,path,message)),unknown=(code,path,message)=>result.unknowns.push(note(code,path,message));
 const artifacts=new Map();
 for(const row of report.source.artifacts){
  if(artifacts.has(row.path))conflict('DUPLICATE_ARTIFACT','source.artifacts','Repeated artifact path '+row.path+'.');
  artifacts.set(row.path,row);if(row.sha256===null)unknown('ARTIFACT_HASH_UNKNOWN',row.path,'No artifact hash was declared.');
 }
 for(const key of ['tool','toolVersion','project','revision','generatedAt'])if(report.source[key]===null)unknown('PROVENANCE_UNKNOWN','source.'+key,'Source '+key+' was not reported.');
 if(!report.source.artifacts.length)unknown('ARTIFACTS_MISSING','source.artifacts','No original vendor/build/bench artifact was declared.');
 const devices=new Set();
 report.memoryPools.forEach((row,i)=>{
  const path='memoryPools['+i+']';
  if(devices.has(row.device))conflict('DUPLICATE_MEMORY_POOL',path,'Repeated component '+row.device+'.');devices.add(row.device);
  const target=Object.hasOwn(POOLS,row.device)?POOLS[row.device]:null;
  if(target===null)conflict('MEMORY_DEVICE',path,'Component '+row.device+' is outside the selected four R23 pools.');
  else if(row.selectedMiB!==target)conflict('SELECTED_MEMORY_CAPACITY',path,'R23 selects '+target+' MiB for '+row.device+'; the report declares '+row.selectedMiB+' MiB.');
  if(row.physicalCandidateBits===null)unknown('MEMORY_GEOMETRY_UNKNOWN',path+'.physicalCandidateBits','Exact physical candidate density is unknown.');
  else if(row.physicalCandidateBits/(8*MIB)!==row.selectedMiB)conflict('MEMORY_GEOMETRY_CONFLICT',path,'Physical density '+row.physicalCandidateBits+' bits is '+row.physicalCandidateBits/(8*MIB)+' MiB, not the declared '+row.selectedMiB+' MiB. Addressing a subset does not prove a different installed capacity.');
  const documented=row.part!==null&&Object.hasOwn(KNOWN_MEMORY,row.part)?KNOWN_MEMORY[row.part]:null;
  if(documented){
   if(documented.bits/(8*MIB)!==row.selectedMiB)conflict('MEMORY_PART_CAPACITY_CONFLICT',path+'.part','The named Alliance part is documented as '+documented.bits/(8*MIB)+' MiB; it does not implement the selected '+row.selectedMiB+' MiB physical pool.');
   if(row.physicalCandidateBits!==null&&row.physicalCandidateBits!==documented.bits)conflict('MEMORY_PART_GEOMETRY_CONFLICT',path+'.physicalCandidateBits','Declared density contradicts the named part\'s documented '+documented.bits+' bits.');
   if(['T120-A','T120-B','BT820B'].includes(row.device)&&documented.dqBits!==(row.device==='BT820B'?16:32))conflict('MEMORY_PART_WIDTH_CONFLICT',path+'.part','Named part organization does not match the selected component\'s '+(row.device==='BT820B'?16:32)+'-bit memory target.');
  }
  if(row.part===null)unknown('MEMORY_PART_UNKNOWN',path+'.part','Exact memory part/source revision was not supplied.');
  if(row.reportedMeasuredMiB===null)unknown('MEMORY_MEASUREMENT_UNKNOWN',path+'.reportedMeasuredMiB','No physical capacity measurement was reported.');
  else {unknown('MEMORY_MEASUREMENT_UNVERIFIED',path+'.reportedMeasuredMiB','The reported measurement is not authenticated hardware proof.');if(row.reportedMeasuredMiB!==row.selectedMiB)conflict('MEMORY_MEASUREMENT_CONFLICT',path,'Reported measured capacity differs from the selected pool.');}
  unknown('MEMORY_CONTROLLER_UNVERIFIED',path,'Reported part/density does not prove controller setup, rails, ballout, calibration, independent ownership or throughput.');
 });
 for(const device of Object.keys(POOLS))if(!devices.has(device))unknown('MEMORY_POOL_MISSING',device,'No record was supplied for the selected '+POOLS[device]+' MiB pool.');
 if(report.memoryPools.length!==4)unknown('MEMORY_COVERAGE','memoryPools','R23 requires four independently evidenced physical pools.');
 const owners=new Set();
 report.norDevices.forEach((row,i)=>{
  const path='norDevices['+i+']',seenPaths=new Set(),seenRoles=new Set(),roundedImageBytes=[];
  if(owners.has(row.owner))conflict('DUPLICATE_NOR_OWNER',path,'Repeated NOR owner '+row.owner+'.');owners.add(row.owner);
  if(!NOR_OWNERS.includes(row.owner))conflict('NOR_OWNER',path,'Only F133-B, T120-A and T120-B own the three dedicated NORs.');
  if(row.capacityBytes!==NOR_CAPACITY)conflict('NOR_CAPACITY',path+'.capacityBytes','Each dedicated R23 NOR is exactly 16 MiB (16,777,216 bytes).');
  if(row.eraseBlockBytes===null)unknown('NOR_ERASE_GEOMETRY_UNKNOWN',path+'.eraseBlockBytes','Selected part erase-block geometry is unknown.');
  else if(row.eraseBlockBytes>row.capacityBytes||row.capacityBytes%row.eraseBlockBytes!==0)conflict('NOR_ERASE_GEOMETRY',path,'Reported erase geometry does not divide the stated device capacity.');
  if(row.metadataBytes===null)unknown('NOR_METADATA_UNKNOWN',path+'.metadataBytes','Manifest/journal/protection metadata space is unknown.');
  if(!row.images.length)unknown('NOR_IMAGES_MISSING',path+'.images','No authentic loadable image sizes were reported.');
  let declaredBytes=0,allocatedBytes=0,complete=row.metadataBytes!==null&&row.eraseBlockBytes!==null&&row.images.length>0;
  for(const [j,image] of row.images.entries()){
   const imagePath=path+'.images['+j+']';
   if(seenPaths.has(image.path))conflict('DUPLICATE_NOR_IMAGE',imagePath,'Repeated image path within one NOR. Declare distinct archive paths for distinct stored copies.');seenPaths.add(image.path);
   if(seenRoles.has(image.role))conflict('DUPLICATE_NOR_ROLE',imagePath,'Repeated image role within one NOR.');seenRoles.add(image.role);
   const artifact=artifacts.get(image.path);
   if(!artifact)unknown('IMAGE_ARTIFACT_UNDECLARED',imagePath,'The image path is not declared in source.artifacts.');
   else if(image.sha256!==null&&artifact.sha256!==null&&image.sha256!==artifact.sha256)conflict('IMAGE_HASH_CONFLICT',imagePath,'Image and source artifact hashes disagree.');
   if(image.sha256===null)unknown('IMAGE_HASH_UNKNOWN',imagePath+'.sha256','No loadable-image hash was declared.');
   let roundedBytes=null;
   if(image.loadableBytes===null){complete=false;unknown('IMAGE_SIZE_UNKNOWN',imagePath+'.loadableBytes','Authentic generated loadable binary size is unknown; text .hex/archive length is not a substitute.');}
   else {
    declaredBytes+=image.loadableBytes;
    if(row.eraseBlockBytes!==null){roundedBytes=Math.ceil(image.loadableBytes/row.eraseBlockBytes)*row.eraseBlockBytes;allocatedBytes+=roundedBytes;}
   }
   roundedImageBytes.push({path:image.path,declaredBytes:image.loadableBytes,roundedBytes});
  }
  const metadataRoundedBytes=row.metadataBytes===null||row.eraseBlockBytes===null?null:Math.ceil(row.metadataBytes/row.eraseBlockBytes)*row.eraseBlockBytes;
  if(metadataRoundedBytes!==null)allocatedBytes+=metadataRoundedBytes;
  if(!Number.isSafeInteger(declaredBytes)||!Number.isSafeInteger(allocatedBytes)){complete=false;conflict('NOR_ARITHMETIC_RANGE',path,'Declared capacity arithmetic exceeds safe integer range.');}
  if(declaredBytes>row.capacityBytes||row.metadataBytes!==null&&declaredBytes+row.metadataBytes>row.capacityBytes||row.eraseBlockBytes!==null&&allocatedBytes>row.capacityBytes)conflict('NOR_CAPACITY_EXCEEDED',path,'Declared images/metadata, including conservative erase-block rounding when known, exceed the NOR capacity.');
  unknown('NOR_LAYOUT_UNVERIFIED',path,'Rounded slot-size sum is a planning lower bound, not offsets/nonoverlap, boot compatibility, write protection, endurance or recovery proof.');
  result.norDevices.push({...clone(row),capacityDiagnostic:{declaredImageBytes:Number.isSafeInteger(declaredBytes)?declaredBytes:null,metadataRoundedBytes,allocatedBytes:complete?allocatedBytes:null,remainingBytes:complete?row.capacityBytes-allocatedBytes:null,roundedImageBytes,geometryVerified:false}});
 });
 for(const owner of NOR_OWNERS)if(!owners.has(owner))unknown('NOR_DEVICE_MISSING',owner,'The selected dedicated 16 MiB NOR lacks a record.');
 if(report.norDevices.length!==3)unknown('NOR_COVERAGE','norDevices','Exactly three dedicated physical NOR devices require separate evidence.');
 if(report.gameStorage.technology!=='SPI NAND')conflict('GAME_STORAGE_TECHNOLOGY','gameStorage.technology','R23 selects separate SPI NAND; eMMC is prohibited.');
 for(const key of ['part','capacityBytes','eccEvidence'])if(report.gameStorage[key]===null)unknown('NAND_'+key.toUpperCase()+'_UNKNOWN','gameStorage.'+key,'NAND '+key+' remains unknown.');
 unknown('NAND_IMPLEMENTATION_UNVERIFIED','gameStorage','Declared ECC evidence does not prove controller/OOB compatibility, bad-block handling, wear leveling, filesystem or power-loss recovery.');
 if(JSON.stringify(report.video.path)!==JSON.stringify(VIDEO_PATH))conflict('VIDEO_PATH','video.path','Selected R23 path is T120-A → BT820B → IT6263N → HDMI.');
 for(const key of ['pixelClockMHz','links','measuredFps'])if(report.video[key]===null)unknown('VIDEO_'+key.toUpperCase()+'_UNKNOWN','video.'+key,'Video '+key+' was not reported.');
 else unknown('VIDEO_REPORTED_VALUE_UNVERIFIED','video.'+key,'The reported '+key+' does not establish end-to-end electrical timing or a working display.');
 if(!report.video.sourceArtifactPaths.length)unknown('VIDEO_ARTIFACTS_MISSING','video.sourceArtifactPaths','No video timing/build/monitor artifacts were referenced.');
 const videoPaths=new Set();
 for(const path of report.video.sourceArtifactPaths){if(videoPaths.has(path))conflict('DUPLICATE_VIDEO_ARTIFACT','video.sourceArtifactPaths','Repeated video artifact path '+path+'.');videoPaths.add(path);if(!artifacts.has(path))unknown('VIDEO_ARTIFACT_UNDECLARED',path,'Referenced video artifact is absent from source.artifacts.');}
 unknown('VIDEO_CHAIN_UNVERIFIED','video','No serializer/mode/clock mapping is inferred from numbers alone. LVDS input/composition/output, controller memory, EDID/HPD, audio and monitor measurements require authentic evidence.');
 report.signoffs.forEach((row,i)=>{
  const path='signoffs['+i+']';
  if(!result.gates.some(gate=>gate.id===row.gate))conflict('UNKNOWN_GATE',path,'Unknown R23 gate '+row.gate+'.');
  if(!['OPEN','UNKNOWN'].includes(row.status))conflict('SIGNOFF_NOT_SUPPORTED',path,'Reported '+row.status+' cannot close a hardware gate, even with a matching artifact hash. '+row.gate+' stays OPEN.');
  if(row.artifactSha256===null)unknown('SIGNOFF_ARTIFACT_UNKNOWN',path,'No signoff artifact hash was supplied; no approval is granted.');
 });
 result.summary={memoryPools:report.memoryPools.length,selectedTotalMiB:report.memoryPools.reduce((sum,row)=>sum+row.selectedMiB,0),physicalCandidateTotalMiB:report.memoryPools.every(row=>row.physicalCandidateBits!==null)?report.memoryPools.reduce((sum,row)=>sum+row.physicalCandidateBits/(8*MIB),0):null,norDevices:report.norDevices.length,norTotalCapacityBytes:report.norDevices.reduce((sum,row)=>sum+row.capacityBytes,0)};
 for(const key of ['selectedTotalMiB','norTotalCapacityBytes'])if(!Number.isSafeInteger(result.summary[key])){result.summary[key]=null;conflict('SUMMARY_ARITHMETIC_RANGE','summary.'+key,'Aggregate declaration exceeds safe integer range.');}
 unknown('AUTHENTICITY_UNVERIFIED','source','Declarations and byte hashes do not authenticate vendor origin, semantic content or measurements. No native vendor adapter is inferred.');
 unknown('HARDWARE_GATES_OPEN','gates','All G01–G14 remain OPEN. Software intake cannot provide EDA, prototype or manufacturing approval.');
 result.status=result.conflicts.length?'CONFLICT':'UNKNOWN';return result;
}
async function intake({text,filename,reportBytes,attachments=[]}={}){
 const parsed=parse(text),result=parsed.ok?validate(parsed.report):blank();
 if(!parsed.ok){result.status='PARSER_ERROR';result.parserErrors=parsed.parserErrors;}
 result.input={filename:String(filename||'unnamed R23 report'),format:'r23-json',sha256:null,raw:typeof text==='string'&&new TextEncoder().encode(text).byteLength<=MAX_REPORT_BYTES?text:null};
 try{
  if(typeof globalThis.ARC1Evidence?.sha256!=='function')throw Error('Load the unchanged legacy evidence.js SHA-256 helper before R23 intake.');
  const bytes=reportBytes===undefined?new TextEncoder().encode(typeof text==='string'?text:''):reportBytes;
  if(!(bytes instanceof Uint8Array))throw Error('Report bytes must be Uint8Array.');
  if(bytes.byteLength>MAX_REPORT_BYTES)throw Error('Report exceeds 2 MiB.');
  if(reportBytes!==undefined&&new TextDecoder('utf-8',{fatal:true}).decode(bytes)!==(typeof text==='string'?text.replace(/^\uFEFF/,''):null))throw Error('Report bytes do not match supplied text.');
  result.input.sha256=await ARC1Evidence.sha256(bytes);
  if(!Array.isArray(attachments)||attachments.length>200)throw Error('Expected at most 200 evidence attachments.');
  let total=0;const supplied=new Map();
  for(const attachment of attachments){
   if(!object(attachment)||!archivePath(attachment.name)||!(attachment.bytes instanceof Uint8Array))throw Error('Attachment requires relative archive path name and Uint8Array bytes.');
   total+=attachment.bytes.byteLength;if(attachment.bytes.byteLength>MAX_ARTIFACT_BYTES||total>MAX_TOTAL_ARTIFACT_BYTES)throw Error('Evidence attachment limit: 32 MiB each, 64 MiB total.');
   if(supplied.has(attachment.name))throw Error('Ambiguous duplicate attachment name '+attachment.name+'.');
   supplied.set(attachment.name,{sha256:await ARC1Evidence.sha256(attachment.bytes),byteLength:attachment.bytes.byteLength});
  }
  if(parsed.ok){
   for(const artifact of parsed.report.source.artifacts){
    const actual=supplied.get(artifact.path),status=!actual?'MISSING':!artifact.sha256?'HASH_UNDECLARED':actual.sha256===artifact.sha256?'HASH_MATCH':'MISMATCH';
    result.artifacts.push({path:artifact.path,kind:artifact.kind,expectedSha256:artifact.sha256,actualSha256:actual?.sha256||null,byteLength:actual?.byteLength??null,status,originVerified:false});
    if(status==='MISMATCH')result.conflicts.push(note('ARTIFACT_HASH_MISMATCH',artifact.path,'Attachment bytes do not match the reported SHA-256.'));
    else if(status!=='HASH_MATCH')result.unknowns.push(note('ARTIFACT_'+status,artifact.path,'Attachment status '+status+'; original origin/meaning remains unverified.'));
   }
   for(const [path,actual] of supplied)if(!parsed.report.source.artifacts.some(row=>row.path===path)){result.artifacts.push({path,expectedSha256:null,actualSha256:actual.sha256,byteLength:actual.byteLength,status:'UNDECLARED',originVerified:false});result.unknowns.push(note('ARTIFACT_UNDECLARED',path,'Attachment is not declared by the report.'));}
   for(const nor of parsed.report.norDevices)for(const image of nor.images){
    const actual=supplied.get(image.path);
    if(actual&&image.sha256!==null&&image.sha256!==actual.sha256)result.conflicts.push(note('IMAGE_HASH_MISMATCH',image.path,'Stored-image declaration does not match attachment bytes.'));
    if(actual)result.unknowns.push(note('IMAGE_BYTES_NOT_LOADABILITY_PROOF',image.path,'Observed '+actual.byteLength+' file bytes. File length/hash does not authenticate the declared '+(image.loadableBytes===null?'UNKNOWN':image.loadableBytes)+' loadable bytes or vendor format.'));
   }
  }
 }catch(error){result.parserErrors.push(note('INTAKE','input',error.message));}
 result.status=result.parserErrors.length?'PARSER_ERROR':result.conflicts.length?'CONFLICT':'UNKNOWN';return result;
}
globalThis.ARC1R23Evidence=Object.freeze({SCHEMA,MAX_REPORT_BYTES,MAX_ARTIFACT_BYTES,MAX_TOTAL_ARTIFACT_BYTES,parse,validate,intake});
})();
