/* ARC-1 R23 source/arithmetic review. No assigned nets, native EDA or signoff. */
(()=>{'use strict';
const SCHEMA='arc1-r23-architecture-review-v1';
const GATE_IDS=Array.from({length:14},(_,i)=>'G'+String(i+1).padStart(2,'0'));
const requireValue=(condition,message)=>{if(!condition)throw Error(message);};
const positive=value=>typeof value==='number'&&Number.isFinite(value)&&value>0;
const equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
function studyVideoClock(){
 const requiredLinkMHz=74.25,oscillatorMHz=38.4,documentedMultipliers=[13,15],configurations=[];
 for(const multiplier of documentedMultipliers)for(let divider=1;divider<=16;divider++){
  const clockMHz=oscillatorMHz*multiplier/(2*divider);
  configurations.push({multiplier,divider,clockMHz,withinTxPclkLimit:clockMHz<=83.2});
 }
 const legal=configurations.filter(item=>item.withinTxPclkLimit);
 const nearest=legal.reduce((a,b)=>Math.abs(a.clockMHz-requiredLinkMHz)<=Math.abs(b.clockMHz-requiredLinkMHz)?a:b);
 return {requiredLinkMHz,oscillatorMHz,documentedMultipliers,dividerRange:[1,16],txPclkCeilingMHz:83.2,
  formula:'38.4 * SYSPLL_NS / (2 * (TXCLKDIV + 1))',configurations,
  documentedReachable:legal.some(item=>Math.abs(item.clockMHz-requiredLinkMHz)<1e-9),
  nearestDocumentedMHz:nearest.clockMHz,vendorApprovedAlternative:null,measuredClockMHz:null,
  note:'Documented configuration gap; do not infer all vendor strategies are impossible or silently change the 60 Hz target.'};
}
function analyze(record,facts){
 requireValue(record?.schema===SCHEMA&&record.stage==='SOURCE_REVIEW_ONLY','Unsupported R23 source-review schema or stage.');
 requireValue(record.fabrication==='NO-GO'&&record.gateStatus==='OPEN','R23 hardware release assertions are not accepted.');
 requireValue(Array.isArray(record.gates)&&record.gates.length===14&&new Set(record.gates.map(g=>g.id)).size===14&&GATE_IDS.every(id=>record.gates.some(g=>g.id===id&&g.state==='OPEN')),'Every G01–G14 gate must remain OPEN.');
 requireValue(Array.isArray(record.sources)&&record.sources.length&&Array.isArray(record.decisions)&&Array.isArray(record.experiments),'Auditable R23 records are required.');
 const sourceIds=new Set(record.sources.map(item=>item.id));
 requireValue(sourceIds.size===record.sources.length,'Duplicate R23 source identifiers.');
 for(const source of record.sources)for(const key of ['id','title','version','locator'])requireValue(typeof source[key]==='string'&&source[key],'Incomplete source metadata: '+key+'.');
 const references=item=>requireValue(item.sourceIds?.length&&item.sourceIds.every(id=>sourceIds.has(id))&&item.gateIds?.length&&item.gateIds.every(id=>GATE_IDS.includes(id)),'Missing R23 source or gate reference.');
 const decisionIds=new Set();
 for(const decision of record.decisions){
  requireValue(!decisionIds.has(decision.id)&&['SELECTED_CONDITIONAL','PROPOSED','REJECTED'].includes(decision.state),'Unsupported or duplicate R23 decision.');
  decisionIds.add(decision.id);references(decision);
 }
 const experimentIds=new Set();
 for(const experiment of record.experiments){
  requireValue(experiment.state==='OPEN'&&!experimentIds.has(experiment.id),'R23 experiments need authentic artifacts before completion.');experimentIds.add(experiment.id);references(experiment);
  for(const field of ['requiredArtifacts','acceptance','stopConditions'])requireValue(Array.isArray(experiment[field])&&experiment[field].length,'Missing experiment contract: '+field+'.');
 }
 for(const constraint of record.documentedConstraints||[]){
  requireValue(['DOCUMENTED_CAPABILITY','DOCUMENTED_CAPABILITY_REQUIRES_VENDOR_CONFIRMATION'].includes(constraint.stage)&&constraint.measured===null,'A source constraint cannot claim measured proof.');references(constraint);
 }
 requireValue(globalThis.ARC1Architecture?.summarizeFacts,'Historical F484 source reader is required.');
 const resourceBudget=ARC1Architecture.summarizeFacts(facts),inputs=record.calculationInputs;
 requireValue(inputs?.hostTargetBitsPerSecond===1000000000&&inputs.lvdsDocumentedLaneCeilingMbps===800&&inputs.lvdsSerializationFactor===7,'Unexpected host or LVDS assumptions.');
 requireValue(inputs.parallelClockMHz===null&&inputs.achievedLinkBytesPerSecond===null,'Achieved link performance must remain UNKNOWN.');
 requireValue(equal(inputs.parallelWidthsPerDirection,[16,32])&&equal(inputs.serializedLanesPerDirection,[4,8,16]),'Unexpected A/B candidate study.');
 requireValue(equal(record.videoPath,['T120-A','BT820B','IT6263N','HDMI']),'The active R23 video path must include BT820B.');
 requireValue(record.gameStorage?.technology==='SPI NAND'&&record.gameStorage.part===null&&record.gameStorage.capacityBytes===null,'R23 game NAND part/capacity remain OPEN; eMMC is retired.');
 const targets={'F133-B':64,'T120-A':128,'T120-B':128,'BT820B':64},seen=new Set();
 requireValue(Array.isArray(record.memoryPools)&&record.memoryPools.length===4,'Four independent memory pools are required.');
 const pools=record.memoryPools.map(pool=>{
  requireValue(!seen.has(pool.device)&&targets[pool.device]===pool.targetMiB&&pool.independent===true&&pool.measuredMiB===null,'R23 memory targets or independence changed.');seen.add(pool.device);
  requireValue(pool.physicalCandidateBits===null||(Number.isSafeInteger(pool.physicalCandidateBits)&&pool.physicalCandidateBits>0),'Invalid physical memory geometry.');
  const knownBits={'AS4C32M32MD2A-25BIN':1073741824,'AS4C64M16MD2A-25BIN':1073741824};
  if(knownBits[pool.part])requireValue(pool.physicalCandidateBits===knownBits[pool.part],'Named Alliance geometry contradicts the original datasheet.');
  const candidateMiB=pool.physicalCandidateBits===null?null:pool.physicalCandidateBits/8/1048576;
  return {...pool,candidateMiB,capacityConflict:candidateMiB!==null&&candidateMiB!==pool.targetMiB};
 });
 const memoryPools={pools,targetInstalledMiB:pools.reduce((sum,pool)=>sum+pool.targetMiB,0),
  candidateInstalledMiB:pools.every(pool=>pool.candidateMiB!==null)?pools.reduce((sum,pool)=>sum+pool.candidateMiB,0):null,
  sharedAddressSpace:false,measuredInstalledMiB:null};
 const owners=['F133-B','T120-A','T120-B'];
 requireValue(Array.isArray(record.norDevices)&&record.norDevices.length===3&&new Set(record.norDevices.map(nor=>nor.owner)).size===3,'Three dedicated NOR devices are required.');
 const norDevices=record.norDevices.map(nor=>{
  requireValue(owners.includes(nor.owner)&&nor.targetBytes===16777216&&nor.actualImageBytes===null&&nor.part===null&&nor.eraseBlockBytes===null,'NOR capacity is selected per device; SKU, erase geometry and generated image sizes remain UNKNOWN.');
  return {...nor,fit:'UNKNOWN',measuredEnduranceCycles:null};
 });
 const hostRawBytesPerSecond=inputs.hostTargetBitsPerSecond/8;
 requireValue(Array.isArray(inputs.modes)&&inputs.modes.length,'Missing video timing targets.');
 const modes=inputs.modes.map(mode=>{
  for(const key of ['width','height','totalWidth','totalHeight','fps','framebufferBytesPerPixel'])requireValue(positive(mode[key]),'Invalid display arithmetic input '+key+'.');
  requireValue(mode.totalWidth>=mode.width&&mode.totalHeight>=mode.height&&mode.sourceIds?.length&&mode.sourceIds.every(id=>sourceIds.has(id)),'Invalid timing totals or missing sources.');
  const frameBytes=mode.width*mode.height*mode.framebufferBytesPerPixel,scanoutBytesPerSecond=frameBytes*mode.fps,pixelClockMHz=mode.totalWidth*mode.totalHeight*mode.fps/1000000;
  const singleLinkMbps=pixelClockMHz*7,dualLinkMbps=singleLinkMbps/2;
  requireValue([frameBytes,scanoutBytesPerSecond,pixelClockMHz,singleLinkMbps,dualLinkMbps,hostRawBytesPerSecond/frameBytes].every(positive),'Display arithmetic exceeds positive finite numeric range.');
  return {...mode,frameBytes,scanoutBytesPerSecond,pixelClockMHz,singleLinkMbps,dualLinkMbps,
   hostRawCeilingExceeded:scanoutBytesPerSecond>hostRawBytesPerSecond,hostRawFrameRateCeiling:hostRawBytesPerSecond/frameBytes,
   singleLinkExceedsLvdsLimit:singleLinkMbps>800,dualLinkExceedsLvdsLimit:dualLinkMbps>800,measuredScanoutBytesPerSecond:null};
 });
 const linkCandidates=inputs.parallelWidthsPerDirection.map(width=>({widthPerDirection:width,ddioDataPinsPerChip:2*width,bytesPerClockPerDirection:2*width/8,
  clockMHz:null,rawBytesPerSecond:null,remainingConservativeDdioAfterData:resourceBudget.conservativeUnannotatedDdioPins-2*width,
  rgmiiPhysicalPinsBudget:12,remainingConservativeDdioAfterDataAndRgmii:resourceBudget.conservativeUnannotatedDdioPins-2*width-12}));
 const serializedLinkCandidates=inputs.serializedLanesPerDirection.map(lanes=>({lanesPerDirection:lanes,lvdsTxPairsForData:lanes,lvdsRxPairsForData:lanes,
  sourceLaneCeilingMbps:800,theoreticalRawBytesPerSecond:lanes*800000000/8,achievedLaneMbps:null,achievedBytesPerSecond:null,clockPairs:null}));
 const videoClockStudy=studyVideoClock();
 const findings=[
  {id:'R23-AF01',title:'Resolve the BT memory candidate discrepancy',message:'Selected independent pools total 384 MiB. AS4C64M16MD2A-25BIN is 1 Gbit = 128 MiB, making the named candidate installation 448 MiB. Keep the 64 MiB BT target; choose and qualify its exact part or obtain an explicit owner decision.',sourceIds:['R23-AUTHORITY','ALLIANCE-DDR','BT-DS'],gateIds:['G12','G07']},
  {id:'R23-AF02',title:'74.25 MHz clock strategy remains OPEN',message:'AN086 v1.4 documents 38.4 MHz × {13,15} / (2 × divider), divider 1–16. No documented setting produces 74.25 MHz. Nearest is 72 MHz, which would change the standard timing/frame rate. Obtain a vendor-approved 60 Hz strategy without bypassing BT820B.',sourceIds:['BT-PROGRAM','BT-DS','LINUX-MODES'],gateIds:['G02','G12']},
  {id:'R23-AF03',title:'Budget both LVDS boundaries',message:'For RGB24 dual-pixel input, conservatively budget eight T120-A TX data pairs plus two clock pairs. BT outputs also expose two clock pairs; the ITE reference uses a common clock. Pair allocation, odd/even alignment and clock connection need exact-source proof; never tie active clock outputs.',sourceIds:['BT-HARDWARE','T120-PINOUT','ITE-6263'],gateIds:['G02','G08','G12']},
  {id:'R23-AF04',title:'Render locally and measure BT traffic',message:'1080p60 active RGB888 is 373.248 MB/s and RGBA32 is 497.664 MB/s, above the raw 125 MB/s host ceiling. Four hypothetical RGB888 DRAM passes would consume 1492.992 MB/s of the BT x16-800 raw 1600 MB/s; actual pass count, overlays, arbitration and latency remain unmeasured.',sourceIds:['LINUX-MODES','BT-DS','R23-AUTHORITY'],gateIds:['G01','G04','G12']},
  {id:'R23-AF05',title:'Prove capacity separately in each NOR',message:'Each CPU/FPGA has exactly 16 MiB selected NOR capacity. Generated loadable bytes, erase-rounded metadata, boot/rollback layout and part endurance are unknown. The 48 MiB aggregate cannot cover overflow in another device.',sourceIds:['R23-AUTHORITY','STORAGE-REVIEW'],gateIds:['G05','G13']},
  {id:'R23-AF06',title:'Separate cold boot from game personality loading',message:'A and B cold-boot from their own NORs. Study passive/RAM-staged B game loading with exclusive programming ownership, NOR isolation, CRC/fences and independent JTAG recovery. Per-launch NOR rewriting is not the default.',sourceIds:['R23-AUTHORITY','T120-DS','STORAGE-REVIEW'],gateIds:['G03','G05','G13']},
  {id:'R23-AF07',title:'Keep power and lifetime qualification blocking',message:'Regular I4 FPGA core/PLL is nominal 1.2 V. Alliance LPDDR2 needs near-1.8 V VDD1 and near-1.2 V VDD2/CA/Q classes. The preliminary part limits uncontrolled power-offs to 400 over life; current vendor confirmation and controlled shutdown/power-loss qualification remain required.',sourceIds:['T120-DS','ALLIANCE-DDR'],gateIds:['G01','G07','G09','G11','G12']},
  {id:'R23-AF08',title:'Complete the paired resource and host study',message:'The workbook has 96 DDIO and 40 TX/40 RX pairs per F484. Quarantining configuration/DDR-reference candidates leaves 76 DDIO; this is not a net allocation. DDR startup PLL/ref, RGMII pinmux/fixed-link driver integration, SPI rescue and native-LVDS A/B alternatives need whole-system Efinity and bench evidence.',sourceIds:['T120-PINOUT','T120-DS','HOST-S02','HOST-S03'],gateIds:['G01','G03','G04','G08']},
  {id:'R23-AF09',title:'Assign control, assets and audio explicitly',message:'BT SPI/QSPI control master is OPEN; its raw QSPI ceiling is 30 MB/s and is not automatic access to FPGA RAM. BT I²S is transmit-slave and requires an external BCLK/LRCLK master. SDK, asset transfers, sound source, EDID/HPD/DDC and bridge control need explicit ownership.',sourceIds:['BT-DS','BT-PROGRAM','R23-AUTHORITY'],gateIds:['G02','G10','G12']},
  {id:'R23-AF10',title:'Qualify the separate SPI NAND game library',message:'NAND model/capacity, ECC/OOB/bad-block handling, wear leveling, power-loss-safe updates and exact F133 BSP/controller support are OPEN. Generic Linux support is a candidate path, not a tested console driver. No eMMC substitution.',sourceIds:['R23-AUTHORITY','STORAGE-REVIEW'],gateIds:['G05','G14']}
 ];
 return {status:'SOURCE_REVIEW_ONLY',fabrication:'NO-GO',gates:record.gates.map(g=>({...g})),
  calculations:{hostRawBytesPerSecond,modes,resourceBudget,linkCandidates,serializedLinkCandidates,memoryPools,norDevices,videoClockStudy,
   btMemoryTrafficStudy:{hypotheticalRgb888Passes:4,rawBytesPerSecond:1600000000,hypotheticalActiveBytesPerSecond:1492992000,actualPassCount:null,measuredBytesPerSecond:null},
   aToBtDualRgb24PairBudget:{dataPairs:8,clockPairs:2,totalPairs:10,assignedPairs:null}},findings};
}
globalThis.ARC1R23Architecture=Object.freeze({SCHEMA,GATE_IDS:Object.freeze(GATE_IDS),studyVideoClock,analyze});
})();
