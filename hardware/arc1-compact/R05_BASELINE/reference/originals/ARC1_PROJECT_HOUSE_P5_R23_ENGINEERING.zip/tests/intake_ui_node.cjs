/* Actual intake UI handlers in a minimal DOM harness. This is not a browser test. */
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const {webcrypto,createHash}=require('node:crypto');
const root=path.resolve(__dirname,'..');
const inventory=fs.readFileSync(path.join(root,'pins.json'));
const template=JSON.parse(fs.readFileSync(path.join(root,'engineering/ARC1_EVIDENCE_TEMPLATE.json'),'utf8'));
const source=JSON.parse(inventory).find(p=>p.chip==='T120-A'&&p.ball==='P4');
const clone=x=>JSON.parse(JSON.stringify(x));
const toBuffer=b=>b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength);
function file(name,text){const b=Buffer.from(text);return {name,size:b.length,arrayBuffer:async()=>toBuffer(b)};}
function vector(){const r=clone(template);r.assignments=[{chip:source.chip,ball:source.ball,net:'SYNTHETIC_UI_TEST',bank:source.bank,voltage:null,resource:'GPIO',function:source.name}];return r;}
function harness(options={}){
 const nodes=new Map();let present=true,download=null;
 const element=id=>{if(!nodes.has(id))nodes.set(id,{value:'',innerHTML:'',dataset:{},click(){},remove(){}});return nodes.get(id);};
 const panel={innerHTML:'',querySelector:element,querySelectorAll(){
  return [...panel.innerHTML.matchAll(/data-evidence-path="(\d+)"/g)].map(m=>{
   const input=element('path'+m[1]);input.dataset.evidencePath=m[1];return input;
  });
 }};
 const box={TextEncoder,TextDecoder,Blob,crypto:webcrypto,console,setTimeout(){},
  URL:{createObjectURL(blob){download=blob;return 'blob:synthetic-test';},revokeObjectURL(){}},
  document:{querySelector:()=>present?panel:null,createElement:()=>element('download'),body:{append(){}}},
  fetch:options.fetch||(async()=>({ok:true,arrayBuffer:async()=>toBuffer(inventory)}))};
 const context=vm.createContext(box);
 for(const name of ['evidence.js','evidence-ui.js'])vm.runInContext(fs.readFileSync(path.join(root,name),'utf8'),context,{filename:name});
 const api=context.ARC1EvidenceUI;
 function mount(){present=true;panel.innerHTML=api.panel();api.mount();}
 mount();
 // Historical DEV-002 vectors explicitly select the preserved legacy importer;
 // the current PWA's default importer is versioned R23 system JSON.
 element('#evidenceFormat').onchange({target:{value:'json'}});
 return {panel,api,element,mount,leave(){present=false;},
  select(report){element('#evidenceReportFile').onchange({target:{files:[report]}});},
  artifacts(files){element('#evidenceArtifactFiles').onchange({target:{files}});},
  format(value){element('#evidenceFormat').onchange({target:{value}});},
  submit(){element('#evidenceForm').onsubmit({preventDefault(){}});},
  clear(){element('#evidenceClear').onclick();element('#evidenceFormat').onchange({target:{value:'json'}});},
  async exported(){element('#evidenceExport').onclick();assert(download);return JSON.parse(await download.text());}};
}
async function until(check){for(let i=0;i<200;i++){if(check())return;await new Promise(r=>setTimeout(r,5));}assert.fail('UI operation did not finish');}
const resultReady=h=>until(()=>/Intake result:/.test(h.panel.innerHTML));

test('UI uses real module/dictionary, escapes reported strings and exports original hashed report with OPEN gates',async()=>{
 const h=harness(),r=vector();r.source.project='<img src=x onerror="throw 1">';
 const text='\uFEFF'+JSON.stringify(r);h.select(file('<report>.json',text));h.submit();await resultReady(h);
 assert(h.panel.innerHTML.includes('Intake result: UNKNOWN'));
 assert(h.panel.innerHTML.includes('&lt;img'));assert(!h.panel.innerHTML.includes('<img src=x'));
 const output=await h.exported();assert.equal(output.input.raw,text);
 assert.equal(output.input.sha256,createHash('sha256').update(text).digest('hex'));
 assert.equal(output.inventory.status,'HASH_MATCH');assert.equal(output.gates.length,11);
 assert(output.gates.every(g=>g.status==='OPEN'));assert.equal(output.source.project,r.source.project);
});
test('UI separates malformed JSON, source conflicts and no-conflict UNKNOWN results',async()=>{
 const h=harness();h.select(file('malformed.json','{'));h.submit();await resultReady(h);
 assert(h.panel.innerHTML.includes('Intake result: PARSER_ERROR'));
 let output=await h.exported();assert(output.parserErrors.length);assert.equal(output.conflicts.length,0);
 h.clear();const r=vector();r.assignments[0].ball='ZZ99';h.select(file('synthetic-conflict.json',JSON.stringify(r)));h.submit();await resultReady(h);
 output=await h.exported();assert.equal(output.status,'CONFLICT');assert.equal(output.parserErrors.length,0);
 assert(output.conflicts.some(d=>d.code==='UNKNOWN_BALL'));
});
test('explicit artifact path mapping hashes original bytes without modifying report',async()=>{
 const h=harness(),r=vector(),artifact='Synthetic UI test bytes; not vendor output';
 r.source.artifacts=[{path:'reports/original.txt',kind:'synthetic-test',sha256:createHash('sha256').update(artifact).digest('hex')}];
 const text=JSON.stringify(r);h.select(file('synthetic.json',text));h.artifacts([file('original.txt',artifact)]);
 h.element('path0').oninput({target:{dataset:{evidencePath:'0'},value:'reports/original.txt'}});
 h.submit();await resultReady(h);const output=await h.exported();
 assert.equal(output.artifacts[0].status,'HASH_MATCH');assert.equal(output.input.raw,text);
 assert(output.unknowns.some(d=>d.code==='AUTHENTICITY_UNVERIFIED'));
});
test('declared CSV template loads through actual UI with the selected parser',async()=>{
 const h=harness();h.format('csv');h.select(file('empty-template.csv',fs.readFileSync(path.join(root,'engineering/ARC1_EVIDENCE_TEMPLATE.csv'))));h.submit();await resultReady(h);
 const output=await h.exported();assert.equal(output.status,'UNKNOWN');assert.equal(output.input.format,'csv');assert.equal(output.summary.assignments,0);
});
test('navigation retains selected files/results and pending reads safely finish away from Lab',async()=>{
 const h=harness();let finish;
 const b=Buffer.from(JSON.stringify(vector()));const deferred={name:'deferred.json',size:b.length,arrayBuffer:()=>new Promise(r=>{finish=r;})};
 h.select(deferred);h.submit();h.leave();finish(toBuffer(b));
 await until(()=>/Intake result: UNKNOWN/.test(h.api.panel()));h.mount();
 assert(h.panel.innerHTML.includes('deferred.json'));assert(h.panel.innerHTML.includes('Intake result: UNKNOWN'));
 h.leave();h.mount();assert.equal((await h.exported()).status,'UNKNOWN');
});
test('clearing during file reads prevents a stale operation from restoring results',async()=>{
 const h=harness();let finish;const b=Buffer.from(JSON.stringify(vector()));
 h.select({name:'deferred-clear.json',size:b.length,arrayBuffer:()=>new Promise(r=>{finish=r;})});h.submit();h.clear();finish(toBuffer(b));
 await new Promise(r=>setTimeout(r,20));assert(h.panel.innerHTML.includes('No evidence imported in this session'));
 assert(!h.api.panel().includes('Intake result:'));assert(h.panel.innerHTML.includes('Report: <b>none selected'));
});
test('file read and inventory failures are visible; inventory loading can be retried',async()=>{
 let attempts=0;const h=harness({fetch:async()=>{if(++attempts===1)throw Error('synthetic inventory outage');return {ok:true,arrayBuffer:async()=>toBuffer(inventory)};}});
 h.select(file('retry.json',JSON.stringify(vector())));h.submit();await until(()=>h.panel.innerHTML.includes('synthetic inventory outage'));
 h.submit();await resultReady(h);assert.equal((await h.exported()).status,'UNKNOWN');assert.equal(attempts,2);
 h.clear();h.select({name:'broken.json',size:1,arrayBuffer:async()=>{throw Error('synthetic file failure');}});h.submit();await until(()=>h.panel.innerHTML.includes('synthetic file failure'));
});
test('oversized and invalid UTF-8 reports fail without a false validation result',async()=>{
 const h=harness();h.select({name:'oversized.json',size:2097153,arrayBuffer:async()=>{throw Error('Must not read');}});h.submit();
 assert(h.panel.innerHTML.includes('Report exceeds the 2 MiB limit'));assert(!h.panel.innerHTML.includes('Intake result:'));
 h.clear();const invalid=Buffer.from([255]);h.select({name:'not-utf8.json',size:1,arrayBuffer:async()=>toBuffer(invalid)});h.submit();await until(()=>h.panel.innerHTML.includes('Intake unavailable:'));
 assert(!h.panel.innerHTML.includes('Intake result:'));
});
