/* Executes the actual service worker with a synthetic, zero-dependency runtime.
 * Cached responses contain real repository bytes. This is not a browser, real
 * ServiceWorker installation, network measurement or Chromium offline signoff. */
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.resolve(__dirname,'..');
const scope='https://arc1.invalid/arc1/';
const worker=fs.readFileSync(path.join(root,'sw.js'),'utf8');

function runtime(){
  const events=new Map(),storage=new Map(),network=[];
  const state={online:true,skipWaiting:0,claimed:0};
  const absolute=input=>new URL(typeof input==='string'?input:input.url,scope).href;
  const key=(input,ignoreSearch=false)=>{
    const url=new URL(absolute(input));if(ignoreSearch)url.search='';return url.href;
  };
  function fileFor(input){
    const url=new URL(absolute(input));
    assert.equal(url.origin,new URL(scope).origin,'Synthetic network can only read this fixture origin');
    assert.ok(url.pathname.startsWith('/arc1/'),'Synthetic network can only read within registration scope');
    const relative=decodeURIComponent(url.pathname.slice('/arc1/'.length))||'index.html';
    const file=path.resolve(root,relative);
    assert.ok(file.startsWith(root+path.sep),'Synthetic network cannot escape the repository');
    return file;
  }
  async function fetchBytes(input){
    network.push(absolute(input));
    if(!state.online)throw Error('Synthetic offline network');
    const file=fileFor(input);
    if(!fs.existsSync(file)||!fs.statSync(file).isFile())return new Response('Synthetic 404',{status:404});
    return new Response(fs.readFileSync(file),{status:200});
  }
  class Cache{
    constructor(){this.entries=new Map();}
    async put(input,response){this.entries.set(key(input),response.clone());}
    async match(input,options={}){
      const found=[...this.entries].find(([url])=>key(url,options.ignoreSearch)===key(input,options.ignoreSearch));
      return found?found[1].clone():undefined;
    }
    async addAll(inputs){
      // Like Cache.addAll, stage the whole batch before mutating the cache.
      const responses=await Promise.all(inputs.map(input=>fetchBytes(input)));
      assert.ok(responses.every(response=>response.ok),'Every precached repository file must exist');
      for(let i=0;i<inputs.length;i++)await this.put(inputs[i],responses[i]);
    }
  }
  const caches={
    async open(name){if(!storage.has(name))storage.set(name,new Cache());return storage.get(name);},
    async keys(){return [...storage.keys()];},
    async delete(name){return storage.delete(name);},
    async match(input,options){for(const cache of storage.values()){const result=await cache.match(input,options);if(result)return result;}}
  };
  const self={
    location:new URL(scope),registration:{scope},
    addEventListener(name,handler){events.set(name,handler);},
    async skipWaiting(){state.skipWaiting++;},clients:{async claim(){state.claimed++;}}
  };
  const context=vm.createContext({self,caches,fetch:fetchBytes,URL,Request,Response});
  vm.runInContext(worker,context,{filename:'sw.js'});
  const assets=Array.from(vm.runInContext('ASSETS',context));
  const cacheName=vm.runInContext('CACHE',context);
  async function lifecycle(name){
    let pending;events.get(name)({waitUntil(value){assert.equal(pending,undefined);pending=value;}});
    assert.ok(pending,'Lifecycle event must register work');await pending;
  }
  async function request(input,options={}){
    // Browser navigation Request construction is unavailable in Node; this
    // explicit event record models that one browser-owned mode for fallback.
    const req=options.mode==='navigate'?{url:absolute(input),method:options.method||'GET',mode:'navigate'}:new Request(absolute(input),options);
    let pending;events.get('fetch')({request:req,respondWith(value){assert.equal(pending,undefined);pending=value;}});
    return {handled:pending!==undefined,response:pending===undefined?undefined:await pending};
  }
  return {state,storage,caches,network,assets,cacheName,fileFor,lifecycle,request};
}

test('actual sw.js install precaches every declared asset using its real file bytes',async()=>{
  const env=runtime();assert.ok(env.assets.length>=30);assert.equal(new Set(env.assets).size,env.assets.length);
  await env.lifecycle('install');assert.equal(env.state.skipWaiting,1);
  assert.equal(env.network.length,env.assets.length);assert.deepEqual(await env.caches.keys(),[env.cacheName]);
  const cache=await env.caches.open(env.cacheName);assert.equal(cache.entries.size,env.assets.length);
  for(const asset of env.assets){
    const response=await cache.match(asset);assert.ok(response?.ok,asset);
    assert.deepEqual(Buffer.from(await response.arrayBuffer()),fs.readFileSync(env.fileFor(asset)),asset+' must preserve exact repository bytes');
  }
});

test('actual activation cleans older ARC-1 House caches and preserves current and unrelated caches',async()=>{
  const env=runtime();
  for(const name of ['arc1-house-r21','arc1-house-r22-p05',env.cacheName,'other-project-cache','arc1-unrelated-cache'])await env.caches.open(name);
  await env.lifecycle('activate');
  assert.deepEqual(await env.caches.keys(),[env.cacheName,'other-project-cache','arc1-unrelated-cache']);assert.equal(env.state.claimed,1);
});

test('offline evidence modules, inventory, schema, both templates and roadmap resolve from installed cache',async()=>{
  const env=runtime();await env.lifecycle('install');env.state.online=false;env.network.length=0;
  for(const asset of ['evidence.js','evidence-ui.js','r23-evidence.js','architecture.js','r23-architecture.js','architecture-ui.js','pins.json','engineering/r23/architecture.json','engineering/r23/R23_SYSTEM_EVIDENCE_SCHEMA.json','engineering/r23/R23_SYSTEM_EVIDENCE_TEMPLATE.json','engineering/r23/ARC1_R23_Handoff.docx','engineering/architecture/architecture.json','engineering/architecture/spreadsheetfacts.json','engineering/architecture/ARCHITECTURE_DECISION_RECORD.md','engineering/ARC1_EVIDENCE_SCHEMA.json','engineering/ARC1_EVIDENCE_TEMPLATE.json','engineering/ARC1_EVIDENCE_TEMPLATE.csv','tasks/roadmap.json']){
    const {handled,response}=await env.request(asset+'?offline-test=1');assert.equal(handled,true,asset);assert.equal(response.status,200);
    assert.deepEqual(Buffer.from(await response.arrayBuffer()),fs.readFileSync(env.fileFor(asset)),asset);
  }
  assert.equal(env.network.length,0,'Known assets and query variants must not attempt the network');
});

test('offline navigation falls back to the real application shell for uncached scoped routes',async()=>{
  const env=runtime();await env.lifecycle('install');env.state.online=false;env.network.length=0;
  const {handled,response}=await env.request('uncached-navigation',{mode:'navigate'});
  assert.equal(handled,true);assert.equal(response.status,200);assert.equal(env.network.length,1);
  assert.deepEqual(Buffer.from(await response.arrayBuffer()),fs.readFileSync(path.join(root,'index.html')));
});

test('offline uncached data requests produce network errors rather than application HTML',async()=>{
  const env=runtime();await env.lifecycle('install');env.state.online=false;
  const {handled,response}=await env.request('uncached-data.json');assert.equal(handled,true);assert.equal(response.type,'error');assert.equal(response.status,0);
});

test('uncached same-origin GET falls back to the network and preserves real bytes',async()=>{
  const env=runtime();await env.lifecycle('install');env.network.length=0;
  const {handled,response}=await env.request('CLAUDE.md');assert.equal(handled,true);assert.equal(response.status,200);
  assert.deepEqual(Buffer.from(await response.arrayBuffer()),fs.readFileSync(path.join(root,'CLAUDE.md')));assert.equal(env.network.length,1);
  assert.equal(await env.caches.match('CLAUDE.md'),undefined,'Network responses are not silently added to this static cache');
});

test('fetch handler excludes POST, foreign origins and paths outside its registration scope',async()=>{
  const env=runtime();await env.lifecycle('install');env.network.length=0;
  for(const [url,options] of [['pins.json',{method:'POST'}],['https://other.invalid/arc1/pins.json',{}],['https://arc1.invalid/elsewhere/pins.json',{}],['https://arc1.invalid/arc1-adjacent/pins.json',{}]]){
    const result=await env.request(url,options);assert.equal(result.handled,false,url);assert.equal(result.response,undefined);
  }
  assert.equal(env.network.length,0);
});
