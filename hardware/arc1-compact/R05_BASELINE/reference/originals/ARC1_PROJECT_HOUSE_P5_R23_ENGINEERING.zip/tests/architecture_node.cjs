/* Source-review arithmetic and UI runtime tests. Uses actual archived records
 * and workbook-derived package facts. This is not Efinity, PCB, measured
 * performance, a real-browser run or hardware signoff. */
const {test,before}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const {pathToFileURL}=require('node:url');
const {createHash}=require('node:crypto');
const root=path.resolve(__dirname,'..');
const read=name=>fs.readFileSync(path.join(root,name),'utf8');
const clone=value=>JSON.parse(JSON.stringify(value));
const freeze=value=>{if(value&&typeof value==='object'){Object.values(value).forEach(freeze);Object.freeze(value);}return value;};
let architecture,record,facts,activeArchitecture,activeRecord;
before(async()=>{
  await import(pathToFileURL(path.join(root,'architecture.js')).href);
  architecture=globalThis.ARC1Architecture;
  record=JSON.parse(read('engineering/architecture/architecture.json'));
  facts=JSON.parse(read('engineering/architecture/spreadsheetfacts.json'));
  await import(pathToFileURL(path.join(root,'r23-architecture.js')).href);
  activeArchitecture=globalThis.ARC1Architecture;
  activeRecord=JSON.parse(read('engineering/r23/architecture.json'));
});
const analyze=(value=record,source=facts)=>architecture.analyze(value,source);
const rejectRecord=(mutate,pattern)=>{const value=clone(record);mutate(value);assert.throws(()=>analyze(value),pattern);};
const rejectFacts=(mutate,pattern)=>{const value=clone(facts);mutate(value);assert.throws(()=>architecture.summarizeFacts(value),pattern);};

test('source facts bind the actual original F484 workbook and all 484 package definitions',()=>{
  const digest=createHash('sha256').update(fs.readFileSync(path.join(root,'engineering/T120_pinout_v1.4.xlsx'))).digest('hex');
  assert.equal(digest,architecture.WORKBOOK_HASH);assert.equal(facts.source.sha256,digest);assert.equal(facts.source.sheet,'T120F484');
  assert.equal(facts.schema,'arc1-f484-resource-facts-v1');assert.equal(facts.rows.length,484);assert.equal(new Set(facts.rows.map(row=>row.ball)).size,484);
  const pins=JSON.parse(read('pins.json'));
  for(const chip of ['T120-A','T120-B']){
    const dictionary=new Map(pins.filter(pin=>pin.chip===chip).map(pin=>[pin.ball,pin]));assert.equal(dictionary.size,484);
    for(const row of facts.rows){const pin=dictionary.get(row.ball);assert.ok(pin,row.ball);for(const key of ['bank','name','ddr'])assert.equal(row[key],pin[key],chip+'/'+row.ball+'/'+key);}
  }
  for(const row of facts.rows){assert.ok(!Object.hasOwn(row,'net'));assert.ok(!Object.hasOwn(row,'assignedNet'));}
});

test('real DDIO, configuration overlap, PHY reference and native LVDS counts remain distinct',()=>{
  const summary=architecture.summarizeFacts(facts);
  for(const [key,value] of Object.entries({gpioPerChip:256,ddioPerChip:96,configDdioPins:19,ddrReferenceDdioPins:1,conservativeUnannotatedDdioPins:76,lvdsTxPairs:40,lvdsRxPairs:40,hardDdrControllersPerChip:1}))assert.equal(summary[key],value,key);
  assert.equal(Object.values(summary.bankCounts).reduce((sum,bank)=>sum+bank.gpio,0),256);
  assert.equal(Object.values(summary.bankCounts).reduce((sum,bank)=>sum+bank.ddio,0),96);
  assert.equal(facts.rows.find(row=>row.ball==='R12').ddio,'','LVDS-bank PHY reference cannot be inferred to support DDIO');
  assert.equal(facts.rows.find(row=>row.ball==='M15').ddio,'Yes');
  const ddio=facts.rows.filter(row=>row.ddio==='Yes');assert.equal(ddio.length,96);assert.ok(ddio.every(row=>row.name.startsWith('GPIO')));
  assert.ok(facts.rows.filter(row=>row.lvds).every(row=>row.ddio===''),'Native differential resources are not inferred to be parallel DDIO');
});

test('host and display arithmetic distinguishes active framebuffer traffic from LVDS serialization',()=>{
  const result=analyze();assert.equal(result.calculations.hostRawBytesPerSecond,125000000);
  const [p720,p1080]=result.calculations.modes;
  assert.equal(p720.id,'720p60');assert.equal(p720.frameBytes,3686400);assert.equal(p720.scanoutBytesPerSecond,221184000);assert.equal(p720.pixelClockMHz,74.25);
  assert.equal(p720.singleLinkMbps,519.75);assert.equal(p720.dualLinkMbps,259.875);assert.equal(p720.hostRawCeilingExceeded,true);assert.equal(p720.singleLinkExceedsLvdsLimit,false);assert.equal(p720.dualLinkExceedsLvdsLimit,false);
  assert.equal(p1080.id,'1080p60');assert.equal(p1080.frameBytes,8294400);assert.equal(p1080.scanoutBytesPerSecond,497664000);assert.equal(p1080.pixelClockMHz,148.5);
  assert.equal(p1080.singleLinkMbps,1039.5);assert.equal(p1080.dualLinkMbps,519.75);assert.equal(p1080.hostRawCeilingExceeded,true);assert.equal(p1080.singleLinkExceedsLvdsLimit,true);assert.equal(p1080.dualLinkExceedsLvdsLimit,false);
  assert.ok(p720.hostRawFrameRateCeiling<60);assert.ok(p1080.hostRawFrameRateCeiling<60);
  for(const mode of result.calculations.modes)assert.equal(mode.measuredScanoutBytesPerSecond,null);
});

test('parallel DDIO studies account for both directions without locking clocks or achieved throughput',()=>{
  const candidates=analyze().calculations.linkCandidates;assert.equal(candidates.length,2);
  for(const [index,width,dataPins,bytesPerCycle,remaining,withHost] of [[0,16,32,4,44,32],[1,32,64,8,12,0]]){
    const candidate=candidates[index];assert.equal(candidate.widthPerDirection,width);assert.equal(candidate.ddioDataPinsPerChip,dataPins);assert.equal(candidate.bytesPerClockPerDirection,bytesPerCycle);
    assert.equal(candidate.remainingConservativeDdioAfterData,remaining);assert.equal(candidate.rgmiiPhysicalPinsBudget,12);assert.equal(candidate.remainingConservativeDdioAfterDataAndRgmii,withHost);
    assert.equal(candidate.clockMHz,null);assert.equal(candidate.rawBytesPerSecond,null);
  }
});

test('native LVDS lane candidates state source ceilings while keeping operating rates and extra clock resources unknown',()=>{
  const candidates=analyze().calculations.serializedLinkCandidates;assert.equal(candidates.length,3);
  for(const [i,lanes,rawBytesPerSecond] of [[0,4,400000000],[1,8,800000000],[2,16,1600000000]]){
    const candidate=candidates[i];assert.equal(candidate.lanesPerDirection,lanes);assert.equal(candidate.lvdsTxPairsForData,lanes);assert.equal(candidate.lvdsRxPairsForData,lanes);
    assert.equal(candidate.sourceLaneCeilingMbps,800);assert.equal(candidate.theoreticalRawBytesPerSecond,rawBytesPerSecond);assert.equal(candidate.achievedLaneMbps,null);assert.equal(candidate.achievedBytesPerSecond,null);assert.equal(candidate.clockPairs,null);
  }
});

test('both 128 MiB candidate memories remain independent, with theoretical bandwidth separate from measurements',()=>{
  const memory=analyze().calculations.memory;assert.equal(memory.perChipBytes,134217728);assert.equal(memory.perChipMiB,128);assert.equal(memory.candidateRawBytesPerSecond,3200000000);
  assert.equal(memory.measuredBytesPerSecond,null);assert.equal(memory.sharedAddressSpace,false);assert.equal(memory.combinedBytesAreIndependentPools,true);
});

test('documented exact-part supply, clock, lifetime and display constraints remain separate from implementation proof',()=>{
  const constraints=new Map(record.documentedConstraints.map(constraint=>[constraint.id,constraint]));assert.equal(constraints.size,5);
  assert.deepEqual(constraints.get('DC01').value,{nominalV:1.2,minV:1.15,maxV:1.25});assert.ok(constraints.get('DC01').statement.includes('I4L'));assert.ok(constraints.get('DC01').statement.includes('not the selected part'));
  assert.deepEqual(constraints.get('DC02').value,{vdd1MinV:1.7,vdd1MaxV:1.95,vdd2CaQMinV:1.14,vdd2CaQMaxV:1.3});
  assert.deepEqual(constraints.get('DC03').value,{pll:'PLL_BR0',output:'CLKOUT0'});assert.ok(constraints.get('DC03').statement.includes('No primary ball is assigned'));
  assert.deepEqual(constraints.get('DC04').value,{preliminaryUncontrolledPowerOffLimit:400});assert.equal(constraints.get('DC04').stage,'DOCUMENTED_CAPABILITY_REQUIRES_VENDOR_CONFIRMATION');assert.ok(constraints.get('DC04').statement.includes('preliminary'));
  assert.deepEqual(constraints.get('DC05').value,{referenceTxPairs:11,candidate8bitTxPairs:9});assert.ok(constraints.get('DC05').statement.includes('candidate only'));
  for(const constraint of constraints.values()){assert.equal(constraint.measured,null);assert.ok(constraint.sourceIds.length);assert.ok(constraint.gateIds.length);}
  const result=analyze();assert.equal(result.fabrication,'NO-GO');assert.ok(result.gates.every(gate=>gate.state==='OPEN'));
});

test('documented constraints reject fabricated measurements, EDA approval and missing source or gate links',()=>{
  for(const mutate of [
    value=>value.documentedConstraints[0].measured=1.2,
    value=>value.documentedConstraints[0].measured={status:'PASS'},
    value=>delete value.documentedConstraints[0].measured,
    value=>value.documentedConstraints[0].stage='EDA_VERIFIED',
    value=>value.documentedConstraints[0].sourceIds=['INVENTED-SOURCE'],
    value=>value.documentedConstraints[0].sourceIds=[],
    value=>delete value.documentedConstraints[0].sourceIds,
    value=>value.documentedConstraints[0].gateIds=['G99'],
    value=>value.documentedConstraints[0].gateIds=[],
    value=>delete value.documentedConstraints[0].gateIds
  ])rejectRecord(mutate);
});

test('successful source review retains NO-GO and every hardware gate OPEN',()=>{
  const result=analyze();assert.equal(result.status,'SOURCE_REVIEW_ONLY');assert.equal(result.fabrication,'NO-GO');assert.equal(result.gates.length,11);
  assert.deepEqual(result.gates.map(gate=>[gate.id,gate.state]),Array.from({length:11},(_,i)=>['G'+String(i+1).padStart(2,'0'),'OPEN']));
  assert.ok(record.experiments.every(experiment=>experiment.state==='OPEN'));
  assert.ok(!Object.hasOwn(result,'assignments'));assert.ok(!Object.hasOwn(result.calculations,'assignments'));
  const ids=new Set(record.sources.map(source=>source.id)),gateIds=new Set(record.gates.map(gate=>gate.id));
  for(const finding of result.findings){assert.ok(finding.sourceIds.length);assert.ok(finding.sourceIds.every(id=>ids.has(id)),finding.id);assert.ok(finding.gateIds.every(id=>gateIds.has(id)),finding.id);}
});

test('unsupported architecture stage, fabrication release, gate completion and duplicate gates are rejected',()=>{
  for(const mutate of [value=>value.stage='EDA_VERIFIED',value=>value.fabrication='GO',value=>value.gateStatus='PASS',value=>value.gates[0].state='PASS',value=>value.gates[10].id='G01',value=>value.gates.pop()])rejectRecord(mutate);
});

test('decisions require legitimate source and gate references with distinct IDs and conditional states',()=>{
  for(const mutate of [value=>value.decisions[0].sourceIds=['INVENTED-SOURCE'],value=>value.decisions[0].sourceIds=[],value=>value.decisions[0].gateIds=['G99'],value=>value.decisions[0].state='PASS',value=>value.decisions[1].id=value.decisions[0].id,value=>value.sources[1].id=value.sources[0].id])rejectRecord(mutate);
  for(const field of ['id','title','version','locator'])rejectRecord(value=>delete value.sources[0][field]);
});

test('experiments cannot be completed by source arithmetic and require artifact, acceptance and stop contracts',()=>{
  for(const mutate of [value=>value.experiments[0].state='COMPLETE',value=>value.experiments[1].id=value.experiments[0].id,value=>value.experiments[0].requiredArtifacts=[],value=>value.experiments[0].acceptance=[],value=>value.experiments[0].stopConditions=[],value=>value.experiments[0].gateIds=['G99']])rejectRecord(mutate);
});

test('wrong workbook hash, package sheet, incomplete rows and duplicate balls are rejected',()=>{
  for(const mutate of [value=>value.source.sha256='0'.repeat(64),value=>value.source.sheet='T120F576',value=>value.rows.pop(),value=>value.rows[1].ball=value.rows[0].ball,value=>delete value.rows[0].clockRegion,value=>value.rows[0].ball='INVENTED_BALL'])rejectFacts(mutate);
});

test('source annotations cannot contain fake electrical nets or inferred DDIO capability',()=>{
  for(const mutate of [value=>value.rows[0].net='INVENTED_ARC1_NET',value=>value.rows[0].assignedNet='INVENTED_ARC1_NET',value=>value.rows[0].ddio='Maybe',value=>value.rows.find(row=>row.ball==='R12').ddio='Yes'])rejectFacts(mutate);
  rejectFacts(value=>{value.rows.find(row=>row.ball==='R12').ddio='Yes';value.rows.find(row=>row.ball==='M15').ddio='';},/DDIO/);
});

test('display arithmetic rejects nonfinite inputs, invalid totals and absent source references',()=>{
  for(const invalid of [NaN,Infinity,-Infinity,0,-1,'60',null]){
    const value=clone(record);value.calculationInputs.modes[0].fps=invalid;assert.throws(()=>analyze(value));
  }
  for(const mutate of [value=>value.calculationInputs.modes[0].totalWidth=1,value=>value.calculationInputs.modes[0].sourceIds=['INVENTED-SOURCE'],value=>value.calculationInputs.modes=[]])rejectRecord(mutate);
  rejectRecord(value=>{Object.assign(value.calculationInputs.modes[0],{width:1e308,totalWidth:1e308,height:1e308,totalHeight:1e308});});
  rejectRecord(value=>{Object.assign(value.calculationInputs.modes[0],{width:1e-308,height:1e-308});});
});

test('unmeasured interface rates, undocumented width/lane assumptions and changed memory goals are rejected',()=>{
  for(const mutate of [value=>value.calculationInputs.parallelClockMHz=100,value=>value.calculationInputs.achievedLinkBytesPerSecond=100000000,value=>value.calculationInputs.parallelWidthsPerDirection=[64],value=>value.calculationInputs.serializedLanesPerDirection=[32],value=>value.calculationInputs.hostTargetBitsPerSecond=2000000000,value=>value.calculationInputs.lvdsDocumentedLaneCeilingMbps=1200,value=>value.calculationInputs.fpgaMemoryBits=2147483648])rejectRecord(mutate);
});

test('frozen source records and resource facts remain immutable after analysis',()=>{
  const frozenRecord=freeze(clone(record)),frozenFacts=freeze(clone(facts));const beforeRecord=JSON.stringify(frozenRecord),beforeFacts=JSON.stringify(frozenFacts);
  const result=analyze(frozenRecord,frozenFacts);result.gates[0].state='mutated-result-only';
  assert.equal(JSON.stringify(frozenRecord),beforeRecord);assert.equal(JSON.stringify(frozenFacts),beforeFacts);
});

function uiHarness({recordValue=activeRecord,factsValue=facts,analyzer=activeArchitecture,failFetch=false}={}){
  const attributes=new Map(),requests=[];
  const container={innerHTML:'',setAttribute(key,value){attributes.set(key,value);},querySelector(){return null;}};
  const context=vm.createContext({URL,console,ARC1Architecture:analyzer,document:{querySelector(selector){return selector==='#architectureReview'?container:null;}},fetch:async url=>{
    requests.push(url);return {ok:!failFetch,status:failFetch?404:200,json:async()=>clone(String(url).endsWith('/architecture.json')?recordValue:factsValue)};
  }});
  vm.runInContext(read('architecture-ui.js'),context,{filename:'architecture-ui.js'});
  return {ui:context.ARC1ArchitectureUI,container,attributes,requests,async mount(){context.ARC1ArchitectureUI.mount();await new Promise(resolve=>setImmediate(resolve));}};
}

test('actual architecture UI module renders calculated values, conditional decisions, sources and all OPEN gates',async()=>{
  const env=uiHarness();assert.ok(env.ui.panel().includes('Architecture viability review'));await env.mount();
  assert.equal(env.requests.length,2);assert.equal(env.attributes.get('aria-busy'),'false');
  const html=env.container.innerHTML;
  for(const text of ['SOURCE_REVIEW_ONLY','NO-GO','221.184 MB/s','497.664 MB/s','74.25 MHz','148.5 MHz','1,039.5 Mbit/s','519.75 Mbit/s','DDIO pins per F484 chip','Native LVDS A ↔ B lane studies','UNKNOWN','Conditional architecture decisions','Required archived artifacts','Manufacturer sources and access limits'])assert.ok(html.includes(text),text);
  for(let i=1;i<=14;i++)assert.ok(html.includes('G'+String(i).padStart(2,'0')+' · OPEN'));
  for(const text of ['Documented constraints requiring implementation proof','Selected I4 FPGA supply class','LPDDR2 separate supply roles','Uncontrolled power-off lifetime limit','400 uncontrolled power-off sequences','DOCUMENTED_CAPABILITY_REQUIRES_VENDOR_CONFIRMATION'])assert.ok(html.includes(text),text);
  assert.equal((html.match(/Measured: UNKNOWN/g)||[]).length,activeRecord.documentedConstraints.length,'Documented constraint values must not render as measurements');
  assert.ok(html.includes('does not write pin assignments'));assert.ok(!html.includes('· PASS'));
  const again=env.ui.panel();assert.ok(again.includes('SOURCE_REVIEW_ONLY'));env.ui.mount();assert.equal(env.requests.length,2,'Remount uses the loaded read-only review');
});

test('architecture UI escapes source text and excludes unsafe external link protocols',async()=>{
  const value=clone(activeRecord);value.sources[0].url='javascript:alert(1)';value.sources[0].title='<img src=x onerror=alert(1)>';
  value.documentedConstraints[0].statement='<script>UNTRUSTED_CONSTRAINT_TEXT</script>';value.documentedConstraints[0].value='</p><script>UNTRUSTED_SOURCE_VALUE</script>';
  const env=uiHarness({recordValue:value});await env.mount();const html=env.container.innerHTML;
  assert.ok(html.includes('&lt;img src=x onerror=alert(1)&gt;'));assert.ok(!html.includes('href="javascript:'));assert.ok(!html.includes('<img src=x'));assert.ok(html.includes('rel="noopener noreferrer"'));
  assert.ok(html.includes('&lt;script&gt;UNTRUSTED_CONSTRAINT_TEXT&lt;/script&gt;'));assert.ok(html.includes('&lt;/p&gt;&lt;script&gt;UNTRUSTED_SOURCE_VALUE&lt;/script&gt;'));assert.ok(!html.includes('<script>'));
});

test('architecture UI reports missing bundled source data without displaying an approved review',async()=>{
  const env=uiHarness({failFetch:true});await env.mount();assert.ok(env.container.innerHTML.includes('Architecture review unavailable'));assert.ok(env.container.innerHTML.includes('HTTP 404'));assert.ok(!env.container.innerHTML.includes('· PASS'));
});

test('architecture UI rejects an analyzer response that claims a closed hardware gate',async()=>{
  const analyzer={analyze(){return {status:'SOURCE_REVIEW_ONLY',gates:[{id:'G01',state:'PASS'}]};}};
  const env=uiHarness({analyzer});await env.mount();assert.ok(env.container.innerHTML.includes('Architecture review unavailable'));assert.ok(env.container.innerHTML.includes('every gate OPEN'));assert.ok(!env.container.innerHTML.includes('G01 · PASS'));
});

test('actual House navigation mounts the review in Systems and Lab while retaining six departments',async()=>{
  const handlers={},elements={},storage=new Map();
  function element(selector){return elements[selector]||(elements[selector]={innerHTML:'',textContent:'',hidden:false,setAttribute(){},removeAttribute(){},focus(){},scrollIntoView(){},querySelector(){return null;},classList:{toggle(){}}});}
  const document={querySelector(selector){if(selector==='#architectureReview'&&!element('#mainContent').innerHTML.includes('id="architectureReview"'))return null;return element(selector);},querySelectorAll(){return [];},addEventListener(event,handler){handlers[event]=handler;}};
  const box={document,URL,console,setTimeout,clearTimeout,location:{hash:'#systems',href:'https://arc1.invalid/arc1/index.html',protocol:'https:'},history:{replaceState(){}},localStorage:{getItem(key){return storage.get(key)||null;},setItem(key,value){storage.set(key,value);}},navigator:{},alert(){},addEventListener(){},scrollTo(){},fetch:async url=>{
    const value=String(url).includes('spreadsheetfacts.json')?facts:String(url).includes('/architecture.json')?activeRecord:String(url).includes('roadmap.json')?JSON.parse(read('tasks/roadmap.json')):JSON.parse(read('pins.json'));
    return {ok:true,status:200,json:async()=>clone(value)};
  }};
  box.window=box;const context=vm.createContext(box);
  for(const script of ['architecture.js','r23-architecture.js','architecture-ui.js','viewer.js','house.js'])vm.runInContext(read(script),context,{filename:script});
  await new Promise(resolve=>setImmediate(resolve));assert.ok(element('#mainContent').innerHTML.includes('Physical systems'));assert.ok(element('#architectureReview').innerHTML.includes('SOURCE_REVIEW_ONLY'));assert.ok(element('#pinResults').innerHTML.includes('physical ball'));
  handlers.click({target:{closest(selector){return selector==='[data-viewer]'?null:{dataset:{page:'lab'}};}}});
  assert.ok(element('#mainContent').innerHTML.includes('Architecture viability review'));assert.ok(element('#architectureReview').innerHTML.includes('G14 · OPEN'));
  assert.equal(storage.size,0,'Read-only navigation must not write local notes or status');
  const nav=read('index.html').match(/<nav class="house-nav"[\s\S]*?<\/nav>/)[0];assert.equal((nav.match(/data-page=/g)||[]).length,6);
  for(const page of ['home','viewer','systems','lab','manual','archive'])assert.ok(nav.includes('data-page="'+page+'"'));
});
