/* R23 software regression vectors. Actual authority/source files are retained;
 * synthetic declarations and attachments below are not hardware evidence. */
const {test,before}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const {pathToFileURL}=require('node:url');
const {createHash,webcrypto}=require('node:crypto');
const root=path.resolve(__dirname,'..');
const clone=value=>JSON.parse(JSON.stringify(value));
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const bytes=value=>new TextEncoder().encode(value);
let architecture,evidence,record,facts,template;
before(async()=>{
  if(!globalThis.crypto?.subtle)globalThis.crypto=webcrypto;
  for(const script of ['architecture.js','r23-architecture.js','evidence.js','r23-evidence.js'])await import(pathToFileURL(path.join(root,script)).href);
  architecture=globalThis.ARC1R23Architecture;evidence=globalThis.ARC1R23Evidence;
  record=JSON.parse(fs.readFileSync(path.join(root,'engineering/r23/architecture.json'),'utf8'));
  facts=JSON.parse(fs.readFileSync(path.join(root,'engineering/architecture/spreadsheetfacts.json'),'utf8'));
  template=JSON.parse(fs.readFileSync(path.join(root,'engineering/r23/R23_SYSTEM_EVIDENCE_TEMPLATE.json'),'utf8'));
});
function openGates(result){assert.deepEqual(result.gates,Array.from({length:14},(_,i)=>({id:'G'+String(i+1).padStart(2,'0'),status:'OPEN'})));}
function codes(result,field='conflicts'){return result[field].map(note=>note.code);}
function has(result,code,field='conflicts'){assert.ok(codes(result,field).includes(code),code+': '+JSON.stringify(result[field]));}
function report(){return clone(template);}
function withoutCapacityConflict(){const value=report();const bt=value.memoryPools.find(pool=>pool.device==='BT820B');bt.physicalCandidateBits=null;bt.part=null;return value;}
function validate(value){return evidence.validate(value);}
async function intake(value,extra={}){const text=JSON.stringify(value);return evidence.intake({text,filename:'SYNTHETIC-R23-software-vector.json',...extra});}

test('current R23 authority preserves the actual full owner DOCX and its source hash',()=>{
  const authority=record.sources.find(source=>source.id==='R23-AUTHORITY');assert.ok(authority);
  const actual=fs.readFileSync(path.join(root,'engineering/r23/ARC1_R23_Handoff.docx'));
  assert.equal(authority.sha256,hash(actual));assert.ok(actual.length>0);
});

test('R23 selected installed memory and named physical candidate discrepancy are both preserved',()=>{
  const result=architecture.analyze(record,facts),memory=result.calculations.memoryPools;
  assert.equal(memory.targetInstalledMiB,384);assert.equal(memory.candidateInstalledMiB,448);
  assert.equal(result.fabrication,'NO-GO');assert.equal(result.gates.length,14);assert.ok(result.gates.every(gate=>gate.state==='OPEN'));
  assert.equal(memory.sharedAddressSpace,false);assert.equal(memory.measuredInstalledMiB,null);assert.equal(memory.pools.find(pool=>pool.device==='BT820B').capacityConflict,true);
});

test('R23 architecture retains three individually bounded NOR targets with actual image sizes unknown',()=>{
  const devices=architecture.analyze(record,facts).calculations.norDevices;assert.equal(devices.length,3);
  assert.deepEqual(devices.map(device=>device.id).sort(),['NOR-F133','NOR-T120-A','NOR-T120-B']);
  for(const device of devices){assert.equal(device.targetBytes,16777216);assert.equal(device.actualImageBytes,null);}
});

test('R23 BT video clock study exposes the unresolved 74.25 MHz synthesis constraint',()=>{
  const study=architecture.analyze(record,facts).calculations.videoClockStudy;
  assert.equal(study.requiredLinkMHz,74.25);assert.equal(study.documentedReachable,false);
  assert.equal(study.configurations.length,32);assert.equal(study.nearestDocumentedMHz,72);assert.equal(study.vendorApprovedAlternative,null);assert.equal(study.measuredClockMHz,null);
  const rates=[];for(const multiplier of [13,15])for(let divider=1;divider<=16;divider++)rates.push(38.4*multiplier/(2*divider));
  assert.equal(rates.length,32);assert.equal(rates.reduce((nearest,rate)=>Math.abs(rate-74.25)<Math.abs(nearest-74.25)?rate:nearest),72);
  assert.ok(rates.every(rate=>Math.abs(rate-74.25)>1e-9),'Documented integer-divider combinations cannot produce the needed clock');
});

test('global architecture dispatcher preserves historical R22 source review and routes current R23 authority',()=>{
  const historical=JSON.parse(fs.readFileSync(path.join(root,'engineering/architecture/architecture.json'),'utf8'));
  const legacy=globalThis.ARC1Architecture.analyze(historical,facts),active=globalThis.ARC1Architecture.analyze(record,facts);
  assert.equal(legacy.gates.length,11);assert.equal(active.gates.length,14);assert.equal(legacy.calculations.memory.perChipMiB,128);assert.equal(active.calculations.memoryPools.targetInstalledMiB,384);
});

test('R23 architecture cannot release hardware, close any gate or invent achieved performance',()=>{
  for(const mutate of [value=>value.fabrication='GO',value=>value.gateStatus='PASS',value=>value.gates[13].state='PASS',value=>value.gates.pop()]){
    const value=clone(record);mutate(value);assert.throws(()=>architecture.analyze(value,facts));
  }
  const result=architecture.analyze(record,facts);
  for(const candidate of result.calculations.linkCandidates){assert.equal(candidate.clockMHz,null);assert.equal(candidate.rawBytesPerSecond,null);}
  for(const mode of result.calculations.modes)assert.equal(mode.measuredScanoutBytesPerSecond,null);
});

test('current R23 documented constraints retain source/gate links and cannot claim measured or EDA proof',()=>{
  const sourceIds=new Set(record.sources.map(source=>source.id)),gateIds=new Set(record.gates.map(gate=>gate.id));assert.ok(record.documentedConstraints.length);
  for(const constraint of record.documentedConstraints){assert.equal(constraint.measured,null);assert.ok(['DOCUMENTED_CAPABILITY','DOCUMENTED_CAPABILITY_REQUIRES_VENDOR_CONFIRMATION'].includes(constraint.stage));assert.ok(constraint.sourceIds.length&&constraint.sourceIds.every(id=>sourceIds.has(id)));assert.ok(constraint.gateIds.length&&constraint.gateIds.every(id=>gateIds.has(id)));}
  for(const mutate of [constraint=>constraint.measured={status:'PASS'},constraint=>constraint.stage='EDA_VERIFIED',constraint=>constraint.sourceIds=['INVENTED_SOURCE'],constraint=>constraint.gateIds=['G99'],constraint=>constraint.sourceIds=[],constraint=>constraint.gateIds=[]]){
    const value=clone(record);mutate(value.documentedConstraints[0]);assert.throws(()=>architecture.analyze(value,facts));
  }
});

test('R23 architecture rejects nonfinite and overflowing or underflowing display arithmetic',()=>{
  for(const invalid of [NaN,Infinity,-Infinity,0,-1]){const value=clone(record);value.calculationInputs.modes[0].fps=invalid;assert.throws(()=>architecture.analyze(value,facts));}
  for(const dimensions of [{width:1e308,height:1e308,totalWidth:1e308,totalHeight:1e308},{width:1e-308,height:1e-308}]){
    const value=clone(record);Object.assign(value.calculationInputs.modes[0],dimensions);assert.throws(()=>architecture.analyze(value,facts));
  }
});

test('new R23 JSON schema remains separate from immutable legacy FPGA-pin intake',()=>{
  assert.notEqual(evidence.SCHEMA,'arc1-evidence-v1');assert.equal(evidence.parse(JSON.stringify(template)).ok,true);
  const legacy=JSON.parse(fs.readFileSync(path.join(root,'engineering/ARC1_EVIDENCE_TEMPLATE.json'),'utf8'));
  assert.equal(evidence.parse(JSON.stringify(legacy)).ok,false);
  assert.equal(evidence.parse('chip,ball,net\nT120-A,P4,SYNTHETIC\n').ok,false);
});

test('R23 parser rejects missing and undeclared fields instead of inventing component evidence',()=>{
  for(const field of ['schema','source','memoryPools','norDevices','gameStorage','video','signoffs']){const value=report();delete value[field];assert.equal(evidence.parse(JSON.stringify(value)).ok,false,field);}
  const extra=report();extra.assignedPcbGeometry={};assert.equal(evidence.parse(JSON.stringify(extra)).ok,false);
  const missing=report();delete missing.memoryPools[0].physicalCandidateBits;assert.equal(evidence.parse(JSON.stringify(missing)).ok,false);
});

test('selected 64 MiB BT pool versus 1 Gbit x16 candidate is a conflict, never silently reclassified',()=>{
  const value=report(),bt=value.memoryPools.find(pool=>pool.device==='BT820B');bt.physicalCandidateBits=1073741824;bt.part='AS4C64M16MD2A-25BIN';
  const result=validate(value);assert.equal(result.status,'CONFLICT');assert.deepEqual(result.parserErrors,[]);has(result,'MEMORY_GEOMETRY_CONFLICT');openGates(result);
  assert.equal(bt.selectedMiB,64);assert.equal(bt.physicalCandidateBits,1073741824);assert.ok(bt.part.includes('AS4C64M16'));
});

test('unknown physical candidate and measurement values remain unknown without changing selected pools',()=>{
  const value=withoutCapacityConflict(),result=validate(value);assert.equal(result.status,'UNKNOWN');assert.deepEqual(result.conflicts,[]);openGates(result);
  assert.deepEqual(value.memoryPools.map(pool=>[pool.device,pool.selectedMiB]),template.memoryPools.map(pool=>[pool.device,pool.selectedMiB]));
  assert.ok(result.unknowns.length);
});

test('known part organization cannot be disguised by omitted density, a false 512 Mbit claim or the wrong controller width',()=>{
  for(const physicalCandidateBits of [null,536870912]){
    const value=withoutCapacityConflict(),bt=value.memoryPools.find(pool=>pool.device==='BT820B');bt.part='AS4C64M16MD2A-25BIN';bt.physicalCandidateBits=physicalCandidateBits;
    const result=validate(value);has(result,'MEMORY_PART_CAPACITY_CONFLICT');openGates(result);
    if(physicalCandidateBits!==null)has(result,'MEMORY_PART_GEOMETRY_CONFLICT');
  }
  const value=withoutCapacityConflict();value.memoryPools.find(pool=>pool.device==='T120-A').part='AS4C64M16MD2A-25BIN';has(validate(value),'MEMORY_PART_WIDTH_CONFLICT');
});

test('wrong owner capacities and duplicate component declarations are semantic conflicts',()=>{
  for(const mutate of [
    value=>value.memoryPools[0].selectedMiB=128,
    value=>value.memoryPools[1].device='INVENTED_COMPONENT',
    value=>value.memoryPools.push(clone(value.memoryPools[0])),
    value=>value.norDevices[0].capacityBytes=33554432,
    value=>value.norDevices[0].owner='BT820B',
    value=>value.norDevices.push(clone(value.norDevices[0])),
    value=>value.gameStorage.technology='eMMC',
    value=>value.video.path=['T120-A','IT6263N','HDMI']
  ]){const value=withoutCapacityConflict();mutate(value);const result=validate(value);assert.equal(result.status,'CONFLICT');assert.deepEqual(result.parserErrors,[]);openGates(result);}
});

test('missing NOR geometry and genuine payload lengths do not become a fit or rollback guarantee',()=>{
  const result=validate(withoutCapacityConflict());assert.equal(result.status,'UNKNOWN');openGates(result);assert.ok(result.unknowns.length);
  has(result,'NOR_ERASE_GEOMETRY_UNKNOWN','unknowns');has(result,'NOR_METADATA_UNKNOWN','unknowns');has(result,'NOR_IMAGES_MISSING','unknowns');
  for(const nor of result.norDevices){assert.equal(nor.capacityDiagnostic.allocatedBytes,null);assert.equal(nor.capacityDiagnostic.remainingBytes,null);assert.equal(nor.capacityDiagnostic.geometryVerified,false);}
  for(const nor of template.norDevices){assert.equal(nor.capacityBytes,16777216);assert.equal(nor.eraseBlockBytes,null);assert.equal(nor.metadataBytes,null);assert.ok(nor.images.every(image=>image.loadableBytes===null));}
});

test('synthetic NOR rounding is only a declared lower bound and attached text size is not loadability proof',async()=>{
  const value=withoutCapacityConflict(),nor=value.norDevices[0],content=bytes('SYNTHETIC .hex TEXT VECTOR; NOT A GENERATED IMAGE'),digest=hash(content);
  // Deliberately hypothetical parser geometry; no flash SKU or hardware is selected.
  nor.eraseBlockBytes=4096;nor.metadataBytes=1;nor.images=[{role:'SYNTHETIC-rounding-vector',path:'synthetic/vector.hex',loadableBytes:4097,sha256:digest}];
  value.source.artifacts=[{path:'synthetic/vector.hex',sha256:digest,kind:'synthetic-software-test'}];
  const result=await intake(value,{attachments:[{name:'synthetic/vector.hex',bytes:content}]});assert.equal(result.status,'UNKNOWN');openGates(result);
  const diagnostic=result.norDevices[0].capacityDiagnostic;assert.equal(diagnostic.allocatedBytes,12288);assert.equal(diagnostic.remainingBytes,16777216-12288);assert.equal(diagnostic.geometryVerified,false);
  assert.equal(result.artifacts[0].status,'HASH_MATCH');has(result,'IMAGE_BYTES_NOT_LOADABILITY_PROOF','unknowns');has(result,'NOR_LAYOUT_UNVERIFIED','unknowns');
});

test('per-device NOR arithmetic rejects overflow rather than borrowing another flash device capacity',()=>{
  const value=withoutCapacityConflict(),nor=value.norDevices[0];nor.eraseBlockBytes=4096;nor.metadataBytes=4096;
  nor.images=[{role:'SYNTHETIC-golden',path:'synthetic/golden.bin',loadableBytes:12*1048576,sha256:null},{role:'SYNTHETIC-rollback',path:'synthetic/rollback.bin',loadableBytes:12*1048576,sha256:null}];
  const result=validate(value);assert.equal(result.status,'CONFLICT');assert.deepEqual(result.parserErrors,[]);openGates(result);
});

test('malformed negative, fractional and unsafe-integer capacity/length declarations are parser errors',()=>{
  for(const invalid of [-1,1.5,Number.MAX_SAFE_INTEGER+1,'16777216']){
    const value=withoutCapacityConflict();value.norDevices[0].capacityBytes=invalid;const result=validate(value);assert.equal(result.status,'PARSER_ERROR');assert.deepEqual(result.conflicts,[]);openGates(result);
  }
  for(const invalid of [-1,0.5]){const value=withoutCapacityConflict();value.norDevices[0].images=[{role:'SYNTHETIC',path:'synthetic/payload.bin',loadableBytes:invalid,sha256:null}];assert.equal(validate(value).status,'PARSER_ERROR');}
});

test('reported measurements and signoff claims never close the fourteen active gates',()=>{
  const value=withoutCapacityConflict();value.memoryPools[0].reportedMeasuredMiB=64;value.video.measuredFps=60;
  value.signoffs=Array.from({length:14},(_,i)=>({gate:'G'+String(i+1).padStart(2,'0'),status:'PASS',artifactSha256:null}));
  const result=validate(value);assert.equal(result.status,'CONFLICT');openGates(result);
});

test('R23 attachment hashing distinguishes byte identity, mismatch and missing evidence while preserving open gates',async()=>{
  const content=bytes('SYNTHETIC R23 SOFTWARE VECTOR - NOT HARDWARE PROOF\r\n'),digest=hash(content),value=withoutCapacityConflict();
  value.source.artifacts=[{path:'synthetic/source.txt',sha256:digest,kind:'synthetic-software-test'}];
  const matched=await intake(value,{attachments:[{name:'synthetic/source.txt',bytes:content}]});assert.equal(matched.artifacts[0].status,'HASH_MATCH');assert.equal(matched.artifacts[0].actualSha256,digest);openGates(matched);
  const claimed=clone(value);claimed.signoffs=Array.from({length:14},(_,i)=>({gate:'G'+String(i+1).padStart(2,'0'),status:'PASS',artifactSha256:digest}));
  const withClaims=await intake(claimed,{attachments:[{name:'synthetic/source.txt',bytes:content}]});assert.equal(withClaims.status,'CONFLICT');assert.equal(withClaims.artifacts[0].status,'HASH_MATCH');assert.equal(codes(withClaims).filter(code=>code==='SIGNOFF_NOT_SUPPORTED').length,14);openGates(withClaims);
  const mismatch=await intake(value,{attachments:[{name:'synthetic/source.txt',bytes:bytes('altered synthetic bytes')}]});assert.equal(mismatch.status,'CONFLICT');assert.equal(mismatch.artifacts[0].status,'MISMATCH');openGates(mismatch);
  const missing=await intake(value);assert.equal(missing.artifacts[0].status,'MISSING');assert.ok(missing.unknowns.length);openGates(missing);
});

test('R23 hashes preserve exact imported bytes and detect disagreement between bytes and supplied text',async()=>{
  const value=withoutCapacityConflict(),text='\uFEFF'+JSON.stringify(value,null,2).replaceAll('\n','\r\n'),raw=bytes(text);
  const result=await intake(value,{text,reportBytes:raw});assert.equal(result.input.sha256,hash(raw));assert.equal(result.input.raw,text);openGates(result);
  const mismatch=await intake(value,{reportBytes:bytes(JSON.stringify(value)+' ')});assert.equal(mismatch.status,'PARSER_ERROR');openGates(mismatch);
});

test('R23 software validation does not mutate selected authority, immutable source inventory or report declarations',async()=>{
  const originalRecord=JSON.stringify(record),originalFacts=JSON.stringify(facts),value=withoutCapacityConflict(),original=JSON.stringify(value);
  const pinsPath=path.join(root,'pins.json'),before=hash(fs.readFileSync(pinsPath));architecture.analyze(record,facts);await intake(value);
  assert.equal(JSON.stringify(record),originalRecord);assert.equal(JSON.stringify(facts),originalFacts);assert.equal(JSON.stringify(value),original);assert.equal(hash(fs.readFileSync(pinsPath)),before);
  assert.equal(before,globalThis.ARC1Evidence.PIN_HASH);
});

test('actual intake UI defaults to R23 JSON, exports all fourteen OPEN gates and does not fetch or mutate FPGA pins',async()=>{
  const nodes=new Map();let download=null,fetches=0;
  const element=selector=>{if(!nodes.has(selector))nodes.set(selector,{value:'',innerHTML:'',dataset:{},click(){},remove(){}});return nodes.get(selector);};
  const panel={innerHTML:'',querySelector:element,querySelectorAll(){return [];}};
  const box={TextEncoder,TextDecoder,Blob,crypto:webcrypto,console,setTimeout(){},URL:{createObjectURL(blob){download=blob;return 'blob:synthetic-r23-test';},revokeObjectURL(){}},document:{querySelector(){return panel;},createElement(){return element('download');},body:{append(){}}},fetch:async()=>{fetches++;throw Error('R23 component intake must not fetch FPGA inventory');}};
  const context=vm.createContext(box);for(const script of ['evidence.js','r23-evidence.js','evidence-ui.js'])vm.runInContext(fs.readFileSync(path.join(root,script),'utf8'),context,{filename:script});
  const api=context.ARC1EvidenceUI;panel.innerHTML=api.panel();api.mount();assert.ok(panel.innerHTML.includes('value="r23-json" selected'));
  const value=withoutCapacityConflict();value.source.project='<script>SYNTHETIC_SOURCE_TEXT</script>';const text=JSON.stringify(value),raw=Buffer.from(text);
  const file={name:'SYNTHETIC-R23-UI.json',size:raw.byteLength,arrayBuffer:async()=>raw.buffer.slice(raw.byteOffset,raw.byteOffset+raw.byteLength)};
  element('#evidenceReportFile').onchange({target:{files:[file]}});element('#evidenceForm').onsubmit({preventDefault(){}});
  for(let i=0;i<200&&!panel.innerHTML.includes('Intake result:');i++)await new Promise(resolve=>setTimeout(resolve,5));
  assert.ok(panel.innerHTML.includes('Intake result: UNKNOWN'));assert.ok(panel.innerHTML.includes('&lt;script&gt;SYNTHETIC_SOURCE_TEXT'));assert.ok(!panel.innerHTML.includes('<script>SYNTHETIC_SOURCE_TEXT'));
  element('#evidenceExport').onclick();assert.ok(download);const output=JSON.parse(await download.text());openGates(output);assert.equal(output.input.raw,text);assert.equal(output.input.format,'r23-json');assert.equal(output.input.sha256,hash(raw));assert.equal(output.norDevices.length,3);assert.equal(fetches,0);
});
