const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const handler={};const elements={};
function el(n){return elements[n]||(elements[n]={innerHTML:'',textContent:'',hidden:false,classList:{toggle(){}},setAttribute(){},removeAttribute(){},focus(){},scrollIntoView(){}})}
const doc={querySelector:el,querySelectorAll(){return []},addEventListener(k,cb){handler[k]=cb}};
const pins=JSON.parse(fs.readFileSync(path.join(root,'pins.json'),'utf8'));
const roadmap=JSON.parse(fs.readFileSync(path.join(root,'tasks/roadmap.json'),'utf8'));
const local=new Map();
const box={document:doc,location:{hash:'#home',href:'https://example.invalid/arc1/index.html',protocol:'https:'},history:{replaceState(){}},localStorage:{getItem(k){return local.get(k)||null},setItem(k,v){local.set(k,v)}},navigator:{},fetch:async(url)=>({ok:true,json:async()=>String(url).includes('roadmap.json')?roadmap:pins}),alert(){},setTimeout,clearTimeout,console};
box.window=box;box.addEventListener=()=>{};box.scrollTo=()=>{};
const context=vm.createContext(box);
for(const f of ['viewer.js','house.js'])vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),context,{filename:f});
assert(el('#mainContent').innerHTML.includes('ARC-1'));
assert(el('#mainContent').innerHTML.includes('Tabletop dimensions and physical placement')); 
function click(dataset){handler.click({target:{closest(selector){if(selector==='[data-viewer]')return dataset.viewer?{dataset}:null;if(selector==='[data-page],[data-detail],[data-chapter],[data-action]')return {dataset};return null;}}});}
click({page:'viewer'});
assert(el('#mainContent').innerHTML.includes('ARC-1 Tabletop Studio'));
assert(el('#mainContent').innerHTML.includes('No physical model loaded'));
assert((el('#mainContent').innerHTML.match(/class="viewer-layer /g)||[]).length===5);
assert(el('#mainContent').innerHTML.includes('<circle'));
click({viewer:'tab',value:'pcb'});
assert((el('#mainContent').innerHTML.match(/class="viewer-layer /g)||[]).length===15);
click({viewer:'solo',value:'gpua'});
assert(el('#mainContent').innerHTML.includes('<h2>T120-A permanent GPU</h2>'));
assert(el('#mainContent').innerHTML.includes('1/15 selected'));
click({viewer:'all'});assert(el('#mainContent').innerHTML.includes('15/15 selected'));
click({viewer:'none'});assert(el('#mainContent').innerHTML.includes('0/15 selected'));
click({viewer:'tab',value:'case'});assert((el('#mainContent').innerHTML.match(/class="viewer-layer /g)||[]).length===4);
click({viewer:'tab',value:'face'});assert((el('#mainContent').innerHTML.match(/class="viewer-layer /g)||[]).length===3);
click({viewer:'tab',value:'firmware'});assert((el('#mainContent').innerHTML.match(/class="viewer-layer /g)||[]).length===6);
click({viewer:'tab',value:'tools'});assert((el('#mainContent').innerHTML.match(/class="viewer-layer /g)||[]).length===4);
for(const page of ['lab','manual','archive','home']){click({page});assert(el('#mainContent').innerHTML.length>800,page)}
click({page:'handoff'});
assert(el('#mainContent').innerHTML.includes('Continue ARC-1 development'));
assert(el('#mainContent').innerHTML.includes('Export project snapshot JSON'));
click({page:'systems'});
new Promise(r=>setTimeout(r,100)).then(async()=>{
 assert(el('#pinResults').innerHTML.includes('physical ball'));
 assert(el('#mainContent').innerHTML.includes('FPGA pin explorer'));
 click({page:'handoff'});
 await new Promise(r=>setTimeout(r,0));
 assert(el('#devTasks').innerHTML.includes('DEV-002'),'Handoff should load live task records');
 assert(pins.length===968,'Pin inventory must contain 968 balls');
 for(const f of ['index.html','manifest.webmanifest','house.js','viewer.js','house.css','viewer.css','sw.js']){
   assert(fs.existsSync(path.join(root,f)))
 }
 console.log(`PASS: 6 viewer tabs; solo/all/none; nav; developer handoff; ${roadmap.tasks.length} task records; 968 package balls; prohibited symbol`);
}).catch(e=>{console.error(e);process.exit(1)});
