# ARC-1 Project House — R23 / Pass 05

Existing ARC-1 engineering PWA, updated to the full R23 owner handoff. **Hardware release NO-GO; G01–G14 OPEN.**

1. Extract the complete ZIP and run `npm test` with Node 18+; no npm installation is needed.
2. Run `npm run serve` and open `http://localhost:8000`.
3. Read `CLAUDE.md`, the [full R23 handoff](engineering/r23/ARC1_R23_Handoff.docx), [decision record](engineering/r23/R23_ARCHITECTURE_DECISION_RECORD.md) and [migration record](engineering/r23/R23_MIGRATION_RECORD.md).
4. Open Systems or Lab for source-backed architecture calculations, then Lab→Efinity evidence intake for current R23 system JSON or historical A/B pin JSON/CSV. Both are declared interchange formats, not native vendor exports.

The PWA preserves six departments, six Viewer tabs, local notes and unmodeled geometry. For installable mobile PWA use, serve the complete folder over HTTPS. ZIP/file mode cannot install the service worker.

R23 selects F133-B 64 MiB, T120-A 128 MiB, T120-B 128 MiB and BT820B 64 MiB, four independent pools totaling 384 MiB. The named BT candidate is 128 MiB; its installed total would be 448 MiB. Three dedicated 16 MiB NORs serve CPU/A/B; separate SPI NAND games has model/capacity OPEN. Video target is A→BT820B composition→IT6263N candidate→external HDMI. No eMMC, T20 or internal LCD is selected.

Immediate qualification issues are the BT exact 64 MiB part/init and standard 74.25 MHz clock gap. Manufacturer alternate-blanking HDMI examples offer a candidate test path, but exact frame rate, ITE mappings and monitor acceptance remain unverified. Complete FPGA pin/bank/DDR/clock allocation, actual image fit, NAND/BSP support, independent recovery and concurrent power/thermal behavior remain OPEN.

The [R23 test report](engineering/r23/R23_TEST_REPORT.md) records actual checks and limitations. The [change record](engineering/r23/R23_CHANGELOG.md) lists exact changes and hashes. [Unsent vendor questions](engineering/r23/R23_VENDOR_QUESTIONS.md) identify the next source artifacts. Historical R22 records remain accessible in Archive and `engineering/history/r22/`.

`npm run architecture:check` prints source/arithmetic diagnostics. `python scripts/verify-package-facts.py` independently compares all 484 F484 rows with original workbook columns A–H. Software tests, synthetic DOM/service-worker execution and hashes do not establish hardware or real-browser success.
