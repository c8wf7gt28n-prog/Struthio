# ARC-1 R22 recovery, storage and power architecture review

Review date: 2026-10-12. Status: **PROPOSED IMPLEMENTATION; hardware gates OPEN; fabrication NO-GO.** Read with the R22 work order and evidence policy. This review preserves the F133-B, two T120F484I4 devices, two separate 128 MiB LPDDR2 candidates, protected system storage and physically separate rewritable game storage. It assigns control ownership and falsifiable acceptance criteria; it does not assign package balls, PCB nets, flash capacity, regulators or current budgets.

## Recommended reference strategy

Use the F133 as the normal configuration loader for **each** FPGA, with independent passive configuration paths and individual service JTAG access. A board supervisor/sequencer/watchdog outside both FPGA user designs enforces rail-good, reset and isolation conditions. Its exact implementation remains OPEN; an additional MCU is not silently selected. F133 failure must leave the board in a safe state and permit external service recovery.

Keep system/recovery NOR under the F133 boot domain. Keep game storage on a distinct device and compatible host interface. Protected system storage holds the F133 rescue software and validated golden A/B images. Normal B personalities originate in game storage, are checked by the F133, and are loaded directly to B. A user RTL is never the sole gateway to either FPGA configuration or external debug.

The independent SPI rescue interface to A user logic is useful for diagnostics when A is configured. It cannot configure an empty or broken A user design. Therefore it supplements the passive configuration and JTAG paths; it does not replace them. No FPGA should become a bus master of the F133 boot NOR. Avoid using A as the configuration master in an A-to-B configuration daisy chain. Separate device select, reset, status and service paths must allow A recovery with B absent, held in reset or unpowered.

## Manufacturer constraints actually reviewed

The registry [recovery_sources.json](recovery_sources.json) contains versioned primary-source URLs, page locations and hashes of browser extraction records. Original PDF byte hashes remain null; extracted-text hashes are not original-source hashes. Vendor PDFs and IP are not redistributed.

| Constraint | Source location | Design consequence |
| --- | --- | --- |
| Selected I4 core and PLL analog supply: 1.15–1.25 V, nominal 1.2 V. The 1.1 V table is for I4L/C4L. LPDDR2 VCCIO_DDR: 1.14–1.3 V, nominal 1.2 V. | REC-S01, printed pp52–53, tables62–63 | Do not apply the low-voltage grade to T120F484I4. Match the DDR candidate's separate supply requirements. |
| VCC/VCCA stable before VCCIO; keep CRESET_N low during power-up. | REC-S01, p48 | Sequence and supervise actual rails. |
| Reset pulse minimum 320 ns; passive/JTAG data delay minimum 1.2 µs. tUSER minimum 25 µs under stated load, maximum derived separately. | REC-S01, pp64–68, tables92–96 | Use worst-case board timing, not CDONE alone. |
| I4 passive x1 maximum 12.5 MHz; JTAG maximum 25 MHz; inactive alternative programming interface. | REC-S01, pp66–67 | Verify host waveforms and mode ownership. |
| External loading is supported; configuration pins/banks have mode restrictions; no drive before FPGA power; supervisor or processor can control CRESET_N. | REC-S02, pp5–10, 41–45 | Reserve controls and isolate every cross-domain path. |
| Development kit demonstrates passive SPI and JTAG; its guide explicitly directs new boards to datasheet sequencing and recommends CRESET_N supervision. | REC-S03, pp8–10 | Reuse the strategy, not its F576 nets, supply sizing or clock choices. |

Use current authorized datasheet/errata and AN006 before schematic review. These observations establish documented capability only. In particular, no active-mode multi-image behavior proves that a syntactically valid but defective game image can recover itself.

## Ownership that must be enforceable electrically

| Resource | Owner and allowed authority | Required independent enforcement |
| --- | --- | --- |
| A CRESET_N/configuration | F133 normal loader; supervisor and service recovery can force isolation/reset | B has no connection or programmable authority to reset A, select A's image, disable A clock or change protection. |
| B CRESET_N/configuration | F133 loader; supervisor/service can force B reset | A may request recovery, but loading and physical isolation remain possible without A user RTL. |
| A and B JTAG | External service owner through individual access paths | No required traversal through B to reach A. Disable other programming drivers during ownership handover. |
| Configuration status | Independent per-device observation | Separate A/B CDONE and error observations; do not merge statuses into an apparent two-chip success. |
| System NOR writes | Deliberate service/update transaction under F133 boot policy | Select a device and circuitry with demonstrated protection semantics; a nominal WP pin or software read-only flag alone is insufficient. B cannot clear protection. |
| Rewritable game storage | F133 storage stack | B receives validated payloads and bounded jobs, never host boot-storage ownership. |
| Cross-domain output enables | Supervisor/guard controls backed by rail-good and permitted state | Default disabled during reset, power loss, loading and fault. B user logic cannot override a disabled guard. |
| Reference clocks | Stable oscillator/clock distribution independent of B user logic | Loss, disable or reconfiguration of B does not remove F133/A recovery clocks or display reference. Exact frequencies/PLL allocation remain OPEN. |

As a proposed interlock, `ALLOW_B_TRAFFIC = F133_AUTHORIZED && A_READY && B_RAILS_GOOD && B_CONFIGURATION_READY && B_PROTOCOL_READY && !FAULT`. Missing signals force isolation. A status bit emitted by B alone does not satisfy the condition. If the selected fast link cannot accommodate a hardware disconnect/guard without losing timing, keep the B I/O domain powered during reconfiguration and still prove reset-state contention safety. Independent B power-off remains forbidden until an electrically verified isolation design exists; a software flag cannot make power-off safe.

The release design must tolerate a B configuration that drives an assigned output incorrectly. Directional physical links reduce shared-driver contention, but they do not protect the A receive path from arbitrary packets or the common supply from B fault current. Specify electrical signal direction/termination, powered-off leakage, default pulls and guard behavior for every A/B, configuration, debug, clock and status net. Choose fault protection/rail partitioning so B faults do not brown out F133/A within the reviewed fault envelope. No regulator or bus-switch family is selected by this review.

## Boot and B reconfiguration sequence

1. On cold boot, independent supervision holds FPGA configuration resets and cross-domain guards safe until the exact rail sequence, ramp and timing conditions are met. Host boot must succeed with both FPGAs unconfigured. Service can take ownership with host firmware unavailable.
2. F133 boots protected rescue-capable software, records reset cause and checks image manifests. It programs A through A's dedicated configuration path, observes configuration/error status, waits the board-qualified user-mode interval, starts DDR A and validates A identity/ABI and recovery display. B remains isolated.
3. For a game, F133 verifies B target device, payload hash, compatibility, physical-interface profile and policy before permitting loading. Hashes detect accidental corruption; a separate signature/trust policy is required if the system will accept untrusted downloaded images. Arbitrary unconstrained B bitstreams cannot be claimed electrically safe.
4. Before replacing B, stop new jobs, drain or timeout existing transactions, revoke every A memory lease granted to B, increment the protocol generation, and capture diagnostics. A scans out from owned buffers and continues its bounded service path; B absence cannot stall A's DDR arbiter indefinitely.
5. Assert physical isolation, hold B configuration reset, select the correct programming owner/mode and load B directly. Keep A and F133 clocks/reset untouched. After configuration, observe per-device status and the qualified user interval; then reset/initialize/calibrate DDR B. CDONE alone does not authorize a workload.
6. Verify B identity, ABI, allowed interface profile, generation, DDR self-test and heartbeat. Grant bounded leases and enable link traffic only after successful negotiation. Old responses from a previous generation are rejected.
7. On any timeout or fault, isolate first, revoke leases, record cause and retry a policy-bounded recovery image or leave B unavailable. F133 launcher/A diagnostics remain usable. Supervisor/service recovery does not depend on B issuing a friendly reset or A accepting a command.

Resetting/reconfiguring B destroys its local DDR-controller state and allocated contents. No retention or shared 256 MiB address space is implied. A runtime reset and CRESET_N must be treated as distinct controls; the latter initiates device reconfiguration and cannot be substituted casually for a soft system reset.

## Storage capacity and update rules

Capacity remains OPEN until authentic generated A/B images and F133 rescue payloads are collected. Record emitted format, raw loadable payload bytes, initialization/header options, exact device/tool/version, hash, and generated programming map; text `.hex` file length is not flash payload capacity. Do not size from a development kit's flash part or an assumed compressed bitstream.

Calculate required protected capacity from actual bootloader/rescue payloads, golden A, golden B, recovery/rollback slots, erase-block alignment, manifest/journal redundancy and the selected flash's addressing/programming limits. Calculate rewritable capacity from supported game packages/personality payloads and update space. The product's games capacity is a product decision after workload evidence, not a fixed memory budget.

Golden images must be preserved across interrupted normal updates. Stage updates outside the committed golden region, verify payload and readback, then commit an atomic redundant manifest. Prove service override can restore a corrupted mutable slot without relying on A/B user logic. The exact F133 boot mux, protected NOR part, game storage technology and write-protect circuit are unresolved. Host review supplies candidate SPI0 NOR plus independent SMHC0 games storage; no connection is locked here.

## Power, clocks, reset and USB closure inputs

Create a per-domain rail sheet for F133/in-package DDR, A core/PLL/IO/DDR, B core/PLL/IO/DDR, both memory parts, HDMI transmitter, storage, oscillator/distribution, supervisor and USB VBUS/hub. Record minimum/nominal/maximum at device pins, load estimates, transient/inrush, sequencing/reset predicates, ripple/impedance criteria, regulator tolerance and fault response. Equal nominal voltages do not establish that supplies can be combined. The two memory parts' complete manufacturer voltage/timing tables must be reconciled with the FPGA controller outputs.

Run Efinix Power Estimator for both actual candidate builds using realistic activity and simultaneous DDR/link/display loads, then measure prototype current, droop and temperatures. Archive estimator version/input assumptions and uncertainty. Bring USB load/short and plug-in transients into the same supply/fault review. No PSU current, regulator part, fanless guarantee, enclosure geometry or thermal pass is asserted.

The candidate Alliance memory requires two supply classes: VDD1 near 1.8 V and VDD2/VDDCA/VDDQ near 1.2 V within its documented limits. The FPGA’s nominal 1.2 V core is a separate requirement; equal nominal values do not approve a combined supply topology.

The [memory review](MEMORY_REVIEW.md) identifies a lifetime blocker in the publicly hosted preliminary Alliance specification: no more than 400 uncontrolled power-off events over device life. This is unresolved for a ten-year product. Obtain current manufacturer clarification and prove controlled shutdown under normal removal, sudden input loss and any B-domain power operation. Evaluate power-fail detection, controller/CKE authority, required hold-up and relative rail-fall conditions using the exact current specification; no hold-up capacitance is guessed here. A wedged B user design must not be the sole path to a required memory shutdown. Keep B and its memory powered during ordinary reconfiguration unless the qualified shutdown/isolation design permits a power cycle. Reconfiguration still requires controller reinitialization and rejects previous allocations. Add controlled/uncontrolled shutdown waveforms and a justified lifetime policy to REC-08/REC-09 acceptance; the exact memory part remains a candidate until resolved.

Retain F133 USB ROM/service functionality as a proposed development path. A hub on the independent USB host controller is a candidate for two external gamepad sockets; its exact driver, high-side current limit, overcurrent handling, ESD and backfeed behavior require separate evidence. Service USB must not become an uncontrolled supply source to unpowered rails. F133 UART and individual A/B JTAG need access before user logic boots. USB connector type follows a verified native interface and voltage/power role; it is not a new F133 hardware capability.

## Ordered closure experiments and acceptance vectors

All entries below are **OPEN**, with artifacts required before a gate can close.

| ID | Experiment | Required acceptance evidence |
| --- | --- | --- |
| REC-01 | Authentic A/B memory-only and golden-recovery builds; generate exact programming payloads | Tool/project/source/constraints hashes, native reports and actual sizes; legal config/DDR resources for each F484; no inference from sample designs. |
| REC-02 | Configuration ownership schematic/ERC and programmer prototype | A and B each load without the other user design; JTAG/passive ownership mutually exclusive; state/timing captures satisfy exact source limits; protected NOR remains host-owned. |
| REC-03 | Cold boots with B absent, unconfigured, reset, or malformed payload | F133 rescue boot and A recovery display available; per-device diagnostics distinguish fault; no host/boot flash contention. |
| REC-04 | Valid configuration with wedged B heartbeat, illegal protocol, stale generation and stalled link | Isolation and lease revocation within an explicit reviewed timeout; A scanout/command-service bounds satisfied; retry bounded; external recovery usable. |
| REC-05 | B reconfiguration during A display and active queues | No stale DMA into A; no A reset/clock interruption; A underflow/error counts and visible output captured against a declared budget; DDR B reinitialized before admission. |
| REC-06 | Cross-domain electrical analysis and powered-off tests | Every net's drive/leakage/default state justified by selected component specs; no prohibited drive into unpowered FPGA/DDR; measurements against device-pin voltage/current limits. Do not run unsafe power-off injection without the reviewed circuit. |
| REC-07 | Power interruption at every update/manifest stage | Known-good rescue software and golden images recover after restart; no falsely committed partial image; hashes/readback and fault logs retained. |
| REC-08 | Brownout, reset-button, watchdog and clock-failure scenarios | Independent control asserts safe state; F133/A preserved under the defined B-local fault envelope; rail/reset/clock captures explain recovery and any allowed full-board reset. |
| REC-09 | Simultaneous worst-case load and USB overcurrent/hot-plug | Estimator then measured rail/current/thermal evidence for reviewed workloads and environmental limits; USB port fault containment; final regulator/input/cooling decisions justified. |

Document/software tests can check this state model and manifests, but cannot satisfy REC-02 through REC-09 physical acceptance. Gates for storage/recovery, USB, power/thermal, complete pin/clock allocation and final manufacturing approval remain OPEN.
