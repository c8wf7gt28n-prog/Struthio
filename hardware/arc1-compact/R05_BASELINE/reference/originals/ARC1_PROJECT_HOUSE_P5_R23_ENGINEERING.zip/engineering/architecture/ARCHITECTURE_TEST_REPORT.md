# R22 architecture source/software verification

Date: 2026-10-12. No hardware acceptance result is claimed.

## Baseline

Before this turn's source modification, `npm test` passed the existing 67 automated tests plus original navigation/source checks: six departments, Viewer selection controls, 968 unassigned balls and 30 offline assets. This preserved the DEV-002 intake baseline.

## Executed source review checks

`python scripts/verify-package-facts.py`: PASS. Every one of the 484 derived F484 rows matches original workbook columns A–H; original SHA-256 matches the archived handoff. No electrical nets are assigned. The derived common package facts apply independently to A/B; they do not establish shared electrical rails across chips.

The final pre-R23 baseline passed 89 automated tests:52 legacy evidence,8 intake UI,22 architecture and7 service-worker tests, plus original navigation/source verification. The architecture suite covers exact source counts, active-frame versus serial-link arithmetic, candidate-only throughput, independent memory, OPEN gates, malformed records and actual module/House UI handlers in a synthetic runtime. Captured output is preserved at `engineering/r23/logs/R22_BEFORE_R23_BASELINE.log`. This document is historical R22 source/software evidence; R23 current results are in `engineering/r23/R23_TEST_REPORT.md`.

## Unperformed hardware/browser checks

There is no Efinity installation or authentic generated A/B project in this workspace; no synthesis/STA/CDC result, actual F133 firmware build/boot, FPGA programming, SI/ERC/DRC, PCB/footprint implementation, rail/current/temperature measurement, memory calibration/stress, monitor/audio/link/USB or recovery bench acceptance was executed. KiCad CLI availability alone supplies no schematic evidence.

Earlier real-browser attempts are recorded in `engineering/R22_DEV002_BROWSER_REPORT.json`: local HTTP serving failed with EPERM; Chromium failed before navigation with socket permissions/SIGTRAP. That record is historical; this turn does not count it as a new browser test. Browser/visual/mobile/PWA installation/offline reload remain unverified. Synthetic DOM/service-worker tests do not replace those checks.

Public documents/kernel sources were read with the web connector. New original source bytes were not retrieved through the blocked shell proxy; original PDF/model/source hashes remain null where unavailable. Source-register snapshot hashes identify browser extraction JSON only, not original documents or authenticated vendor execution. No confidential manufacturer PDF or restricted IP is bundled.

## Remaining release boundary

AD01–AD10 are selected goals/conditional recommendations/rejected assumptions, not approvals. E00–E06 require authentic archived artifacts and measured acceptance. The preliminary memory lifecycle/power-off requirement, exact F484 paired pin/clock/bank allocation, dual-link bridge, RGMII/fixed-link implementation, independent reset/configuration/recovery and simultaneous power/thermal behavior remain unresolved. G01–G11 are OPEN and fabrication remains NO-GO.
