# ARC-1 R22 display and inter-FPGA feasibility review

Date: 2026-10-12. Scope: source-backed candidate resource budgets and experiments. **G02 (display), G03 (A/B link), and the whole-board gate remain OPEN.** The existing R22 hardware remains two T120F484I4 devices with independent proposed 128 MiB ×32 LPDDR2 pools. No nets, bank voltages, bus width, operating clock, PCB geometry or manufacturing approval are assigned here.

## Engineering direction

Qualify dual-link LVDS for 1080p60 before allocating the lifetime board, and compare native LVDS against the proposed 16+16 and 32+32 parallel A/B buses. Native LVDS is a useful additional study because the package's 256 GPIO definitions include only 96 DDIO-capable pins. A 32+32 parallel bus cannot be justified from the headline GPIO count. Select a final candidate from complete paired Efinity designs, useful measured throughput, reset isolation and power/SI evidence.

The 720p60 fallback and 1080p60 targets remain untested. These calculations refine the experiment; they do not close it.

## Exact package resource inventory

[spreadsheetfacts.json](spreadsheetfacts.json) is a deterministic extraction of all 484 balls from `engineering/T120_pinout_v1.4.xlsx`, sheet `T120F484`, worksheet `xl/worksheets/sheet2.xml`. The workbook SHA-256 is `8a6ecd5700c5895cfe306dfe3c37bac2d40feebe2b7ea4e8c43291eab831bc6d`. Its A–H columns are bank, name, configuration function, DDR annotation, LVDS pair, DDIO, clock region and ball. Empty source cells remain empty. This common package dictionary applies independently to A and B; it does not imply common electrical rails between chips.

| Source-derived resource | Per T120F484 device | Interpretation |
|---|---:|---|
| Package balls | 484 | Includes power, DDR and dedicated resources |
| Existing application GPIO classification | 256 | Includes single-ended use of LVDS pads |
| Explicit `DDIO: Yes` rows | 96 | 73 left-side ordinary GPIO; 23 right-side ordinary GPIO |
| DDIO rows with configuration alternatives | 19 | 9 in 1A, 6 in 1B, 4 in 1G; reuse is mode dependent |
| DDIO rows with DDR-reference annotation | 1 | M15 / `GPIOR_186_PLLIN0`; candidate, not automatically reserved |
| DDIO rows without either annotation | 76 | Conservative study pool, not an approved available-pin count |
| LVDS TX pairs | 40 | 22 top, 18 bottom; every pair has two package balls |
| LVDS RX pairs | 40 | 22 top, 18 bottom |
| LVDS TX pairs with configuration alternatives | 12 | Six in 4E, six in 4F; 28 TX pairs remain unannotated |
| Dedicated DDR rows | 74 | BANK3E; not general link or display resources |
| GPIO `CLK0`–`CLK15` entries | 16 | Four in 1C, four in 1D, eight in 3D; clock topology still matters |
| LVDS RX `CLKP/CLKN` pairs | 6 | Three top, three bottom; one contains R12 DDR-reference candidate |

Two GPIO DDR-reference candidates exist: R12 `GPIOB_RXP09_CLKP0` in 4C, and M15 `GPIOR_186_PLLIN0` in BR. Only M15 has DDIO. Excluding both candidates from general use is a conservative planning exercise; the authentic DDR_0 project must resolve which resources it uses.

| Native-LVDS bank | TX pairs | RX pairs | Configuration-annotated TX pairs |
|---|---:|---:|---:|
| 2A / 2B / 2C | 7 / 8 / 7 | 0 | 0 |
| 2D / 2E / 2F | 0 | 6 / 8 / 8 | 0 |
| 4A / 4B / 4C | 0 | 4 / 7 / 7 | 0 |
| 4D / 4E / 4F | 5 / 7 / 6 | 0 | 0 / 6 / 6 |

| Shared ordinary-GPIO supply group | DDIO rows | Conservative rows after excluding configuration/DDR-reference annotations |
|---|---:|---:|
| VCCIO1A | 9 | 0 |
| VCCIO1B_1C | 28 | 22 |
| VCCIO1D_1E | 18 | 18 |
| VCCIO1F_1G | 18 | 14 |
| VCCIO3D_TR_BR | 23 | 22 |
| Total | 96 | 76 |

The same named bank in the other FPGA belongs to a separate device. Power rows with bank `-` are not one shared bank. For 2A–2F and 4A–4F, the workbook gives individual VCCIO names. A hypothetical common rail voltage is not evidence that every selected I/O standard is legal.

## Manufacturer limits that affect candidate selection

The [T120 data sheet v4.0](https://www.efinixinc.com/docs/trion120-ds-v4.0.pdf), Table 9/pages 13–14, distinguishes ordinary GPIO DDIO from LVDS-as-GPIO, which has no DDIO. Pages 21–23 document native LVDS serialization factors 2–8, including 7:1 and 8:1, and an 800 Mbit/s lane limit. The document requires two unassigned LVDS pairs between LVDS-as-GPIO and native LVDS on each device side; Efinity rejects violations. It recommends at most 14 output/bidirectional LVDS-as-GPIO pins per bank and same-side TX data/forwarded-clock placement. Table 77/page 57 specifies nominal 3.3 V native-LVDS VCCIO. Tables 18–20 distinguish FASTCLK, SLOWCLK and forwarded-clock mode/division. These are constraints on subsequent projects; do not infer a serializer's FPGA FASTCLK from the lane bit rate alone.

## HDMI: reference design is F576, not a transferable F484 pin plan

The [T120 BGA576 development-kit guide v2.3](https://www.efinixinc.com/docs/trion120f576-devkit-ug-v2.3.pdf), Table 25/page 26, identifies IT6263N. It lists **ten data pairs (A–E on each of two links) and one shared clock pair**, plus reset and programming I²C. Thus its complete deep-color interface uses **11 TX pairs**, not ten. Its first-link resources are `GPIOB_TX13/24/25/23/22`; the second uses `GPIOB_TX10/12/11/14/21`; clock is `GPIOB_TX26`. It uses `GPIOL_74` reset and `GPIOT_TXP15/TXN15` programming. The reported address is `0x98`; confirm the address convention before constructing software.

Direct workbook comparison shows F484 lacks `GPIOB_TX10`, `TX11`, `TX12`, `TX21` and `GPIOL_74`. These missing reference resources prevent copying the F576 mapping. F484 does contain the clock pair and first-link pairs, but some bottom TX resources have configuration alternatives. An alternate allocation needs a genuine F484 project. The programming pair is present; using it as GPIO must obey separation constraints if that side also uses native LVDS.

For an explicitly supported 8-bit RGB mapping, a four-data-pair link could carry 28 serialized bits including synchronization; two such links plus a shared clock would use nine pairs. That is a **proposed mode to qualify**, not proof that the exact selected IT6263N revision permits discarding E lanes. Retaining the full documented reference budget uses eleven pairs. No deep-color requirement is silently added to R22.

Using the standard target pixel clocks recorded in `architecture.json`, the proposed 7:1 lane rates are:

| Target/mode study | Pixel clock | Pixel-link clock | Calculated data-lane rate | Comparison with 800 Mbit/s ceiling |
|---|---:|---:|---:|---|
| 720p60, single pixel link | 74.25 MHz | 74.25 MHz | 519.75 Mbit/s | Within lane limit; untested |
| 1080p60, single pixel link | 148.5 MHz | 148.5 MHz | 1039.5 Mbit/s | Exceeds lane limit; reject this particular mode |
| 1080p60, dual even/odd pixel links | 148.5 MHz | 74.25 MHz per link | 519.75 Mbit/s | Within arithmetic lane limit; exact bridge mode unproven |

Formula: pixel clock × seven bits ÷ simultaneous pixel links. Blank intervals, color mapping and bridge register selection must match the actual video mode. This arithmetic does not prove PLL synthesis, timing, video stability, HDMI audio or interoperability. Select the appropriate serializer forwarding-clock division from the actual Efinity/ITE configuration; do not guess it from the table.

Required procurement/support evidence remains OPEN: exact IT6263N versus current IT6263FN ordering suffix and package, distributor quotation and lifecycle, authorized schematic/BOM, electrical data sheet, programming register guide/init sequence, redistribution rights, DDC/EDID/HPD and stereo-audio details. A public family product page or an upstream Linux binding alone cannot establish those requirements. Vendor/support-center assets must retain their license terms; no restricted IP is bundled here.

## A/B link candidates and useful bandwidth

Each direction is an independent packet channel into bounded DMA queues. The receiver owns its local memory; B receives explicit bounded leases, never unrestricted A VRAM access. A must continue scanout and independent rescue during malformed traffic, B reset and B reconfiguration. A CRC, framing, backpressure/credits, personality/version discovery and CDC/reset protocol are engineering requirements for every physical candidate.

| Candidate study | Resources per FPGA, before extra controls | Raw rate per direction | Main qualification pressure |
|---|---|---|---|
| 16+16 parallel DDIO | 32 ordinary GPIO data pins + forwarded-clock/control budget | `16 × 2 × f / 8` bytes/s | Bank/clock placement, host DDIO sharing, skew and CDC |
| 32+32 parallel DDIO | 64 ordinary GPIO data pins + forwarded-clock/control budget | `32 × 2 × f / 8` bytes/s | Tight ordinary-GPIO allocation; multiple banks and configuration reuse |
| 4 TX + 4 RX native LVDS data lanes | 8 data pairs + one TX/one RX clock pair = 20 balls | `4 × laneBitRate / 8` bytes/s | PLL input legality, alignment/deskew and clock sharing |
| 8 TX + 8 RX native LVDS data lanes | 16 data pairs + one TX/one RX clock pair = 36 balls | `8 × laneBitRate / 8` bytes/s | Same constraints; contention with HDMI/DDR reference choices |

Extra reset/isolation/control signals and any additional clocks must be counted in the complete plan. Full duplex is not a promise that both local DDR controllers can sustain simultaneous traffic.

At a **calculation-only example** `f=125 MHz`, 16-bit and 32-bit parallel DDIO yield 500 MB/s and 1000 MB/s raw per direction. At the documented **ceiling**, four/eight native LVDS data lanes yield 400/800 MB/s raw per direction. These are decimal rates before framing, CRC, idle periods, retries, memory refresh/arbitration and scanout; none is an achieved ARC-1 rate or an operating-clock selection. Compare measured payload throughput, sustained utilization, latency and power under the same workloads.

On A, a conservative host physical bundle is 12 RGMII pins: ten DDIO data/control pins and two clocks. Adding those twelve to 64 parallel data pins consumes the entire 76-pin conservative pool before A/B clocks. Counting just ten DDIO host data/control pins leaves two from that pool, but those are not automatically legal A/B clock resources. Mode-specific configuration reuse may restore capacity; each reused pin needs startup, programming, strap and electrical review. SPI rescue and bridge control/reset also require explicit space. B lacks the RGMII/display allocations, but the same A/B protocol must be implementable on both chips.

For native LVDS, A's top edge has 22 TX pairs with no configuration annotation. An eleven-pair HDMI budget plus eight A/B data pairs and one A/B forwarded-clock pair totals twenty top TX pairs. This makes a candidate worth generating without consuming bottom configuration TX pairs. It is only a **resource-count illustration**: different serializer clocks, local routing, reference clocks, guard pairs for any nearby GPIO, input termination, bank rails, external pin placement and timing may invalidate it. A/B RX has its own clock-capable resources and the DDR-reference choice must be preserved. No pins or topology are selected by this illustration.

Do not use native-LVDS-as-GPIO pins to inflate a DDIO budget. An SDR parallel alternative on those pads could be studied separately with its own rate formula and separation/output-switching limits; it is not a drop-in replacement for DDR I/O.

## Required projects and evidence

1. Generate independent memory-only A/B projects for **T120F484I4**, DDR_0 LPDDR2 ×32 1 Gbit using exact approved memory timings; preserve 128 MiB each. Export untouched native projects, generated DDR mappings, selected reference-clock/PLL resources, bank rail report and logs. Proposed 800 MT/s remains unverified until generated and then measured.
2. Add F484 LVDS video candidate configurations to A: 720p60 single link and 1080p60 dual link. Preserve the real bridge revision, pixel/color/bit mappings, serialization and forwarded-clock settings, PLL outputs, lane assignments and all reset/control resources. Archive the licensed bridge initialization/schematic references or access records.
3. Generate complete paired A/B candidate projects for 16+16 DDIO, 32+32 DDIO and useful native-LVDS lane counts. Each includes host RGMII, independent SPI rescue, both DDRs, A display, configuration/JTAG, reserved clocks, shared rail groups and startup ownership. Export genuine pin/bank/clock reports, synthesis/utilization, warnings and static timing with source-synchronous external delays for both directions.
4. Simulate packet corruption, loss of clock, receiver stall, bounded-lease violation, B reset while A scans out, and B personality replacement. Verify CDC/RDC, FIFO limits, credit recovery and independent rescue. HDL simulations establish protocol behavior only; they do not certify silicon timing.
5. Review actual netlist/ERC and device-specific IBIS/SI including loading, termination, skew and return paths; complete power/thermal estimates. Do not invent routed lengths or geometry. Prototype measurements must exercise both DDRs, worst-case A/B traffic and video concurrently.
6. Archive measured video modes, EDID/fallback, HPD reconnection, stereo audio, prolonged no-underflow scanout, A/B error counters and sustained payload throughput with exact hardware/RTL/firmware/build revisions, input conditions, hashes and logs. Define and approve numerical acceptance thresholds before running qualification, including useful sustained bandwidth for the agreed game workloads.

No spreadsheet count, PWA diagnostic, conflict-free importer result, source calculation, proposed pin plan or successful software test satisfies these hardware acceptance steps. All affected gates remain OPEN and fabrication remains NO-GO.
