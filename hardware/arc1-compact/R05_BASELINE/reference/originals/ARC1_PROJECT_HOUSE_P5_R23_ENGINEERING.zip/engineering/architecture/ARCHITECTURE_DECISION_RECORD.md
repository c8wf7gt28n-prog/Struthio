# R22 architecture viability and development decision record

Date: 2026-10-12. Scope: source review, calculated constraints and recommended engineering experiments. **Hardware gates G01–G11 remain OPEN; fabrication remains NO-GO.** The agreed R22 work order is unchanged. No PCB geometry, schematic net assignments or Efinity-generated proof is created by this record.

## Architecture direction

Retain F133-B as host, T120F484I4 A as permanent graphics/display, and the same T120 B as the game-defined accelerator. Retain a separate proposed 128 MiB x32 LPDDR2 pool on each FPGA, external HDMI monitor, standard USB gamepads, physically separated protected system and rewritable game storage, external power and independent recovery. This direction has a credible documented capability basis. The complete combined implementation is **not yet demonstrated viable**.

The practical development target is a complete paired Efinity interface study and independently recoverable prototype, rather than premature permanent-board release. There is no evidence supporting a silent processor/package change or an arbitrary game-memory cap. Any source-backed impossibility found in the real projects must trigger an explicit architecture decision before copper lock.

## Recommended functional partition

This is a proposed responsibility diagram, not a schematic, placement drawing, electrical netlist or approved component BOM.

```mermaid
flowchart LR
  Sys[Protected system and golden-image storage] --> Host[F133-B host / 64 MiB]
  Games[Separate rewritable game storage] --> Host
  Pads[External USB HID gamepads] --> USB[Qualified USB host / hub and VBUS protection]
  USB --> Host
  Host <-->|Candidate crossed RGMII / commands and assets| A[T120-A permanent graphics]
  A <--> MA[Independent candidate 128 MiB LPDDR2-A]
  A <-->|Qualified full-duplex bounded job/data link| B[T120-B game personality]
  B <--> MB[Independent candidate 128 MiB LPDDR2-B]
  A -->|Qualified dual-link LVDS study| HDMI[HDMI bridge / external monitor]
  Host <-->|Independent SPI control candidate| Recovery[Independent recovery / supervisor and service access]
  Recovery -->|Reset / configuration ownership| A
  Recovery -->|Reset / configuration ownership| B
```

F133 owns boot, storage, input, game rules, image authentication/update policy and diagnostics. A owns its memory allocator, graphics ABI, scanout service and protected dispatch to B. B has its own local memory and receives only bounded jobs/leases. Configuration/reset/service access must remain reachable without either user image. The exact supervisor, arbitration circuitry, flash topology and rails remain part of the schematic qualification work.

## What the review resolves

**Memory configuration class:** the current T120 data sheet documents the selected LPDDR2 width, density and speed class. This supports proceeding with the exact two memory-only experiments. It does not prove the Alliance pin mapping, timing, start-up or calibration. Read [the memory review](MEMORY_REVIEW.md) before entering settings; preserve exact revision, package and rail distinctions.

**Host/display workload boundary:** a 32-bit framebuffer example requires 221.184 MB/s for active 720p60 reads and 497.664 MB/s for active 1080p60 reads. Both exceed a 1 Gbit/s host link's raw 125 MB/s ceiling, before protocol overhead. The viable direction is graphics commands/assets to A, local rendering and scanout, and workload-aware DDR arbitration. CPU-rendered low-resolution modes can be evaluated, but they are not grounds for limiting the lifetime board or imposing a fixed game budget. These rates are calculations, not measured DDR demand or achieved useful throughput.

**1080p60 LVDS mode:** Linux's pinned reference timing table gives 148.5 MHz for the standard target. Seven serialized bits per lane require 1039.5 Mbit/s for a single pixel link, above the T120 lane ceiling. A dual-pixel-link arrangement halves the calculated data-lane rate to 519.75 Mbit/s. Therefore dual-link is the recommended bridge qualification study for this target. Exact clock sharing, pair mapping, color format, PLL settings and bridge initialization must match the specific bridge revision. Single-link 720p60 calculates within the ceiling and remains a fallback target; neither mode is advertised as tested.

**Useful A/B link selection:** the workbook has 256 GPIO definitions per chip but only 96 explicitly DDIO-capable pins. Nineteen DDIO rows have configuration alternatives, and one has a DDR reference-clock annotation. Conservatively quarantining all of those leaves 76 unannotated DDIO candidates; this is not an actual reservation decision. A 32+32 data study plus a conservative 12-physical-pin host budget consumes that count before additional A/B resources. The host data/control requirement is narrower than its total clock-inclusive physical bundle, and mode-specific configuration reuse may change the allocation. Native LVDS offers another documented resource class worth comparing. **No width, lane count or operating clock is locked.** Read [the display/link review](DISPLAY_LINK_REVIEW.md); aggregate counts cannot establish routing, rail or timing legality.

**Exact host package integration:** the F133 review distinguishes real package candidates from generic D1 mux defaults. Study PG RGMII and PD-group SPI1, protected SPI0 NOR and separate SMHC0 game storage. Avoid the known PG/SMHC1 and SPI0/MMC2 overlaps. A two-port USB2 hub on the separate host controller is a candidate that preserves the OTG/service interface. These are source-informed bus roles, not net assignments or a finalized storage/hub BOM. Read [the host-link review](HOST_LINK_REVIEW.md), including the source-mirror and exact-version fixed-link binding limitations.

**Independent recovery:** a SPI service implemented only in A user RTL disappears when A is blank or corrupt. Recovery must instead reach actual reset/programming access through a qualified host/supervisor/service path. A and B need individually reviewable configuration ownership; B failure must not reset A or corrupt protected system storage. Read [the recovery/power review](RECOVERY_POWER_REVIEW.md). Typical currents, family example circuits or chip counts cannot size a final supply or validate power-off I/O behavior.

**Supply and DDR start-up corrections:** the selected regular I4 FPGA core/PLL class is nominal 1.2 V, not the 1.1 V low-voltage I4L class. The candidate memory also needs its VDD1 supply class near 1.8 V alongside its near-1.2 V VDD2/CA/Q classes. DDR clock start-up requires the documented PLL_BR0/CLKOUT0 and primary-reference behavior; the workbook's LVDS-labeled DDR clock alternative cannot be chosen automatically for configuration-phase initialization.

**Ten-year power-loss qualification:** the manufacturer's publicly hosted preliminary memory data limits uncontrolled power-off sequences to 400 over device life. This is a concrete lifecycle blocker to resolve, not a prediction that the device necessarily fails on the next event. Obtain current vendor confirmation and prove controlled shutdown/rail/CKE behavior, including sudden input loss and B reconfiguration. Do not approve the exact part for the ten-year goal while that requirement is unresolved. If it cannot be satisfied, qualify another exact device while retaining the agreed capacity/width objectives.

## Decisions and remaining choices

The auditable [architecture JSON](architecture.json) records AD01–AD10 with source identifiers, evidence stages, linked gates and required remaining work. Selected goals remain selected; new implementation choices are PROPOSED. Explicitly rejected assumptions include full-frame high-resolution host streaming, a single-link standard1080p60 path at the stated serializer limit, a rescue path dependent on a healthy A image, automatic 32+32 allocation and hardware certification from software tests.

Open decisions include the A/B physical interface and clocking, exact HDMI bridge ordering revision/initialization, memory ball/CA mapping and timings, exact F133 firmware/driver/boot mux, supervisor/arbitration design, actual storage parts/capacities, USB topology/protection, all regulator/current/thermal choices and every fabrication artifact. The manufacturer sources do not substitute for their acceptance evidence.

## Ordered boundary-closing work

The record defines E00–E06 as OPEN experiments with required untouched artifacts, explicit acceptance and stop conditions:

1. **E00:** obtain authoritative sources, errata, exact part support, tool/IP licenses and a predeclared gameplay workload/acceptance budget.
2. **E01:** generate independent exact-device A/B memory-only Efinity projects. Archive configuration, actual mapping, pins/PLL/rails, warnings/errors, build and STA outputs.
3. **E02:** compare complete paired plans for dual-link HDMI, host RGMII/rescue and each parallel/native-LVDS A/B candidate. Include all clocks, boot/config/JTAG, voltage groups and separation rules.
4. **E03:** build the exact-board F133 firmware and link endpoint, then prove clock ownership, fixed-link behavior, storage/input coexistence and independent blank-image recovery on a real fixture.
5. **E04:** prove DDR/scanout and bridge behavior under concurrent load, including both monitor modes, EDID/HPD/audio, calibration, integrity and underflow/latency acceptance.
6. **E05:** inject corrupt images, reset/reconfiguration, stale descriptors/leases, stalled clocks and storage-update failures. Show that B failure cannot remove A output or independent service/recovery.
7. **E06:** validate simultaneous-load power/ramp/reset/USB/thermal/SI behavior and complete the reviewed schematic/layout/BOM/ERC/DRC/STA/release package.

The design that advances is the one meeting useful workload and recovery criteria. A candidate that fits a pin count but fails timing, receiver-clock ownership, calibration, bus isolation or thermal acceptance is a NO-GO. A slow diagnostic boot does not justify permanently deleting important physical capabilities.

## Reproducible software checks and provenance

`architecture.js` computes the display/memory/link envelopes from declared inputs and the independently extracted F484 resource facts. It refuses closing gate/experiment assertions and does not manufacture measured rates. Run `npm run architecture:check` for its JSON output. The optional standard-library `python scripts/verify-package-facts.py` compares every derived row to original workbook columns A–H. These are source/arithmetic checks only.

The original pin dictionary, clean package CSV, workbook and R22 authorities remain unchanged. Public manufacturer/kernel sources are linked with versions and locators; where original bytes were not downloaded their hashes are explicitly null. Browser-response hashes in review registries identify extracted snapshots, not original PDFs or authenticated tool output. No new vendor HDL/IP, confidential manufacturer PDF or copied driver is redistributed.

This workspace has no Efinity installation or authentic generated A/B project, and no connected prototype/bench evidence was provided. KiCad CLI is present, but there is no real ARC-1 schematic/layout to run meaningful ERC/DRC against. Real browser launch and local HTTP serving were previously blocked by sandbox socket permissions. None of these missing experiments is counted as executed or passed. The hardware-access question remains unanswered at preparation time.
