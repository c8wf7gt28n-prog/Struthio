# R22 architecture development change record

Date: 2026-10-12. Scope: agreed-goal source review, conditional implementation decisions, calculated feasibility and engineering acceptance preparation. **No hardware gate is closed.**

## Added engineering records and tooling

- `architecture.json`: AD01–AD10, versioned sources, documented constraints, OPEN G01–G11 and E00–E06 experiments with required artifacts, acceptance and stop conditions.
- `ARCHITECTURE_DECISION_RECORD.md`: recommended functional partition, source-resolved constraints and ordered work required to establish an actual viable implementation.
- `MEMORY_REVIEW.md`, `HOST_LINK_REVIEW.md`, `DISPLAY_LINK_REVIEW.md`, `RECOVERY_POWER_REVIEW.md`: detailed exact-device reviews and their four source registries. New vendor PDFs, HDL/IP and copied drivers are not redistributed; unavailable original byte hashes stay null.
- `spreadsheetfacts.json`: all 484 original F484 rows including configuration, DDR, LVDS, DDIO and clock-region fields. Empty cells stay empty; these are package definitions with no nets.
- `architecture.js`: source/resource checks and display/memory/link arithmetic. Gate closure, invented measured rates and malformed source facts are rejected.
- `architecture-ui.js`: read-only review in Systems and Lab, conditional decisions, documented constraints, source references and experiment links. All physical statuses remain OPEN.
- `scripts/check-architecture.mjs`: independently checks workbook bytes then prints the source-review calculations.
- `scripts/verify-package-facts.py`: optional standard-library exact XLSX-to-facts audit; no Python runtime dependency for the PWA or npm tests.
- `tests/architecture_node.cjs`: real-record/resource/arithmetic/integrity and actual UI/House handler checks in a synthetic runtime.
- `ARCHITECTURE_TEST_REPORT.md` and captured output: executed validation and unperformed EDA/bench/browser checks.

## Changed existing files

| File | Result |
|---|---|
| `index.html` | Load the architecture modules before House; shell/branding/navigation unchanged |
| `house.js` | Mount review in Systems/Lab, link bundled architecture documents in Archive, update supplemental experiment brief |
| `house.css` | Append matching review styles; existing design rules preserved |
| `sw.js` | New cache version and bundled architecture modules/data/reviews/source registries for offline use |
| `package.json` | Add architecture tests and `architecture:check`; keep zero npm dependencies |
| `scripts/verify.mjs` | Require architecture records/modules/assets, auditable references and OPEN gate consistency |
| `tests/offline_node.cjs` | Verify all declared cached files and added architecture resources without a stale fixed asset count |
| `tests/smoke_node.cjs` | Report live roadmap task count |
| `tasks/roadmap.json` | DEV-003 partial progress and new HW-007 qualification task; all hardware tasks/gates remain OPEN |
| `engineering/R22_DEVELOPER_TASKS.json` | Byte-identical task mirror retained |
| `README_FIRST.md` | Review and reproducible check instructions |
| `WORKING_SOURCE_HASHES.sha256` | Current delivery manifest; original handoff manifest preserved |

The original workbook, 968-ball dictionary and clean package CSV, R22 work order/evidence policy/CLAUDE authority, Viewer code/styles/placeholders, icons and PWA manifest are preserved. No PCB geometry, electrical signal allocation, chosen regulator/current/capacity, approved bus width, achieved clock or measured throughput is introduced.

## Material findings and remaining work

The review narrows a credible direction: local graphics/scanout on A, bounded game acceleration and separate DDR on B, dual-link HDMI qualification, whole-package DDIO/native-LVDS comparison, exact F133 mux partition and independently reachable A/B programming/reset/service paths. Regular I4 core/PLL supply differs from low-voltage I4L; memory requires both documented supply classes and a legal DDR startup clock.

The exact Alliance memory remains a candidate: its publicly hosted preliminary data states a 400 uncontrolled-power-off lifetime limit, requiring current vendor clarification and controlled shutdown/power-loss acceptance for the ten-year goal. F576 HDMI reference resources cannot be copied to F484. No candidate is approved by arithmetic alone.

Authentic Efinity projects/STA, exact timing/ball/CA maps, current authorized device/bridge/lifecycle documents, real firmware/endpoint tests, schematic/ERC/DRC/SI and prototype power/display/DDR/link/USB/storage/recovery evidence remain required. E00–E06 and G01–G11 remain OPEN; fabrication remains NO-GO.
