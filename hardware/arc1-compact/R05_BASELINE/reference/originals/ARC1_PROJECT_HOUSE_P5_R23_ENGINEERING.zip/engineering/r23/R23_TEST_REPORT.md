# ARC-1 R23 software/source test report

Date: 2026-10-12. Runtime: Node v24.19.0, npm 11.9.0, Python 3.12.14. This is software/source verification, not EDA or hardware acceptance. **G01–G14 OPEN; hardware/fabrication NO-GO.**

## Baseline and executed checks

`npm test` ran before any R23 modifications and passed the 89-test R22 source-review baseline, plus navigation/source checks (11 tasks,45 cached assets). Its exact output is [R22_BEFORE_R23_BASELINE.log](logs/R22_BEFORE_R23_BASELINE.log). The complete pre-migration source snapshot was preserved separately as `R22_SOURCE_REVIEW_BEFORE_R23.zip`, SHA-256 `89a8fc7ecfc1be554367be210e1e9dd26bf563075e350abe8587f2a4e9ef488b`. R22 historical instructions and roadmap are also included in `engineering/history/r22/`.

Final `npm test`: **PASS, 112 automated node:test cases, zero failures**, plus original smoke/consistency checks. Captured full output: [R23_NPM_TEST.log](logs/R23_NPM_TEST.log).

| Check | Executed result | Coverage |
|---|---|---|
| Original smoke/navigation | PASS | Six departments, six Viewer tabs, selection controls,14 OPEN current gates and968 unassigned A/B balls |
| Legacy evidence core |52/52 PASS | Strict declared JSON/CSV, pins/banks/config/DDR conflicts, provenance, hashes, input limits and11 historical OPEN gates |
| Legacy intake handlers |8/8 PASS | Actual UI handlers in synthetic DOM, format changes, file failures, export, escaping, clear and limits |
| Architecture source/runtime |22/22 PASS | Actual workbook-derived resources, historical arithmetic and current R23 panel/House integration, source references and OPEN constraints |
| New R23 system intake/architecture |23/23 PASS | Full owner DOCX hash;384 target/448 candidate discrepancy;3 separate NORs; clock gap; strict schema, bad declarations, unknown fit, conservative erase arithmetic, signoff rejection and raw/attachment hashes; actual R23 default import/export without pin mutation |
| Actual service-worker handlers |7/7 PASS |74 real precache files, offline reads/query variants, activation cleanup, navigation fallback, uncached errors and request scope |
| Source/identity verifier |PASS | Immutable original authorities and R23 DOCX hash, historical/current schema separation,14 tasks/gates, matching task mirror, existing links and74 offline assets |
| Independent workbook audit |PASS | Every484F484 row matches original columnsA–H exactly; no electrical nets assigned |
| Architecture CLI |PASS | Current source/arithmetic result SOURCE_REVIEW_ONLY,14 OPEN gates, fabricationNO-GO; [captured JSON](logs/R23_ARCHITECTURE_CHECK.json) |
| Portable browser script syntax |PASS | Python compilation only; no browser execution is implied |

Independent source audit output: [R23_PACKAGE_FACTS.log](logs/R23_PACKAGE_FACTS.log). No dependency installation was required.

## Evidence limits

DOM and service-worker tests execute actual application handlers against synthetic runtime APIs and real files. They are not a real Chromium/mobile/PWA installation run. Historical attempted browser execution is recorded in `engineering/R22_DEV002_BROWSER_REPORT.json`: HTTP listen failed with EPERM and Chromium failed before navigation with socket permissions/SIGTRAP. Interactive layout/accessibility, installation, cache reload in a real browser and visual rendering remain unverified. The portable browser test has been updated for R23 and can run on a desktop permitting local HTTP and Chromium.

No Efinity installation/license or authentic generated A/B projects are supplied here. No native vendor parser/export, synthesis, STA, RTL simulator run, F133 BSP build/boot, FPGA programming, schematic/ERC/DRC/SI, calibrated DDR test, monitor/audio/gamepad demonstration, power/thermal trace or recovery bench acceptance was executed. KiCad CLI availability alone provides no schematic evidence. No physical CAD geometry or electrical assignments were invented.

Current manufacturer documents were inspected through the web connector. Vendor original-file hashes remain null where raw bytes were unavailable; extraction metadata is not an original PDF hash. Manufacturer capabilities and alternate-timing examples are not measured ARC-1 evidence. No restricted vendor PDF/IP/code is redistributed.

The named BT memory mismatch remains OPEN. Current guide omits LPDDR2/512Mbit initialization presets, and documented BT clock settings do not generate standard 74.25MHz. AN097's 72MHz alternate-blanking HDMI example is a qualification path, without exact 60Hz/IT6263N acceptance. NOR loadable lengths, erase geometry, partitions and endurance are UNKNOWN; selected 16MiB capacity is enforced individually.

## Release boundary and next evidence

All 14 gates remain OPEN, including G12 BT memory/composition, G13 NOR fit/endurance and G14 SPI NAND. [Decision record](R23_ARCHITECTURE_DECISION_RECORD.md) contains ten decisions and eight unexecuted acceptance contracts. The next bounded actions are vendor clarification of exact BT memory/init/clock and original paired full-interface Efinity generation, followed by authentic per-device image-size evidence. [Vendor questions](R23_VENDOR_QUESTIONS.md) are unsent drafts; no outreach occurred.

`SOURCE_HASHES.sha256` remains the original R22 manifest; the original CLAUDE hash maps to `engineering/history/r22/CLAUDE.md`. `WORKING_SOURCE_HASHES.sha256` identifies final delivery bytes. Hash equality establishes byte identity, not vendor authenticity or hardware signoff.
