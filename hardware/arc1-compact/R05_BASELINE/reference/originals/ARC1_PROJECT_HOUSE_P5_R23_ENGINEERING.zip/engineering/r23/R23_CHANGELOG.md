# ARC-1 R23 delivery change record

Branch/task: supplied existing Project House, DEV-002 extension and DEV-003 architecture reconciliation. No Git commit was supplied. Date: 2026-10-12. Source revision is identified by `WORKING_SOURCE_HASHES.sha256`.

The full R23 DOCX was read and preserved unchanged, including text, header/footer and conceptual diagram. Before migration, npm tests passed 89 cases plus original source/navigation checks. Historical R22 source-review snapshot and root instructions/roadmap/hash manifest were preserved before active edits.

## Resulting behavior

The PWA retains its visual design, six departments, six Viewer tabs, local notes and no-model geometry. Current cards, diagram, Manual, Lab gates, handoff and exports follow R23: four independent RAM pools with 384 MiB target and 448 MiB named-candidate discrepancy; three dedicated 16 MiB NORs; separate SPI NAND/no eMMC; full A→BT820B→IT6263N→HDMI. Viewer slots are documentation placeholders, not CAD. Active gate metadata is always G01–G14 OPEN.

Legacy strict A/B pin intake is retained unchanged at the core and labeled partial R23 coverage. New explicit JSON intake checks memory density/organization, dedicated NOR owners/capacity/erase-rounded declared image budgets, SPI NAND/video topology, source provenance and artifact hashes. It reports missing actual geometry/images as UNKNOWN and refuses claimed signoffs. It never writes the manufacturer inventory. No native Efinity formats or partitions are invented.

New R23 source/arithmetic records expose the memory mismatch, standard 74.25 MHz clock gap, current LPDDR2 preset documentation gap and manufacturer alternate-blanking qualification path. The historical 11-gate analyzer remains available; dispatcher routes the new schema to a separate 14-gate review. All achieved/physical performance remains null. Ten decisions and eight artifact/acceptance/stop-condition contracts organize the remaining work.

Updated SW cache is `arc1-house-r23-p05-evidence-v1`, with 74 assets and preserved ARC-1 cache cleanup. Roadmap now has 14 tasks, 14 OPEN gates and 14 recommended workstream roles, without asserting fourteen actual agent identities. Current task mirror is in `engineering/r23/`; R22 mirror is historical. The source verifier checks original CLAUDE against its archived copy and checks the original R23 DOCX hash.

Historical `engineering/architecture/ARCHITECTURE_TEST_REPORT.md` was finalized with the actually captured 89-test pre-R23 result; its architecture remains historical. R22 work order/evidence policy, package data, original legacy core/schema/templates/tests and all four R22 subsystem source reviews are unchanged.

## Executed proof and limits

Final npm tests: **112/112 PASS** plus navigation/source checks; 74 cached assets; independent 484-row workbook audit PASS. [Test report](R23_TEST_REPORT.md) links exact logs and separates real-browser/native EDA/bench checks that were not performed. Portable browser script updated and syntax checked only.

G01–G14 remain OPEN; hardware/fabrication NO-GO. Immediate unresolved issues: exact BT 64 MiB part/init, monitor-compatible 60 Hz BT→ITE timing and clock mapping, paired whole-system Efinity legality, authentic per-NOR image fit/endurance, NAND/BSP/ECC/filesystem, independent recovery, power/lifetime and simultaneous-load measurements. [Migration inventory](R23_MIGRATION_RECORD.md) gives KEEP/ADAPT/RETIRE/BLOCKED details; [vendor questions](R23_VENDOR_QUESTIONS.md) are unsent.

## Exact file changes versus pre-R23 snapshot

The [machine-readable diff](R23_CHANGED_FILES.json) is calculated from the actual pre-R23 ZIP; no source files were deleted. The final working hash manifest includes all delivered files except itself. Generated Python cache and Git metadata are excluded from the delivery.

### Modified files

- `CLAUDE.md`
- `README_FIRST.md`
- `architecture-ui.js`
- `architecture.js`
- `engineering/architecture/ARCHITECTURE_TEST_REPORT.md`
- `evidence-ui.js`
- `house.css`
- `house.js`
- `index.html`
- `package.json`
- `scripts/check-architecture.mjs`
- `scripts/verify.mjs`
- `sw.js`
- `tasks/roadmap.json`
- `tests/architecture_node.cjs`
- `tests/browser_smoke.py`
- `tests/intake_ui_node.cjs`
- `tests/offline_node.cjs`
- `tests/smoke_node.cjs`
- `viewer.js`

### Added files

- `engineering/history/r22/CLAUDE.md`
- `engineering/history/r22/README_FIRST.md`
- `engineering/history/r22/roadmap.json`
- `engineering/r23/ARC1_R23_Handoff.docx`
- `engineering/r23/BT820_MEMORY_VIDEO_REVIEW.md`
- `engineering/r23/R23_ARCHITECTURE_DECISION_RECORD.md`
- `engineering/r23/R23_CHANGED_FILES.json`
- `engineering/r23/R23_CHANGELOG.md`
- `engineering/r23/R23_DEVELOPER_TASKS.json`
- `engineering/r23/R23_MIGRATION_RECORD.md`
- `engineering/r23/R23_OWNER_ARCHITECTURE_DIAGRAM.png`
- `engineering/r23/R23_OWNER_HANDOFF_TEXT.md`
- `engineering/r23/R23_SYSTEM_EVIDENCE_INTAKE.md`
- `engineering/r23/R23_SYSTEM_EVIDENCE_SCHEMA.json`
- `engineering/r23/R23_SYSTEM_EVIDENCE_TEMPLATE.json`
- `engineering/r23/R23_TEST_REPORT.md`
- `engineering/r23/R23_VENDOR_QUESTIONS.md`
- `engineering/r23/THREE_NOR_NAND_REVIEW.md`
- `engineering/r23/VIDEO_CHAIN_REVIEW.md`
- `engineering/r23/architecture.json`
- `engineering/r23/bt820_sources.json`
- `engineering/r23/logs/R22_BEFORE_R23_BASELINE.log`
- `engineering/r23/logs/R23_ARCHITECTURE_CHECK.json`
- `engineering/r23/logs/R23_NPM_TEST.log`
- `engineering/r23/logs/R23_PACKAGE_FACTS.log`
- `engineering/r23/storage_sources.json`
- `engineering/r23/video_sources.json`
- `r23-architecture.js`
- `r23-evidence.js`
- `tests/r23_node.cjs`

