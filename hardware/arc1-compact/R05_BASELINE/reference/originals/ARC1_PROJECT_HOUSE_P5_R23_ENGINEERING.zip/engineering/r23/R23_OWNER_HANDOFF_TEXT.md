# Exact R23 owner handoff text extraction

Source SHA-256: 007186705ecdde8a22860b0c287a3baaeb622cf526f9c1b7b22f9ca66a9e0d2a

All active paragraph text retained in order; DOCX remains the authority for tables/diagram/layout. The diagram is architectural, not PCB geometry.

## word/document.xml

ASSISTED RISC CONSOLE  /  PERMANENT MOTHERBOARD

ARC-1

R23 ARCHITECTURE

Engineering specification, revision crosswalk & 14-agent continuation guide

12 October 2026     •     Architecture decision baseline     •     Not fabrication-ready

This document makes the latest owner decisions explicit so 14 ongoing engineering agents can preserve valuable prior work while retiring superseded hardware assumptions. It identifies selected architecture, qualified facts, proposed interfaces, tests, and unfinished electrical dependencies.

Diagram is architectural, not a schematic. Dotted/interfaced paths marked * remain to be validated. Memory is physically independent at all four devices.

LOCKED PROJECT DECISIONS

CURRENT BASELINE

Console identity

ARC-1 tabletop console; no internal LCD; external HDMI TV/monitor; wired USB gamepads

Processing

Allwinner F133-B + two Efinix T120F484I4 + Bridgetek BT820B graphics-assist target

Memory

64 + 64 + 128 + 128 MiB = 384 MiB installed volatile memory

Boot flash

3 × 16 MiB dedicated SPI NOR: one each for F133, T120-A, T120-B

Game storage

Separate SPI NAND; capacity/model open. NO eMMC.

Lifetime design rule

One fixed motherboard; improve games, firmware and FPGA logic over approximately ten years.

 

01  Decision authority and scope

Architecture decisions are selected; component compatibility, trace routes and performance are not certified.

This specification defines what ARC-1 is intended to become. It is the migration authority for active agents and supersedes earlier T20 coprocessor, handheld/LCD, reduced-memory and eMMC assumptions. No owner decision here should be silently overturned by an agent, implementation convenience or a previous document.

1.1  Non-negotiable configuration

AREA

OWNER-SELECTED REQUIREMENT

ENGINEERING STATUS

Identity

ARC-1 is a tabletop, wired, HDMI-output videogame console.

SELECTED

CPU

Allwinner F133-B; 64 MiB in-package DDR2; RISC-V CPU remains the game/platform authority.

SELECTED; interfaces to verify

GPU

Efinix Trion T120F484I4 (A); programmable permanent GPU, dedicated 128 MiB LPDDR2.

SELECTED; DDR/clock feasibility OPEN

Accelerator

Second T120F484I4 (B), independent 128 MiB LPDDR2; game-specific configurations.

SELECTED; DDR/link feasibility OPEN

2D/video assist

Bridgetek BT820B with independent 64 MiB ×16 LPDDR2; live video/overlays/composition route to evaluate.

TARGET; integration OPEN

Main video

External HDMI with 720p60 and 1080p60 targets; IT6263N bridge candidate.

TARGET; complete chain OPEN

NOR

Three identical-capacity 16 MiB SPI NOR parts, one per CPU/FPGA.

CAPACITY LOCKED; SKU/partitions OPEN

Game library

Independent SPI NAND without eMMC; standard USB storage may assist loading and recovery.

TECHNOLOGY SELECTED; SIZE OPEN

Longevity

Maximize useful interconnect, recovery and programming headroom on the original permanent motherboard.

DESIGN PRINCIPLE

1.2  Evidence classification

Use one of six evidence states on every claim: SELECTED DESIGN; MANUFACTURER DOCUMENTED; PROPOSED IMPLEMENTATION; EDA VERIFIED; PROTOTYPE MEASURED; MANUFACTURING RELEASED. A selected architecture is never equivalent to Efinity/STA closure, board-level signal integrity, a working monitor, or an assembled first boot.

Project House currently reports source-backed package-ball data and running software validation; it does not contain a signable electrical netlist or independently verified R23 schematic.

02  Hardware block responsibilities

2.1  F133-B — primary system and game CPU

Run system firmware, game executable logic, input and scheduling, loader, update/recovery control, storage services, sound sequencing, system observability and platform ABI. Its 64 MiB DDR2 is physically internal to the CPU package. It submits renderer commands and accelerator jobs rather than transporting every intermediate graphics result.

2.2  T120-A — permanent GPU

Host GPU command front-end; graphics command queues; programmable 2D/2.5D/3D pipelines; local frame/depth/texture buffers; own LPDDR2 controller; inter-FPGA accelerator dispatch; video stream toward the BT820B; performance counters and fault reporting. Its GPU configuration may evolve under a stable platform/SDK compatibility contract.

2.3  T120-B — game-configurable super-system

A second equal-class Trion FPGA, not the historical T20. It owns a separate 128 MiB LPDDR2 pool and may accelerate geometry, visibility, particle systems, physics, transforms, raster sub-jobs, procedural content or title-specific algorithms. Results can be returned into A-owned buffers through the inter-FPGA link, or in compact form to the CPU when they affect authoritative game state.

2.4  BT820B — professional 2D/video subsystem

The BT820B is the chosen evaluation target for display-list/2D UI functions, asset/video-oriented operations and final composition. It has 64 MiB independent LPDDR2 memory (proposed Alliance ×16 device). Manufacturer material documents DDR3/DDR3L/LPDDR2 support, dual-channel LVDS input/output and high-resolution live-video features. Its actual suitability for ARC-1’s proposed T120-A → BT820B → HDMI video chain is NOT yet verified.

Do not treat BT820B as a general-purpose hardware 3D triangle GPU. Do not assume a PNG/ASTC decoder automatically writes into T120 memory: bridging memory domains requires an explicit, measured transfer design.

03  Memory: three balanced 128 MiB systems

LOGICAL GROUP

PHYSICAL MEMORY

INTERFACE / PEAK

OWNER

Base system: 128 MiB

F133: 64 MiB DDR2 + BT820B: 64 MiB LPDDR2

BT820B ×16, 800 MT/s → 1.6 GB/s theoretical

CPU + 2D/video assist

Super-system A: 128 MiB

T120-A: 1 Gbit 32M ×32 LPDDR2

×32, 800 MT/s → 3.2 GB/s theoretical

Permanent GPU

Super-system B: 128 MiB

T120-B: 1 Gbit 32M ×32 LPDDR2

×32, 800 MT/s → 3.2 GB/s theoretical

Game-specific hardware

Total installed volatile RAM: 384 MiB. The three logical 128 MiB groups are NOT shared memory or a 384 MiB unified address space.

The 3.2 + 3.2 + 1.6 = 8.0 GB/s figure is only the sum of theoretical local-interface ceilings, not useful system throughput; simultaneous access, refresh, arbitration, source bandwidth and cross-chip links reduce effective application rates.

3.1  Memory part families (targets, not approved BOM)

DEVICE

CANDIDATE MEMORY PART

ORGANIZATION

REQUIRED PROOF

T120-A / B

Alliance AS4C32M32MD2A-25BIN (each)

1 Gbit; 32M ×32; LPDDR2-800

Efinity DDR_0 1 Gbit ×32 generation, clocks, rails, timing, package nets, board SI

BT820B

Alliance AS4C64M16MD2A-25BIN

1 Gbit; 64M ×16; LPDDR2-800

BT820 memory controller setup, MRS/training/init and exact interface pin compatibility

Component families are manufacturer-listed; same LPDDR2 technology does not make the DRAM footprints, pin functions or controllers interchangeable. Each device gets its own complete, routed, independently tested memory channel.

04  Physical interconnect and bandwidth plan

PATH

DESIGN INTENT

OPEN HARDWARE/PROTOCOL TEST

F133 → T120-A

RGMII Gigabit-MAC-based high-speed host path; independent low-speed SPI rescue and diagnostics.

F133 pinmux, MAC-to-fabric PHY/fixed-link behavior, Efinix MAC/IP integration, clock and skew, retries; driver support.

T120-A ↔ T120-B

Wide, bidirectional, flow-controlled data stream; direct accelerator results avoiding CPU bulk copies.

Legal pins, common bank rails, lane width, clock rate, CDC, SI, CRC, backpressure, reset isolation, useful bandwidth.

T120-A → BT820B

Live framebuffer/video transport from programmable GPU into BT820B LVDS receiver.

Pixel format, dual-LVDS mappings, synchronization, timing/latency, signal levels, bandwidth, scaling and video tearing.

BT820B → IT6263N

Composited LVDS stream into LVDS-to-HDMI bridge for monitor.

Dual-channel mapping, 720p60/1080p60 bridge support, PLLs, EDID/HPD, DDC, ESD, TMDS and audio.

F133 / T120-A → BT820B

SPI/QSPI command/asset control route, final bus master OPEN.

Ownership/arbitration, upload speed, asset load latency, contention with NOR/NAND and bus-voltage compatibility.

F133 ↔ USB controllers

Wired USB HID gamepad input, optional hub and removable media.

Host-mode pins, 5 V source, current limits, hub topology, ESD, enumeration/reconnect.

F133 ↔ storage

Independent NOR boot and separate game SPI NAND.

Supported controller mode, bad-block ECC, boot-strap conflicts, image authenticity and power-loss recovery.

4.1  Explicit rate calculations

RGMII 1 Gbit/s corresponds to 125 MB/s raw line rate before framing/protocol costs. LPDDR2-800 ×32 corresponds to 3.2 GB/s theoretical; ×16 corresponds to 1.6 GB/s. One 1920×1080×60 RGB888 active pixel stream is approximately 373.25 MB/s; 32-bit pixel data would be approximately 497.66 MB/s if carried uncompressed as full RGBA. These are planning calculations, not hardware performance guarantees.

Standard 1080p60 transport typically uses 148.5 MHz pixel timing including blanking. This must be reconciled with the BT820B’s dual-link LVDS and the chosen HDMI bridge input constraints, not inferred from display resolution alone.

05  Three independent SPI NOR devices

LOCKED: 3 × 16 MiB = 48 MiB NOR total. Each processing device has its own physical SPI NOR.

NOR DEVICE

CAPACITY

INTENDED CONTENT / ACCESS

UNRESOLVED

NOR-F133

16 MiB (128 Mbit)

Bootloader, system firmware and minimal CPU rescue image.

F133 boot-mode compatibility, write protect, A/B firmware packing and recovery tooling.

NOR-T120-A

16 MiB (128 Mbit)

Known-good GPU configuration plus update/recovery metadata and space as proven.

Actual Efinity binary size, boot mode, golden protection and independent JTAG rescue.

NOR-T120-B

16 MiB (128 Mbit)

Known-good accelerator shell / safe configuration, local configuration staging as viable.

Game-specific loading route, practical erase/write endurance, rollback versus bitstream size.

Do NOT promise simultaneous golden + active + rollback images in every 16 MiB NOR until measured image lengths and erase-block layout prove they fit. Do NOT rewrite B NOR on every game launch by default: test a safe passive configuration or RAM-staged route before choosing an endurance-sensitive workflow. Both FPGAs need independently accessible debug/programming and a mechanism to avoid bus contention when an external controller programs a NOR.

5.1  Separate game library

Use separate SPI NAND for game binaries, art, music, compressed resources, cutscenes and game-specific T120-B configuration files. Capacity remains OPEN. NAND implementation needs verified F133 pinmux, ECC, factory and grown bad-block management, wear leveling, atomic metadata, signed/hashed files as appropriate, and interrupted-update testing. eMMC is explicitly prohibited; a mechanical hard drive is not required.

5.2  Proposed cold boot sequence

Power supervisor holds reset and high-impedance interfaces until valid supply rails and clock conditions.

F133 boots from dedicated NOR-F133; both T120s enter documented known-safe configuration paths from their own NORs, each independently recoverable.

Perform serial diagnostics and hardware identity handshake even if display fails; train and stress-check both T120 LPDDR2 channels.

Initialize BT820B controller and its independent 64 MiB LPDDR2; configure the LVDS/HDMI path; establish monitor EDID/HPD and audio route.

Mount SPI NAND through ECC/bad-block-aware driver; show launcher; authenticate game metadata and select compatible accelerator package.

Quiesce T120-A/B job link, revoke DMA/window grants, load validated B game image through the verified configuration method, check B identification, then enter gameplay.

On failure, preserve diagnostic reason and revert to known-good shell or external programmer path; no required recovery step may rely on the failed user logic.

06  Graphics, SDK and ten-year software trajectory

6.1  Rendering split

F133 executes game code; T120-A builds programmable rendering pipelines and makes scanout-ready video; T120-B performs high-value custom math/graphics work with its own RAM; BT820B draws/composes final 2D/video layers as its capabilities and measured timing permit. The IT6263N candidate converts the final compatible LVDS interface to HDMI. The design may use reduced internal 3D render resolution with high-quality scaling, but 720p60 and 1080p60 are output mode targets, not unmeasured rendered-scene guarantees.

6.2  Stable ABI and capability boundaries

Preserve the good prior ARC-LINK concepts but update names and transfer semantics from T20/borrowed GPU RAM to T120-B/independent RAM. Core ideas to salvage: HELLO/IDENTIFY, SUBMIT_JOB, JOB_DONE, faults, bounded buffer capabilities, generations, sequence IDs, CRC, timeouts, flow-control, memory fences and instrumentation. Payload reads and writes now cross separate memory controllers and may require explicit DMA staging on both sides.

CPU/game-facing conceptual SDK: gpu_alloc(), gpu_submit(), accel_load(), accel_grant(), accel_submit(), fence_wait(), trace_read(), display_set_mode(). Names above are architectural sketches, not final C headers or a frozen ABI. An FPGA bitstream is a versioned executable hardware artifact, bound to a declared protocol shell and compatible application.

6.3  Ten-year original-board policy

Ten-year life means improved programming, better algorithms, FPGA RTL, asset formats and late-generation games on the SAME hardware; it does not mean that manufacturers guarantee ten years of active component supply. Preserve build reproducibility, original Efinity versions/licenses, design sources, golden bitstreams, PCB/CAD revision history, SDK tests, compiler/toolchain containers and repair/flash procedures so work remains understandable in 2036 and beyond.

07  R22 DEV-002 package: audited migration map

In-scope user upload: ARC1_PROJECT_HOUSE_P5_R22_DEV002.zip, 47 files. Independently extracted and executed npm test against Node 22.16.0 in the current working environment; exit code 0. This is a software baseline result only. The existing bundle reports 968 Efinix T120F484 package-ball records, 10 roadmap tasks and 30 offline assets; it does NOT assign PCB nets.

R22 CONTENT

R23 DISPOSITION

ACTION FOR ACTIVE AGENTS

index.html, house.js/css, viewer.js/css, assets, offline PWA

KEEP

Preserve six departments: House, Viewer, Systems, Lab, Manual, Archive. Reword hardware labels where needed.

pins.json and Efinix T120 pinout spreadsheet

KEEP UNMODIFIED

Preserve 484 source-derived balls for A and 484 for B; do not invent assignment or alter vendor workbook.

evidence.js, evidence-ui.js, schema/templates

KEEP + EXTEND

Reuse strict parser, provenance, hashed artifacts and read-only checks. Add R23 component, NOR and video evidence types without weakening rules.

DEV-002 tests and software test harness

KEEP + EXPAND

Maintain passing regression baseline; add fixtures for R23 video/3-NOR constraints and schema migrations.

R22 handoff, work order, roadmap

REVISE

R23 overrides storage, 2D composition, HDMI/video pipeline, 384 MiB totals; do not mark hardware gates closed.

Old F133–T120–T20 interconnect v0.1/v0.2

SALVAGE CONCEPTS

Retain framing, queueing, grants, fences, debug and lifecycle. Replace T20 topology, bus-width assumptions and shared GPU-RAM service.

Old R19 DDR_0 DDR example

SALVAGE WORKFLOW

Keep genuine Efinity report-generation method; correct old 256 Mbit size and LCD/SDIO assumptions.

OverDrive hardware exploration

SALVAGE RESEARCH

Reuse host RGMII, watchdog, rails, profiling, FRAM and recovery studies. Update old assertion against fourth chip.

T20 RTL and 480×800 LCD assumptions

RETIRE AS ARCHITECTURE

Source concepts may inform new logic; no T20 device, handheld PCB, portrait LCD or display cable in current ARC-1.

eMMC planning

RETIRE

No eMMC. Separate SPI NAND remains capacity TBD, with three dedicated 16 MiB NORs.

7.1  Existing Project House DEV-002 evidence caveats

Current Node tests passing do not equal a successful interactive desktop browser test, Efinity run, real pin allocation, schematics or functioning DDR/HDMI. The uploaded changelog explicitly retains gates G01–G11 as OPEN and says no PCB fabrication authorization. Continue respecting that evidence hierarchy.

08  Fourteen parallel agent workstreams

These are recommended assignments for the 14 active agents, not a claim about their current identities. Map each ongoing branch to the nearest workstream before discarding existing work. Every agent must produce a salvage inventory, exact changed files, evidence, blockers, remaining R23 discrepancies and next test.

Agent 01  /  R23 architecture reconciler  [P0]

Write machine-readable R23 authority and crosswalk; identify contradictions without overwriting historical records.

Minimum deliverable: R23 decision registry + migration diff.

Agent 02  /  F133 boot/NOR engineer  [P0]

Verify 16 MiB boot NOR, strap/pinmux, firmware split, watchdog and rescue UART.

Minimum deliverable: CPU boot-flash schematic candidate + verified source citations.

Agent 03  /  T120-A Efinity DDR engineer  [P0]

Generate authentic T120F484I4 DDR_0 LPDDR2 ×32 1 Gbit configuration with Alliance part.

Minimum deliverable: Original Efinity project/reports/constraints + actual errors.

Agent 04  /  T120-B Efinity DDR engineer  [P0]

Independently repeat DDR_0 and full interface resource study on B.

Minimum deliverable: Original B Efinity files + conflicts and memory geometry.

Agent 05  /  Dual-FPGA link RTL engineer  [P0]

Design throughput-based link and simulation with independent memories, reset and CRC.

Minimum deliverable: Parameterized RTL+testbench + traffic/bandwidth models.

Agent 06  /  RGMII + SPI host engineer  [P0]

Prove MAC/fixed-link model, pinmux and rescue transport compatibility.

Minimum deliverable: Linux/bare-metal driver and FPGA endpoint feasibility notes.

Agent 07  /  BT820B 2D/video engineer  [P0]

Validate 64 MiB LPDDR2 init, video input composition, SPI/QSPI controls and display-list asset strategy.

Minimum deliverable: BT820 register/init model, I/O timing/latency evidence.

Agent 08  /  HDMI + audio engineer  [P0]

Prove BT820B LVDS output compatibility with IT6263N, monitors, EDID, HPD, DDC and stereo audio.

Minimum deliverable: Video chain schematic and timing feasibility dossier.

Agent 09  /  Three-NOR recovery engineer  [P0]

Analyze image sizes, golden safety, flash mux/write-protect and independent programmer paths.

Minimum deliverable: Three 16 MiB NOR capacity proof and recovery state machine.

Agent 10  /  SPI NAND game-library engineer  [P0]

Select NAND class/capacity evidence, ECC/wear leveling, F133 controller and power-loss-safe filesystem.

Minimum deliverable: Capacity study, flash-driver tests and update rollback plan.

Agent 11  /  Power, PCB & SI engineer  [P0]

Create rails, sequencing, reset domains, thermal loads, BGA escape and controlled-impedance rulebook.

Minimum deliverable: Validated engineering constraints + preliminary BOM/power tree.

Agent 12  /  Firmware / game SDK engineer  [P1]

Refactor T20 ABI/loader architecture for T120-B own 128 MiB memory; capability/fence/error contracts.

Minimum deliverable: Protocol/manifest draft + negative/fault test vectors.

Agent 13  /  Project House / evidence engineer  [P1]

Extend DEV-002 intake, viewer documentation, roadmap and offline tests to R23 without falsifying EDA success.

Minimum deliverable: Passing npm tests + source-backed R23 UI state.

Agent 14  /  Verification / archival lead  [P0]

Integrate all source registers, tests, checksums, hardware gates, reproducibility and cross-agent conflicts.

Minimum deliverable: Signed-off evidence matrix; explicit NO-GO until proven.

09  Pre-fabrication hardware acceptance gates

GATE

TOPIC

CLOSURE REQUIREMENT

G01

T120-A/B DDR_0

Independent authentic Efinity designs: ×32 LPDDR2-800; 1 Gbit geometry, exact F484 banks, PLL/clock, chip timing, routing and calibration; 128 MiB per T120.

G02

Video/HDMI electrical path

Legal T120-A LVDS TX → BT820B LVDS RX → BT820B LVDS TX → IT6263N LVDS RX; correct modes, DDC/EDID/HPD, audio, monitor acceptance.

G03

A↔B link

Realized pin/rail/legal-clock plan; RTL handshake, CRC, independent DDR transfers; bandwidth and robustness under rendering.

G04

F133 host link

RGMII MAC→fabric/fixed-link demonstration with genuine driver support; independent SPI rescue; pinmux/clock/skew proof.

G05

Three NOR + NAND recovery

Exact capacity and golden-image proof for three 16 MiB NOR devices; correct dual-FPGA rescue ownership; bad game NAND does not brick console.

G06

USB devices

Gamepad(s) enumerate/reconnect, hub if needed, ESD/overcurrent protection and real firmware drivers.

G07

Power and thermal

Worst-case active F133+BT820B+2×T120+3×external LPDDR2+bridge+USB measured after electrical budgets.

G08

Whole-system pins + PCB

Complete Efinity constraints, correct bank rails, PCB ERC/DRC and SI; legal BGA pin allocation; no hidden shared-resource collision.

G09

Measured bring-up

Repeat cold boots, DDR stress, video, controls, inter-chip traffic, safe reprogramming, watchdog and recovery under fault injection.

G10

Video/asset IP and licenses

Permissible IP/software licenses, BT820 decompression format support, golden vectors and actual throughput/FPGA-area savings.

G11

2036 reproducibility

Archived toolchains, primary sources, firmware images, constraints, BSP/SDK interfaces and independent programming/repair manuals.

G12

BT820B memory + composition

Exact Alliance ×16 device configured at 800 MT/s; overlaying live high-res video plus assets at sustained frame rate, bounded latency.

G13

NOR bitstream size & endurance

Real Efinity image sizes, partition/erase layout, write protects, power-loss outcomes and B game-switching endurance.

G14

NAND filesystem

Controller ECC/OOB, bad-block handling, large game package reads, power-loss safety and versioned update rollback.

R23 overall hardware release: NO-GO. A passing software test, datasheet statement or preliminary schematic cannot close G01–G14.

10  Priority order: keep agents productive without PCB guesswork

Phase A — immediate, parallel, no hardware needed

Freeze this R23 decision register, preserve immutable original pin workbook and DEV-002 evidence core.

Compile existing source and run npm test before rewriting any PWA layer; save a baseline and file hashes.

Generate independent Efinity A and B reports; start vendor BT820 DDR/LVDS feasibility and manufacturer application-note analysis.

Design and simulate A↔B packets and memory transfer fences using independent 128 MiB model address spaces.

Extract and count genuine A/B bitstream sizes for 16 MiB NOR plans; do not invent partitions or commit to per-game NOR rewrites.

Phase B — combined electrical integration

Overlay both FPGA package-bank plans with DDR, LVDS, host RGMII, debug, three NOR devices, NAND and inter-FPGA data lanes.

Select the actual BT820 video chain, bridge mappings and clocks from vendor sources; write down mismatched timing explicitly.

Derive regulator/current/power budgets and sequencing from verified source maxima and measured engineering-board data when possible.

Build a full-system recovery-path fault tree with CPU absent, FPGA-A absent, FPGA-B invalid and NAND corrupt scenarios.

Phase C — physical prototype release

Authorize schematic and PCB only after Efinity package legality, parts availability, interface viability and signed verification gates.

Prototype first boot; measure simultaneous memory, host and video operation; archive working images and logic analyzer logs.

Produce a reproducible service/programming manual and archive exact hardware/software revisions.

11  Instructions to send every ongoing agent

AGENT CONTINUATION DIRECTIVE — ARC-1 R23 (12 OCTOBER 2026)

You are continuing an existing ARC-1 workstream whose prior assumptions may be obsolete. First inventory all work and DO NOT delete valuable source, CAD, RTL, tests or prior evidence. Compare your branch against the R23 architecture: tabletop HDMI; F133-B with 64 MiB DDR2; T120-A and T120-B each 128 MiB ×32 LPDDR2; BT820B 64 MiB ×16 LPDDR2; 3 × 16 MiB dedicated SPI NOR; separate game SPI NAND; no eMMC, no T20, no handheld LCD. Preserve the DEV-002 evidence model and immutable manufacturer package-ball inventory. Identify which artifacts are KEEP, ADAPT, RETIRE or BLOCKED. Implement only work supported by exact source/EDA evidence; preserve unknown pins/timing as UNKNOWN. Run existing tests, add reproducible tests and output source hashes, exact files changed, unclosed gates and your next experiment. Never claim completed hardware proof from code-only validation.

Required agent return format

FIELD

REQUIRED CONTENT

Branch / original objective

Exact current branch name or task ID; latest commit/revision and upstream files.

Salvage inventory

KEEP / ADAPT / RETIRE / BLOCKED with evidence and file paths.

R23 architecture conflicts

Specific obsolete assumptions and the minimal correction needed.

Changes made

File-by-file diff summary, APIs/interfaces impacted and test fixture changes.

Executed proof

Commands, versions, logs, source reference, measured/generated values; no inferred PASS.

Still OPEN

Gate IDs G01–G14, blocker owners and required primary vendor evidence.

Proposed next step

One bounded action that creates an inspectable artifact, not a general promise.

12  R23 open decision register

ID

UNLOCKED DECISION / VALIDATION

STOP CONDITION

D-01

Exact T120F484I4 hard DDR_0 capability, LPDDR2 ×32 1 Gbit mapping, clock and Alliance part compatibility.

No PCB pin lock without native Efinity evidence.

D-02

BT820B 64 MiB LPDDR2-800 specific part, power rails, pad map, performance and working initialization.

No video subsystem footprint approval without proven memory path.

D-03

LVDS-A→BT820B→IT6263N dual-link format, high-res 60 Hz timing and audio route.

No HDMI output sign-off without end-to-end timing model.

D-04

T120-A/B physical high-throughput interface width, clocks and CRC/flow-control protocol.

No routing assumptions or throughput promises.

D-05

F133 RGMII endpoint mode and fallback SPI electrical plan.

No exclusive bus/pinmux allocations until checked.

D-06

Three identical 16 MiB NOR orderable part number, actual boot geometry and golden/active partitioning.

No rollback guarantee until compiled images fit.

D-07

SPI NAND density, manufacturer/part, ECC, wear leveling, filesystem/driver, pinmux.

No silent switch to eMMC.

D-08

Power rail tree, DC input, fan/no fan, enclosure dimensions, USB hub and connectors.

No invented thermal, mechanical or cost assumptions.

D-09

Which processor commands BT820B; how assets cross memory pools; frame buffer sharing protocol.

No claims of direct memory access between devices.

D-10

Exact sound source/I2S path to HDMI bridge and PC-side debug/programmer hardware.

No audio/recovery gate closure by inference.

13  Source register and reproducibility

Source classifications: [U] user-furnished current-turn ZIP or known earlier engineering document; [M] vendor primary material; [R] secondary component listing. URLs identify documents to archive with date/version. These sources establish capabilities or earlier decisions—not proof of the R23 board.

[U1] ARC1_PROJECT_HOUSE_P5_R22_DEV002.zip (47 files); README_FIRST.md; CLAUDE.md; R22_DEV002_CHANGELOG.md; R22_DEV002_TEST_REPORT.md; R22_TABLETOP_SYSTEM_WORK_ORDER.md; tasks/roadmap.json; engineering/T120_pinout_v1.4.xlsx.

[U2] ARC1_THREE_CHIP_INTERCONNECT_R02_128MiB.docx (older F133–T120–T20 data flow, packet/ABI/verification concepts; topology superseded).

[U3] ARC1_OverDrive_Ideas_v1.docx (earlier RGMII, watchdog, profiling, boot-flash and debug ideas; T20 assumptions superseded).

[U4] ARC1_EFINITY_DDR0_HANDOFF.md (Efinity procedural model; references R19 geometry and obsolete LCD/SDIO assumptions).

[M1] Efinix Trion T120 documents and official T120F484 package pinout: https://www.efinixinc.com/support/docs.php?p=t

[M2] Efinix Trion DDR DRAM Block User Guide: https://www.efinixinc.com/support/docsdl.php?pn=UG-DDR-DRAM&s=ef

[M3] Efinix Trion Interface User Guide: https://www.efinixinc.com/support/docsdl.php?pn=UG-TINTF&s=ef

[M4] Allwinner F133 vendor product brief: https://www.allwinnertech.com/uploads/pdf/20211016141154e7.pdf

[M5] Bridgetek BT820B product and BT820 datasheet: https://brtchip.com/product/bt820b/ ; https://brtchip.com/wp-content/uploads/2024/10/DS_BT820.pdf

[M6] Alliance 1 Gbit LPDDR2 component family and two organizations: https://www.alliancememory.com/product/lpddr2-mobile-ddr2/ ; https://www.alliancememory.com/as4c64m16md2/

[M7] Efinix T120 development-board LVDS/IT6263N example: https://www.efinixinc.com/docs/trion120f576-devkit-ug-v2.3.pdf (F576 example is not an F484 pin validation).

[M8] Efinix Triple-Speed Ethernet MAC IP: https://www.efinixinc.com/support/ip/tse-mac.php (IP availability does not establish F133 fixed-link operation).

[R1] Alliance AS4C64M16MD2A-25BIN distributor listing: https://www.digikey.com/en/products/detail/alliance-memory-inc/AS4C64M16MD2A-25BIN/9664078 (stock/price time-variable).

Local independent validation for this handoff: ZIP unzipped from /mnt/data/ARC1_PROJECT_HOUSE_P5_R22_DEV002.zip; npm test executed in project root with Node 22.16.0; process exit 0; log retained during authoring. This statement certifies neither original pre-agent file claims nor a live browser integration run.

13.1  Change log

REVISION

DELTA

R22 / Pass 05

Dual T120 tabletop architecture, 320 MiB CPU+2 GPU memory proposal, HDMI bridge, independent recovery principle. DEV-002 builds source-preserving evidence intake.

R23 / 12 October 2026

Add BT820B + 64 MiB ×16 LPDDR2 to produce 384 MiB total; make BT820B composition the display-chain candidate; lock three independent 16 MiB NOR flash chips; explicitly prohibit eMMC; retain separate SPI NAND of unknown capacity; provide 14-agent crosswalk.

R23 documentation status

ARCHITECTURAL HANDOFF ONLY. Electrical pinlock, complete netlist, Efinity proof, board design and manufacturing authorization remain OPEN.

## word/header1.xml

ARC-1   /   ENGINEERING ARCHITECTURE & AGENT HANDOFF

## word/footer1.xml

R23  •  12 OCT 2026     |     DESIGN AUTHORITY ≠ FABRICATION APPROVAL     |     
