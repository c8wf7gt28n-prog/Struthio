# ARC-1 R22 → R23 migration record

Date: 2026-10-12. Authority: the **complete** owner-furnished [ARC1_R23_Handoff.docx](ARC1_R23_Handoff.docx), with readable extraction [R23_OWNER_HANDOFF_TEXT.md](R23_OWNER_HANDOFF_TEXT.md). R23 is the current architectural baseline. Historical R22 records describe prior selected assumptions and research; they are retained, not edited into apparent R23 evidence.

Release status: **G01–G14 OPEN; hardware NO-GO**. Software regression, source inspection and arithmetic cannot close these gates. The owner diagram is architectural, not CAD, a signable electrical netlist or a placement drawing.

## Current decisions and precise limits

R23 preserves tabletop ARC-1, external HDMI and wired USB gamepads, F133-B with 64 MiB in-package DDR2, and separate T120F484I4 A/B devices with 128 MiB ×32 LPDDR2 targets each. It adds the **BT820B target with a separate 64 MiB ×16 LPDDR2 goal**. The selected total is **384 MiB across four independent physical pools**; three logical 128 MiB groupings do not create shared memory.

The selected video evaluation chain is **T120-A → BT820B → IT6263N candidate → HDMI**. BT composition and 720p60/1080p60 remain goals requiring an actual clock/format/memory/latency demonstration. BT is not assumed to be a general 3D triangle GPU or to decode directly into T120 memory.

Storage is locked to **three physical 16 MiB NOR devices**, one per F133/A/B, plus **separate game SPI NAND with capacity/SKU OPEN**. No eMMC. Each FPGA must have its own safe self-boot and independent programming/recovery. Temporary passive B loading is a proposal to avoid rewriting NOR on every game launch; fit, partitions, protection and endurance need authentic payloads and device specifications.

## File-level salvage inventory

| Disposition | Concrete files/artifacts | Action and evidence boundary |
| --- | --- | --- |
| KEEP UNMODIFIED | `pins.json`; `engineering/T120_pinout_v1.4.xlsx`; `engineering/R22_T120_PACKAGE_BALLS_UNASSIGNED.csv` | Preserve 484 manufacturer package-ball records for A and 484 for B. They remain unassigned package definitions, not 968 electrical nets. BT/bridge/DRAM inventories require separate exact sources. |
| KEEP | `evidence.js`; legacy `arc1-evidence-v1` schema/JSON/CSV templates; `tests/evidence_node.cjs`; `tests/intake_ui_node.cjs` | Retain strict legacy intake, provenance, artifact hashing and read-only A/B pin/bank checks. Do not reinterpret it as a native Efinity or whole-R23 parser. |
| KEEP | Six departments in `index.html`, `house.js`, `house.css`, `viewer.js`, `viewer.css`; existing assets and offline-first structure | Preserve House, Viewer, Systems, Lab, Manual, Archive and the existing visual/navigation decisions. Keep unavailable-geometry circle/slash placeholders. No fabricated PCB/enclosure geometry. |
| KEEP AS HISTORY | `engineering/R22_TABLETOP_SYSTEM_WORK_ORDER.md`; R22 handoff/evidence/test/change records; `engineering/architecture/*`; `engineering/history/r22/CLAUDE.md` | Retain prior source/review artifacts with historical revision labels. Their R22 totals, direct display topology and storage suggestions are not current authority. |
| ADAPT | Active `CLAUDE.md`, README/handoff entry points, `tasks/roadmap.json`, system/House/Lab/Manual labels and offline manifests | Point working instructions at R23; show BT target, 384 MiB goal, four physical pools, three dedicated 16 MiB NORs, separate SPI NAND and G01–G14 OPEN. Preserve history links and existing design. |
| ADAPT | `architecture.js`, `architecture-ui.js`, the active architecture decision registry and associated regression checks | Distinguish selected goals, manufacturer facts, proposals and unresolved conflicts. Never turn a source citation or successful calculation into hardware certification. |
| ADAPT BY ADDITION | `r23-evidence.js`; `engineering/r23/R23_SYSTEM_EVIDENCE_SCHEMA.json`; template/intake documentation; `tests/r23_node.cjs` | Add explicitly declared R23 system evidence alongside the legacy importer. Check memory/component/video/three-NOR declarations, real payload/geometry inputs and absence of forbidden topology assumptions. Native vendor adapters remain blocked on authentic samples. |
| ADAPT BY NEW REVIEW | `BT820_MEMORY_VIDEO_REVIEW.md`, `VIDEO_CHAIN_REVIEW.md`, `THREE_NOR_NAND_REVIEW.md` and their source registries in this directory | Reconcile manufacturer constraints with R23 without assigning nets, clocks, parts or regulator budgets by inference. These are proposed/source reviews, not EDA or hardware results. |
| RETIRE AS CURRENT ASSUMPTION | R22 direct A→IT6263/HDMI display baseline and omission of BT820B | Keep historical research; budget current A→BT and BT→bridge interfaces. No silent BT bypass. |
| RETIRE AS CURRENT ASSUMPTION | R22 generic/centralized protected flash proposal, default F133-only FPGA cold loader, SMHC0 games-storage suggestion and any eMMC plan | Replace current topology with three own NOR self-boots and separate SPI NAND. Preserve independent supervisor/service concepts. Final control-bus arbitration remains OPEN. |
| RETIRE AS CURRENT ARCHITECTURE | T20 topology/shared GPU-RAM service, portrait 480×800 LCD, handheld board/assets and reduced-memory assumptions | Only framing, queues, grants, generations, fences, fault recovery and report-generation concepts can be salvaged after the real source artifacts are inspected. No old device/geometry is imported. |
| BLOCKED SOURCE SALVAGE | Owner references U2 `ARC1_THREE_CHIP_INTERCONNECT_R02_128MiB.docx`; U3 `ARC1_OverDrive_Ideas_v1.docx`; U4 `ARC1_EFINITY_DDR0_HANDOFF.md` | These referenced artifacts are not present in this workspace/attachment set. Record their intended salvage subjects; do not claim a full review or fabricate their contents. |

KEEP means preserve the valuable artifact, not promote its evidence level. RETIRE applies to its current architectural assumption, not deletion of historical work. ADAPT entries identify migration scope; final executed validation belongs in the delivery test/change report.

## Contradictions and unavailable proof

1. **BT memory density:** R23 selects 64 MiB but names `AS4C64M16MD2A-25BIN`, a 1 Gbit ×16 part that represents **128 MiB installed**. That candidate would produce 448 MiB total. Preserve the owner's 64 MiB/384 MiB goal and expose the conflict; a software cap cannot change physical capacity. A compatible orderable **512 Mbit ×16** LPDDR2 part or an explicit owner change is required. No replacement is selected here. See [BT memory review](BT820_MEMORY_VIDEO_REVIEW.md).
2. **Standard output-clock strategy:** the reviewed BT82X documented 38.4 MHz reference, multipliers 13/15 and integer divider do not produce 74.25 MHz. Standard 720p60 single-link and 1080p60 dual-link require that per-link rate. A 72 MHz example with unchanged standard totals is about 58.18 Hz, not 60 Hz. Obtain a vendor-supported exact clock or explicitly qualified mode strategy. No undocumented PLL/alternate-reference workaround is invented. See [video review](VIDEO_CHAIN_REVIEW.md).
3. **LVDS/bridge integration:** BT has one clock pair per channel; the reviewed ITE reference has one shared input clock. Never tie two driven outputs together. Eight-bit mapping, odd/even alignment, unused clock handling, actual bridge suffix/register support and audio clock ownership remain OPEN.
4. **Storage proof:** actual F133 rescue payloads and A/B Efinity image lengths are unavailable. Each 16 MiB NOR's fit, erase/protection map, golden/update policy, programmer arbitration and practical endurance remain UNKNOWN. Linux source availability does not prove the exact F133 SPI NAND stack, ECC/OOB layout, pinmux or interrupted-update behavior. See [storage review](THREE_NOR_NAND_REVIEW.md).
5. **Native/physical verification:** no authentic R23 paired Efinity generation/STA/pin reports, finalized schematic/ERC/DRC/SI, full-system power estimator/rail budgets, controlled memory shutdown proof or bench acceptance traces exist here. Browser/PWA interaction also requires an executed browser run; Node tests alone cannot assert installation/offline/browser success.
6. **Ten-year qualification:** existing preliminary Alliance memory power-off/lifecycle questions remain unresolved and now apply to three external memory channels. Manufacturer supply availability and safe power-loss operation cannot be inferred from the ten-year design objective.

## Acceptance gates retained

| Gate | R23 subject | Status |
| --- | --- | --- |
| G01 | Independent A/B DDR_0, exact ×32 LPDDR2-800/1 Gbit/F484 configuration and channel proof | OPEN |
| G02 | A→BT→ITE→HDMI complete electrical/video/audio/monitor chain | OPEN |
| G03 | A↔B legal link, independent DDR transfers, integrity and useful bandwidth | OPEN |
| G04 | F133 RGMII endpoint, driver/pinmux/skew and independent SPI rescue | OPEN |
| G05 | Three NOR plus separate NAND and independent recovery | OPEN |
| G06 | USB host/gamepad/hub/ESD/overcurrent behavior | OPEN |
| G07 | Full-system power and thermal budgets then simultaneous-load measurements | OPEN |
| G08 | Whole-system package/bank/clock allocation, PCB ERC/DRC/SI | OPEN |
| G09 | Measured repeatable bring-up and fault/recovery operation | OPEN |
| G10 | Video/asset IP rights, golden vectors and actual resource/throughput benefit | OPEN |
| G11 | Archived reproducible toolchains, sources, images and independent repair procedures | OPEN |
| G12 | Exact BT memory, live composition performance and bounded latency | OPEN |
| G13 | Actual NOR bitstream sizes, protection/partition/endurance/power-loss proof | OPEN |
| G14 | NAND ECC/OOB/bad blocks/filesystem/package reads and update rollback | OPEN |

## Continuation and verification record

The handoff's **fourteen workstreams are recommended engineering roles**, not an assertion that fourteen agents currently exist or that their deliverables are complete. Map active work to those roles and attach concrete KEEP/ADAPT/RETIRE/BLOCKED inventory, changed files, executed proof, remaining gate IDs and one bounded next experiment to every return.

This record is based on the full R23 DOCX and the inspectable source reviews above. It does not assert a new Efinity build, PCB approval, payload capacity pass, browser smoke pass or supplier response. The prepared [vendor questions](R23_VENDOR_QUESTIONS.md) remain unsent drafts. Preserve original inputs and extraction hashes, run the established regression suite for implementation changes, and report exact commands/results separately from hardware status.

Next bounded integration artifact: one versioned R23 feasibility dossier joining the corrected BT memory candidate and supported output-clock plan with authentic A/B Efinity whole-interface projects, three real NOR payload/geometry inputs and the chosen F133 SPI NAND/control-bus resource matrix. Until those artifacts exist, copper lock and fabrication remain NO-GO.

## Current guide and alternative-timing clarification

AN086 v1.4 Table5 documents DDR3/DDR3L presets but omits LPDDR2/512 Mbit encodings, despite DS v1.1 capability statements. Exact LPDDR2 host initialization remains a vendor question. AN097 v1.0 adds manufacturer-tested 72 MHz alternate-blanking HDMI-converter examples; the 74.25 MHz gap applies to standard CTA timing. These examples supply a bounded qualification path, not exact 60 Hz or selected IT6263N proof. No target, memory part or converter is silently substituted.
