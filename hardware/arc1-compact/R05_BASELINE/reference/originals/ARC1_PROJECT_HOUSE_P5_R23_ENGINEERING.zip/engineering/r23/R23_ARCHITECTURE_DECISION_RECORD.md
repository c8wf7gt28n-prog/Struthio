# ARC-1 R23 architecture decision record

Date: 12 October 2026. Branch/task: existing Project House, DEV-002 extension and DEV-003 R23 reconciliation. No Git revision was supplied; delivery source hashes identify the file revision. This record implements the full R23 owner handoff, archived unchanged with SHA-256 `007186705ecdde8a22860b0c287a3baaeb622cf526f9c1b7b22f9ca66a9e0d2a`.

**SOURCE_REVIEW_ONLY. G01–G14 OPEN. Hardware/fabrication NO-GO.** Owner-selected architecture and manufacturer capabilities are conditional until authentic EDA and physical acceptance evidence exists.

## Selected architecture

F133-B remains CPU/platform authority with its internal 64 MiB DDR2. T120F484I4 A is the permanent GPU with independent 128 MiB x32 LPDDR2; B is the game-defined accelerator with independent 128 MiB x32 LPDDR2. BT820B is the final composition target with independent 64 MiB x16 LPDDR2. All four pools are physically separate, with no automatic shared address space or direct cross-device DMA.

Three dedicated 16 MiB SPI NORs serve F133/A/B. Each device must fit its own boot/recovery/update strategy; aggregate 48 MiB does not cover an overflowing image on another NOR. SPI NAND is separate game storage; part/capacity/ECC/filesystem are OPEN. No eMMC is selected.

Video is A LVDS TX→BT LVDS RX→composition→BT LVDS TX→IT6263N candidate→HDMI. RGMII CPU→A is a candidate with independent SPI rescue. A↔B must provide useful full-duplex transport; DDIO widths/native-LVDS lanes and operating clocks are studies, not locked assignments. BT command master, asset-transfer ownership and audio clock/source are OPEN.

```mermaid
flowchart LR
 CPU["F133-B · 64 MiB internal DDR2"] -->|"RGMII candidate / SPI rescue"| A["T120-A · 128 MiB x32 target"]
 A <-->|"Full-duplex candidate · width/clock OPEN"| B["T120-B · 128 MiB x32 target"]
 A -->|"LVDS · mapping/clock OPEN"| BT["BT820B · 64 MiB x16 target"]
 BT -->|"LVDS · two-clock compatibility OPEN"| ITE["IT6263N candidate"]
 ITE --> HDMI["External HDMI monitor"]
 CPU --- NORC["Dedicated 16 MiB NOR"]
 A --- NORA["Dedicated 16 MiB NOR"]
 B --- NORB["Dedicated 16 MiB NOR"]
 CPU --- NAND["Separate SPI NAND · model/capacity OPEN"]
```

Diagram shows functional intent only, with no PCB dimensions, routing or electrical net assignments.

## Immediate qualification issues

1. **Memory discrepancy:** AS4C64M16MD2A-25BIN is 64M×16 = 1 Gbit = 128 MiB. Installing the named candidates makes total RAM 448 MiB, not selected 384 MiB. Preserve the 64 MiB BT target and qualify an exact 512 Mbit x16 device/init, or obtain an explicit owner capacity decision. DS v1.1 documents that controller class, but current AN086 v1.4 Table5 lists only DDR3/DDR3L presets, without LPDDR2/512 Mbit entries. Do not invent the host command encoding.
2. **Standard clock gap:** AN086 v1.4 documents 38.4 MHz × SYSPLL_NS / (2 × (TXCLKDIV+1)), supported multipliers 13/15 and divider1–16. Enumerated settings do not produce standard 74.25 MHz, required for standard720p60 or dual-pixel1080p60. TX PCLK ceiling is83.2 MHz. AN097 contains manufacturer-tested alternate-blanking HDMI adapter examples at72 MHz. Those support a qualification path, not proof of exact60 Hz, ITE compatibility or CTA timing. Conditional arithmetic for the stated example totals yields about60.81/60.73 Hz; actual register/monitor behavior still needs validation. No silent target reduction or converter substitution.
3. **Two LVDS boundaries:** conservatively budget eight A TX data pairs plus two clocks for BT RGB24 dual-pixel RX. BT's two RX channels represent odd/even of one stream, not independent videos. BT also exposes two output clock pairs; the ITE reference uses a common clock. Exact mapping/phase/clock ownership and N/FN bridge revision/init/license are OPEN; never tie active clock outputs.
4. **Memory and power lifetime:** T120 regularI4 core/PLL nominal1.2 V is different from I4L. Alliance memory requires its near1.8 V VDD1 and near1.2 V VDD2/CA/Q classes. The preliminary datasheet's400 uncontrolled-power-off lifetime limit requires current vendor clarification, controlled shutdown and power-loss qualification before accepting the exact parts for a ten-year platform.

## Calculated boundaries, not measured performance

Raw1 Gbit/s host ceiling is125 MB/s. Active1080p60 RGB888 requires373.248 MB/s and RGBA32 requires497.664 MB/s; rendering/scanout belongs in local A RAM rather than full-frame host streaming. BT control/asset QSPI raw ceiling is30 MB/s and is not shared-memory access.

A hypothetical four-pass RGB888 BT memory workload is1492.992 MB/s versus x16 LPDDR2-800 raw1600 MB/s, before overhead/overlays. The actual pipeline pass count is unknown; this calculation neither certifies throughput nor proves rejection. Measure capture/composition/asset arbitration and latency. Single7:1 standard1080p60 is1039.5 Mbit/s versus T120's800 Mbit/s source ceiling; dual-pixel arithmetic is519.75 Mbit/s per lane, without legal pin/timing proof.

The exact workbook exposes256GPIO,96DDIO and40TX/40RX differential pairs per F484. Quarantining every configuration/DDR-reference candidate leaves76unannotatedDDIO, not76assigned/reserved pins. The32+32 data study plus conservative12-pin RGMII budget exhausts that pool before extra controls/clocks. Native LVDS merits comparison; full paired Efinity allocation is mandatory.

## D-01 — Independent 128 MiB DDR on A and B

State: **SELECTED_CONDITIONAL**. Gates: G01, G08. Sources: R23-AUTHORITY, T120-DS, ALLIANCE-DDR, T120-PINOUT.

Retain T120F484I4, each with its own 1 Gbit x32 LPDDR2 candidate; no shared physical RAM.

Selected owner roles require local useful capability over the platform lifetime.

Still required:

- Authentic A/B Efinity DDR_0 projects, exact-part CA/ball maps, clocks, rails and STA
- Current authorized memory datasheet/errata/lifecycle and power-loss limits

## D-02 — BT memory target and physical candidate conflict

State: **PROPOSED**. Gates: G12, G07. Sources: R23-AUTHORITY, ALLIANCE-DDR, BT-DS, BT-PROGRAM.

Keep independent 64 MiB x16 LPDDR2-800 target; named AS4C64M16MD2A-25BIN is 128 MiB and is not a reconciled target part.

384 MiB is the selected total; the named installation would be 448 MiB.

Still required:

- Qualify exact 512 Mbit x16 part and working init, or obtain explicit owner capacity revision
- Measured capture/composition/asset bandwidth, frame rate and bounded latency

## D-03 — Complete BT video chain

State: **PROPOSED**. Gates: G02, G12, G08. Sources: R23-AUTHORITY, BT-DS, BT-PROGRAM, BT-HARDWARE, BT-LVDS-SELECTION, ITE-6263.

Study A LVDS TX → BT LVDS RX → BT composition → BT LVDS TX → IT6263N candidate → HDMI.

BT is part of R23; direct A→ITE is historical. Standard 74.25 MHz is absent from the documented clock set; alternate-blanking vendor example requires separate qualification.

Still required:

- Vendor-approved timing/clock and both boundary mappings; two-clock-to-common-clock compatibility
- Exact ITE N/FN revision/init/license; monitor EDID/HPD/DDC/audio tests

## D-04 — Full-duplex A/B transport

State: **PROPOSED**. Gates: G03, G08. Sources: R23-AUTHORITY, T120-PINOUT, T120-DS.

Compare 16+16, 32+32 DDIO and native-LVDS lane studies; width/clocks remain OPEN.

76 conservative unannotated DDIO is a source accounting boundary, not a legal allocation; two directions and other interfaces compete.

Still required:

- Parameterized packet/CRC/credits/fences specification and simulation
- Whole-device paired Efinity allocation/STA and concurrent-load measurements

## D-05 — Host link and rescue

State: **PROPOSED**. Gates: G04, G05, G08. Sources: R23-AUTHORITY, HOST-S02, HOST-S03, T120-DS.

Keep RGMII candidate plus independently reachable SPI recovery.

Direct MAC interoperability, F133 exact bonds/pinmux and fixed-link integration need proof; user RTL disappears when A is blank.

Still required:

- Exact F133 pinmux and Linux/BSP support, legal clock ownership/skew
- Independent configuration/reset/service route without working A logic

## D-06 — Three dedicated boot NORs

State: **PROPOSED**. Gates: G05, G13. Sources: R23-AUTHORITY, STORAGE-REVIEW, T120-DS.

Lock one 16 MiB NOR each for F133/A/B; do not aggregate their capacities or invent partition sizes.

Actual generated loadable images, erase-rounded layout, golden strategy and flash endurance are unavailable.

Still required:

- Exact orderable SKUs/boot mode/protection/mux schematic and generated image bytes
- Cold-boot recovery and power-fail tests; passive/RAM-staged B loading with NOR isolated

## D-07 — Separate SPI NAND library

State: **PROPOSED**. Gates: G14, G05. Sources: R23-AUTHORITY, STORAGE-REVIEW, HOST-S02.

Use separate SPI NAND; model, capacity, ECC, driver and filesystem remain OPEN.

R23 retires eMMC and old SMHC0 games topology. Generic Linux candidates are not verified F133 hardware support.

Still required:

- Exact-part on-die ECC/OOB/BBM/endurance and pinmux/BSP qualification
- Power-loss-safe update/rollback, wear leveling and bad-block fault tests

## D-08 — Whole-system power and mechanics

State: **PROPOSED**. Gates: G07, G09, G11. Sources: R23-AUTHORITY, T120-DS, ALLIANCE-DDR, BT-DS.

Derive a verified rail/current/sequence tree for F133, BT, both T120, three external memories, bridge and USB.

Regular I4 nominal1.2V differs from I4L; LPDDR2 has1.8V and1.2V classes; preliminary400 uncontrolled-power-off limit blocks lifetime claims.

Still required:

- Current vendor maxima and sequencing, brownout/controlled shutdown and thermal tests
- Actual enclosure/connectors/USB decisions and electrical CAD; no invented dimensions

## D-09 — BT command and asset ownership

State: **PROPOSED**. Gates: G10, G12, G04. Sources: R23-AUTHORITY, BT-DS, BT-PROGRAM.

Leave F133 versus A SPI/QSPI command master OPEN and define explicit cross-pool asset/queue/fence contracts.

Four independent pools have no automatic cross-device DMA/address space; raw QSPI30MB/s is not measured transfer performance.

Still required:

- Bus master arbitration/reset behavior and SDK capability ABI
- Asset format/license/golden vectors and measured load/composition latency

## D-10 — Audio and service paths

State: **PROPOSED**. Gates: G02, G05, G09, G11. Sources: R23-AUTHORITY, BT-DS, BT-PROGRAM, STORAGE-REVIEW.

Leave audio source/external I²S clock master and PC-side programming/debug hardware OPEN.

BT is I²S transmit-slave; service must survive invalid FPGA images and corrupt NAND.

Still required:

- I²S BCLK/LRCLK/source/rate ownership, mute/reset and HDMI tests
- Independent JTAG/UART/reset access and reproducible repair/programming manual

## Ordered acceptance experiments

These are contracts for future work; none was executed as hardware acceptance.

### R23-E00 — Resolve BT capacity and video clock before pin lock

State: OPEN. Gates: G02, G12.

Required artifacts:

- Current vendor memory/clock clarification, exact source revision and proposed initialization
- Exact ITE clock/mapping/init source and complete timing spreadsheet

Acceptance:

- Reconcile selected 64 MiB versus named 128 MiB explicitly
- Establish monitor-compatible 720p/1080p 60 Hz operation through BT and the exact bridge

Stop conditions:

- No silently changed capacity, frame rate, timing totals or BT bypass
- No footprint/pin lock from family datasheet or source-only review

### R23-E01 — Generate independent full A and B Efinity projects

State: OPEN. Gates: G01, G03, G04, G08.

Required artifacts:

- Untouched exact-device A/B projects and generated DDR/register/ball/bank/clock reports
- Tool/IP versions, full constraints, warnings, resource/STA reports and image hashes

Acceptance:

- Verify 1 Gbit x32 geometry and DDR startup PLL_BR0/CLKOUT0/pad reference
- Fit DDR, host, video, A/B link, own NOR, configuration and debug concurrently on F484

Stop conditions:

- Missing exact-part timing or current authorized datasheet
- Pin/bank/clock collisions or unsupported DDR reference cannot be suppressed

### R23-E02 — Simulate protocols and fault boundaries

State: OPEN. Gates: G03, G04, G05, G10.

Required artifacts:

- Parameterized RTL/host golden models and executable simulator tests
- CRC, credits, epochs, fences, reset/error/replay traces; independent 128 MiB memory models

Acceptance:

- Bound queueing and recovery under backpressure, error and reset; no implicit shared RAM
- Prevent B from controlling A reset/clocks or protected boot storage

Stop conditions:

- No claimed RTL simulation before a real simulator is run
- No unsupported fixed-link/driver or pad-mux assertions

### R23-E03 — Prove each16MiB boot layout and NAND recovery

State: OPEN. Gates: G05, G13, G14.

Required artifacts:

- Actual compiled CPU/A/B loadable image lengths and unedited generator outputs
- Exact NOR/NAND datasheets and erase-aligned partition/update/recovery state machine

Acceptance:

- Each NOR individually fits required images and metadata without borrowing other devices
- Corrupt NAND or an invalid B user image cannot block independently reachable safe boot/service

Stop conditions:

- Unknown generated image length or erase geometry keeps fit UNKNOWN
- No per-game NOR rewrite/endurance or rollback guarantee without evidence

### R23-E04 — Qualify power and long-life behavior

State: OPEN. Gates: G01, G07, G12.

Required artifacts:

- Vendor-authorized current memory lifecycle/shutdown guidance
- Worst-case rail/sequence/reset schematic, USB protection and power-loss traces

Acceptance:

- Prove required 1.8/1.2 V classes, controlled shutdown/CKE and safe brownout
- Measure simultaneous F133, both T120, BT, three DDR, bridge and USB current/thermal margin

Stop conditions:

- Preliminary 400 uncontrolled-power-off limit unresolved
- No invented currents, regulators, board geometry or enclosure dimensions

### R23-E05 — Bench DDR, host, A/B and composed HDMI

State: OPEN. Gates: G01, G02, G03, G04, G06, G09, G12.

Required artifacts:

- Real prototype revision, instruments, binaries and source hashes
- DDR stress, CRC, video/audio/USB/latency traces and monitor matrix

Acceptance:

- Repeated cold boots and sustained simultaneous workload meet defined budgets
- Validate actual frame rate, audio, asset composition and isolation during B reload

Stop conditions:

- No measured PASS from source, arithmetic or software tests
- Any clock/drop/error/brownout recovery failure is a recorded blocker

### R23-E06 — Whole-system CAD and release review

State: OPEN. Gates: G07, G08, G09.

Required artifacts:

- Actual schematic, PCB, ERC/DRC, stackup, controlled-impedance and SI reports
- Signed traceable gate acceptance artifacts and measured prototype report

Acceptance:

- All required boundaries documented and legal without hidden multiplex conflicts
- Approve physical release only through a separate engineering review

Stop conditions:

- No supplied geometry means Viewer remains a placeholder
- All 14 gates remain OPEN in this software/source delivery

### R23-E07 — Archive SDK/licenses/service through2036

State: OPEN. Gates: G10, G11, G13, G14.

Required artifacts:

- Permitted vendor/IP/BSP archives and reproducible build manifests
- Repair/programming/update/rollback manual and signed license/lifecycle decisions

Acceptance:

- Rebuild all images with documented toolchain and independently recover the system
- Golden codec/SDK vectors, capability/fence contracts and bounded flash maintenance

Stop conditions:

- No unapproved vendor code redistribution
- Absent U2/U3/U4 source documents are BLOCKED, not reconstructed

## Current gate register

| Gate | Boundary | State |
|---|---|---|
| G01 | T120-A/B DDR_0 | OPEN |
| G02 | Video/HDMI electrical path | OPEN |
| G03 | A↔B link | OPEN |
| G04 | F133 host link | OPEN |
| G05 | Three NOR + NAND recovery | OPEN |
| G06 | USB devices | OPEN |
| G07 | Power and thermal | OPEN |
| G08 | Whole-system pins + PCB | OPEN |
| G09 | Measured bring-up | OPEN |
| G10 | Video/asset IP and licenses | OPEN |
| G11 | 2036 reproducibility | OPEN |
| G12 | BT820B memory + composition | OPEN |
| G13 | NOR bitstream size & endurance | OPEN |
| G14 | SPI NAND game library | OPEN |

## Source and delivery links

[Machine-readable decisions and sources](architecture.json), [BT memory/init review](BT820_MEMORY_VIDEO_REVIEW.md), [video chain review](VIDEO_CHAIN_REVIEW.md), [three NOR/NAND review](THREE_NOR_NAND_REVIEW.md), [migration inventory](R23_MIGRATION_RECORD.md), [unsent vendor questions](R23_VENDOR_QUESTIONS.md), [software test report](R23_TEST_REPORT.md).

Original workbook/pins/cleanCSV and R22 authorities remain unchanged. New public manufacturer/kernel sources were inspected through the web connector; original vendor-file hashes are null where raw bytes were unavailable. No vendor code, confidential PDF, native EDA, real electrical geometry or measured bench result is bundled. Referenced U2/U3/U4 documents are absent and cannot be salvaged beyond concepts expressly described by R23.

The next bounded experiment is R23-E00 vendor memory/clock clarification, in parallel with R23-E01 independent full A/B Efinity projects. Neither current source arithmetic nor software import status authorizes pin lock or fabrication.
