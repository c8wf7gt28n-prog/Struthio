# ARC-1 R23 video-chain review

Date: 2026-10-12. Authority: the complete owner-supplied `ARC1_R23_Handoff.docx`, read from the current-turn attachment. **G02 and G12 remain OPEN; all G01–G14 remain OPEN and hardware release remains NO-GO.** This is a source/candidate review, not an electrical schematic or prototype result.

## R23 responsibility and migration

The current chain is **T120-A → BT820B LVDS input → BT820B composition/LVDS output → IT6263N candidate → HDMI monitor**. T120-A remains the programmable renderer with independent 128 MiB; BT820B captures its live video and adds final 2D/UI composition in its own memory. T120-B retains its independent 128 MiB and accelerator role. The selected BT memory target is 64 MiB ×16; the R23 listed 1 Gbit ×16 candidate physically represents 128 MiB and requires resolution in the memory review. This review does not change the target or reinterpret extra physical capacity as proven usable memory.

KEEP: the immutable F484 workbook, 968 unassigned A/B inventory records, DDIO/LVDS source counts, independent-memory protocol principles and evidence policy. ADAPT: display resource budgeting and verification now terminate A's stream at BT820B. RETIRE AS CURRENT TOPOLOGY: the R22 direct A→IT6263 scanout path. BLOCKED: native F484 projects, BT memory initialization, exact bridge BOM/programming support and measured composition latency. Historical [R22 display review](../architecture/DISPLAY_LINK_REVIEW.md) remains unchanged. No BT bypass is authorized here.

## Primary-source findings

The R23 BT datasheet URL serves **v1.0**. The current official product-page link serves [DS_BT820 v1.1](https://brtchip.com/wp-content/uploads/2025/01/DS_BT820-1.pdf), January 2025. Sections 4.2–4.3/pages 18–19 specify two four-data-lane LVDS channels in each direction, 18/24-bit RGB, VESA/JEIDA mapping, channel 0 odd/channel 1 even and channel-0-only single-link operation. Transmit PCLK reaches 83.2 MHz; receive clock is limited to 144 MHz at 72 MHz system clock. Table 25/page 46 gives receive differential voltage 100–500 mV and common mode 0.3–1.6 V. Section 4.10.2/page 32 makes BT I²S a **transmit slave**: BCLK/LRCLK inputs, serial-data output. Section 4.12 specifies a 38.4 MHz reference; it does not establish arbitrary alternate-reference operation.

[BRT_AN_092 v1.1](https://brtchip.com/wp-content/uploads/2025/06/BRT_AN_092-BT820-Hardware-Design-Example.pdf), Tables 7–8/pages 13–14, provides **one clock pair per channel** for both RX and TX. Section 9/page 29 includes 1920×1080 dual-eight-bit input as a demo-board converter setting. This is useful reference practice; it is not an ARC-1 end-to-end 60 Hz result. Do not transplant its LCD/eMMC/demo-board architecture into R23.

The [ITE family product page](https://www.ite.com.tw/en/product/cate1/IT6263) documents single/dual LVDS, JEIDA/VESA/OpenLDI, up to 150 MHz input clock, up to ten-bit input color, HDMI output, I²S input and HPD. Its current listed ordering name is IT6263FN. The R23 IT6263N candidate's exact revision, register guide, schematic, electrical data, availability and permission to redistribute support files remain unresolved. Family compatibility alone cannot approve a suffix substitution.

The [Efinix T120 datasheet](https://www.efinixinc.com/docs/trion120-ds-v4.0.pdf) provides an 800 Mbit/s native-LVDS ceiling and 7:1 serialization. F484 has 40 TX pairs; 22 top pairs lack configuration annotations. Same-side data/clock placement and separation from LVDS-as-GPIO apply. Exact A DDR/host/A-B/configuration resources must share the full feasibility project.

## Standard timing gap and documented alternate timing study

The current [BT82X programming guide v1.4, 7 September 2026](https://brtchip.com/wp-content/uploads/2026/09/BRT_AN_086_BT82X-Series-Programming-Guide-1.pdf) uses `REG_LVDSTX_PLLCFG`, not assumed BT817 `REG_PCLK_FREQ`/`REG_PCLK_2X` settings. Table 21/page 77 and `REG_SYS_STAT`/page 84 document:

- `systemPLL = oscillator × SYSPLL_NS`, with supported multiplier **13 or 15**.
- `LVDSTX clock = systemPLL / (2 × (TXCLKDIV + 1))`, with a four-bit divider.
- `REG_SO_MODE` distinguishes single/dual channels and pixels per clock.
- LVDS capture writes local DDR through Swapchain 2; the render engine or scanout consumes those buffers. RX core/system channel and pixels-per-clock settings must agree.

With the documented 38.4 MHz reference and supported integer parameters, **74.25 MHz is not generated**. This is an arithmetic result from the documented settings, not proof that every possible vendor-supported clock path has been exhausted. An undocumented fractional PLL, arbitrary external-reference frequency or older-generation register must not be invented to remove the gap.

Both standard 720p60 single-link and standard 1080p60 dual-link need 74.25 MHz per link. The closest documented example, 72 MHz, is about 3.03% lower. With unchanged standard blanking, it would yield approximately **58.18 Hz**, so that particular clock/totals combination cannot be labeled 60 Hz. The 83.2 MHz example also does not equal the requested standard timing. This establishes a gap for standard timing, not a categorical inability to produce HDMI modes near 60 Hz.

[BRT_AN_097 v1.0, 19 August 2025](https://brtchip.com/wp-content/uploads/2025/08/BRT_AN_097_Selection-and-Integration-of-LVDS-LCD-Panels-with-VM820C.pdf), sections 2.4–2.5/pages 6–8, reports tested BT820B output through `SLH1080P_PRO V1.5` and `S.LH1080P.AUDIO.V20` converter boards. Table 4 labels output modes at 60 Hz and lists a 1920×1080 dual-channel example at 72 MHz, `SO_MODE=3`, `TXCLKDIV=3`, `HCYCLE=2140`, `VCYCLE=1108`; its 1280×720 single-channel example uses 72 MHz and totals 1480×800. Section 4.2/Table 7/page 21 independently corroborates the discrete clock choices. This is a manufacturer reference for an **alternate blanking qualification path**, not an IT6263N or ARC-1 result.

Under a simple two-pixel-per-link-clock interpretation, the listed 1080 totals calculate `144000000/(2140×1108) ≈ 60.73 Hz`; the single-channel 720 example calculates `72000000/(1480×800) ≈ 60.81 Hz`. Those conditional arithmetic values differ from exact 60 Hz; register/scanout semantics, actual generated frame rate, converter behavior and monitor acceptance must be inspected and measured before applying either example. Do not silently replace the owner's requested modes with a different refresh rate. Required next evidence is a vendor-approved strategy for the requested mode: either an exact supported clock path, or explicitly reviewed alternative timing accepted by EDID/IT6263N/monitors at the actual requested frame rate. No alternative clock, refresh rate or converter substitution is selected by this review.

## Interface contract to qualify

**Color:** start qualification with 24-bit RGB, eight bits per component, using one expressly matched VESA or JEIDA mapping throughout. BT's 32-bit RGBA bitmap capability does not make its LVDS stream 32-bit RGBA. Alpha blending can occur locally during composition; the display link carries the documented RGB output. The bridge's optional ten-bit/deep-color capability does not establish a ten-bit BT input/output path. An eight-bit bridge configuration must be demonstrated for the exact revision.

**Input:** A must emit one coherent frame whose odd/even pixels occupy the two BT channels. Two channels do not represent two independent screens or two asynchronous video sources. Specify bit order, lane polarity, sync/DE polarity, totals, channel ordering, pixel origin and phase. A's serialized stream and the BT receive clock domain require reviewed skew and a genuine F484 PLL/pin report.

**Output:** BT independently generates scanout from its local memory. Its two clock-output pairs and the IT6263 reference's one shared clock input create a real interface question. Select a documented compatible clock connection, validate cross-channel alignment and termination/loading, and handle the other output according to the exact electrical guidance. **Do not tie two active BT clock outputs together.** Do not assume input clock recovery automatically genlocks the output.

**Physical pair budget:** the conservative dual-eight-bit A→BT plan has eight data pairs plus **two** forwarded clock pairs, or ten T120-A TX pairs/twenty FPGA balls. A single-link plan has four data pairs plus one clock. Common-clock fanout or clock elimination requires separate vendor/SI proof before reducing that count. The count can fit within 22 top TX pair definitions, but it does not establish legal resources, routing, bank rail selection or timing. If an eight-TX-lane A/B candidate plus its clock also uses that side, the simple count is ten plus nine = nineteen; native Efinity constraints must decide feasibility.

The F576 IT6263 reference's complete deep-color mapping uses ten data pairs plus one shared clock. Four of its data-pair names and its reset name are absent from F484; it was never a legal F484 plan. Under R23, that reference informs **BT→bridge** mode/clock questions, and does not assign A→BT pins. BT has only the documented four data lanes per channel, so its output cannot reproduce the reference's fifth deep-color lane by assertion.

## Bandwidth and latency model

These are calculations, not achieved performance:

| Quantity | Calculated value | What it does not establish |
|---|---:|---|
| 1920×1080×60 RGB888 active bytes | 373.248 MB/s | Link blanking, composition or sustained DDR throughput |
| Same active pixels at four bytes | 497.664 MB/s | RGBA LVDS capability |
| Standard 1080p60 total pixel timing | 148.5 MHz | A generated BT output configuration |
| 7:1 single-link data lane | 1039.5 Mbit/s | Exceeds T120's 800 Mbit/s ceiling |
| 7:1 dual-link lane at 74.25 MHz | 519.75 Mbit/s | Only arithmetic lane-limit feasibility |
| BT ×16 LPDDR2 at 800 MT/s | 1.6 GB/s theoretical | Controller initialization or useful simultaneous processing |

A minimum capture-write plus scanout-read of an RGB888 frame costs approximately **746.496 MB/s** active payload. If final composition also reads the captured background, writes a composed frame and scans it out, the four full-frame passes calculate **1.492992 GB/s** before overlay texture reads, refresh, burst inefficiency and command uploads. That simple worst-case model nearly consumes the 1.6 GB/s theoretical ×16 ceiling. The vendor implementation may organize traffic differently; verify the actual capture/render/scanout path and counters rather than claiming the four-pass model is a hardware measurement. Reduced formats, scaling or alternate traffic plans are experiments, not silent requirements changes.

Capture completion, queue depth, composition duration, output scan position and unsynchronized clocks determine latency. Use a timestamped/frame-ID pattern, live-source flash/input stimulus and an output photodiode/capture measurement to measure minimum, median, tail and worst observed latency. Test whether frames repeat/drop, whether overlays correspond to the captured frame, and what happens during backpressure, missing input and source reset. No fixed one-frame, zero-copy or zero-latency promise is made. Define an acceptable bound for games before qualification; expose faults and retain independent rescue even when the display chain fails.

## Control, EDID and audio ownership

The final F133-versus-A BT SPI/QSPI master remains D-09 OPEN. The complete control proposal must define who resets/initializes BT DDR, configures capture/scanout, uploads display lists/assets, reads frame/error counters and arbitrates shared buses. Independent memory pools require explicit asset transfers. A raw QSPI rate is not full-frame transport capacity or proof of overlay loading while rendering.

The bridge has distinct programming, HDMI DDC/EDID and HPD functions. Identify the actual physical owners, voltage domains, pull-ups/translation and reset dependencies from its exact schematic/register documentation. EDID must control supported-mode negotiation and a fallback **through the selected BT chain**. Missing/invalid EDID, monitor hot-plug, mode changes and bridge reset need inspectable state-machine behavior.

If BT supplies audio data, an external I²S clock master must supply its BCLK/LRCLK and a compatible clocked stream to the bridge. Two receiver/slave interfaces alone do not generate those clocks. If F133 supplies audio instead, that remains an explicit D-10 proposal with its own pinmux/clock review. Select the actual source, sample format/rate, HDMI clock regeneration, mute/restart and video/audio synchronization only after exact component documentation and prototype evidence. An IT6263 I²S feature list does not close the audio gate.

## Bounded next experiment and closure evidence

First produce a **version-pinned BT clock/mode dossier**: enumerate only documented 38.4 MHz, multiplier 13/15 and legal divider candidates; reproduce the AN097 alternate-blanking examples as a reference experiment; archive vendor clarification for generating/negotiating the required 60 Hz modes with IT6263N; specify both input and output format/clock contracts. This artifact addresses the standard-timing gap without changing owner goals or selecting the AN097 converter boards for ARC-1.

Then create genuine F484 A projects with approved DDR_0 and the complete R23 I/O plan. Add BT initialization/readback and capture/compose/scanout register traces for the corrected exact memory part. Archive native projects, full source/constraints, warnings, STA, clock trees, exact support-file license records and electrical checks. Qualify 720p60 and 1080p60 separately on physical hardware with live A video plus overlays, continuous stereo audio, both T120 DDRs active, worst-case A/B traffic and USB input. Record actual clocks/frame rates, EDID, error counters, tearing/underflow, latency and recovery with artifact hashes and exact revisions.

Source research and arithmetic above resolve planning questions, while **G02/G12 and all other gates remain OPEN**. No PCB geometry, pin lock, power-off electrical compatibility or tested video mode has been invented.
