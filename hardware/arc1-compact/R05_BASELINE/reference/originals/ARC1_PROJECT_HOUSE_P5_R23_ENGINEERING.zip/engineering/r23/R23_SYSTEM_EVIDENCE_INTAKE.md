# R23 system evidence intake

This is an explicitly declared JSON interchange, **`arc1-r23-system-evidence-v1`**. It records source declarations and checks selected R23 component, memory, NOR and video constraints. It is not a native Efinity, BT820, flash-tool or bench-report parser. Original vendor exports must be archived unchanged; a native adapter requires an authentic sample and its documented format.

The current owner authority is the complete `ARC1_R23_Handoff.docx`, dated 12 October 2026. R23 selects F133-B 64 MiB, T120-A/B 128 MiB each, and BT820B 64 MiB: **384 MiB across four independent physical pools**. It also selects three dedicated 16 MiB NOR devices, separate game SPI NAND of unknown capacity, no eMMC, and the candidate video chain **T120-A → BT820B → IT6263N → HDMI**. These selections are not hardware proof.

Legacy `evidence.js`, `arc1-evidence-v1`, its JSON/CSV templates and the manufacturer pin inventory remain unchanged. The legacy importer examines an A/B pin report; the R23 importer examines system declarations. They do not replace each other. Neither closes hardware gates. R23 intake always returns **G01–G14 OPEN**.

## Files and API

- [R23_SYSTEM_EVIDENCE_SCHEMA.json](R23_SYSTEM_EVIDENCE_SCHEMA.json): strict schema; every declared field is required, with `null` for explicitly unknown nullable values. Undeclared fields are parser errors.
- [R23_SYSTEM_EVIDENCE_TEMPLATE.json](R23_SYSTEM_EVIDENCE_TEMPLATE.json): selected goals with unknown physical candidates, measurements, erase geometry, metadata and binary lengths. It is intentionally UNKNOWN, not a completed evidence record.
- `r23-evidence.js`: `globalThis.ARC1R23Evidence`, a read-only module. Load unchanged `evidence.js` first; R23 borrows its SHA-256 helper without modifying the legacy module.

```js
const parsed = ARC1R23Evidence.parse(text);
// { ok, report: object | null, parserErrors: [{code,path,message}] }

const checked = ARC1R23Evidence.validate(parsed.report);

const imported = await ARC1R23Evidence.intake({
  text, filename, reportBytes, attachments
});
// reportBytes: optional Uint8Array containing exact original UTF-8 bytes.
// attachments: [{ name: 'relative/archive/path', bytes: Uint8Array }]
```

Results contain `status`, `parserErrors`, `conflicts`, `unknowns`, fourteen `gates`, preserved `source`, copied `memoryPools`, `norDevices`, `gameStorage`, `video`, and a declaration `summary`. Intake additionally records `input` (`filename`, format, raw text and exact imported-byte SHA-256) and attachment diagnostics in `artifacts`. Diagnostics have stable `code`, `path` and `message` fields. Input objects, selected authority, source inventory and hardware state are never mutated.

Status precedence is **PARSER_ERROR → CONFLICT → UNKNOWN**. There is no PASS status:

- **PARSER_ERROR:** malformed JSON, wrong schema, missing/undeclared fields, invalid types/paths/calendar timestamps, unsafe numeric byte counts or intake byte/attachment errors.
- **CONFLICT:** a well-formed declaration contradicts selected goals, another declaration, a known exact-part organization, or attached bytes' declared hashes.
- **UNKNOWN:** declarations are compatible but proof is missing. Even a hash-matched vendor-report claim remains UNKNOWN for origin, semantic validity and hardware approval.

## Declared fields

`source` preserves `kind` (`interchange` or `vendor-report`), `tool`, `toolVersion`, `project`, `revision`, `generatedAt`, and `artifacts`. Nullable provenance is reported as UNKNOWN. `generatedAt` must be a real ISO calendar timestamp with a timezone when supplied. Each artifact declares a relative archive `path`, nullable lowercase `sha256`, and nonempty reported `kind`. These fields do not authenticate an author or vendor tool.

Each `memoryPools` row declares `device`, `selectedMiB`, `physicalCandidateBits`, `part`, and `reportedMeasuredMiB`. Canonical device names are `F133-B`, `T120-A`, `T120-B`, `BT820B`. Duplicate/unknown components and wrong selected capacities conflict; omitted component records remain incomplete. Physical candidate density is in **bits**, selected capacity in **MiB**, and reported measured capacity remains an unverified claim.

The named Alliance `AS4C64M16MD2A-25BIN` is **1 Gbit = 128 MiB**, not 64 MiB. Giving this part a 512 Mbit density, or treating half-addressing as proof of 64 MiB installed capacity, conflicts. The known `AS4C32M32MD2A-25BIN` is likewise 1 Gbit, with x32 organization. These exact part checks use the R23 handoff and [Alliance Rev.1.0 January 2018 manufacturer data](https://www.alliancememory.com/wp-content/uploads/20180221__AllianceMemory_1G_LPDDR2_AS4C32M32MD2A_AS4C64M16MD2A-25BIN_v1.0_Jan2018.pdf); they expose contradictions without approving these candidate parts, timing, lifetime or footprints. Unrecognized part strings require fresh primary evidence rather than an inferred organization. The blank template deliberately supplies no candidate part.

Each `norDevices` row declares owner `F133-B`, `T120-A` or `T120-B`, `capacityBytes`, `eraseBlockBytes`, `metadataBytes`, and `images`. Exactly **16,777,216 bytes per device** is the selected capacity. Devices cannot lend capacity to another owner's images. Duplicate owners, wrong capacities, incompatible erase geometry, repeated image paths/roles within a NOR and overflow conflict.

An image declares `role`, relative `path`, nullable `loadableBytes` and nullable `sha256`. Use authentic generated loadable binary counts, not `.hex` character counts or compressed/archive file size. Reference the original artifact in `source.artifacts`. Declared image and source-artifact hashes must agree when both exist. Distinct stored copies require distinct declared paths/roles. Images and metadata round up **independently** to reported erase blocks; their conservative sum can expose overflow. Missing erase geometry, metadata or binary sizes produce UNKNOWN diagnostics. `capacityDiagnostic.geometryVerified` always remains false: this arithmetic does not prove offsets, nonoverlap, boot addressing, protected regions, endurance or recovery. It cannot promise golden + active + rollback slots.

`gameStorage` declares `technology`, nullable `part`, nullable `capacityBytes` and nullable `eccEvidence`. A technology other than `SPI NAND`, including `eMMC`, is syntactically valid but a semantic conflict. A declared ECC note is not proof of controller/ECC/OOB compatibility, bad-block handling, wear leveling, filesystem integrity or power-loss safety.

`video` preserves the exact component `path`, nullable `pixelClockMHz`, `links`, `measuredFps`, and `sourceArtifactPaths`. The clock and link count are reported values; the importer does not infer serializer ratio, internal clock synthesis, scaling, frame timing, per-link mappings or audio wiring. Referenced artifacts must also be declared in source provenance to avoid UNKNOWN coverage. Measurements cannot certify a working end-to-end chain by assertion.

`signoffs` declares `gate`, `status`, nullable `artifactSha256`. Only OPEN/UNKNOWN claims are accepted without a conflict; a PASS/closed/released claim conflicts, including one accompanied by a matching hash. All fourteen returned gate states stay OPEN.

## Byte identity and limits

Reports are bounded to **2 MiB**. At most 200 attachments are accepted, **32 MiB each and 64 MiB combined**. Paths exclude absolute paths, drive prefixes, traversal, backslashes and control characters. Byte counts are safe integers; measurements/clock values must be finite positive numbers when present. Unknowns are explicit nulls, not zero or blank strings.

When supplied, `reportBytes` must decode to the imported text, accounting for a leading UTF-8 BOM; hashing preserves original BOM bytes and line endings. Attachments compare original bytes against declared hashes and show HASH_MATCH, MISMATCH, MISSING, HASH_UNDECLARED or UNDECLARED. **HASH_MATCH means byte identity only, not authenticated vendor origin or engineering correctness.** Observed image file length is kept distinct from claimed loadable payload length; without an inspected native format, file byte count does not verify loadability or flash placement.

Archive untouched original reports, source/tool revisions, exact input conditions and actual test logs separately. The interchange can point to them and reveal conflicts; reviewed authentic EDA, electrical, prototype and manufacturing artifacts are still needed to close G01–G14.
