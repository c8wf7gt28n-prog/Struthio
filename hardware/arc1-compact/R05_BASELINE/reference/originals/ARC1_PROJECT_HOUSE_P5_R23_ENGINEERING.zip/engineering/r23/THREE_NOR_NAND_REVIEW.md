# ARC-1 R23: three-NOR boot, game NAND and recovery review

Status: **PROPOSED IMPLEMENTATION**. All G01–G14 remain **OPEN**; manufacturing release is **NO-GO**. Authority is the complete user-furnished `ARC1_R23_Handoff.docx`, dated 12 October 2026. This review changes the working proposal for R23; R22 records remain historical and unchanged.

## Decisions preserved and prior work adapted

| Artifact or assumption | Disposition | R23 correction |
| --- | --- | --- |
| R22 independent supervisor, per-device reset/JTAG, bounded leases and fault tests | KEEP | Extend protection to BT820B/video and the new storage topology. |
| F133 as sole normal boot-image loader for both FPGAs | ADAPT | Each FPGA cold-boots a known-safe image from its **own dedicated NOR**. F133 performs verified passive loading for B game personalities and controlled service/update operations. |
| One protected host NOR holding all golden images | RETIRE as current topology | Three physical 16 MiB NOR devices: NOR-F133, NOR-T120-A and NOR-T120-B. |
| Generic games technology, SMHC0 game-storage suggestion, eMMC alternatives | RETIRE as current requirement | Separate **SPI NAND** is selected; capacity/SKU remain OPEN. No eMMC. USB removable media may assist loading/recovery. |
| Golden + active + rollback presumed to fit | BLOCKED | Require authentic generated payload sizes and exact erase/protection/address maps for each individual 16 MiB NOR. |
| R22 source registries and electrical caution | KEEP as history | Reuse verified sources where applicable; do not let historical topology override R23. |

**Locked capacity:** each NOR is 16 × 2²⁰ = **16,777,216 bytes**, or 128 Mbit; total installed NOR is 48 MiB across three separate devices. Unused space in one device cannot make another device's images fit. Capacity is locked; orderable SKU, voltage, read commands, erase geometry and partitions are unresolved.

## Reference strategy: self-boot plus temporary passive loading

F133 boots its own minimal rescue-capable firmware from NOR-F133. T120-A and T120-B independently use documented **SPI active** configuration to load known-safe images from NOR-T120-A and NOR-T120-B. The independent supervisor holds unsafe interfaces isolated until rails/configuration/user-mode timing and protocol readiness are qualified. Cold boot must not require either FPGA's user logic to retrieve another device's image.

Normal game switching reads a compatible B personality from the separate game SPI NAND into verified host staging buffers, quiesces jobs and revokes A memory grants, then loads **B configuration RAM through the verified SPI-passive path**. This is a proposed implementation supported by the vendor's active/passive configuration capabilities, not an implemented ARC-1 programmer. It does not rewrite NOR-T120-B on every game launch. After load, initialize/test DDR B, identify the personality and its allowed interface profile, increment generation and grant bounded traffic. A, its clock/reset and the final BT820B/HDMI service chain stay independent.

On a bad image, timeout or incompatible personality, isolate B first, revoke grants and record cause. Restore the active self-boot path to B's dedicated safe NOR, perform the required reset sequence, and admit traffic only after checks. A user-RTL SPI diagnostic endpoint is supplementary; a blank A cannot execute it. External service JTAG and flash access remain usable without A/B user logic and, where the reviewed service circuit permits, without F133 firmware.

## Exclusive ownership states

The following are functional states, **not assigned nets or a chosen mux part**. A reviewed circuit must enforce break-before-make ownership, correct default straps, safe voltage and powered-off behavior. Three dedicated memories are never merged into a shared flash by this state model.

| State | Clock/data master | Connected target | Other paths and interlocks |
| --- | --- | --- | --- |
| CPU self-boot | F133 ROM/SPL | NOR-F133 | External programmer disabled; A/B do not drive CPU boot storage. |
| FPGA self-boot, independently for A or B | That FPGA's configuration engine | Its own NOR | External loader/writer disabled; active-mode select valid before configuration reset release; game link isolated. |
| B temporary passive load | F133 verified loader or qualified service loader | B configuration pins | B NOR disconnected from conflicting configuration signals/chip select; passive mode established before reset release; A unchanged. |
| Read/update FPGA NOR | Exactly one authorized writer | Selected FPGA's NOR | Affected FPGA reset/isolation asserted and its flash-driving path physically disabled; no assumption that a friendly user design tri-states itself. |
| External CPU NOR programming | External service programmer | NOR-F133 | F133 reset and boot-bus drivers isolated according to reviewed source/circuit; no simultaneous CPU flash execution. |
| Individual FPGA JTAG | External service tool | Only A or only B | Alternative configuration clocks/drivers inactive; no required chain through the other FPGA. |
| Fault or power invalid | No programming/data master | Paths isolated/default safe | Supervisor owns reset/guard regardless of failed processor/user logic. No drive into unpowered devices. |

AN006 v6.6 documents SPI active as autonomous flash loading and SPI passive as loading from an external processor (printed p10). Its mode pins and dual-purpose configuration pins need review (pp5–9); a configuration source must stop driving a pin before user logic drives it. It also requires powered-up FPGA I/O before external signals and supervisable CRESET_N (pp41–45). These facts support this functional strategy; exact F484 pin/bank allocation and ARC-1 hardware arbitration remain OPEN.

The ownership circuit must prevent a defective B personality from reprogramming or disabling the golden region, resetting A, removing A's reference clock, or holding F133 boot storage hostage. Reserve necessary dual-purpose configuration pins from arbitrary game use. A declared bitstream manifest cannot electrically constrain arbitrary configuration contents: define a trusted build/interface-profile policy and test configuration resources. A WP-labelled pin is not a complete proof of immutable golden storage; select and verify actual device lock/protection-register behavior and an authorized update override.

## Capacity proof required for each 16 MiB NOR

No genuine R23 F133 firmware payload or A/B Efinity bitstream is available here. Consequently, **fit, partition layout and rollback capability are UNKNOWN**, not successful. Do not substitute sample bytes, truncated fixtures or a devkit's flash capacity as proof.

For each NOR, record these actual inputs:

- Orderable flash revision; capacity bytes; legal erase regions; program page size; protection granularity; power-up addressing/command mode; update endurance; boot-reader compatibility.
- Native project/tool version and hashes; each loadable raw payload's actual byte length and hash; initialization/header options; generated programming map; required boot offset/alignment and metadata format.
- Desired golden, mutable, rollback and rescue payloads, with a declared role. Text `.hex` character count is not the flash payload size; parse the authentic programming representation and inspect the emitted address map.

A parameterized software check should reject negative/fractional lengths, missing inputs, illegal alignment, overlap and an end address beyond 16,777,216. For uniform erase size `E`, rounded region size is `ceil(bytes/E) × E`; nonuniform geometry must use the actual region map. Evaluate each slot's `[offset, offset + reserved_length)` separately. Fit evidence requires all real payloads and metadata; unknown image lengths produce **UNKNOWN**. Zero bytes are not a substitute for missing images. Arithmetic **FIT** means only that declared regions fit; it does not prove cold boot, protection, endurance, update atomicity or recovery.

A conservative viable milestone is **one proven safe self-boot image on each FPGA NOR**, with the chosen write protection and external restore procedure. Multiple local images can be planned only after measured lengths leave enough independently protected erase regions. The capacity lock must not be silently enlarged to resolve a failed calculation. If desired slots do not fit, reduce the mutable local image policy while retaining the locked dedicated devices, or bring a concrete conflict to the owner. Game personalities stay in NAND and temporary configuration RAM by default.

NOR-F133 must hold the actual bootloader, system/minimal rescue payload and required metadata independently of usable game NAND. Verify F133 ROM boot read commands and SPL loading offsets for the selected 128 Mbit part and driver. A 24-bit address covers exactly the locked byte range by arithmetic; it does not establish flash power-up mode or ROM command compatibility.

## SPI NAND: credible software route, exact implementation OPEN

Upstream Linux **v6.12** provides an inspectable candidate chain:

- Shared `sunxi-d1s-t113.dtsi` declares SPI0 and SPI1 with `sun50i-r329-spi` fallback compatibles, clocks, resets and DMA. This shared SoC description is not a verified F133 package pin plan.
- `spi-sun6i.c` matches that fallback and exposes dual/quad modes in the r329 configuration; it implements transfers, DMA paths and timeout/error handling. Driver presence is not a tested speed or NAND compatibility claim.
- `drivers/mtd/nand/spi/core.c` uses SPI-memory operations, supports chip-specific identification/operation variants, on-die ECC and OOB layouts, reports corrected/uncorrectable status and has bad-block read/mark operations. **This does not establish a F133 controller hardware ECC engine.** On-die ECC is an exact NAND/device-driver choice requiring validation.

These are primary implementation sources, not a selected F133 BSP. Archive the chosen kernel/BSP/U-Boot versions/configuration, board device tree and exact manufacturer NAND entry before claiming support. If bare-metal firmware is chosen, these Linux sources are research only and an equivalent qualified storage stack is still required. Exact NAND manufacturer, density, page/OOB/erase geometry, ECC requirements/strength, read/program/erase modes, endurance, retention and lifecycle are OPEN.

For a Linux candidate, evaluate **MTD + UBI + UBIFS** for game-library storage; the filesystem is proposed, not locked or demonstrated. ECC corrects bounded bit errors; it does not supply wear leveling, authenticated files or atomic game update semantics by itself. The implementation must preserve manufacturer bad-block markers, reserve replacement capacity, account for ECC/OOB ownership, retire grown bad blocks and expose error/health counters. Required usable capacity depends on measured game packages, active/staged versions, reserved/bad-block allowance and filesystem overhead; no arbitrary density is selected.

The kernel's [UBIFS documentation](https://docs.kernel.org/6.12/filesystems/ubifs.html) describes the UBI wear-leveling layer and UBIFS journal recovery, but also documents a default that skips data-node CRC checks. Select and archive integrity/authentication settings deliberately and verify package hashes; filesystem recovery is not proof of a fully committed, authentic game package.

Stage game updates as new immutable package content, hash/sign according to the trust policy, read back through the ECC-aware stack, and commit a redundant versioned manifest only after validation. On restart, select the last fully committed valid package; reject partial packages and record ECC/hash failures. NAND unavailable, corrupt, full or timed out must leave CPU rescue boot and FPGA safe self-boot paths usable. Never erase an entire raw NAND to "repair" a filesystem without preserving factory bad-block information and a deliberate service procedure.

## Host pinmux and bus contention questions to resolve first

Inventory both F133 SPI controllers and every legal **bonded** alternative, not generic D1 defaults. The R22 [host review](../architecture/HOST_LINK_REVIEW.md) identifies source concerns about PC boot-SPI resources, PD SPI1 alternatives and PG RGMII; retain those constraints, but retire its SMHC0 games proposal. No CPU/FPGA/BT820B package balls are assigned by this review.

Compare a dedicated CPU boot bus plus an arbitrated second bus against individually selected peripherals sharing a verified host bus. Whichever topology is chosen must reserve simultaneous requirements for CPU NOR, game NAND, independent FPGA rescue, temporary B loading, FPGA NOR service access and BT820B controls. BT820B's final control master remains **OPEN**. Two controllers do not imply an unlimited set of independently operating QSPI buses. Extra chip selects, GPIO mode control, muxes or separate service connections require genuine pin/rail/timing evidence and explicit ownership.

A shared clock/data bus needs mutually exclusive chip selects, bounded transfers, mode restoration and fault containment. An electrically stuck NAND output on a shared rescue bus can defeat rescue even when software chip selects are correct; an isolation or alternate service path must address that defined fault. SPI NOR and SPI NAND protocol modes cannot be assumed interchangeable. CPU boot-ROM defaults, quad-enable/address state after resets, flash update execution location, FPGA autonomous active clocks and external programmer handover all belong in the same resource matrix. No sharing is locked before the F133 package/BSP and paired Efinity plans are checked.

## Inspectable next experiments

| Experiment | Required artifact and acceptance | Gate status |
| --- | --- | --- |
| Produce actual F133 rescue image and independent A/B safe-image builds | Hashed payloads/maps; source/tool/configuration; per-NOR capacity check against authentic erase/protection geometry | G05/G13 OPEN |
| Draw functional ownership netlist candidate and review ERC/modes | No two masters; self-boot from each own NOR; programmer takeover with CPU/A/B failed; legal bank voltage/strap/default/power-off behavior | G05/G08/G13 OPEN |
| Implement and simulate B load/recover state machine | Quiesce/revoke/generation; no default NOR write during game launch; failure restores safe local boot or service; A/BT display continues within declared bounds | G03/G05/G09/G13 OPEN |
| Compile chosen F133 SPI/NAND BSP with exact NAND description | Reproducible kernel/firmware/device-tree/config logs; exact READ-ID/op modes, ECC/OOB layout and BBM semantics | G04/G08/G14 OPEN |
| NAND emulator/fault tests then target-board tests | Factory/grown bad blocks, corrected and uncorrectable reads, timeouts, full media and interrupted package/manifest writes; CPU/FPGA rescue remains available | G05/G09/G14 OPEN |
| Flash boot/update/programmer bench qualification | Cold boots after mode changes; golden protection; interrupted write/erase; bounded NAND faults; per-device programming/reset traces; lifetime write budget | G05/G09/G13/G14 OPEN |

Software models validate declared state/capacity rules only. No physical gate is closed by this document, source inspection or a Node test. Power/thermal and controlled LPDDR2 shutdown concerns from the historical review remain applicable and now require the added BT820B/third external-memory domain.

## Workstream return record

Objective: R23 workstreams09/10, three-NOR recovery and separate game SPI NAND. Changed files: this review and `storage_sources.json`; historical R22 files untouched. Executed proof: full DOCX XML text read, original DOCX SHA-256 recorded; versioned upstream source and Efinix source inspection; JSON syntax validation of the source registry. No Efinity, F133 BSP build, bitstream fit or hardware test executed. Sources/extraction hashes are in the registry; original web-source byte hashes remain null. Remaining R23 discrepancies: exact payload sizes, flash/NAND SKUs and protection, host pinmux/bus control, trusted image policy, storage stack and fault measurements. Next bounded artifact: authentic per-device rescue payloads and flash geometry fed into a per-NOR capacity/ownership experiment. All G01–G14 remain OPEN.
