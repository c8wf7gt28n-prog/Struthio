// Offline consistency checks. No compiler/synthesis or physical PCB validation is claimed.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const read=(name)=>fs.readFileSync(path.join(root,name),'utf8');
const exists=(name)=>fs.existsSync(path.join(root,name));
const pins=JSON.parse(read('pins.json'));
const rawCSV=read('engineering/R22_T120_PACKAGE_BALLS_UNASSIGNED.csv').trim().split(/\r?\n/);
assert.equal(rawCSV.length,969,'Package CSV must contain 968 rows plus one header');
for(const line of rawCSV.slice(1))assert(/,MANUFACTURER PIN SOURCE \/ ARC1 NET NOT ASSIGNED$/.test(line),'Old net candidate found in clean R22 CSV');
assert.equal(pins.length,968,'Expect 484 ball definitions per T120');
const sets=new Map([['T120-A',new Map()],['T120-B',new Map()]]);
for(const r of pins){
  assert(sets.has(r.chip),`Unexpected FPGA instance: ${r.chip}`);
  assert(/^[A-Z]{1,2}\d{1,2}$/.test(r.ball),`Malformed ball: ${r.ball}`);
  assert(r.name&&typeof r.name==='string',`Missing name ${r.ball}`);
  assert.equal(r.net,'',`Unexpected assigned ARC-1 net: ${r.chip}/${r.ball}`);
  assert.match(r.status,/UNASSIGNED/,`Assigned R22 net status not permitted: ${r.chip}/${r.ball}`);
  const block=sets.get(r.chip);
  assert(!block.has(r.ball),`Duplicate physical ball ${r.chip}/${r.ball}`);
  block.set(r.ball,r);
}
for(const [chip,set] of sets)assert.equal(set.size,484,`Incomplete ${chip} package definition`);
const a=sets.get('T120-A'),b=sets.get('T120-B');
for(const [ball,p] of a){
  const q=b.get(ball);assert(q,`T120-B missing ${ball}`);
  for(const field of ['bank','name','role','ddr'])assert.equal(p[field],q[field],`${ball}: A/B vendor mapping mismatch for ${field}`);
}
const plan=JSON.parse(read('tasks/roadmap.json'));
assert.equal(plan.schema,'arc1-roadmap-v1');
assert.equal(read('engineering/R22_DEVELOPER_TASKS.json'),read('tasks/roadmap.json'),'Engineering Archive task mirror out of sync');
assert(plan.tasks.length>=8,'Missing developer/hardware work queue');
assert(plan.tasks.some(t=>t.id==='DEV-002'&&t.state==='ready'));
const ids=new Set();
for(const t of plan.tasks){assert(!ids.has(t.id),`duplicate task ${t.id}`);ids.add(t.id);assert(t.pass_condition&&t.deliverables.length,'Task needs tangible pass evidence');}
const index=read('index.html'),house=read('house.js'),viewer=read('viewer.js'),sw=read('sw.js'),manifest=read('manifest.webmanifest');
const mandatory=['index.html','house.css','house.js','viewer.css','viewer.js','manifest.webmanifest','sw.js','pins.json','CLAUDE.md','engineering/T120_pinout_v1.4.xlsx','engineering/R22_T120_PACKAGE_BALLS_UNASSIGNED.csv','engineering/R22_CLAUDE_CODE_HANDOFF.md','engineering/R22_EVIDENCE_POLICY.md','engineering/R22_TABLETOP_SYSTEM_WORK_ORDER.md','tasks/roadmap.json'];
for(const x of mandatory)assert(exists(x),`Missing required source ${x}`);
assert(index.includes('R22 / PASS 05'));
assert(house.includes('handoffPage')&&house.includes('loadDeveloperRoadmap')&&house.includes('exportSnapshot'));
assert(viewer.includes('No physical model loaded'));
for(const entry of ['House','Viewer','Systems','Lab','Manual','Archive'])assert(index.includes('>'+entry+'</span>'),`Missing bottom department ${entry}`);
const m=sw.match(/const ASSETS=(\[[^;]+\]);/);assert(m,'Invalid service-worker precache list');
const assets=JSON.parse(m[1]);
const unique=new Set();
for(let asset of assets){assert(!unique.has(asset),'Duplicate service-worker asset '+asset);unique.add(asset);if(asset==='./')continue;asset=asset.replace(/^\.\//,'');assert(exists(asset),'Missing offline precache asset '+asset);}
for(const f of ['house.js','viewer.js','house.css','viewer.css','index.html','manifest.webmanifest'])assert(!/\b(?:SLIM4|STRUTHIO)\b/i.test(read(f)),'Prior-project identity in active UI '+f);
for(const href of house.matchAll(/href=\\?"engineering\/([^"\\]+)\\?"/g)){
  const name=decodeURIComponent(href[1]);
  if(name.includes('${'))continue; // Runtime-generated Archive card, checked separately below.
  assert(exists('engineering/'+name),'Broken bundled engineering link '+name);
}
for(const entry of house.matchAll(/\['[^'\n]+','(R22_[^'\n]+\.(?:md|json)|T120_pinout_v1\.4\.xlsx|R19_T120_pin_inventory\.csv)'/g)){assert(exists('engineering/'+entry[1]),'Archive references missing '+entry[1]);}
JSON.parse(manifest);
console.log(`PASS: ${pins.length} unassigned A/B package balls; ${plan.tasks.length} developer tasks; ${assets.length} offline assets; required source and identity checks.`);
