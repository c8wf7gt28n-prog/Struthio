# ARC-1 Project House — R22 / Pass 05

An independent **tabletop dual-T120 console engineering PWA**, prepared for continuation in **Claude Code**. This is not an approved PCB release.

## Use from a desktop computer

1. Extract the ZIP into a folder of your choice.
2. Run `npm test` from the folder (requires Node 18+).
3. Run `npm run serve`; open `http://localhost:8000`.
4. Choose **Claude Code handoff** in House or Lab; read **`CLAUDE.md`** before starting an agent session.
5. Begin with **DEV-002** in `tasks/roadmap.json` while waiting for Efinity A/B DDR reports.

No `npm install` required. To deploy as a PWA on iPhone, host the entire folder on HTTPS; ZIP and `file://` mode cannot provide a normal service-worker installation.

## Architecture preserved

- Allwinner F133-B / 64 MiB in-package DDR2.
- T120F484I4 **A** permanent GPU + its own proposed 128 MiB x32 LPDDR2.
- T120F484I4 **B** game-defined FPGA + an independent proposed 128 MiB x32 LPDDR2.
- Preferred RGMII CPU/GPU-A high-speed link, with independent SPI recovery; neither is proven on an ARC-1 PCB.
- TBD high-bandwidth T120-A↔B interface; native HDMI bridge to external screen; standard wired USB gamepads.
- Protected system flash separate from rewritable game-storage flash; sizes remain open.
- Future FPGA asset decompression should prefer appropriate licensed professional IP to reinventing a codec.

## Verified software scope

Standalone PWA with six departments, circle/slash no-model viewer, 968 manufacturer package-ball records (but **no ARC-1 netlist**), Lab gates, notes, Archive, engineering manual, new developer work queue and JSON snapshot export. Automated smoke checks are included; browser and offline tests should be repeated after any edits.

**Remaining major blockers:** Efinity DDR generation, complete F484 pin/bank feasibility, RGMII, FPGA↔FPGA link, HDMI, power/thermal, USB, independent recovery and proper bitstream sizing. See `engineering/R22_CLAUDE_CODE_HANDOFF.md`.
