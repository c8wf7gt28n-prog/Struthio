// Zero-dependency development HTTP server, no deployment/public Internet access.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const port=Number(process.env.PORT||8000);
const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.webmanifest':'application/manifest+json','.md':'text/markdown; charset=utf-8','.xlsx':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','.csv':'text/csv; charset=utf-8','.png':'image/png'};
http.createServer((req,res)=>{
  const url=new URL(req.url||'/',`http://localhost:${port}`);
  let name;
  try{name=decodeURIComponent(url.pathname)}catch{res.writeHead(400);res.end('Bad URL');return}
  const normal=path.resolve(root,name.replace(/^\//,''));
  let file=normal;
  if(name==='/'||name.endsWith('/'))file=path.join(normal,'index.html');
  if(!file.startsWith(root+path.sep)&&file!==root){res.writeHead(403);res.end('Forbidden');return}
  fs.stat(file,(err,stat)=>{
    if(err||!stat.isFile()){res.writeHead(404);res.end('Not found');return}
    res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream','Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});
    fs.createReadStream(file).pipe(res);
  });
}).listen(port,'127.0.0.1',()=>console.log(`ARC-1 Project House at http://localhost:${port}`));
