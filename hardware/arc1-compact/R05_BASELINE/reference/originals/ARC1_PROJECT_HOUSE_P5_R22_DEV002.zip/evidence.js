/* ARC-1 DEV-002. Explicit interchange only; no native Efinity format is assumed.
   Read-only comparisons against manufacturer package definitions, never signoff. */
(()=>{'use strict';
const SCHEMA='arc1-evidence-v1', CSV_MARKER='#ARC1-EVIDENCE-CSV-v1';
const MAX_REPORT_BYTES=2*1024*1024, MAX_ARTIFACT_BYTES=32*1024*1024, MAX_TOTAL_ARTIFACT_BYTES=64*1024*1024;
const CHIPS=['T120-A','T120-B'], RESOURCES=['GPIO','DDR','CONFIG','JTAG','LVDS','CLOCK'];
const COLUMNS=['chip','ball','net','bank','voltage','resource','function'];
const PIN_HASH='2fd34c6e8d8448198369f7a4c1c7faf676a3dffb46fd3b7b67ae14d24897415b';
const WORKBOOK_HASH='8a6ecd5700c5895cfe306dfe3c37bac2d40feebe2b7ea4e8c43291eab831bc6d';
const object=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
const note=(code,path,message)=>({code,path,message});
const hashPattern=/^[a-f0-9]{64}$/;
const string=v=>typeof v==='string'&&v.trim().length>0&&v.length<=2048&&Array.from(v).length<=1024;
const voltage=v=>v===null||(typeof v==='number'&&Number.isFinite(v)&&v>0&&v<=6);
const archivePath=v=>string(v)&&!(/^(?:\/|[A-Za-z]:)|(?:^|[\\/])\.\.(?:[\\/]|$)|[\u0000-\u001f\u007f\u2028\u2029]/.test(v)||v.includes('\\'));
function timestamp(value){
 if(typeof value!=='string')return false;
 const m=value.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(?:Z|([+-])(\d{2}):(\d{2}))$/);
 if(!m)return false;
 const year=Number(m[1]),month=Number(m[2]),day=Number(m[3]);
 const leap=year%4===0&&(year%100!==0||year%400===0);
 const days=[31,leap?29:28,31,30,31,30,31,31,30,31,30,31];
 return month>=1&&month<=12&&day>=1&&day<=days[month-1]&&Number(m[4])<=23&&Number(m[5])<=59&&Number(m[6])<=59&&(!m[7]||(Number(m[8])<=23&&Number(m[9])<=59))&&Number.isFinite(Date.parse(value));
}
function shapeErrors(report){
 const errors=[];
 const error=(path,message)=>errors.push(note('SCHEMA',path,message));
 function keys(value,allowed,path){
  if(!object(value)){error(path,'Expected an object.');return false;}
  for(const k of Object.keys(value))if(!allowed.includes(k))error(path+'.'+k,'Undeclared field; v1 does not infer its meaning.');
  for(const k of allowed)if(!Object.hasOwn(value,k))error(path+'.'+k,'Required field missing; use null for explicitly unknown values.');
  return true;
 }
 const nullable=(value,path)=>{if(value!==null&&!string(value))error(path,'Expected a nonempty string or null.');};
 if(!keys(report,['schema','device','source','assignments','bankRails','signoffs'],'report'))return errors;
 if(report.schema!==SCHEMA)error('schema','Expected '+SCHEMA+'.');
 if(!string(report.device))error('device','Expected an exact device part string.');
 if(keys(report.source,['kind','tool','toolVersion','project','revision','generatedAt','artifacts'],'source')){
  if(!['interchange','efinity-export'].includes(report.source.kind))error('source.kind','Expected interchange or efinity-export (a reported origin, not authenticated).');
  for(const k of ['tool','toolVersion','project','revision','generatedAt'])nullable(report.source[k],'source.'+k);
  if(report.source.generatedAt!==null&&!timestamp(report.source.generatedAt))error('source.generatedAt','Expected a real calendar ISO timestamp with timezone or null.');
  if(!Array.isArray(report.source.artifacts)||report.source.artifacts.length>200)error('source.artifacts','Expected an array of at most 200 artifacts.');
  else report.source.artifacts.forEach((a,i)=>{const p='source.artifacts['+i+']';if(keys(a,['path','sha256','kind'],p)){
   if(!archivePath(a.path))error(p+'.path','Expected a relative archive path without traversal or backslashes.');
   if(a.sha256!==null&&(typeof a.sha256!=='string'||!hashPattern.test(a.sha256)))error(p+'.sha256','Expected lowercase SHA-256 or null.');
   if(!string(a.kind))error(p+'.kind','Expected artifact kind (reported, not interpreted).');
  }});
 }
 if(!Array.isArray(report.assignments)||report.assignments.length>2000)error('assignments','Expected at most 2000 assignment rows.');
 else report.assignments.forEach((a,i)=>{const p='assignments['+i+']';if(keys(a,COLUMNS,p)){
  for(const k of ['chip','ball','net'])if(!string(a[k]))error(p+'.'+k,'Expected a nonempty string.');
  for(const k of ['bank','function'])nullable(a[k],p+'.'+k);
  if(!voltage(a.voltage))error(p+'.voltage','Expected numeric volts >0 and <=6, or null. This bound does not certify a legal voltage.');
  if(!RESOURCES.includes(a.resource))error(p+'.resource','Expected '+RESOURCES.join(', ')+'.');
 }});
 if(!Array.isArray(report.bankRails)||report.bankRails.length>200)error('bankRails','Expected at most 200 bank rail rows.');
 else report.bankRails.forEach((a,i)=>{const p='bankRails['+i+']';if(keys(a,['chip','bank','voltage'],p)){
  for(const k of ['chip','bank'])if(!string(a[k]))error(p+'.'+k,'Expected a nonempty string.');
  if(!voltage(a.voltage))error(p+'.voltage','Expected numeric volts >0 and <=6, or null.');
 }});
 if(!Array.isArray(report.signoffs)||report.signoffs.length>50)error('signoffs','Expected at most 50 recorded claims; claims cannot close gates.');
 else report.signoffs.forEach((a,i)=>{const p='signoffs['+i+']';if(keys(a,['gate','status','artifactSha256'],p)){
  for(const k of ['gate','status'])if(!string(a[k]))error(p+'.'+k,'Expected a nonempty string.');
  if(a.artifactSha256!==null&&(typeof a.artifactSha256!=='string'||!hashPattern.test(a.artifactSha256)))error(p+'.artifactSha256','Expected lowercase SHA-256 or null.');
 }});
 return errors;
}
// Strict RFC-4180-style row reader, supporting quoted commas, quotes and newlines.
function csvRows(text){
 const rows=[];let row=[],field='',quoted=false,closed=false;
 for(let i=0;i<text.length;i++){
  const c=text[i];
  if(quoted){if(c==='"'){if(text[i+1]==='"'){field+='"';i++;}else{quoted=false;closed=true;}}else field+=c;continue;}
  if(c==='"'){if(field||closed)throw Error('Quote inside unquoted field.');quoted=true;continue;}
  if(c===','||c==='\n'||c==='\r'){
   row.push(field);field='';closed=false;
   if(c!==','){rows.push(row);row=[];if(c==='\r'&&text[i+1]==='\n')i++;}continue;
  }
  if(closed)throw Error('Unexpected character after closing quote.');
  field+=c;
 }
 if(quoted)throw Error('Unterminated quoted CSV field.');
 if(field||closed||row.length){row.push(field);rows.push(row);}
 return rows;
}
function parse(text,format){
 let report;
 try{
  if(typeof text!=='string')throw Error('Expected report text.');
  if(new TextEncoder().encode(text).byteLength>MAX_REPORT_BYTES)throw Error('Report exceeds 2 MiB.');
  const clean=text.replace(/^\uFEFF/,'');
  if(format==='json')report=JSON.parse(clean);
  else if(format==='csv'){
   const lines=clean.match(/^([^\r\n]*)\r?\n([^\r\n]*)\r?\n([\s\S]*)$/);
   if(!lines||lines[1]!==CSV_MARKER||!lines[2].startsWith('#metadata:'))throw Error('CSV requires the declared marker and one #metadata: JSON line. Native vendor CSV is not supported.');
   report=JSON.parse(lines[2].slice(10));
   if(!object(report)||Object.hasOwn(report,'assignments'))throw Error('CSV metadata must be an object without assignments.');
   const rows=csvRows(lines[3]);
   if(!rows.length||JSON.stringify(rows.shift())!==JSON.stringify(COLUMNS))throw Error('CSV header must exactly be '+COLUMNS.join(',')+'.');
   report.assignments=rows.map((row,i)=>{
    if(row.length!==COLUMNS.length)throw Error('CSV row '+(i+4)+' has '+row.length+' fields; expected 7.');
    if(row[4]!==''&&!/^(?:\d+(?:\.\d+)?|\.\d+)$/.test(row[4]))throw Error('CSV row '+(i+4)+' voltage must be decimal volts or blank.');
    return Object.fromEntries(COLUMNS.map((k,j)=>[k,k==='voltage'?(row[j]===''?null:Number(row[j])):(['bank','function'].includes(k)&&row[j]===''?null:row[j])]));
   });
  }else throw Error('Select explicitly declared json or csv format.');
 }catch(e){return {ok:false,report:null,parserErrors:[note('PARSE','input',e.message)]};}
 const parserErrors=shapeErrors(report);
 return {ok:parserErrors.length===0,report:parserErrors.length?null:report,parserErrors};
}
function blank(){return {status:'UNKNOWN',parserErrors:[],conflicts:[],unknowns:[],source:null,summary:{assignments:0,devices:[],banks:0},gates:Array.from({length:11},(_,i)=>({id:'G'+String(i+1).padStart(2,'0'),status:'OPEN'})),assignments:[],banks:[],artifacts:[]};}
function validate(report,pins){
 const result=blank(), errors=shapeErrors(report);
 if(errors.length){result.status='PARSER_ERROR';result.parserErrors=errors;return result;}
 result.source=JSON.parse(JSON.stringify(report.source));
 const conflict=(code,path,message)=>result.conflicts.push(note(code,path,message));
 const unknown=(code,path,message)=>result.unknowns.push(note(code,path,message));
 const inventory=new Map();
 if(!Array.isArray(pins)){result.status='PARSER_ERROR';result.parserErrors.push(note('INVENTORY','pins','Manufacturer inventory is unavailable.'));return result;}
 if(pins.some(p=>!object(p))){result.status='PARSER_ERROR';result.parserErrors.push(note('INVENTORY','pins','Every manufacturer row must be an object.'));return result;}
 for(const chip of CHIPS){
  const map=new Map(),rows=pins.filter(p=>p.chip===chip);
  for(const p of rows){if(!string(p.ball)||!string(p.name)||!string(p.bank)||!string(p.role)||typeof p.ddr!=='string'||map.has(p.ball)){result.parserErrors.push(note('INVENTORY','pins','Malformed or duplicate manufacturer row for '+chip+'.'));break;}map.set(p.ball,p);}
  if(map.size!==484)result.parserErrors.push(note('INVENTORY','pins','Expected 484 manufacturer balls for '+chip+'.'));
  inventory.set(chip,map);
 }
 if(pins.length!==968)result.parserErrors.push(note('INVENTORY','pins','Expected exactly 968 A/B package definitions.'));
 if(result.parserErrors.length){result.status='PARSER_ERROR';return result;}
 const railMaps=new Map();
 for(const [chip,map] of inventory){
  const rails=new Map();
  // Shared supply identities are copied from real VCCIO package function names.
  for(const p of map.values())if(p.role==='POWER'&&p.name.startsWith('VCCIO')&&p.name!=='VCCIO_DDR'){
   for(const token of p.name.slice(5).split('_'))rails.set(/^[1-4][A-Z]$/.test(token)?'BANK'+token:token,p.name);
  }
  rails.set('BANK3E','VCCIO_DDR'); // Dedicated DDR bank in the supplied F484 source.
  railMaps.set(chip,rails);
 }
 if(report.device!=='T120F484I4')conflict('DEVICE_PART','device','Expected exact R22 device T120F484I4; received '+report.device+'.');
 const usedBalls=new Map(),usedNets=new Map(),groups=new Map(),declaredBanks=new Set();
 function bank(chip,value,path){
  if(!CHIPS.includes(chip)){conflict('DEVICE_INSTANCE',path,'Unknown FPGA instance '+chip+'.');return null;}
  const known=new Set([...inventory.get(chip).values()].map(p=>p.bank).filter(b=>b!=='-'));
  if(!known.has(value)){conflict('UNKNOWN_BANK',path,'Bank '+value+' is absent from '+chip+' manufacturer dictionary.');return null;}
  const rail=railMaps.get(chip).get(value);
  if(!rail){unknown('RAIL_MAPPING',path,'No shared supply identity established for '+value+'.');return null;}
  return rail;
 }
 function addVoltage(chip,rail,value,path){
  if(!rail)return;
  const key=chip+'/'+rail;
  if(!groups.has(key))groups.set(key,{chip,rail,voltages:[],rows:[]});
  const group=groups.get(key);group.rows.push(path);
  if(value===null)unknown('VOLTAGE_UNKNOWN',path,'VCCIO requirement is unknown for '+key+'.');
  else if(!group.voltages.includes(value))group.voltages.push(value);
 }
 report.bankRails.forEach((r,i)=>{
  const path='bankRails['+i+']',key=r.chip+'/'+r.bank;
  if(declaredBanks.has(key))conflict('DUPLICATE_BANK',path,'Repeated bank rail declaration '+key+'.');
  declaredBanks.add(key);addVoltage(r.chip,bank(r.chip,r.bank,path),r.voltage,path);
 });
 report.assignments.forEach((a,i)=>{
  const path='assignments['+i+']',key=a.chip+'/'+a.ball,net=a.chip+'/'+a.net;
  if(usedBalls.has(key))conflict('BALL_REUSE',path,'Ball '+key+' is already assigned at '+usedBalls.get(key)+'.');
  if(usedNets.has(net))conflict('DUPLICATE_NET',path,'Logical signal '+net+' is repeated at '+usedNets.get(net)+'. Fan-out requires separate modeled ports, not duplicate rows.');
  usedBalls.set(key,path);usedNets.set(net,path);
  if(!CHIPS.includes(a.chip)){conflict('DEVICE_INSTANCE',path,'Unknown FPGA instance '+a.chip+'.');return;}
  const p=inventory.get(a.chip).get(a.ball);
  if(!p){conflict('UNKNOWN_BALL',path,'Ball '+key+' does not exist in the manufacturer dictionary.');return;}
  const rail=p.bank==='-'?null:bank(a.chip,p.bank,path);
  result.assignments.push({...a,manufacturer:{bank:p.bank,name:p.name,role:p.role,ddr:p.ddr},rail});
  if(a.bank===null)unknown('BANK_UNREPORTED',path,'No reported bank; manufacturer dictionary says '+p.bank+'.');
  else if(a.bank!==p.bank)conflict('BANK_MISMATCH',path,'Reported '+a.bank+' differs from source '+p.bank+' for '+key+'.');
  // These suffixes are precisely the optional functions in F484 worksheet column C.
  const configToken=p.name.match(/(?:^|_)(CDI(?:[0-9]|[12][0-9]|3[01])|CBUS[0-2]|CCK|CSI|CSO|CRESET_N|CDONE|CBSEL[01]|SS_N|NSTATUS|TEST_N)$/)?.[1];
  const jtagToken=p.name.match(/(?:^|_)(TCK|TMS|TDI|TDO)$/)?.[1];
  const config=Boolean(configToken),jtag=Boolean(jtagToken);
  if(a.function===null)unknown('FUNCTION_UNREPORTED',path,'No reported package function for '+key+'.');
  else if(a.function!==p.name&&!(a.resource==='DDR'&&p.ddr&&a.function===p.ddr)&&!(a.resource==='CONFIG'&&a.function===configToken)&&!(a.resource==='JTAG'&&a.function===jtagToken))conflict('FUNCTION_MISMATCH',path,'Reported function differs from source '+p.name+' for '+key+'.');
  if(p.role==='POWER'||(p.role==='OTHER'&&!config&&!jtag))conflict('RESERVED_BALL',path,'Source '+p.name+' is '+p.role+'; signal assignment is prohibited by this schema.');
  else if(p.role==='OTHER'&&((config&&a.resource!=='CONFIG')||(jtag&&a.resource!=='JTAG')))conflict('CONFIG_RESERVED',path,'Dedicated configuration/JTAG ball '+key+' cannot be assigned to '+a.resource+'.');
  else if(p.role==='DDR'&&a.resource!=='DDR')conflict('DDR_RESERVED',path,'Dedicated DDR ball '+key+' cannot be assigned to '+a.resource+'.');
  else if(a.resource==='DDR'&&p.role!=='DDR'&&!p.ddr)conflict('DDR_RESOURCE',path,'No DDR function documented at '+key+'.');
  if(config&&p.role==='GPIO')unknown('CONFIG_RESERVATION',path,'Multiplexed configuration/test function '+p.name+' requires authentic boot/programming mode and reservation review.');
  if(jtag&&p.role==='GPIO')unknown('JTAG_RESERVATION',path,'Multiplexed JTAG function '+p.name+' requires reservation review.');
  if(a.resource==='CONFIG'&&!config)conflict('CONFIG_RESOURCE',path,'No configuration/test function documented at '+key+'.');
  if(a.resource==='JTAG'&&!jtag)conflict('JTAG_RESOURCE',path,'No JTAG function documented at '+key+'.');
  if(p.ddr&&p.role!=='DDR')unknown('DDR_REFERENCE_RESERVATION',path,'DDR PHY reference-clock candidate; generated controller selection/reservation is unavailable.');
  if(['LVDS','CLOCK'].includes(a.resource))unknown('INTERFACE_LEGALITY',path,'Pair direction, clock routing, PLL and timing legality require real Efinity outputs; a package match is insufficient.');
  if(a.resource==='DDR')unknown('DDR_CONFIGURATION',path,'Package DDR labels do not establish LPDDR2 CA mapping, memory timing, density or calibration.');
  addVoltage(a.chip,rail,a.voltage,path);
  if(rail&&!report.bankRails.some(r=>r.chip===a.chip&&railMaps.get(a.chip).get(r.bank)===rail&&r.voltage!==null))unknown('BANK_RAIL_UNDECLARED',path,'No explicit non-null bank rail declaration for '+a.chip+'/'+rail+'.');
 });
 for(const group of groups.values()){
  if(group.voltages.length>1)conflict('SHARED_RAIL_CONFLICT',group.rows.join(', '),group.chip+'/'+group.rail+' has incompatible reported voltages '+group.voltages.join(' / ')+' V.');
  unknown('VOLTAGE_LEGALITY',group.chip+'/'+group.rail,'Reported rail agreement does not prove supported I/O standards, voltage range, SI or timing.');
 }
 report.signoffs.forEach((s,i)=>{
  if(!result.gates.some(g=>g.id===s.gate))conflict('UNKNOWN_GATE','signoffs['+i+']','Unknown gate '+s.gate+'.');
  if(!['OPEN','UNKNOWN'].includes(s.status))conflict('SIGNOFF_NOT_SUPPORTED','signoffs['+i+']','Reported '+s.status+' cannot be certified by pin intake, including claims with artifact hashes. '+s.gate+' stays OPEN.');
 });
 const paths=new Set();
 for(const a of report.source.artifacts){if(paths.has(a.path))conflict('DUPLICATE_ARTIFACT','source.artifacts','Repeated artifact path '+a.path+'.');paths.add(a.path);}
 for(const k of ['tool','toolVersion','project','revision','generatedAt'])if(report.source[k]===null)unknown('PROVENANCE_UNKNOWN','source.'+k,'Source '+k+' was not reported.');
 unknown('AUTHENTICITY_UNVERIFIED','source','Origin and artifact contents are not authenticated. Native Efinity adapter awaits an authentic export.');
 for(const chip of CHIPS)if(!report.assignments.some(a=>a.chip===chip))unknown('DEVICE_COVERAGE',chip,'No assignments supplied for '+chip+'.');
 unknown('COMPLETENESS_UNVERIFIED','assignments','Partial reports cannot prove the combined DDR, HDMI, RGMII, SPI, A/B link, JTAG and configuration plan.');
 unknown('HARDWARE_GATES_OPEN','gates','All G01–G11 remain OPEN. No EDA, timing, PCB or measured hardware approval is granted.');
 result.banks=[...groups.values()];
 result.summary={assignments:report.assignments.length,devices:[...new Set(report.assignments.map(a=>a.chip))],banks:groups.size};
 result.status=result.conflicts.length?'CONFLICT':'UNKNOWN';return result;
}
async function sha256(bytes){
 if(!globalThis.crypto?.subtle)throw Error('SHA-256 requires a secure browser context or Node Web Crypto.');
 return Array.from(new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');
}
async function intake({text,format,filename,pins,attachments=[],reportBytes,inventoryBytes}={}){
 const parsed=parse(text,format), result=parsed.ok?validate(parsed.report,pins):blank();
 if(!parsed.ok){result.status='PARSER_ERROR';result.parserErrors=parsed.parserErrors;}
 result.input={filename:String(filename||'unnamed report'),format,sha256:null,raw:typeof text==='string'&&new TextEncoder().encode(text).byteLength<=MAX_REPORT_BYTES?text:null};
 try{
  const bytes=reportBytes||new TextEncoder().encode(text||'');
  if(bytes.byteLength>MAX_REPORT_BYTES)throw Error('Report exceeds 2 MiB.');
  // The hash binds the exact imported bytes, including any BOM and line endings.
  if(reportBytes&&new TextDecoder('utf-8',{fatal:true}).decode(bytes)!==text.replace(/^\uFEFF/,''))throw Error('Report bytes do not match supplied text.');
  result.input.sha256=await sha256(bytes);
  result.inventory={path:'pins.json',expectedSha256:PIN_HASH,actualSha256:null,status:'UNKNOWN',workbook:{path:'engineering/T120_pinout_v1.4.xlsx',sha256:WORKBOOK_HASH}};
  if(inventoryBytes){
   result.inventory.actualSha256=await sha256(inventoryBytes);
   const matches=JSON.stringify(JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(inventoryBytes)))===JSON.stringify(pins);
   result.inventory.status=result.inventory.actualSha256===PIN_HASH&&matches?'HASH_MATCH':'MISMATCH';
   if(result.inventory.status==='MISMATCH')result.parserErrors.push(note('INVENTORY_INTEGRITY','pins.json','Source bytes/hash or parsed inventory differ from the archived manufacturer-derived dictionary.'));
  }else result.unknowns.push(note('INVENTORY_HASH_UNKNOWN','pins.json','Inventory byte hash was not supplied; source integrity cannot be verified in this intake.'));
  if(!Array.isArray(attachments)||attachments.length>200)throw Error('Expected at most 200 evidence attachments.');
  let total=0;const supplied=new Map();
  for(const a of attachments){
   if(!object(a)||!archivePath(a.name)||!(a.bytes instanceof Uint8Array))throw Error('Attachment requires a relative archive path name and Uint8Array bytes.');
   total+=a.bytes.byteLength;
   if(a.bytes.byteLength>MAX_ARTIFACT_BYTES||total>MAX_TOTAL_ARTIFACT_BYTES)throw Error('Evidence attachment limit: 32 MiB each, 64 MiB total.');
   if(supplied.has(a.name))throw Error('Ambiguous duplicate attachment name '+a.name+'.');
   supplied.set(a.name,await sha256(a.bytes));
  }
  if(parsed.ok){
   for(const a of parsed.report.source.artifacts){
    const actual=supplied.get(a.path)||null;
    const status=!actual?'MISSING':!a.sha256?'HASH_UNDECLARED':actual===a.sha256?'HASH_MATCH':'MISMATCH';
    result.artifacts.push({path:a.path,kind:a.kind,expectedSha256:a.sha256,actualSha256:actual,status});
    if(status==='MISMATCH')result.conflicts.push(note('ARTIFACT_HASH_MISMATCH','source.artifacts',a.path+' does not match its reported SHA-256.'));
    else if(status!=='HASH_MATCH')result.unknowns.push(note('ARTIFACT_'+status,'source.artifacts',a.path+': '+status+'.'));
   }
   for(const [path,actualSha256] of supplied)if(!parsed.report.source.artifacts.some(a=>a.path===path)){
    result.artifacts.push({path,expectedSha256:null,actualSha256,status:'UNDECLARED'});
    result.unknowns.push(note('ARTIFACT_UNDECLARED','attachments',path+' is not declared by the report.'));
   }
   if(!parsed.report.source.artifacts.length)result.unknowns.push(note('ARTIFACTS_MISSING','source.artifacts','No authentic project, constraints, warnings or timing artifacts supplied.'));
  }
 }catch(e){result.parserErrors.push(note('INTAKE','input',e.message));}
 result.status=result.parserErrors.length?'PARSER_ERROR':result.conflicts.length?'CONFLICT':'UNKNOWN';
 return result;
}
globalThis.ARC1Evidence=Object.freeze({SCHEMA,CSV_MARKER,MAX_REPORT_BYTES,MAX_ARTIFACT_BYTES,MAX_TOTAL_ARTIFACT_BYTES,PIN_HASH,WORKBOOK_HASH,parse,validate,intake,sha256});
})();
