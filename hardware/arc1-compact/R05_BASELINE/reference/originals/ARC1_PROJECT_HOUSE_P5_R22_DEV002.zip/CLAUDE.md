# ARC-1 Project House — Claude Code authority

**Start here.** This is an independent ARC-1 tabletop console project, not the previous handheld/game studio. R22 is the hardware **architecture baseline**, and Pass 05 is the current PWA software pass.

## First commands

```bash
npm test
npm run serve
```

Open `http://localhost:8000` in a browser; use the **Claude Code handoff** tile in House or **Lab → Open developer handoff**. No npm dependency install is needed.

## Read in this order

1. `engineering/R22_CLAUDE_CODE_HANDOFF.md` — complete human handoff, scope, immediate tasks.
2. `engineering/R22_TABLETOP_SYSTEM_WORK_ORDER.md` — the selected architecture and stop conditions.
3. `engineering/R22_EVIDENCE_POLICY.md` — hard distinction between documents, compile tests and hardware proof.
4. `tasks/roadmap.json` — machine-readable task queue and verifiable outcomes.
5. `engineering/R22_EFINITY_FIRST_SESSION.md` — vendor tool requirements.

## Architectural invariants

- **Tabletop ARC-1**; external off-the-shelf HDMI monitor/TV; external USB HID gamepads.
- **CPU:** Allwinner F133-B, 64 MiB in-package DDR2.
- **FPGA A:** Efinix T120F484I4 permanent GPU, proposed dedicated 128 MiB 1 Gbit ×32 LPDDR2.
- **FPGA B:** same T120F484I4, game-defined accelerator, same independent 128 MiB candidate memory.
- **F133→A:** RGMII candidate with *independent SPI rescue*. Direct MAC-to-MAC interoperability **unproven**.
- **A↔B:** high-throughput direct data link, width/clocking unknown; do not auto-lock 16+16 or 32+32.
- **Display:** T120-A via proven-architecture LVDS/HDMI bridge candidate, but legal F484 pin plan not yet validated.
- **Storage:** separate protected system/recovery and rewritable games devices. Capacities not locked.
- **128 MiB in each FPGA:** no arbitrary per-game 16 MiB budget. All RAM pools are physically separate; capacity/allocator design not measured.
- Permanent hardware must be wired for *maximum useful capabilities*; simple first boot cannot justify a deliberately limited lifetime PCB.

## Non-negotiable source integrity

- `pins.json` has **968 copied package-ball entries (484 × 2)** from official Efinix `engineering/T120_pinout_v1.4.xlsx`. These are **package pin definitions, NOT electrical PCB nets**.
- ALL provisional assignments remain UNKNOWN until a real Efinity-generated project has passed checks.
- No former-project branding, old PCB geometry, old assets, or inherited game project data. No fake ARC-1 CAD. Circle/slash means *not modeled*.
- Keep manufacturer documented capabilities separate from calculated performance targets and actual measured results.
- Never mark gates passed on an agent's assertion; require an archived traceable artifact and test.
- No unapproved vendor IP redistribution; assess licenses first.
- Do not silently invent components, packages, pinouts, throughput, software driver availability or schematic nets.

## Immediate job to implement

**DEV-002: Efinity output/evidence intake and pin-conflict validator.**

Work on task definitions in `tasks/roadmap.json`. Build a small source-backed importer for **explicitly declared JSON/CSV report formats** (never assume what Efinity emits). Keep reported source provenance, compare ball names with both T120 dictionaries, verify duplicate nets/ball reuse, shared bank rail conflicts, and DDR/config reserved resources. Distinguish input-parser errors from verified conflicts. Include negative test vectors. Offer read-only results in Project House; do not mutate the manufacturer pin inventory.

When source formats are unknown, first implement a documented interchange schema and tests; build the native Efinity adapter only after inspecting an authentic export.

## Good continuation procedure

Run tests before work; make one small change per task; add automated tests; perform browser smoke tests; update `engineering/` and `tasks/roadmap.json` with evidence links. Leave unsolved questions as OPEN. Preserve all the six bottom navigation departments and a simple no-dependency offline-first app unless there is a demonstrated need for tooling. Record changed files and remaining gates in each handoff.
