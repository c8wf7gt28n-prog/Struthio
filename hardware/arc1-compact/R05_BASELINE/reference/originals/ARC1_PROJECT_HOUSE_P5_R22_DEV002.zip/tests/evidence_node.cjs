/* DEV-002 synthetic parser/validator vectors built from the real F484 dictionary.
 * These tests are software checks, never authentic Efinity output or hardware proof.
 * No fixture assigns ARC-1 PCB nets or closes G01–G11. */
const {test,before}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const {createHash,webcrypto}=require('node:crypto');
const root=path.resolve(__dirname,'..');
const inventoryBytes=fs.readFileSync(path.join(root,'pins.json'));
const pins=JSON.parse(inventoryBytes.toString('utf8'));
const sourcePins=pins.filter(p=>p.chip==='T120-A');
const clone=value=>JSON.parse(JSON.stringify(value));
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const bytes=text=>new TextEncoder().encode(text);
let evidence;
before(async()=>{
  if(!globalThis.crypto?.subtle)globalThis.crypto=webcrypto;
  await import(pathToFileURL(path.join(root,'evidence.js')).href);
  evidence=globalThis.ARC1Evidence;
});
function pin(ball,chip='T120-A'){
  const found=pins.find(p=>p.chip===chip&&p.ball===ball);
  assert.ok(found,'Test vector ball must exist in the real dictionary: '+chip+'/'+ball);
  return found;
}
function row(ball='P4',overrides={}){
  const p=pin(ball,overrides.chip||'T120-A');
  return {chip:p.chip,ball:p.ball,net:'SYNTHETIC_TEST_'+p.ball,bank:p.bank,voltage:null,resource:'GPIO',function:p.name,...overrides};
}
function report(overrides={}){
  return {
    schema:'arc1-evidence-v1',device:'T120F484I4',
    source:{kind:'interchange',tool:null,toolVersion:null,project:null,revision:null,generatedAt:null,artifacts:[]},
    assignments:[row()],bankRails:[],signoffs:[],...overrides
  };
}
function parse(value,format='json'){return evidence.parse(typeof value==='string'?value:JSON.stringify(value),format);}
function validate(value){return evidence.validate(value,pins);}
function codes(result,field='conflicts'){return result[field].map(x=>x.code);}
function has(result,code,field='conflicts'){assert.ok(codes(result,field).includes(code),code+' absent: '+JSON.stringify(result[field]));}
function openGates(result){
  assert.deepEqual(result.gates,Array.from({length:11},(_,i)=>({id:'G'+String(i+1).padStart(2,'0'),status:'OPEN'})));
}
function noConflicts(result){assert.deepEqual(result.parserErrors,[]);assert.deepEqual(result.conflicts,[]);assert.equal(result.status,'UNKNOWN');openGates(result);}
function csv(value,ending='\n'){
  const meta=clone(value);delete meta.assignments;
  const escaped=v=>v===null?'':/[",\r\n]/.test(String(v))?'"'+String(v).replaceAll('"','""')+'"':String(v);
  return '#ARC1-EVIDENCE-CSV-v1'+ending+'#metadata:'+JSON.stringify(meta)+ending+
    'chip,ball,net,bank,voltage,resource,function'+ending+
    value.assignments.map(a=>['chip','ball','net','bank','voltage','resource','function'].map(k=>escaped(a[k])).join(',')).join(ending)+ending;
}
async function intake(value=report(),extras={}){
  const text=JSON.stringify(value);
  return evidence.intake({text,format:'json',filename:'SYNTHETIC-test-report.json',pins,inventoryBytes,...extras});
}
function freeze(value){if(value&&typeof value==='object'){Object.values(value).forEach(freeze);Object.freeze(value);}return value;}

test('real source dictionary and workbook hashes match archived intake identities',()=>{
  assert.equal(pins.length,968);
  for(const chip of ['T120-A','T120-B'])assert.equal(new Set(pins.filter(p=>p.chip===chip).map(p=>p.ball)).size,484);
  assert.equal(hash(inventoryBytes),evidence.PIN_HASH);
  assert.equal(hash(fs.readFileSync(path.join(root,'engineering/T120_pinout_v1.4.xlsx'))),evidence.WORKBOOK_HASH);
  assert.ok(pins.every(p=>p.net===''),'Manufacturer dictionary must stay electrically unassigned');
});

test('valid explicit JSON preserves reported provenance and remains UNKNOWN with every gate OPEN',()=>{
  const value=report();
  value.source={...value.source,kind:'efinity-export',tool:'Efinity (reported only)',toolVersion:'synthetic-vector',project:'SYNTHETIC SOFTWARE TEST',revision:'test-only',generatedAt:'2026-10-12T00:00:00Z'};
  const parsed=parse(value);assert.equal(parsed.ok,true);assert.deepEqual(parsed.report,value);
  const result=validate(parsed.report);noConflicts(result);
  assert.deepEqual(result.source,value.source);has(result,'AUTHENTICITY_UNVERIFIED','unknowns');has(result,'COMPLETENESS_UNVERIFIED','unknowns');
});

test('semantic conflicts stay separate from JSON parser/schema errors',()=>{
  const value=report({device:'T120F324I4',assignments:[{...row(),ball:'NOT_A_PACKAGE_BALL'}]});
  const parsed=parse(value);assert.equal(parsed.ok,true);assert.deepEqual(parsed.parserErrors,[]);
  const result=validate(parsed.report);assert.equal(result.status,'CONFLICT');assert.deepEqual(result.parserErrors,[]);has(result,'DEVICE_PART');has(result,'UNKNOWN_BALL');
  const malformed=parse('{');assert.equal(malformed.ok,false);assert.equal(malformed.report,null);has(malformed,'PARSE','parserErrors');
  const result2=validate({device:'T120F484I4'});assert.equal(result2.status,'PARSER_ERROR');assert.deepEqual(result2.conflicts,[]);openGates(result2);
});

for(const key of ['schema','device','source','assignments','bankRails','signoffs'])test('strict JSON root requires '+key,()=>{
  const value=report();delete value[key];const result=parse(value);assert.equal(result.ok,false);has(result,'SCHEMA','parserErrors');
});

test('nullable values are explicit, and missing fields are never silently inferred',()=>{
  const value=report({assignments:[row('P4',{bank:null,voltage:null,function:null})],bankRails:[{chip:'T120-A',bank:'BANK1B',voltage:null}],signoffs:[{gate:'G01',status:'OPEN',artifactSha256:null}]});
  assert.equal(parse(value).ok,true);
  const result=validate(value);noConflicts(result);has(result,'BANK_UNREPORTED','unknowns');has(result,'FUNCTION_UNREPORTED','unknowns');has(result,'VOLTAGE_UNKNOWN','unknowns');
  for(const k of ['bank','voltage','function']){const missing=clone(value);delete missing.assignments[0][k];assert.equal(parse(missing).ok,false,k+' must be explicitly present');}
  for(const k of ['tool','toolVersion','project','revision','generatedAt']){const missing=clone(value);delete missing.source[k];assert.equal(parse(missing).ok,false,'source.'+k+' must be present');}
});

test('undeclared fields, wrong types, invalid voltages and timestamps are rejected as schema errors',()=>{
  const vectors=[
    {...report(),unrecognized:true},report({schema:'vendor-native'}),report({assignments:null}),
    report({assignments:[row('P4',{resource:'AUTO'})]}),report({assignments:[row('P4',{voltage:'1.8'})]}),
    report({assignments:[row('P4',{voltage:0})]}),report({assignments:[row('P4',{voltage:7})]}),
    report({assignments:[row('P4',{net:''})]}),report({assignments:[row('P4',{bank:''})]}),
    report({bankRails:[{chip:'T120-A',bank:'BANK1B',voltage:null,extra:true}]}),
    report({source:{...report().source,tool:42}}),report({source:{...report().source,generatedAt:'2026-10-12'}}),
    report({source:{...report().source,artifacts:[{path:'test.txt',sha256:'NOT-A-HASH',kind:'synthetic'}]}}),
    report({signoffs:[{gate:'G01',status:'OPEN'}]})
  ];
  for(const value of vectors){const result=parse(value);assert.equal(result.ok,false,JSON.stringify(value));has(result,'SCHEMA','parserErrors');}
  for(const input of [null,[],42,'"text"'])assert.equal(parse(input).ok,false);
});

test('reported timestamps reject impossible calendar dates without normalizing provenance',()=>{
  for(const generatedAt of ['2026-02-30T00:00:00Z','2026-02-29T00:00:00Z','2026-04-31T00:00:00Z','2026-13-01T00:00:00Z','2026-10-12T24:00:00Z']){
    const result=parse(report({source:{...report().source,generatedAt}}));assert.equal(result.ok,false,generatedAt);has(result,'SCHEMA','parserErrors');
  }
  for(const generatedAt of ['2024-02-29T00:00:00Z','2026-10-12T12:34:56.123Z','2026-10-12T12:34:56+05:30']){
    const result=parse(report({source:{...report().source,generatedAt}}));assert.equal(result.ok,true,generatedAt);assert.equal(result.report.source.generatedAt,generatedAt);
  }
});

test('string limits count Unicode code points and reject empty or whitespace-only identifiers',()=>{
  assert.equal(parse(report({assignments:[row('P4',{net:'😀'.repeat(1024)})]})).ok,true);
  assert.equal(parse(report({assignments:[row('P4',{net:'😀'.repeat(1025)})]})).ok,false);
  for(const net of ['', ' ', '\t\n'])assert.equal(parse(report({assignments:[row('P4',{net})]})).ok,false);
});

test('unsupported formats and native-looking vendor CSV fail parsing without invented hardware conflicts',async()=>{
  for(const format of [undefined,'native','xml','JSON'])assert.equal(evidence.parse(JSON.stringify(report()),format).ok,false);
  const text='Pin Name,Bank,Port Name\nP4,1B,SYNTHETIC_TEST\n';
  const result=await evidence.intake({text,format:'csv',pins,inventoryBytes});
  assert.equal(result.status,'PARSER_ERROR');has(result,'PARSE','parserErrors');assert.deepEqual(result.conflicts,[]);openGates(result);
});

test('declared RFC4180 CSV handles BOM, CRLF, quotes, commas, Unicode and embedded newlines',()=>{
  const value=report({assignments:[row('P4',{net:'SYNTHETIC, "quoted"\nUnicode Ω',bank:null,voltage:null,function:null}),row('P5',{voltage:1.8})]});
  for(const ending of ['\n','\r\n']){const parsed=parse('\uFEFF'+csv(value,ending),'csv');assert.equal(parsed.ok,true,JSON.stringify(parsed.parserErrors));assert.deepEqual(parsed.report,value);}
});

test('CSV metadata and header are exact and malformed records remain parser errors',()=>{
  const valid=csv(report()),prefix=valid.slice(0,valid.indexOf('chip,ball'));
  const vectors=[
    valid.replace('#ARC1-EVIDENCE-CSV-v1','#ARC1-EVIDENCE-CSV-v2'),
    valid.replace('#metadata:','#meta:'),valid.replace('chip,ball,net,bank,voltage,resource,function','ball,chip,net,bank,voltage,resource,function'),
    prefix+'chip,ball,net,bank,voltage,resource,function\nT120-A,P4,short\n',
    prefix+'chip,ball,net,bank,voltage,resource,function\nT120-A,P4,"unterminated\n',
    prefix+'chip,ball,net,bank,voltage,resource,function\nT120-A,P4,"closed"extra,BANK1B,,GPIO,GPIOL_36\n',
    prefix+'chip,ball,net,bank,voltage,resource,function\nT120-A,P4,un"quoted,BANK1B,,GPIO,GPIOL_36\n'
  ];
  // Metadata containing assignments is ambiguous and prohibited.
  vectors.push('#ARC1-EVIDENCE-CSV-v1\n#metadata:'+JSON.stringify(report())+'\nchip,ball,net,bank,voltage,resource,function\n');
  for(const text of vectors){const result=parse(text,'csv');assert.equal(result.ok,false,text);has(result,'PARSE','parserErrors');}
  for(const invalid of ['NaN','1e0','+1.8','-1','0x2',' 1.8']){
    const text=csv(report({assignments:[row('P4',{voltage:1.8})]})).replace(',1.8,',','+invalid+',');
    assert.equal(parse(text,'csv').ok,false,invalid);
  }
});

for(const [label,changes,code] of [
  ['device part',{device:'T120F484I3'},'DEVICE_PART'],
  ['instance',{assignments:[{...row(),chip:'T120-C'}]},'DEVICE_INSTANCE'],
  ['unknown ball',{assignments:[{...row(),ball:'ZZ99'}]},'UNKNOWN_BALL'],
  ['case-mismatched ball',{assignments:[{...row(),ball:'p4'}]},'UNKNOWN_BALL'],
  ['bank mismatch',{assignments:[row('P4',{bank:'BANK2A'})]},'BANK_MISMATCH'],
  ['function mismatch',{assignments:[row('P4',{function:'INVENTED_VENDOR_FUNCTION'})]},'FUNCTION_MISMATCH'],
  ['unknown rail bank',{bankRails:[{chip:'T120-A',bank:'BANK9Z',voltage:1.8}]},'UNKNOWN_BANK'],
  ['power bank sentinel',{bankRails:[{chip:'T120-A',bank:'-',voltage:1.8}]},'UNKNOWN_BANK'],
  ['rail instance',{bankRails:[{chip:'T120-C',bank:'BANK1B',voltage:1.8}]},'DEVICE_INSTANCE']
])test('source identity conflict: '+label,()=>{const result=validate(report(changes));assert.equal(result.status,'CONFLICT');assert.deepEqual(result.parserErrors,[]);has(result,code);openGates(result);});

test('duplicate ball reuse and logical net assignments conflict within a chip only',()=>{
  has(validate(report({assignments:[row('P4'),row('P4',{net:'SYNTHETIC_SECOND'})]})),'BALL_REUSE');
  has(validate(report({assignments:[row('P4',{net:'SYNTHETIC_SAME'}),row('P5',{net:'SYNTHETIC_SAME'})]})),'DUPLICATE_NET');
  const independent=report({assignments:[row('P4',{net:'SYNTHETIC_SAME'}),row('P4',{chip:'T120-B',net:'SYNTHETIC_SAME'})]});
  noConflicts(validate(independent));
});

for(const [bank1,bank2] of [['BANK1B','BANK1C'],['BANK1D','BANK1E'],['BANK1F','BANK1G'],['BANK3D','TR'],['BANK3D','BR'],['TR','BR']])test('source shared supply conflict: '+bank1+' / '+bank2,()=>{
  const result=validate(report({assignments:[],bankRails:[{chip:'T120-A',bank:bank1,voltage:1.8},{chip:'T120-A',bank:bank2,voltage:3.3}]}));
  has(result,'SHARED_RAIL_CONFLICT');assert.equal(result.banks.length,1);openGates(result);
});

test('assignment requirements, duplicate bank declarations and explicit same-bank voltage disagreement are checked',()=>{
  const a=sourcePins.find(p=>p.bank==='BANK1B'&&p.role==='GPIO'&&!p.ddr),b=sourcePins.find(p=>p.bank==='BANK1C'&&p.role==='GPIO'&&!p.ddr);
  has(validate(report({assignments:[row(a.ball,{voltage:1.8}),row(b.ball,{voltage:3.3})]})),'SHARED_RAIL_CONFLICT');
  const result=validate(report({assignments:[row('P4',{voltage:1.8})],bankRails:[{chip:'T120-A',bank:'BANK1B',voltage:3.3}]}));
  has(result,'SHARED_RAIL_CONFLICT');
  has(validate(report({bankRails:[{chip:'T120-A',bank:'BANK1B',voltage:1.8},{chip:'T120-A',bank:'BANK1B',voltage:1.8}]})),'DUPLICATE_BANK');
});

test('distinct source rails and independent FPGA supplies do not create false voltage collisions',()=>{
  for(const rails of [
    [{chip:'T120-A',bank:'BANK1B',voltage:1.8},{chip:'T120-A',bank:'BANK2A',voltage:3.3}],
    [{chip:'T120-A',bank:'BANK1B',voltage:1.8},{chip:'T120-B',bank:'BANK1C',voltage:3.3}],
    [{chip:'T120-A',bank:'BANK1B',voltage:1.8},{chip:'T120-A',bank:'BANK1C',voltage:1.8}]
  ]){const result=validate(report({assignments:[],bankRails:rails}));noConflicts(result);has(result,'VOLTAGE_LEGALITY','unknowns');}
});

test('null bank voltage and missing declaration stay UNKNOWN without inferred legal voltage',()=>{
  const result=validate(report({bankRails:[{chip:'T120-A',bank:'BANK1B',voltage:null}]}));
  noConflicts(result);has(result,'VOLTAGE_UNKNOWN','unknowns');has(result,'BANK_RAIL_UNDECLARED','unknowns');has(result,'VOLTAGE_LEGALITY','unknowns');
});

test('all 74 dedicated DDR source balls reject GPIO use and accept only documented DDR resources',()=>{
  const dedicated=sourcePins.filter(p=>p.role==='DDR');assert.equal(dedicated.length,74);
  for(const p of dedicated){
    has(validate(report({assignments:[row(p.ball)]})),'DDR_RESERVED');
    const result=validate(report({assignments:[row(p.ball,{resource:'DDR'})]}));noConflicts(result);has(result,'DDR_CONFIGURATION','unknowns');
  }
  has(validate(report({assignments:[row('P4',{resource:'DDR'})]})),'DDR_RESOURCE');
});

test('both GPIO DDR PHY reference candidates remain UNKNOWN for ordinary GPIO use',()=>{
  const refs=sourcePins.filter(p=>p.ddr&&p.role==='GPIO');assert.equal(refs.length,2);
  for(const p of refs){
    const result=validate(report({assignments:[row(p.ball)]}));noConflicts(result);has(result,'DDR_REFERENCE_RESERVATION','unknowns');
    const result2=validate(report({assignments:[row(p.ball,{resource:'DDR',function:p.ddr})]}));noConflicts(result2);has(result2,'DDR_CONFIGURATION','unknowns');
  }
});

test('dedicated configuration and JTAG pins allow their documented purpose and reject general or cross-purpose use',()=>{
  const config=['V5','V4'],jtag=['T1','U2','T3','U1'];
  for(const [balls,resource] of [[config,'CONFIG'],[jtag,'JTAG']])for(const ball of balls){
    noConflicts(validate(report({assignments:[row(ball,{resource})]})));
    for(const wrong of ['GPIO',resource==='CONFIG'?'JTAG':'CONFIG']){
      const result=validate(report({assignments:[row(ball,{resource:wrong})]}));assert.equal(result.status,'CONFLICT',ball+'/'+wrong);assert.ok(result.conflicts.length>0);openGates(result);
    }
  }
  has(validate(report({assignments:[row('P4',{resource:'CONFIG'})]})),'CONFIG_RESOURCE');
  has(validate(report({assignments:[row('P4',{resource:'JTAG'})]})),'JTAG_RESOURCE');
});

test('all real multiplexed configuration token suffixes remain unresolved for GPIO and accept exact declared capability',()=>{
  const tokens=new Set(['SS_N','CCK','CSI','CSO','CBUS0','CBUS1','CBUS2','NSTATUS','TEST_N','CBSEL0','CBSEL1',...Array.from({length:32},(_,i)=>'CDI'+i)]);
  const multiplexed=sourcePins.filter(p=>p.role==='GPIO'&&[...tokens].some(token=>p.name.endsWith('_'+token)));
  assert.equal(multiplexed.length,43);
  for(const p of multiplexed){
    const token=[...tokens].find(t=>p.name.endsWith('_'+t));
    const gpio=validate(report({assignments:[row(p.ball)]}));noConflicts(gpio);has(gpio,'CONFIG_RESERVATION','unknowns');
    for(const func of [p.name,token])noConflicts(validate(report({assignments:[row(p.ball,{resource:'CONFIG',function:func})]})));
    has(validate(report({assignments:[row(p.ball,{resource:'CONFIG',function:'INCORRECT_CONFIG_TOKEN'})]})),'FUNCTION_MISMATCH');
  }
});

test('all supply and six reference-resistor balls are prohibited as user signal assignments',()=>{
  const reserved=sourcePins.filter(p=>p.role==='POWER'||p.name.startsWith('REF_RES_'));assert.equal(reserved.length,148);
  for(const p of reserved){const result=validate(report({assignments:[row(p.ball)]}));has(result,'RESERVED_BALL');openGates(result);}
  for(const ball of ['C5','D8','C10','Y10','W6','AA3'])has(validate(report({assignments:[row(ball,{resource:'CONFIG'})]})),'RESERVED_BALL');
});

test('LVDS and CLOCK declarations stay UNKNOWN because inventory lacks pair, clock and timing legality',()=>{
  for(const resource of ['LVDS','CLOCK']){const result=validate(report({assignments:[row('P4',{resource})]}));noConflicts(result);has(result,'INTERFACE_LEGALITY','unknowns');}
});

test('actual attachment byte hashes distinguish match, mismatch, absent, undeclared hash and undeclared attachment',async()=>{
  const content=bytes('SYNTHETIC SOFTWARE TEST ARTIFACT. NOT EFINITY OR HARDWARE EVIDENCE.\n');
  const value=report({source:{...report().source,artifacts:[{path:'synthetic.txt',sha256:hash(content),kind:'synthetic-test-vector'}]}});
  const matched=await intake(value,{attachments:[{name:'synthetic.txt',bytes:content}]});
  noConflicts(matched);assert.equal(matched.artifacts[0].status,'HASH_MATCH');assert.equal(matched.artifacts[0].actualSha256,hash(content));has(matched,'AUTHENTICITY_UNVERIFIED','unknowns');
  const mismatch=await intake(value,{attachments:[{name:'synthetic.txt',bytes:bytes('altered synthetic content')}]});
  assert.equal(mismatch.artifacts[0].status,'MISMATCH');has(mismatch,'ARTIFACT_HASH_MISMATCH');
  const missing=await intake(value);noConflicts(missing);assert.equal(missing.artifacts[0].status,'MISSING');has(missing,'ARTIFACT_MISSING','unknowns');
  const undeclaredHash=clone(value);undeclaredHash.source.artifacts[0].sha256=null;
  const withoutHash=await intake(undeclaredHash,{attachments:[{name:'synthetic.txt',bytes:content}]});noConflicts(withoutHash);assert.equal(withoutHash.artifacts[0].status,'HASH_UNDECLARED');
  const extra=await intake(report(),{attachments:[{name:'extra.txt',bytes:content}]});noConflicts(extra);assert.equal(extra.artifacts[0].status,'UNDECLARED');has(extra,'ARTIFACT_UNDECLARED','unknowns');
});

test('artifact path duplication is a conflict; duplicate attachment names are ambiguous input errors',async()=>{
  const artifact={path:'synthetic.txt',sha256:null,kind:'synthetic-test-vector'};
  has(validate(report({source:{...report().source,artifacts:[artifact,{...artifact}]}})),'DUPLICATE_ARTIFACT');
  const attachment={name:'synthetic.txt',bytes:bytes('synthetic')};
  const result=await intake(report(),{attachments:[attachment,{...attachment}]});assert.equal(result.status,'PARSER_ERROR');has(result,'INTAKE','parserErrors');openGates(result);
});

test('unsafe or undeclared artifact path forms never receive filesystem interpretation',()=>{
  for(const artifactPath of ['/absolute.txt','../escape.txt','folder/../escape.txt','C:/drive.txt','folder\\file.txt','file\nname.txt','file\u0000name.txt','file\u007fname.txt','file\u2028name.txt','file\u2029name.txt','   ']){
    const result=parse(report({source:{...report().source,artifacts:[{path:artifactPath,sha256:null,kind:'synthetic'}]}}));assert.equal(result.ok,false,artifactPath);has(result,'SCHEMA','parserErrors');
  }
});

test('unsafe attachment path names are rejected even when absent from the report',async()=>{
  for(const name of ['/absolute.txt','../escape.txt','folder/../escape.txt','C:/drive.txt','folder\\file.txt','file\nname.txt','file\u0000name.txt','file\u007fname.txt','file\u2028name.txt','file\u2029name.txt','   ']){
    const result=await intake(report(),{attachments:[{name,bytes:bytes('synthetic')}]});assert.equal(result.status,'PARSER_ERROR',name);has(result,'INTAKE','parserErrors');openGates(result);
  }
  const nested=await intake(report(),{attachments:[{name:'synthetic/folder/file.txt',bytes:bytes('synthetic')}]});noConflicts(nested);assert.equal(nested.artifacts[0].path,'synthetic/folder/file.txt');
});

test('raw report bytes, including BOM and line endings, and actual inventory bytes are hashed exactly',async()=>{
  const text='\uFEFF'+JSON.stringify(report(),null,2).replaceAll('\n','\r\n');
  const raw=bytes(text),result=await intake(report(),{text,reportBytes:raw,filename:'synthetic-exact-bytes.json'});
  noConflicts(result);assert.equal(result.input.raw,text);assert.equal(result.input.sha256,hash(raw));assert.equal(result.input.filename,'synthetic-exact-bytes.json');
  assert.equal(result.inventory.status,'HASH_MATCH');assert.equal(result.inventory.actualSha256,hash(inventoryBytes));
  const mismatch=await intake(report(),{reportBytes:bytes(JSON.stringify(report())+' ')});
  assert.equal(mismatch.status,'PARSER_ERROR');has(mismatch,'INTAKE','parserErrors');openGates(mismatch);
});

test('inventory hash checks detect altered bytes and divergence between parsed inventory and source bytes',async()=>{
  const altered=clone(pins);altered[0].net='SYNTHETIC_MUTATION_TEST';
  const changedBytes=bytes(JSON.stringify(altered));
  for(const extras of [{inventoryBytes:changedBytes,pins:altered},{pins:altered}]){
    const result=await intake(report(),extras);assert.equal(result.status,'PARSER_ERROR');assert.equal(result.inventory.status,'MISMATCH');has(result,'INVENTORY_INTEGRITY','parserErrors');openGates(result);
  }
  const omitted=await intake(report(),{inventoryBytes:undefined});noConflicts(omitted);assert.equal(omitted.inventory.status,'UNKNOWN');has(omitted,'INVENTORY_HASH_UNKNOWN','unknowns');
});

test('missing, short, duplicate or malformed manufacturer inventory is a parser error',async()=>{
  const duplicate=clone(pins);duplicate[1]=clone(duplicate[0]);
  const malformed=clone(pins);malformed[0].ddr=null;
  const nullRow=clone(pins);nullRow[0]=null;
  for(const inventory of [null,[],pins.slice(1),duplicate,malformed,nullRow]){
    const result=evidence.validate(report(),inventory);assert.equal(result.status,'PARSER_ERROR');has(result,'INVENTORY','parserErrors');assert.deepEqual(result.conflicts,[]);openGates(result);
  }
  const result=await intake(report(),{pins:nullRow});assert.equal(result.status,'PARSER_ERROR');has(result,'INVENTORY','parserErrors');assert.deepEqual(result.conflicts,[]);openGates(result);
});

test('claimed signoffs and even matching attached artifacts cannot close any of G01–G11',async()=>{
  const content=bytes('SYNTHETIC CLAIM ONLY - NOT A SIGNOFF'),digest=hash(content);
  const value=report({
    source:{...report().source,artifacts:[{path:'synthetic-claim.txt',sha256:digest,kind:'synthetic-test-vector'}]},
    signoffs:Array.from({length:11},(_,i)=>({gate:'G'+String(i+1).padStart(2,'0'),status:'PASS',artifactSha256:digest}))
  });
  const result=await intake(value,{attachments:[{name:'synthetic-claim.txt',bytes:content}]});
  assert.equal(result.status,'CONFLICT');assert.equal(result.artifacts[0].status,'HASH_MATCH');assert.equal(codes(result).filter(c=>c==='SIGNOFF_NOT_SUPPORTED').length,11);openGates(result);
  has(validate(report({signoffs:[{gate:'G99',status:'OPEN',artifactSha256:null}]})),'UNKNOWN_GATE');
  noConflicts(validate(report({signoffs:[{gate:'G01',status:'OPEN',artifactSha256:null},{gate:'G02',status:'UNKNOWN',artifactSha256:null}]})));
});

test('read-only validation and intake leave reports, manufacturer dictionaries and source bytes immutable',async()=>{
  const frozenPins=freeze(clone(pins)),value=freeze(report()),beforeReport=JSON.stringify(value),beforePins=JSON.stringify(frozenPins),beforeBytes=hash(inventoryBytes);
  const validated=evidence.validate(value,frozenPins);noConflicts(validated);
  const result=await intake(value,{pins:frozenPins});noConflicts(result);
  result.source.kind='changed-result-only';result.assignments[0].manufacturer.name='changed-result-only';
  assert.equal(JSON.stringify(value),beforeReport);assert.equal(JSON.stringify(frozenPins),beforePins);assert.equal(hash(inventoryBytes),beforeBytes);
  assert.equal(hash(fs.readFileSync(path.join(root,'pins.json'))),evidence.PIN_HASH);
});

test('report limits apply to UTF-8 byte count and schema row counts',()=>{
  assert.equal(evidence.MAX_REPORT_BYTES,2*1024*1024);
  const oversized='é'.repeat(evidence.MAX_REPORT_BYTES/2+1);assert.equal(evidence.parse(oversized,'json').ok,false);
  for(const value of [
    report({assignments:Array.from({length:2001},()=>row())}),
    report({bankRails:Array.from({length:201},()=>({chip:'T120-A',bank:'BANK1B',voltage:null}))}),
    report({source:{...report().source,artifacts:Array.from({length:201},(_,i)=>({path:'synthetic-'+i+'.txt',sha256:null,kind:'synthetic'}))}}),
    report({signoffs:Array.from({length:51},()=>({gate:'G01',status:'OPEN',artifactSha256:null}))})
  ])assert.equal(parse(value).ok,false);
});

test('attachment count, type, per-file and aggregate byte limits reject ambiguous or oversized intake',async()=>{
  assert.equal(evidence.MAX_ARTIFACT_BYTES,32*1024*1024);assert.equal(evidence.MAX_TOTAL_ARTIFACT_BYTES,64*1024*1024);
  const oneMax=new Uint8Array(evidence.MAX_ARTIFACT_BYTES);
  const vectors=[
    {},Array.from({length:201},(_,i)=>({name:'synthetic-'+i,bytes:new Uint8Array()})),
    [{name:'synthetic.txt',bytes:'not-byte-data'}],
    [{name:'synthetic.txt',bytes:new Uint8Array(evidence.MAX_ARTIFACT_BYTES+1)}],
    [{name:'synthetic-a',bytes:oneMax},{name:'synthetic-b',bytes:oneMax},{name:'synthetic-c',bytes:new Uint8Array(1)}]
  ];
  for(const attachments of vectors){const result=await intake(report(),{attachments});assert.equal(result.status,'PARSER_ERROR');has(result,'INTAKE','parserErrors');openGates(result);}
});
