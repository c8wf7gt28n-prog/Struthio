#!/usr/bin/env python3
"""Optional real-browser checks; requires Python Playwright, Chromium and serve.

Run npm run serve, then python tests/browser_smoke.py. No npm dependency is added.
Fixtures derive package identities from pins.json and are synthetic software tests,
never authentic Efinity evidence, schematic assignments or hardware approvals.
"""
import argparse
import copy
import csv
import hashlib
import io
import json
import pathlib
import sys
from datetime import datetime, timezone

ROOT = pathlib.Path(__file__).resolve().parents[1]


def fixtures():
    inventory = (ROOT / "pins.json").read_bytes()
    pins = json.loads(inventory)
    selected = next(p for p in pins if p["chip"] == "T120-A" and
                    p["role"] == "GPIO" and not p["ddr"] and p["ball"] == "P4")
    report = json.loads((ROOT / "engineering/ARC1_EVIDENCE_TEMPLATE.json").read_text())
    report["source"]["project"] = 'SYNTHETIC <img src=x onerror="window.__injected=true">'
    report["assignments"] = [{"chip": selected["chip"], "ball": selected["ball"],
        "net": "SYNTHETIC_BROWSER_TEST", "bank": selected["bank"], "voltage": 1.8,
        "resource": "GPIO", "function": selected["name"]}]
    return report, inventory


def csv_bytes(report):
    meta = copy.deepcopy(report)
    del meta["assignments"]
    out = io.StringIO(newline="")
    out.write("#ARC1-EVIDENCE-CSV-v1\r\n#metadata:" + json.dumps(meta) + "\r\n")
    writer = csv.writer(out)
    keys = ["chip", "ball", "net", "bank", "voltage", "resource", "function"]
    writer.writerow(keys)
    for row in report["assignments"]:
        writer.writerow([row[key] if row[key] is not None else "" for key in keys])
    return out.getvalue().encode()


def run(args, output):
    from playwright.sync_api import sync_playwright, expect
    report, inventory = fixtures()
    checks = output["checks"]
    errors = []
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=args.chromium, headless=True)
        context = browser.new_context(viewport={"width": 1280, "height": 900},
                                      accept_downloads=True)
        page = context.new_page()
        page.on("pageerror", lambda error: errors.append(str(error)))
        page.on("console", lambda message: errors.append(message.text) if message.type == "error" else None)
        page.goto(args.base_url, wait_until="networkidle")
        local_before = page.evaluate("JSON.stringify(Object.entries(localStorage))")

        def nav(name):
            page.locator('.house-nav [data-page="' + name + '"]').click()
            expect(page.locator('.house-nav [data-page="' + name + '"]')).to_have_attribute("aria-current", "page")
            assert page.evaluate("location.hash") == "#" + name

        for name in ["home", "viewer", "systems", "lab", "manual", "archive"]:
            nav(name)
            expect(page.locator("#mainContent")).not_to_be_empty()
        checks.append("Desktop six-department navigation and route transitions")
        nav("viewer")
        for tab, count in [("assembly", 5), ("pcb", 9), ("case", 4), ("face", 3),
                           ("firmware", 5), ("tools", 4)]:
            page.locator('[data-viewer="tab"][data-value="' + tab + '"]').click()
            expect(page.locator(".viewer-layer")).to_have_count(count)
        page.locator('[data-viewer="tab"][data-value="pcb"]').click()
        page.locator('[data-viewer="solo"][data-value="gpua"]').click()
        expect(page.locator(".viewport h2")).to_have_text("T120-A permanent GPU")
        expect(page.locator(".view-count")).to_have_text("1/9 selected")
        page.locator('[data-viewer="all"]').click()
        expect(page.locator(".view-count")).to_have_text("9/9 selected")
        page.locator('[data-viewer="none"]').click()
        expect(page.locator(".view-count")).to_have_text("0/9 selected")
        checks.append("Six viewer tabs; isolation, all and clear; no geometry")

        nav("systems")
        expect(page.locator("#pinResults")).to_contain_text("968 matching physical balls")
        page.locator("#chipFilter").select_option("T120-A")
        expect(page.locator("#pinResults")).to_contain_text("484 matching physical balls")
        page.locator("#pinSearch").fill("P4")
        expect(page.locator("#pinResults")).to_contain_text("P4")
        nav("lab")
        assert page.locator(".gate-id").all_text_contents() == ["G%02d" % i for i in range(1, 12)]
        for gate in page.locator(".gate").all():
            assert "OPEN" in gate.inner_text().upper()
        checks.append("Real per-device manufacturer pin inventory; all eleven hardware gates OPEN")

        def clear():
            page.locator("#evidenceClear").click()
            expect(page.locator("#evidenceResults")).to_contain_text("No evidence imported")

        def select(raw, fmt="json", filename=None):
            page.locator("#evidenceFormat").select_option(fmt)
            page.locator("#evidenceReportFile").set_input_files({"name": filename or "SYNTHETIC." + fmt,
                "mimeType": "application/json" if fmt == "json" else "text/csv", "buffer": raw})

        def complete(status):
            page.locator("#evidenceImport").click()
            expect(page.locator("#evidenceResults")).to_contain_text("Intake result: " + status)
            expect(page.locator("#evidenceResults")).to_have_attribute("aria-busy", "false")
            expect(page.locator("#evidenceResults")).to_contain_text("G01–G11 remain OPEN")

        raw = json.dumps(report, indent=2).encode()
        select(raw)
        nav("home")
        nav("lab")
        expect(page.locator("#evidenceIntake")).to_contain_text("Report: SYNTHETIC.json")
        complete("UNKNOWN")
        expect(page.locator("#evidenceResults")).to_contain_text("1 assignments · 1 devices")
        expect(page.locator("#evidenceResults")).to_contain_text("1.8 V")
        assert not page.evaluate("Boolean(window.__injected)")
        assert page.locator("#evidenceResults img").count() == 0
        with page.expect_download() as download_info:
            page.locator("#evidenceExport").click()
        exported = json.loads(pathlib.Path(download_info.value.path()).read_text())
        assert exported["input"]["raw"] == raw.decode()
        assert exported["input"]["sha256"] == hashlib.sha256(raw).hexdigest()
        assert exported["inventory"]["actualSha256"] == hashlib.sha256(inventory).hexdigest()
        assert exported["source"] == report["source"]
        assert exported["gates"] == [{"id": "G%02d" % i, "status": "OPEN"} for i in range(1, 12)]
        checks.append("JSON UNKNOWN; navigation retains files/results; raw bytes/hash/provenance export; text escaped")

        clear()
        select(b'{"malformed":', filename="SYNTHETIC-malformed.json")
        complete("PARSER_ERROR")
        expect(page.locator("#evidenceResults")).to_contain_text("Parser errors")
        expect(page.locator("#evidenceResults")).to_contain_text("Verified conflicts · 0")
        clear()
        conflict = copy.deepcopy(report)
        conflict["assignments"].append({**conflict["assignments"][0], "net": "SYNTHETIC_REUSE"})
        select(json.dumps(conflict).encode())
        complete("CONFLICT")
        expect(page.locator("#evidenceResults")).to_contain_text("BALL_REUSE")
        checks.append("Malformed JSON parser errors isolated from source-backed ball collision")

        clear()
        select(csv_bytes(report), "csv")
        complete("UNKNOWN")
        clear()
        select(b"Pin Name,Bank,Port Name\nP4,1B,SYNTHETIC\n", "csv")
        complete("PARSER_ERROR")
        clear()
        select(csv_bytes(conflict), "csv")
        complete("CONFLICT")
        expect(page.locator("#evidenceResults")).to_contain_text("BALL_REUSE")
        checks.append("Declared CSV UNKNOWN/CONFLICT and undeclared native-looking CSV PARSER_ERROR")

        clear()
        artifact = b"SYNTHETIC local software artifact\r\n"
        with_artifact = copy.deepcopy(report)
        artifact_hash = hashlib.sha256(artifact).hexdigest()
        with_artifact["source"]["artifacts"] = [{"path": "synthetic/bench.txt", "sha256": artifact_hash,
                                                  "kind": "synthetic-software-test"}]
        select(json.dumps(with_artifact).encode())
        page.locator("#evidenceArtifactFiles").set_input_files({"name": "bench.txt", "mimeType": "text/plain", "buffer": artifact})
        page.locator('[data-evidence-path="0"]').fill("synthetic/bench.txt")
        nav("manual")
        nav("lab")
        expect(page.locator('[data-evidence-path="0"]')).to_have_value("synthetic/bench.txt")
        complete("UNKNOWN")
        page.locator(".evidence-details").filter(has_text="Declared artifact hash checks").locator("summary").click()
        expect(page.locator("#evidenceResults")).to_contain_text("HASH_MATCH")
        expect(page.locator("#evidenceResults")).to_contain_text(artifact_hash)
        with page.expect_download() as download_info:
            page.locator("#evidenceExport").click()
        artifact_export = json.loads(pathlib.Path(download_info.value.path()).read_text())
        assert artifact_export["artifacts"][0]["actualSha256"] == artifact_hash
        checks.append("Optional artifact file retained, explicit path mapping, exact hash/export, no authenticity claim")

        clear()
        # Delay real File reads so a clear/new import can supersede the prior operation.
        page.evaluate("""() => {const read=File.prototype.arrayBuffer;
          window.__originalFileRead=read; File.prototype.arrayBuffer=function(){
            const file=this; return new Promise(r=>setTimeout(r,350)).then(()=>read.call(file));};} """)
        select(json.dumps(conflict).encode(), filename="SYNTHETIC-stale.json")
        page.locator("#evidenceImport").click()
        clear()
        select(raw, filename="SYNTHETIC-current.json")
        complete("UNKNOWN")
        expect(page.locator("#evidenceResults")).to_contain_text("SYNTHETIC-current.json")
        assert "SYNTHETIC-stale.json" not in page.locator("#evidenceResults").inner_text()
        page.evaluate("File.prototype.arrayBuffer=window.__originalFileRead")
        assert page.evaluate("JSON.stringify(Object.entries(localStorage))") == local_before
        checks.append("Clear/reimport cancels stale async reads; intake leaves localStorage unchanged")

        args.output_dir.mkdir(parents=True, exist_ok=True)
        page.screenshot(path=str(args.output_dir / "desktop-evidence.png"), full_page=True)
        page.set_viewport_size({"width": 390, "height": 844})
        for name in ["home", "viewer", "systems", "lab", "manual", "archive"]:
            nav(name)
            assert page.locator(".house-nav").is_visible()
        nav("lab")
        assert page.evaluate("document.documentElement.scrollWidth <= window.innerWidth")
        page.screenshot(path=str(args.output_dir / "mobile-evidence.png"), full_page=True)
        checks.append("Mobile six-department navigation, evidence layout and screenshots")

        page.evaluate("navigator.serviceWorker.ready")
        page.wait_for_function("navigator.serviceWorker.controller !== null")
        cache_urls = page.evaluate("""async()=>{const keys=await caches.keys();
          const key=keys.find(k=>k.startsWith('arc1-house-')); const cache=await caches.open(key);
          return (await cache.keys()).map(r=>new URL(r.url).pathname);} """)
        for asset in ["/evidence.js", "/evidence-ui.js", "/pins.json", "/engineering/ARC1_EVIDENCE_SCHEMA.json",
                      "/engineering/ARC1_EVIDENCE_TEMPLATE.csv", "/engineering/R22_EVIDENCE_INTAKE.md"]:
            assert any(url.endswith(asset) for url in cache_urls), asset
        context.set_offline(True)
        page.reload(wait_until="load")
        nav("lab")
        expect(page.locator("#evidenceResults")).to_contain_text("No evidence imported")
        select(raw)
        complete("UNKNOWN")
        nav("systems")
        expect(page.locator("#pinResults")).to_contain_text("968 matching physical balls")
        context.set_offline(False)
        checks.append("Actual SW precache, offline reload/navigation/intake, reload clears session evidence")
        assert not errors, "Browser errors: " + json.dumps(errors)
        checks.append("No console errors or unhandled browser exceptions")
        output["consoleErrors"] = errors
        browser.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", default="http://localhost:8000/")
    parser.add_argument("--chromium", default="/usr/bin/chromium")
    parser.add_argument("--output-dir", type=pathlib.Path, default=pathlib.Path("/tmp/arc1-browser-smoke"))
    args = parser.parse_args()
    output = {"test": "optional real-browser software verification", "hardwareGates": "G01–G11 OPEN",
              "timestamp": datetime.now(timezone.utc).isoformat(), "checks": [], "status": "FAILED"}
    try:
        run(args, output)
        output["status"] = "PASSED"
    except Exception as error:
        output["error"] = type(error).__name__ + ": " + str(error)
        if not output["checks"]:
            output["status"] = "BLOCKED"
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "browser-report.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))
    return 0 if output["status"] == "PASSED" else 2


if __name__ == "__main__":
    sys.exit(main())
