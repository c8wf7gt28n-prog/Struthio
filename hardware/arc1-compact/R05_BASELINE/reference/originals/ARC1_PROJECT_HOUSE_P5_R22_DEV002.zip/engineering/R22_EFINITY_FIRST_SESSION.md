# R22 Efinity handoff — Twin T120 architecture

1. Create two independent `T120F484I4` configurations, designated T120-A and T120-B.
2. For EACH FPGA, add one DDR_0 hard controller with LPDDR2 ×32, 1 Gbit density, planned 800 MT/s data rate. Select only documented configuration values and enter the exact Alliance device timings; never construct CA pin mapping from generic labels.
3. Export actual Interface Designer DDR pins, PLL configuration, VCCIO assignments and hard DDR startup settings separately for A and B.
4. Identify legal LVDS TX pairs and clock for T120-A to match the HDMI IT6263 bridge and do not collide with its DDR pins.
5. Mark candidate direct FPGA-to-FPGA link bank groups on BOTH chips. Compare 16+16 and 32+32 data signals plus source-synchronous clocks and handshakes for legal pins and achievable I/O constraints.
6. Identify candidate RGMII signals/clock-capable pins on A and reserve SPI rescue + configuration/JTAG. Validate RGMII bank voltage and physical launch/capture timing against the F133 MAC.
7. Create full-project pin/bank reports for BOTH FPGAs. Do not declare pin-lock without generated constraint review and successful synthesis/timing analysis.
8. Zip the native project, generated DDR and HDMI/IP files, pin report, timing analysis, warnings and errors for review.

Immediate minimum milestone: **one memory-only configuration for each T120**, followed by the pinplan feasibility for the complete lifetime interface.
