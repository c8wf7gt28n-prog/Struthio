# R22 / DEV-002 evidence intake v1

Implemented software scope: declared ARC-1 JSON/CSV interchange, local artifact hashing, and read-only comparisons against both manufacturer-derived T120 dictionaries. **No authentic Efinity export was provided. Native Efinity parsing remains OPEN until an untouched export can be inspected.** This format is a project interchange, not a claim about what Efinity emits.

Open Project House → Lab → Efinity evidence intake. Select the declared format and one report. Optionally select original project/report/constraint files and explicitly map each file to its declared archive path. Import and check, review the separate diagnostics, then export the result JSON. Files and results stay in tab memory; reloading clears intake. Nothing is uploaded or written to `pins.json`, notes, or gates. Keep original artifact files beside the result export: artifact bytes are hashed but are not embedded in that export.

## JSON contract

The schema identifier is `arc1-evidence-v1`. See [machine-readable schema](ARC1_EVIDENCE_SCHEMA.json) and [empty JSON template](ARC1_EVIDENCE_TEMPLATE.json). Every listed field is required. Unknown fields are rejected rather than guessed; explicitly unavailable scalar values use `null`. Empty arrays indicate no reported records. Templates contain no proposed signal assignments and are not vendor evidence.

| Field | Type / meaning |
|---|---|
| `schema` | Exact string `arc1-evidence-v1` |
| `device` | Exact part; the validator requires `T120F484I4` |
| `source.kind` | `interchange` or `efinity-export`; both are **reported origin** |
| `source.tool`, `toolVersion`, `project`, `revision` | Nonempty strings or null; preserve original identifiers |
| `source.generatedAt` | ISO timestamp with timezone or null; use the source's date, not an invented timestamp |
| `source.artifacts` | Up to 200 `{path, sha256, kind}` records. Relative archive path, lowercase SHA-256 or null, nonempty reported kind. No absolute/traversal/backslash paths or control/line-separator characters |
| `assignments` | Up to 2000 `{chip, ball, net, bank, voltage, resource, function}` records |
| `bankRails` | Up to 200 `{chip, bank, voltage}` explicit rail declarations |
| `signoffs` | Up to 50 `{gate, status, artifactSha256}` reported claims. Only OPEN/UNKNOWN are accepted; closure claims cause conflicts even with artifact hashes |

Strings are at most 1024 Unicode characters and cannot contain only whitespace. Missing keys, wrong types and undeclared fields are **parser errors**. Well-formed unsupported device/instance/ball/bank/function values are **conflicts**. Exact matching is case-sensitive: no trimming, aliases, automatic ball normalization or implicit unit conversion.

Assignments use `chip: "T120-A"` or `"T120-B"`, exact package ball, nonempty logical signal name, bank or null, numeric volts or null, resource `GPIO`, `DDR`, `CONFIG`, `JTAG`, `LVDS` or `CLOCK`, and source function or null. `function` is the exact manufacturer package name; CONFIG/JTAG may alternatively use the exact column-C token, and DDR may use the source DDR annotation. The net name is a reported logical signal/port, not a schematic netlist. Repeated names within one device are rejected; represent independently modeled ports separately for deliberate fan-out. Same names/balls on A and B refer to independent devices.

Numeric voltage bounds (>0 and ≤6 V) are input limits only, **not supported FPGA voltage claims**. Each assignment voltage is its required VCCIO, not an arbitrary signal amplitude. `bankRails` states the proposed bank supply. All explicit requirements/declarations within a manufacturer's shared supply group must agree. Missing values, electrical limits, standards and timing stay UNKNOWN. The source-defined shared supply groups are documented in [the source audit](R22_DEV002_SOURCE_AUDIT.md).

## CSV contract

Use [the empty CSV template](ARC1_EVIDENCE_TEMPLATE.csv). The first two physical lines must be:

```text
#ARC1-EVIDENCE-CSV-v1
#metadata:{...single-line JSON...}
```

The metadata is the complete JSON report **without** `assignments`. It retains schema, exact device, source, bankRails and signoffs. The next line must be exactly:

```csv
chip,ball,net,bank,voltage,resource,function
```

Remaining rows provide assignments. Quoted commas, doubled quotes and quoted newlines are supported; CRLF and LF are accepted. Seven fields are required. Empty bank/function/voltage cells become null. Voltage cells contain decimal volts only: no `V` suffix, scientific notation, hex or whitespace conversion. Blank assignment rows, malformed quotes, alternate headers, guessed native CSV and metadata containing assignments are rejected. A UTF-8 BOM is accepted and preserved in original report text/hash.

## Diagnostic and provenance boundaries

- **PARSER_ERROR:** invalid format/schema, unreadable/hash-unavailable bytes, attachment limits/ambiguous paths, or manufacturer inventory integrity failure. Conflicts are displayed separately if any were already found.
- **CONFLICT:** unknown/wrong source identities, ball reuse, duplicate signals, incorrect declared banks/functions, incompatible explicit shared-rail voltages, dedicated DDR/config/JTAG misuse, non-signal supply/reference-resistor use, artifact byte mismatch, or unsupported signoff claims.
- **UNKNOWN:** no detected conflict in the supplied information, with unresolved proof. This status is never PASS. Missing per-chip coverage, artifact files, provenance, rail requirements, multiplexed configuration and DDR reference selection are explicit unknowns. LVDS pair/clock/direction, PLL, DDIO, I/O standards, timing, memory CA mapping and whole-board completeness require real Efinity/engineering evidence.

Reports are limited to 2 MiB, attachments to 32 MiB each / 64 MiB total / 200 files. Files must be UTF-8 for report parsing. SHA-256 binds exact report/attachment bytes, including original line endings and BOM. Hash equality proves equality to the supplied declaration; it does **not** authenticate the author, vendor, tool run or artifact contents. Nested archive paths must be entered explicitly for selected files; filenames are never guessed or fetched remotely.

The browser also hashes the exact fetched `pins.json` bytes against the original handoff hash and binds those bytes to the dictionary used. Pure `validate(report, pins)` provides source comparisons only; async `intake(...)` adds hashes and integrity diagnostics. Exported result records include original report text, input hash, reported provenance, expected/actual artifact hashes, manufacturer inventory hash, comparison rows and all diagnostics. They contain **G01–G11 OPEN** regardless of input claims. The XLSX source hash is recorded; the importer does not execute/parse vendor projects or certify the workbook contents at runtime.

The dictionaries omit worksheet columns for LVDS pairs, DDIO and clock regions. Configuration suffix classification follows actual column-C tokens audited against F484. Both DDR reference candidates are GPIO alternatives, so their presence alone is not an unavoidable collision. Dedicated DDR balls cannot be reused as general GPIO. Dedicated configuration/JTAG balls require their documented resource; multiplexed GPIO alternatives remain subject to reservation review.

## Native adapter and remaining work

Archive untouched A/B Efinity projects, tool versions, exact DDR settings, generated constraints, pin/PLL/VCCIO reports, warnings/errors and STA reports with hashes. Inspect actual export samples before adding a version-specific adapter and golden parsing tests. Preserve originals and adapter revision; never infer Efinity format from the interchange or from synthetic test vectors.

Every unresolved hardware gate remains OPEN. No import grants electrical signoff, fixes bus width, confirms Alliance ball mapping, invents PCB geometry, validates RGMII MAC-to-MAC behavior, proves HDMI, measures throughput, sizes storage/regulators or authorizes fabrication. The R22 work order and evidence policy continue to govern release.
