# Pass 05 — Claude Code ready Project House

- Kept R22 twin-T120 tabletop architecture and all existing bottom departments.
- Added on-device developer handoff (`#handoff`) reachable from House and Lab.
- Added versioned machine-readable roadmap with owners, blockers and pass criteria.
- Added project snapshot JSON export combining roadmap and locally saved notes.
- Added `CLAUDE.md`, source/evidence policy, architecture handoff and zero-dependency Node workflow.
- Extended offline manifest to include developer handoff/roadmap documents.
- Added machine-checks for 968 ball definitions, immutable unassigned nets, local links and source integrity.
- No manufactured/synthesized hardware claims; all R22 P0 technical gates remain open.
- Removed old candidate-net CSV and regenerated a clean 968-row R22 T120 package-ball CSV without retired designs.
