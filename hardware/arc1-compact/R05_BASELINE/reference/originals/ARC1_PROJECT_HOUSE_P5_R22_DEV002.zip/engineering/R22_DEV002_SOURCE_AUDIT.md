# R22 / DEV-002 manufacturer source audit

Date: 2026-10-12. Scope: package definitions and source-backed validation rules only. This audit does not assign ARC-1 nets, select bank voltages, validate an Efinity build, or close any hardware gate.

## Sources and integrity

| File | SHA-256 |
|---|---|
| `engineering/T120_pinout_v1.4.xlsx` | `8a6ecd5700c5895cfe306dfe3c37bac2d40feebe2b7ea4e8c43291eab831bc6d` |
| `pins.json` | `2fd34c6e8d8448198369f7a4c1c7faf676a3dffb46fd3b7b67ae14d24897415b` |
| `engineering/R22_T120_PACKAGE_BALLS_UNASSIGNED.csv` | `a8b46b52e97f64a6dcb11f4a7ee9843c49643d6613b2c6705a3e009a12fa7cb5` |

The official workbook includes separate T120F324, T120F484 and T120F576 sheets. Only **T120F484**, associated with `xl/worksheets/sheet2.xml`, applies to this inventory. The Revision History identifies version 1.4 dated 2025-02-27, with the change “Added Clock Region column.” No data from the other packages was combined with F484.

## Comparison performed

The workbook was read using Python's standard-library ZIP and XML readers, resolving shared strings before inspecting cells. Rows with a package ball in column H were compared by exact ball key with each inventory instance:

| Workbook column | Source meaning | Inventory field |
|---|---|---|
| A | Bank Number | `bank` |
| B | Pin Names | `name` |
| D | DDR Interface | `ddr` |
| H | FBGA484 | `ball` |

All 484 package records for T120-A match these workbook fields exactly. T120-B has the same 484 definitions, differing only in `chip`. There are 968 total inventory records, with 484 unique balls in each independent device dictionary. The CSV's instance, ball, bank, vendor pin function, role, DDR annotation and unassigned net values match `pins.json` across all 968 rows. All inventory nets remain empty.

The `role` field is an existing application classification; the workbook has no `role` column. Its per-device counts are 256 GPIO, 74 DDR, 142 POWER and 12 OTHER. These counts do not certify usable ARC-1 I/O. Column C (Configuration Functions), column E (LVDS TX/RX Pairs), column F (DDIO), and column G (Clock Region) are **not stored in `pins.json`**. The dictionary alone therefore cannot prove LVDS pairing, DDIO support, configuration mode legality or clock routing.

## Shared VCCIO resources

These groupings follow the workbook's power pin names. A conflict between explicit, unequal requested voltages on any two group members is source-backed, even if the textual bank names differ. Each chip has its own groups; identical bank names across A and B do not establish a shared electrical rail.

| Source supply name | Member banks | Example F484 supply balls / workbook rows |
|---|---|---|
| `VCCIO1B_1C` | BANK1B, BANK1C | N3 / 393; N6 / 394; R5 / 395 |
| `VCCIO1D_1E` | BANK1D, BANK1E | J6 / 396; K3 / 397 |
| `VCCIO1F_1G` | BANK1F, BANK1G | F2 / 398; F3 / 399 |
| `VCCIO3D_TR_BR` | BANK3D, TR, BR | B18 / 412; C20 / 413 |

The remaining VCCIO names are `VCCIO1A`, `VCCIO2A` through `VCCIO2F`, `VCCIO4A` through `VCCIO4F`, and `VCCIO_DDR`. BANK3E contains the dedicated DDR resources; `VCCIO_DDR` is their named supply. All 142 power/ground records have `bank: "-"`: **do not treat this sentinel as one shared bank** or assign these balls as user signals. The workbook does not specify allowable rail voltages or I/O-standard compatibility in these columns. A consistent declared voltage is not proof that the selected standard or memory controller accepts it.

## Resource classification

### Dedicated DDR

All 74 inventory records with `role: "DDR"` are in BANK3E. Their pin names and DDR column annotations match exactly. Examples are M18 `DDR_A[0]`, K21 `DDR_DQ[0]`, N21 `DDR_CK`, P21 `DDR_CK_N`, K17 `DDR_VREF`, and P18 `DDR_ZQ`. General GPIO, link, display, RGMII, configuration or JTAG use of one of these dedicated DDR balls conflicts with its source-defined resource. Declaring a DDR purpose only establishes resource compatibility; it does not establish a legal LPDDR2 controller configuration or Alliance memory mapping.

Two **GPIO** records also have a DDR annotation:

| Ball | Bank | Pin name | Workbook row / DDR annotation |
|---|---|---|---|
| R12 | BANK4C | `GPIOB_RXP09_CLKP0` | 299 / `DDR (PHY) Reference Clock` |
| M15 | BR | `GPIOR_186_PLLIN0` | 339 / `DDR (PHY) Reference Clock` |

These are reference-clock candidates. Their annotation does not show which candidate an authentic controller project selects, and does not make both balls permanently reserved. Ordinary GPIO use without a reviewed reservation plan must remain **UNKNOWN**, not a verified collision. Once an imported plan explicitly reserves a selected candidate, contradictory use can be diagnosed against that declaration. Any such finding retains its reported provenance and is not an EDA signoff.

### Configuration and JTAG

There are 49 F484 rows with a nonempty Configuration Functions value in column C. Every token is either the exact pin name or the final suffix of the pin name. The complete token set is:

- `CDONE`, `CRESET_N`, `SS_N`, `CCK`, `CSI`, `CSO`.
- `CDI0` through `CDI31`.
- `CBUS0`, `CBUS1`, `CBUS2`.
- `TCK`, `TDI`, `TDO`, `TMS`.
- `NSTATUS`, `TEST_N`, `CBSEL0`, `CBSEL1`.

The dedicated configuration balls are V5 `CDONE` and V4 `CRESET_N`; the dedicated JTAG balls are T1 `TCK`, U2 `TDI`, T3 `TDO` and U1 `TMS`. All six have inventory role OTHER, and column C explicitly repeats the respective function. A declared configuration/JTAG function must match the exact source token; an arbitrary signal name by itself does not prove function ownership.

The remaining 43 column-C entries have role GPIO and are multiplexed configuration-capable pins. Examples are V3 `GPIOL_00_SS_N` (row 6), F1 `GPIOL_151_TEST_N` (row 77), F4 `GPIOL_156_CBSEL0` (row 78), Y7 `GPIOB_TXN13_CDI18` (row 311), and W4 `GPIOB_TXN03_CDI30` (row 326). Their configuration suffixes must be recognized even when their names begin with GPIO or LVDS-style TX labels. General use of a multiplexed ball remains **UNKNOWN** until authentic mode/resource choices resolve its configuration reservation; its alternate function alone does not establish an unavoidable conflict.

### Reference resistor and supply balls

Six OTHER records are dedicated reference-resistor resources: C5 `REF_RES_2A` (row 97), D8 `REF_RES_2B` (114), C10 `REF_RES_2C` (129), Y10 `REF_RES_4D` (310), W6 `REF_RES_4E` (325), and AA3 `REF_RES_4F` (338). Do not classify OTHER wholesale as configuration: it includes these non-user-I/O resources. POWER includes VCC, analog supplies, VCCIO and GND. None of these definitions is an ARC-1 net assignment.

## Safe intake and validator boundaries

- Check ball identity against the exact T120-A or T120-B dictionary. Ball reuse and duplicate logical signal assignments are checked within each device; matching ball names on two independent chips are not a collision.
- Separate malformed/unsupported input from conflicts established by recognized source definitions. An unrecognized format is a parser error, not evidence of a hardware collision.
- Compare explicit requested voltages using the supply groups above. Missing voltages remain UNKNOWN. No legal voltage, clock frequency, I/O standard, bank electrical limit or bus width is inferred from a consistent report.
- Distinguish dedicated resources from multifunction candidates. Matching a declared purpose to a documented capability is insufficient to establish an Efinity-approved pin plan.
- Retain exact artifact names, hashes and reported provenance. Hash equality establishes byte identity; it does not independently establish the author, native Efinity provenance or correctness of the source report.
- Synthetic negative test vectors may use real package definitions, but remain labeled test fixtures and never count as authentic vendor output or hardware evidence.
- No import, parser success, JavaScript test, conflict-free result or claimed signoff closes an unresolved gate. Native Efinity format support requires inspection of an authentic export. Both memory projects, full pin plans, STA, ERC/DRC/SI, recovery and prototype evidence remain OPEN under the R22 evidence policy.

No manufacturer inventory, package source, PCB geometry or hardware status was modified by this audit.
