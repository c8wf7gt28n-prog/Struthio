# R22 / DEV-002 test report

Date: 2026-10-12. Software tests only; no Efinity or physical hardware proof.

## Baseline before source modification

`npm test` in the extracted project passed the original navigation/viewer smoke tests and source/offline checks: six departments, six viewer tabs, solo/all/none, handoff with 10 task records, 968 unassigned A/B package definitions, and 21 offline assets. An initial invocation from `/workspace` had no package.json; the project-root run above passed before any source edit.

## Final verification

Final `npm test`: **PASS**, exit 0 on Node 24.19.0. [Full captured output](R22_DEV002_NPM_TEST.log) is included in this delivery.

| Executed check | Result |
|---|---|
| Original `tests/smoke_node.cjs` | PASS: six departments/viewer tabs, selection controls, handoff task fetch and 968 source balls |
| `tests/evidence_node.cjs` | 52 tests PASS, 0 fail, 0 skipped: strict JSON/CSV, exact source identities, duplicates, all shared rails, dedicated/multiplexed resources, provenance, actual hashes, invalid calendar dates, Unicode/byte limits, immutability and OPEN gates |
| `tests/intake_ui_node.cjs` | 8 tests PASS, 0 fail, 0 skipped: actual intake handlers with real dictionary bytes; escaped reported text, original report/hash export, artifact path mapping, JSON/CSV results, department navigation, clearing during reads, load retry and unreadable/oversized input |
| `tests/offline_node.cjs` | 7 tests PASS, 0 fail, 0 skipped: execute actual service-worker handlers with real file bytes; 30 precached assets, cache lifecycle, offline modules/templates/inventory/roadmap, navigation/data fallback and request filtering |
| `scripts/verify.mjs` | PASS: all 968 nets remain unassigned; original authority hashes unchanged; 10 tasks and byte-identical Archive mirror; 30 offline assets and all hardware gates OPEN |
| JavaScript syntax | PASS for evidence.js, evidence-ui.js, house.js and sw.js |
| Portable `tests/browser_smoke.py` syntax | PASS; this optional tool adds no npm dependency |
| Real local HTTP/browser execution | **BLOCKED**, not PASS; see details below |

There are **67 automated tests** across the three added suites, plus the original smoke/source verification scripts. DOM and service-worker harnesses use simulated browser APIs; they do not establish actual browser rendering or service-worker installation.

## Browser block and repeatable follow-up

`npm run serve` could not bind in the execution sandbox: `listen EPERM 127.0.0.1:8000`. A narrow permission attempt did not execute a server and was cancelled; no HTTP delivery check is counted as passing.

Chromium also failed at launch through Playwright's pipe transport, before any navigation, with crashpad `setsockopt: Operation not permitted (1)` and `SIGTRAP`. The executed portable test returned exit 2 with status BLOCKED and **zero browser checks executed**. [Machine-readable browser report](R22_DEV002_BROWSER_REPORT.json) contains the actual error. No browser screenshots, visual assertions, mobile rendering, real console-error check, PWA installation or actual offline browser reload was verified.

In a browser-capable environment, run:

```bash
npm test
npm run serve
```

Then, in a second terminal with Python Playwright and Chromium available:

```bash
python tests/browser_smoke.py --base-url http://localhost:8000/ --chromium /usr/bin/chromium
```

The optional script covers desktop/mobile navigation and Viewer, JSON/CSV diagnostic outcomes, file retention, explicit artifact path/hash/export, escaping, stale read cancellation, localStorage preservation, all OPEN gates and actual service-worker offline reload/intake. Its follow-up results must be reviewed rather than presumed. Native Efinity adapter tests still require untouched authentic exports.

## Review corrections

Independent source/code review identified invalid provenance dates normalized by JavaScript, null inventory rows throwing before diagnostics, and schema/runtime differences in path/string limits. The final implementation rejects impossible calendar dates and malformed inventory as parser errors, uses Unicode character limits, and applies matching archive-path restrictions. Added regressions pass. Multiplexed config and DDR reference alternatives remain UNKNOWN rather than invented unavoidable collisions.

## Evidence boundaries

The source audit compares the exact F484 sheet of the supplied Efinix workbook with all 484 definitions on each independent device and all 968 clean CSV records. Tests use these real package definitions with deliberately synthetic logical-signal/report vectors. They are parser/validator evidence only, never Efinity-generated output or ARC-1 electrical proof.

Native Efinity import, vendor synthesis/STA, LPDDR2 mapping/calibration, HDMI, RGMII, A/B link, USB, storage/recovery, power/thermal and all PCB/prototype acceptance work remain unperformed. G01–G11 remain OPEN and fabrication remains NO-GO. Safari/iPhone physical-device installation is not tested in this workspace.
