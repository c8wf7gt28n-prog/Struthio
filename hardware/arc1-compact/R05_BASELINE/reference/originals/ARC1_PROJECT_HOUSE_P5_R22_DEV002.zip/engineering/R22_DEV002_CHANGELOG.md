# R22 / DEV-002 change record

Date: 2026-10-12. Existing Pass 05 design and R22 tabletop architecture retained. Software scope is declared interchange intake and read-only checks. Native Efinity adapter remains OPEN pending authentic output.

## Changed existing files

| File | Change and reason |
|---|---|
| `index.html` | Load the evidence core and UI before House; retain original shell, identity and six departments |
| `house.js` | Add intake within Lab, source links in Archive, refresh DEV-002 continuation text; show every unresolved G01–G11 as OPEN |
| `house.css` | Append responsive intake/diagnostic/table styles using existing colors and components |
| `sw.js` | Bump cache identifier and cache the intake modules, schemas, templates and supporting engineering records |
| `package.json` | Include automated evidence tests in `npm test`; add `npm run test:evidence`; retain zero npm dependencies |
| `scripts/verify.mjs` | Check original hashes for immutable authorities, intake offline assets, OPEN gates and updated task evidence |
| `tasks/roadmap.json` | Record implemented interchange scope, evidence paths, OPEN native-adapter work and unresolved hardware gates |
| `engineering/R22_DEVELOPER_TASKS.json` | Keep the existing Archive mirror byte-identical to the roadmap |
| `README_FIRST.md` | Add Lab intake usage and links to the new test/change reports |

## Added files

| File | Purpose |
|---|---|
| `evidence.js` | Strict declared JSON/CSV parsing; A/B package identity, duplicate signal/ball, bank/rail, reserved-resource and claim checks; byte hashing; no inventory writes |
| `evidence-ui.js` | Local file/path intake, separated diagnostics, source comparisons, clearing and JSON export, navigation-safe async reads |
| `engineering/ARC1_EVIDENCE_SCHEMA.json` | Versioned machine-readable JSON contract |
| `engineering/ARC1_EVIDENCE_TEMPLATE.json`, `.csv` | Empty interchange templates, containing no signal assignments or vendor proof |
| `engineering/R22_EVIDENCE_INTAKE.md` | Contract, formats, provenance and validation limits, native adapter continuation |
| `engineering/R22_DEV002_SOURCE_AUDIT.md` | Exact F484 workbook/inventory/CSV audit, shared rails, dedicated and multiplexed resources |
| `tests/evidence_node.cjs` | Automated positive/negative parser and source-backed validator checks using real package definitions |
| `tests/intake_ui_node.cjs` | Actual UI handlers in a minimal DOM harness: local files, hashes, escaping, export, errors and navigation/clear races |
| `tests/offline_node.cjs` | Actual service-worker handlers in a synthetic runtime: real asset bytes, cache lifecycle, offline fallback and request filters |
| `tests/browser_smoke.py` | Optional Playwright desktop/mobile/intake/offline regression checks; not an application dependency |
| `engineering/R22_DEV002_TEST_REPORT.md` | Baseline and final verification evidence and explicit limitations |
| `engineering/R22_DEV002_NPM_TEST.log`, `R22_DEV002_BROWSER_REPORT.json` | Captured passing npm output and actual blocked browser outcome; no browser check represented as passing |
| `WORKING_SOURCE_HASHES.sha256` | Current delivery hashes; original `SOURCE_HASHES.sha256` remains the unchanged handoff manifest |

The official workbook, all 968 inventory records, clean package CSV, `CLAUDE.md`, work order and evidence policy remain byte-identical. Viewer code/styles, placeholders, icons and manifest remain unchanged. No PCB dimensions, geometry, electrical netlist, bank voltage choice, bus width, throughput result or hardware signoff was created.

## Remaining gates — all OPEN

| Gate | Required remaining work |
|---|---|
| G01 | Authentic independent A/B DDR_0 LPDDR2 ×32 1 Gbit projects, exact Alliance timings/mapping, generated pins/PLL/rails and review |
| G02 | F484 LVDS/clock legality, HDMI bridge supplies/init, EDID/HPD/audio and monitor proof |
| G03 | Useful A↔B width/clock study, timing/SI, protocol/CRC/flow control/reset isolation and throughput tests |
| G04 | F133 RGMII interoperability, pinmux/driver/fixed-link model, clocks/skew and independent SPI rescue |
| G05 | Real bitstream sizes, protected system vs game storage, golden images and independent recovery proof |
| G06 | USB host/hub/HID firmware, gamepads, ESD/5 V current protection and reconnection tests |
| G07 | Dual FPGA/DDR power budgets, regulator sequencing, cooling and measured worst-case thermal results |
| G08 | Full A/B combined pin/clock/bank plan plus Efinity/STA, CAD/ERC/DRC/SI and release review |
| G09 | Traceable prototype power-on, DDR stress, video, links, RGMII and USB acceptance results |
| G10 | License-audited decompression IP, bit-identical software vectors and measured FPGA cost/performance |
| G11 | Reproducible toolchains/IP/licenses, stable ABI/diagnostics, golden images and long-term repair instructions |

**Fabrication release remains NO-GO.** No authentic Efinity, synthesis/STA, SI/ERC/DRC, PCB or physical prototype validation occurred during DEV-002. Hash equality and passing software tests cannot close these gates.
