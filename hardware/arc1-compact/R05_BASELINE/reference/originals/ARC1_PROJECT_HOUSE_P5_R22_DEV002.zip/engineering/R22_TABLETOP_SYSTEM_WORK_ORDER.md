# ARC-1 R22 — Tabletop Architecture & Lifetime-Board Work Order
**Status:** selected architecture, physical implementation conditional. **Date:** 12 October 2026. **Owner:** R.A. Peddycoart.

## Governing objective
Design ONE complete electronics platform which remains permanently useful as firmware, GPU RTL, game-specific FPGA designs, SDKs and games improve for approximately ten years. Do not omit important physical buses or provision unpopulated critical components assuming a later revised board. Engineering prototype revisions may be necessary before the final lifetime motherboard is released.

## R22 architecture
| Subsystem | Hardware/design choice | Confidence |
|---|---|---|
| Host | Allwinner F133-B, internal 64 MB DDR2, software/game state/boot | Manufacturer documented; board untested |
| GPU | Trion T120F484I4 **A**, permanent graphics and HDMI scanout | Selected; implementation pending |
| Graphics memory A | Alliance AS4C32M32MD2A-25BIN, 1 Gbit ×32 LPDDR2 = **128 MiB** | Candidate; DDR configuration pending |
| Game-defined compute | Trion T120F484I4 **B**, one loadable game-specific FPGA hardware image at a time | Selected; implementation pending |
| Compute memory B | Same candidate 1 Gbit ×32 LPDDR2 = **128 MiB** | Candidate; DDR configuration pending |
| Total volatile memory | 64 + 128 + 128 = **320 MiB across three physically independent pools** | Arithmetic, not unified address space |
| Host link | F133 Ethernet MAC **RGMII** → T120-A compatible endpoint at 1 Gbit/s target | High-risk: MAC/PHY behavior and clocks unproven |
| Rescue channel | Independent SPI1 or equally proven independent control/debug connection | Retain physically on lifetime board |
| FPGA-to-FPGA link | Direct bidirectional high-throughput bus and control/data DMA, physical width pending | Highest-priority design study |
| Output | T120-A LVDS TX → HDMI transmitter → full-size HDMI Type A | Vendor reference exists for other T120 packages; F484 proof pending |
| Monitor modes | 1280×720@60 and 1920×1080@60 targets with EDID/fallback handling | Needs synthesizable timing, clock/bridge verification |
| Controllers | Wired off-the-shelf USB HID gamepads; 2 external USB-A sockets preferred | F133 USB2 OTG+Host documented; USB hub and drivers pending |
| System storage | Dedicated protected NOR for system firmware + golden FPGA images/rollback | Physical separation selected, capacity not locked |
| Game storage | Physically separate rewritable flash for game images, assets and B personality files | Separation selected, technology/capacity not locked |
| Debug | F133 UART and individual T120-A/B JTAG/programming/test pads | Must work when GPU user logic does not boot |
| Power | External regulated supply, input filtering, dedicated rails and separate reset domains | Rail budgets/regulators pending; no battery charger |
| Compression | Reuse validated vendor or third-party FPGA **asset decompressor** where suitable | Future programmable GPU feature, not another chip |
| Recovery | Configurable golden images and independent supervisor/watchdog | Mandatory before lifetime PCB release |

**Capacity rule:** No fixed 16 MiB game budget and no arbitrary software ceiling on free RAM. GPU A and accelerator B each dynamically allocate their own physical pool, subject to operating-system/driver ownership and protection. Data movement between A/B is through the bounded inter-FPGA protocol; there is no automatic shared-memory space.

## Architectural responsibilities
- **F133:** boot/launcher, audio policy, storage drivers, USB gamepad input, authoritative game rules, job queues and crash diagnostics.
- **T120-A:** stable graphics command ABI, hard DDR controller A, game-facing graphics services, scanout, HDMI bridge startup, display timing, optional hardware compression/decompression, and safe dispatch to B.
- **T120-B:** game-supplied FPGA image; local hard DDR controller B; may accelerate physics, geometry, procedural rendering or other game-defined tasks. B must not gain unlimited access to A's VRAM or interrupt HDMI scanout.
- **Main-memory independence:** three physically separate domains. Configuration changes of B reset its DDR controller. The platform must quiesce traffic, revoke memory leases, program B, initialize/calibrate DDR B, identify the personality, then resume work.

## Conceptual physical block arrangement (NOT a placement drawing)
```
       EXTERNAL USB GAMEPADS                          HDMI TV / MONITOR
                  |                                           ^
                USB2                                         HDMI
                  |                                           |
         +----------------+                          +----------------+
POWER -> |  F133-B + 64M | -- RGMII (+SPI rescue) --> | T120-A  (GPU)   |
         | storage + USB |                          | 128 MiB LPDDR2  |-- LVDS --> HDMI TX
         +----------------+                          +--------+-------+
                                                             ||
                                                    full-duplex FPGA bridge
                                                             ||
                                                     +-------+-------+
                                                     | T120-B         |
                                                     | game-defined   |
                                                     | 128 MiB LPDDR2 |
                                                     +---------------+
Independent recovery/supervisor and programming access to both FPGA devices.
```

## External panel study
**Rear / external connectors (functional plan, not exact ordering):** DC power input, HDMI Type A, two USB-A gamepad ports, service USB-C or debug connector as determined by genuine available host interfaces. **Front:** power/status LED, reset/recovery control only if safe, possible game/controller status. No forced built-in display, battery, touchscreen, audio speaker or Wi-Fi on the main board. HDMI audio is a target, and independent analog audio can be considered if demonstrated practical.

## Pre-PCB gates — evidence, not preferences
**P0 / STOP**
1. **Two hard DDR_0 instances:** create Efinity projects for both T120F484I4, 1 Gbit ×32 LPDDR2, chosen memory timing. Validate **separately** and together with both bank maps and both physical device footprints. Actual hardware calibration is after board fabrication.
2. **FPGA–FPGA link choice:** compare 16+16, 32+32 or other viable full-duplex GPIO/link configurations. Prefer maximum *useful* provisioned bandwidth, not maximum routed pins by appearance. Prove legal clock pins, bank voltages, DDR bit timing, routing topology, design utilization, CDC, packet/checksum and reset isolation. Publish projected vs achieved data rates distinctly.
3. **F133 RGMII:** validate F133 boot/SD/storage pinmux conflicts, Ethernet-MAC driver/fixed-link/PHY-emulation behavior, voltage and 125 MHz DDR clock/skew model. Efinix Triple Speed Ethernet MAC reference design is promising but a MAC core is **not** itself a PHY. Establish a credible interoperable electrical/protocol arrangement before copper lock. SPI recovery remains.
4. **HDMI:** reproduce IT6263N T120 evaluation-board architecture for our **F484**'s legal LVDS TX pins. Obtain bridge schematic, supplies, register initialization, HDMI DDC/EDID/HPD/ESD and stereo audio integration, and confirm availability/licensing.
5. **USB gamepads:** validate F133 USB host, whether a hub is needed, firmware and HID input; define safe 5 V current limit, ESD, and overcurrent protection.
6. **Storage/recovery:** size golden bitstreams and rescue slot(s) using actual generated T120 A/B image sizes. Select NOR/NAND/eMMC and boot pinmaps; avoid two devices contesting boot/programming nets. Validate bad B image cannot prevent A output or independent rescue.
7. **Power/thermal:** model worst-case activity of two T120 FPGAs and both DDRs simultaneously, HDMI bridge, F133 and gamepads. Size regulators, sequencing, copper heat spreaders, vents, and external DC input from estimates, then measure on prototypes. No default fan/fanless guarantee.
8. **Whole-board pin/clock allocation:** Efinity accepts BOTH chips’ pinplans with complete DDR, LVDS HDMI, link, RGMII, JTAG and configuration nets; no incompatible VCCIO sharing or unintended boot strap reuse. Produce actual paired CAD/ERC/DCR/SI reports.

**P1 / long-term software goals**
9. Stable graphics command ABI and game package manifest; hardware acceleration B may be required per title and must be correctly versioned.
10. Hardware asset decompression selection: test simple palette/RLE and existing LZ4 or format-specific RTL cores, audit license and FPGA resource usage; make it optional under capability detection until proven.
11. 320×240/640×360/1280×720 internal render targets, integer scaling, 1080p60 output targeting low video underflow, CPU-side transfer benchmark, profiler and recoverability logging.
12. Reproducible Efinity and software toolchains, archived source/constraints/IP/licenses, golden images and repair instructions for 2036.

## Manufacturer evidence and caveats
- F133 supports a USB2 host plus an OTG controller, 10/100/1000 Ethernet MAC with RGMII, SPI NOR/NAND and internal 64 MB memory: Allwinner F133 official brief: https://www.allwinnertech.com/uploads/pdf/20211016141154e7.pdf
- T120F484 provides one x16/x32 hardened DDR controller and 40 LVDS TX pairs per chip: https://www.efinixinc.com/shop/t120.php
- Alliance 1 Gbit ×32 LPDDR2: https://www.alliancememory.com/product/lpddr2-mobile-ddr2/
- Efinix T120 development-board IT6263N bridge supports HDMI output, but **its exact F484 wiring requires a separate check**: https://www.efinixinc.com/docs/trion120f576-devkit-ug-v2.3.pdf
- Triple Speed Ethernet MAC IP includes RGMII; the published T120 example is on **BGA324**, not F484: https://www.efinixinc.com/support/ip/tse-mac.php

## Release judgement
**Architecture direction: GO.** Current exact electrical schematic and physical PCB: **NO-GO.** Do not assign physical board dimensions, fabrication-ready bank voltages, line-clock targets or PSU amperage without tools and simulation. The test of this R22 design is whether its significant buses work as intended on the *first released* fixed hardware, not whether a simple diagnostic board boots.
