# ARC-1 / Pass 05 — developer handoff for Claude Code

**Architecture: R22 fixed-hardware tabletop console.** **PWA: Pass 05.** No PCB authorization. This handoff is provided so work can continue without reproducing weeks of design discussion.

## What is finished

- ARC-1-only six-department PWA (House, Viewer, Systems, Lab, Manual, Archive); standalone HTML, CSS and JS.
- Navigation, tab isolation, circle/slash placeholders and engineering-system cards.
- Manufacturer pin inventory for two *separate logical instances* of identical T120F484: 968 records, 484 per device. Zero locked ARC-1 connection nets.
- R22 concept architecture and current G01–G11 gates are documented.
- Browser note import/export, mobile-first styling, service worker and offline asset manifest.
- Pass 05 developer continuation workspace, task queue, project snapshot export, zero-dependency tests and local HTTP server.

## What is NOT finished (do not claim otherwise)

- Efinity-generated DDR_0 x32 1 Gbit controller project for either FPGA, timing/power reports, or verified Alliance chip ball map.
- Legal combined package allocation for DDR + LVDS HDMI + RGMII + SPI + A/B link + programming/JTAG and all bank voltages.
- F133 direct RGMII MAC endpoint including fixed-link configuration/driver, electrical skews, and verified throughput.
- HDMI bridge configuration, EDID/HPD/audio, monitor tests or 720p60 / 1080p60 demonstrated on this console.
- A/B high-speed link RTL and timing; two-chip flash BOM; USB HID host; rail power budgets; any board layout/thermal measurement.
- No 3D ARC-1 PCB or enclosure models. Viewer prohibition icons are deliberate.

## Repo / file map

| Path | Purpose |
|---|---|
| `index.html`, `house.css`, `viewer.css` | PWA shell / responsive layout |
| `house.js` | Six departments plus developer handoff, notes, pin explorer |
| `viewer.js` | No-model viewer component selection |
| `pins.json` | Source-derived per-device package balls; immutable until source correction |
| `engineering/T120_pinout_v1.4.xlsx` | Efinix primary physical pin authority |
| `engineering/R22_T120_PACKAGE_BALLS_UNASSIGNED.csv` | Clean per-instance A/B package-only export |
| `engineering/R22_TABLETOP_SYSTEM_WORK_ORDER.md` | R22 architecture authority |
| `engineering/R22_EFINITY_FIRST_SESSION.md` | First real desktop vendor experiment |
| `engineering/R22_EVIDENCE_POLICY.md` | Evidence/provenance conditions |
| `tasks/roadmap.json` | Tasks, owners, blockers, pass criteria |
| `sw.js`, `manifest.webmanifest` | Offline installation and cache lifecycle |
| `tests/`, `scripts/` | Automated regression checks and local server |
| `CLAUDE.md` | First file to read as coding agent |

## Prioritized next engineering tasks

1. **DEV-002 — immediate coding:** evidence intake schema and source-preserving pin/bank conflict checks, with illegal/collision test cases. Do this while awaiting Efinity reports.
2. **HW-001 — vendor desktop:** create independent `T120F484I4` projects A/B, each `DDR_0` `LPDDR2` `×32` `1 Gbit`, proposed `800 MT/s`. Export untouched reports and generated constraints.
3. **HW-002/003/004 — engineering:** prove RGMII MAC→FPGA behavior; choose useful bidirectional A/B link width and clocks; verify F484 LVDS/HDMI bridge feasibility, all **without** stepping on DDR pins.
4. **HW-005/006 — release:** two-chip storage/recovery, power/thermal, gamepad interface, all-bank review. NO board release until verified.
5. **DEV-004 — after base:** license-audited professional asset decompressor IP test harness, plus bit-identical software golden vectors.

## Handoff success criteria

An agent continuation should deliver a tested code change, a file-by-file change summary, an updated machine-readable task record, and an explicit list of still-open hardware gates. Do not mark evidence-free tasks PASS.

**Immediate command:** `npm test` from this folder.
