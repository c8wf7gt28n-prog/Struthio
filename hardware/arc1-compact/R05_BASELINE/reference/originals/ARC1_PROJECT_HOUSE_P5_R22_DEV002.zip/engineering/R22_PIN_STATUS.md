# R22 pin-source status

The PWA pin explorer now contains 968 **package ball records**, namely 484 ball definitions copied from the official Efinix T120F484 pinout for instance A and the exact same 484 definitions for instance B. Each is marked by instance.

No signal assignment has been carried forward from the previous single-accelerator proposals. All connection nets are intentionally blank. The manufacturer spreadsheet verifies ball FUNCTIONS only. This is **not** a design constraint file or electrically approved A/B bank plan.
