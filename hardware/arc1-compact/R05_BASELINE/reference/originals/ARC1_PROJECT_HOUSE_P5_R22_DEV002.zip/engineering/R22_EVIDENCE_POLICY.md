# ARC-1 R22 evidence and release policy

## Evidence stages (not interchangeable)

1. **Selected architecture:** user intent; not proof of electrical compatibility.
2. **Documented capability:** exact manufacturer document, version, package and relevant page.
3. **Proposed implementation:** net list, RTL, register model and specified acceptance test.
4. **EDA verified:** archived authentic Efinity build/project, constraints, pin/bank reports, static timing and warnings.
5. **Prototype measured:** traceable physical board/firmware revision, input conditions, scope/analyzer/test logs, passed acceptance criteria.
6. **Manufacturing released:** complete approvals for ERC, DRC, timing, power, SI, reset/recovery, BOM, thermal and interface validations.

A successful JavaScript, Node, or simulated RTL check is **not** an Efinity/PCB approval. A package ball found in a manufacturer spreadsheet is **not** a signal assigned to that ball. Raw theoretical 125 MB/s RGMII or 3.2 GB/s LPDDR2 is **not** sustained useful throughput. Two independent 128 MiB memory systems are **not** one shared 256 MiB address space.

## Who can close a gate

An engineer or verified automated pipeline attaches artifact hashes, source/revision, date, exact input parameters, build/test logs and acceptance evidence. Project House may display claims and notes but must not autocertify hardware. Agent suggestions must stay marked proposed until the real experiment is performed.

## Stop conditions

**Do not pin-lock or fabricate** if memory configuration cannot generate valid pin/PLL outputs for both T120s, if RGMII signal ownership/clocking conflicts remain, if HDMI LVDS pins aren't legal on F484, if the inter-FPGA link cannot meet timing and reset/isolation requirements, if power/current/cooling are guessed, or if golden-image independent rescue has not been designed and reviewed.

## ARC-1-only visualization

The circle/slash icon represents unavailable ARC-1 geometry. A future model requires independent ARC-1 dimensions/clearances. Drafts are explicitly labeled ROUGH DRAFT and never misrepresented as actual PCB artwork.
