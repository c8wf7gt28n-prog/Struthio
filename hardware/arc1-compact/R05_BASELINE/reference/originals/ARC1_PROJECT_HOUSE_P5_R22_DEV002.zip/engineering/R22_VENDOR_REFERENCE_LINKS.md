# ARC-1 R22 manufacturer/reference links

- F133 product brief: https://www.allwinnertech.com/uploads/pdf/20211016141154e7.pdf
- T120F484 capabilities: https://www.efinixinc.com/shop/t120.php
- T120 BGA576 IT6263 HDMI dev kit: https://www.efinixinc.com/docs/trion120f576-devkit-ug-v2.3.pdf
- T120 BGA324 Triple Speed Ethernet example: https://www.efinixinc.com/support/ed/tsemac-pattern-generator.php
- Efinix Ethernet MAC IP: https://www.efinixinc.com/support/ip/tse-mac.php
- Alliance 1Gb LPDDR2: https://www.alliancememory.com/product/lpddr2-mobile-ddr2/
- Linux IT6263 device tree upstream: https://github.com/torvalds/linux/blob/master/Documentation/devicetree/bindings/display/bridge/ite%2Cit6263.yaml

**These are vendor examples, not proof that the particular ARC-1 wiring has passed Efinity.**
